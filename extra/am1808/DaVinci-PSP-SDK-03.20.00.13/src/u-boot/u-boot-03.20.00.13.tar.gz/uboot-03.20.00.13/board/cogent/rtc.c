/* rtc not implemented yet */

int cma_rtc_not_implemented = 1;
