/*
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/
 *
 * Driver for SPI controller on DaVinci. Based on atmel_spi.c 
 * by Atmel Corporation
 * 
 * Copyright (C) 2007 Atmel Corporation
 *
 * See file CREDITS for list of people who contributed to this
 * project.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 * MA 02111-1307 USA
 */
#include <stdio.h>
#include <stdlib.h>
#include "davinci_spi.h"

#define SPI_CLOCK_FREQUENCY	150000000

static unsigned int data1_reg_val;

static void wait( Uint32 delay )
{
    volatile Uint32 i;
    for ( i = 0 ; i < delay ; i++ ){ };
}

struct spi_slave *spi_setup_slave(unsigned int bus, unsigned int cs,
			unsigned int max_hz, unsigned int mode)
{
	struct davinci_spi_slave	*ds;

	ds = (struct davinci_spi_slave	*)malloc(sizeof(struct davinci_spi_slave));
	if (!ds)
		return NULL;

	ds->slave.bus = bus;
	ds->slave.cs = cs;
	ds->regs = (void *)SPI_BASE;
	ds->freq = max_hz;

	return &ds->slave;
}

void spi_free_slave(struct spi_slave *slave)
{
	struct davinci_spi_slave *ds = to_davinci_spi(slave);

	free(ds);
}

int spi_claim_bus(struct spi_slave *slave)
{
	struct davinci_spi_slave *ds = to_davinci_spi(slave);
	unsigned int scalar;

	/* SPI0 */
    SYS_PINMUX7 &= 0x00000FFF;
    SYS_PINMUX7 |= 0x11111000;

	/* Enable the SPI hardware */
	SPI_SPIGCR0 = 0;
	wait (2000);
	SPI_SPIGCR0 = 1;

	/* Set master mode, powered up and not activated */
	SPI_SPIGCR1 = 3;

	/* CS, CLK, SIMO and SOMI are functional pins */
	SPI_SPIPC0 = (1 << 0) | (1 << 9) | (1 << 10) | (1 << 11);

	/* setup format */
	scalar = ((SPI_CLOCK_FREQUENCY / ds->freq) - 1 ) & 0xFF;

	SPI_SPIFMT0 = 8 | (scalar << 8) | (1 << 16) | (0 << 17) | (0 << 20);

	/* hold cs active at end of transfer until explicitly de-asserted */
	data1_reg_val = (1 << 28) | (slave->cs << 16);
	SPI_SPIDAT1 = data1_reg_val;

	/* including a minor delay. No science here. Should be good even with
	 * no delay
	 */
	SPI_SPIDELAY = (8 << 24) | (8 << 16);

	/* default chip select register */
	SPI_SPIDEF = 1;

	/* no interrupts */
	SPI_SPIINT = 0;
	SPI_SPILVL = 0;

	/* enable SPI */
	SPI_SPIGCR1 |= ( 1 << 24 );

	return 0;
}

void spi_release_bus(struct spi_slave *slave)
{
	struct davinci_spi_slave *ds = to_davinci_spi(slave);

	/* Disable the SPI hardware */
	SPI_SPIGCR0 = 0;
}

int spi_xfer(struct spi_slave *slave, unsigned int bitlen,
		const void *dout, void *din, unsigned long flags)
{
	struct davinci_spi_slave *ds = to_davinci_spi(slave);
	unsigned int	len;
	int		i;
	const Uint8	*txp = dout;
	Uint8		*rxp = din;

	if (bitlen == 0)
		/* Finish any previously submitted transfers */
		goto out;


	/*
	 * It's not clear how non-8-bit-aligned transfers are supposed to be
	 * represented as a stream of bytes...this is a limitation of
	 * the current SPI interface - here we terminate on receiving such a 
	 * transfer request.
	 */
	if (bitlen % 8) {
		/* Errors always terminate an ongoing transfer */
		flags |= SPI_XFER_END;
		goto out;
	}

	len = bitlen / 8;

	/* do an empty read to clear the current contents */
	SPI_SPIBUF;

	/* keep writing and reading 1 byte until done */
	for (i = 0; i < len; i++) {

		/* wait till TXFULL is asserted */
		while( SPI_SPIBUF & 0x20000000 );

		/* write the data */
		data1_reg_val &= ~0xFFFF;
		if(txp) {
			data1_reg_val |= *txp & 0xFF;
			txp++;
		}

		/* write to DAT1 is required to keep the serial transfer going */
		/* we just terminate when we reach the end */
		if((i == (len -1)) && (flags & SPI_XFER_END)) {
			SPI_SPIDAT1 = data1_reg_val & ~(1 << 28);
		} else {
			SPI_SPIDAT1 = data1_reg_val;
		}
		

		/* read the data - wait for data availability */
		while ( SPI_SPIBUF & ( 0x80000000 ) );

		if(rxp) {
			*rxp = SPI_SPIBUF & 0xFF;			
			rxp++;
		} else {
			SPI_SPIBUF;
		}

	}

	return 0;

out:
	if (flags & SPI_XFER_END) {
		SPI_SPIDAT1 = data1_reg_val & ~(1 << 28);
	}

	return 0;
}
