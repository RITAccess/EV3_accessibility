/*
 * Copyright (C) 2008 Texas Instruments, Inc <www.ti.com>
 *
 * See file CREDITS for list of people who contributed to this
 * project.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 * MA 02111-1307 USA
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "davinci_spi.h"

static Uint8 tx[512];
static Uint8 rx[512];
struct spi_slave *slave;
struct spi_flash *flash;

#define MAX_DSPUBL_SIZE	(8*1024)
#define MAX_ARMUBL_SIZE	(24*1024)

#define JTAG_ID_BASE	0x01c14018
#define CHIPREV_ID_BASE	0x01c14024
#define DA850_PART_NUM	0xb7d1
#define DA830_PART_NUM	0xb7df

#ifndef max
#define max( a, b ) ( ((a) > (b)) ? (a) : (b) )
#endif

typedef struct _SPIBOOT_HEADER_
{
	Uint32		magicNum;
	Uint32		entryPoint;	
	Uint32		appSize;
	Uint32		memAddress;
	Uint32		ldAddress;	/* Starting RAM address where image is to copied - XIP Mode */
} SPIBOOT_HeaderObj;

/*
 * Get Device Part No. from JTAG ID register
 */
static Uint16 davinci_get_part_no(void)
{
        Uint32 dev_id, part_no;

        dev_id = *(unsigned int*) JTAG_ID_BASE;

        part_no = ((dev_id >> 12) & 0xffff);

        return part_no;
}

/* ------------------------------------------------------------------------ *
 *                                                                          *
 *  main( )                                               		            *
 *      write to SPI flash and then verify the contents 					*
 *                                                                          *
 * ------------------------------------------------------------------------ */
Int32 main( )
{
	Int16 i;
	Uint8* p8;
	Uint16 page_size;
	FILE	*fPtr;
   	Int32	fileSize = 0;
	Int32   no_of_pages;  
	Int32   no_of_sectors;
	Int32	offset = -1;
	Int8	fileName[256], itype[20];
	Uint8 	idcode[3];
	Uint32	ret;
	unsigned long sector_size;
	SPIBOOT_HeaderObj header = {
		0xa1aced00,
		0xc1080000,
		0,
		0,
		0xc1080000
	};
	int write_header = 0;
	int armboot = 0;

	/* read the chip type you are on. */
	if (davinci_get_part_no() == DA850_PART_NUM ||
		davinci_get_part_no() == DA830_PART_NUM) {
		printf("DA8XX/OMAP-L1XX part detected. ");
		if (*(unsigned int*)(CHIPREV_ID_BASE) & (1 << 4)) {
			armboot = 1;
			printf("Its an ARM boot device\n"
				"\tYou require two images to boot this device\n"
				"\t1) ARM UBL in AIS file format.\n"
				"\t2) U-Boot image in raw binary format\n");
		} else {
			printf("Its a DSP  boot device\n"
				"\tYou require three images to boot\n"
				"\t1) DSP UBL in AIS file format.\n"
				"\t2) ARM UBL in raw binary format.\n"
				"\t3) U-Boot image in raw binary format\n");
		}

		printf("To generate the AIS format file, you need to run"
			" the ARM/DSP .out (COFF) file generated from"
			" CCS build through the AISGen tool.\n");
	}

	/* Initialize the SPI interface */
	slave = (struct spi_slave *)spi_setup_slave(0, 0, 25*1024*1024, 0);
	spi_claim_bus(slave);

	/* Read the ID codes */
	ret = spi_flash_cmd(slave, CMD_READ_ID, &idcode, sizeof(idcode));
	if (ret) {
		printf ( "SF: Error in reading the idcode\n");
		exit (1);
	}

	printf("SF: Got idcode %02x %02x %02x\n", idcode[0],
			idcode[1], idcode[2]);
	printf("Checking if Winbond flash writer can be used..\n");
	flash = (struct spi_flash *)spi_flash_probe_winbond (slave, idcode);
	if (!flash) {
		printf("Checking if STMicro flash writer can be used..\n");
		flash = (struct spi_flash *) spi_flash_probe_stmicro
								(slave, idcode);
	}
	if (flash == NULL) {
		printf ("No known Serial Flash writer found\n");
		exit (2);
	}

	if (strstr(flash->name, "M25P")) {
		struct stmicro_spi_flash *sf = to_stmicro_spi_flash(flash);
		page_size = sf->params->page_size;
		sector_size = sf->params->page_size *
					sf->params->pages_per_sector;
	} else if (strstr(flash->name, "W25")) {
		struct winbond_spi_flash *sf = to_winbond_spi_flash(flash);
		page_size = sf->params->page_size;
		sector_size = sf->params->page_size *
					sf->params->pages_per_sector;
	} else {
		printf("Usupported flash type: %s\n", flash->name);
		exit (2);
	}

	printf("Flash page size: %d bytes\n", page_size);
	printf("Flash sector size: %d bytes\n", sector_size);

	printf( "Starting SPIWriter.\r\n");

	if(armboot)
		printf("Enter the image type (one of \"armais\" \"uboot\" \"other\")\n");
	 else
		printf("Enter the image type (one of \"dspais\" \"armubl\" \"uboot\" \"other\")\n");
	scanf("%s", itype);
	if(!strcmp(itype, "dspais") || (armboot && !strcmp(itype, "armais")))
		offset = 0;
	else if(!armboot && !strcmp(itype, "armubl"))
		offset = max(MAX_DSPUBL_SIZE, sector_size);
	else if(!strcmp(itype, "uboot")) {
		offset = max(MAX_ARMUBL_SIZE, sector_size);
		if(!armboot)
			offset += max(MAX_DSPUBL_SIZE, sector_size);
		write_header = 1;
	}

  	// Read the file from host
	printf("Enter the File Name\n");
	scanf("%s", fileName);
	fflush(stdin);

	// Read the offset from user
	if(offset == -1) {
		printf("Enter the Offset in bytes (decimal)\n");
		scanf("%d", &offset);
		fflush(stdin);
	}

	// Open an File from the hard drive
	fPtr = fopen(fileName, "rb");
	if(fPtr == NULL)
	{
		printf("File %s Open failed\n", fileName);
		exit (2);
	}

	// Initialize the pointer
	fileSize = 0;

	// Read file size
	fseek(fPtr,0,SEEK_END);
	fileSize = ftell(fPtr);

	if(fileSize == 0)
	{
		printf("File read failed.. Closing APP\n");
		fclose (fPtr);
		exit (2);
	}

	if(write_header) {
		header.appSize = fileSize;
		fileSize += sizeof(header);
	}

	fseek(fPtr,0,SEEK_SET);

	no_of_pages = fileSize/page_size + ((fileSize % page_size) ? 1 : 0);
	no_of_sectors = (fileSize/sector_size + ((fileSize % sector_size) ? 1 : 0));

	/* Erase the Serial Flash */
	printf("Erasing flash at byte offset: %d, byte length: %d\n", (offset/sector_size)*sector_size, no_of_sectors*sector_size);
	flash->erase (flash, (offset/sector_size)*sector_size, no_of_sectors*sector_size);

    /* Write 1 page at a time */
	printf("Writing flash at page offset: %d, number of pages: %d\n", (offset/page_size), no_of_pages);
	
	i = (offset/page_size);

	if(write_header) {
		p8 = (Uint8*) tx;
		memcpy(p8, (Uint8*) &header, sizeof(header));
		p8 += sizeof(header);
	   	fread(p8, 1, page_size - sizeof(header), fPtr);
		flash->write (flash, i * page_size, page_size, ( Uint8 *)tx);
		i++;
	}

    while(!feof(fPtr))
    {
		p8 = (Uint8*) tx;
	   	if(!feof(fPtr)) {
	   		fread(p8, 1, page_size, fPtr);
		}
		flash->write (flash, i * page_size, page_size, ( Uint8 *)tx);
		i++;
    }

	fseek(fPtr,0,SEEK_SET);

	printf("Reading verifying the file.. ");
	fflush(stdout);

	i = (offset/page_size);

	if(write_header) {
	   	fread(tx, 1, page_size - sizeof(header), fPtr);
		tx[page_size - sizeof(header)] = '\0';

		flash->read (flash, i * page_size, page_size, (Uint8 *)rx);
        rx[page_size] = '\0'; 
		if(strcmp((const char *)rx + sizeof(header), (const char *)tx)!= 0)
			printf("Files did not match @ %d\n", i);
		i++;
	}

    while(!feof(fPtr))
    {
		unsigned int nbytes;

	   	if(!feof(fPtr)) {
			nbytes = fread(tx, 1, page_size, fPtr);
		}		
		tx[nbytes] = '\0';

		flash->read (flash, i * page_size, page_size, (Uint8 *)rx);
        rx[nbytes] = '\0'; 
		if(strcmp((const char *)rx,(const char *)tx)!= 0) {
			printf("Files did not match @ %d\n", ftell(fPtr));
			goto finish;
		}
		i++;
    }

	printf("Files matched \n");

finish:
	fclose(fPtr);
    return 0;
}
