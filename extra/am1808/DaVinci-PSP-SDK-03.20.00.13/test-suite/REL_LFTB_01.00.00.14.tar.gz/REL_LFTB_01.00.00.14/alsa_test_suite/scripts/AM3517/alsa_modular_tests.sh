MODULE_NAME=$1
DURATION=$2
count=$3


usage()
{

	echo "================================================================================================="
        echo "This program is to runs the modular tests."
        echo ""
        echo "Syntax: alsa_modular_tests.sh<module_name><duration><loop_count>"
        echo ""
        echo "options for module_name: snd-soc-evm.ko etc"
        echo ""
        echo "options for loop_count: 10,20,100 etc"
        echo ""
        echo "options for playback/capture duration in seconds: 10,20,30 etc"
        echo ""
        echo "Example: alsa_modular_tests.sh snd-soc-evm.ko 10 15  "

        echo "===================================================================================================="

}
if [ -z "${MODULE_NAME}" ]
then
        echo "ERROR: No MODULE_NAME specified."
        usage
        exit 1
fi
if [ -z "${DURATION}" ]
then
        echo "ERROR: No DURATION TIME specified."
        usage
        exit 1
fi
if [ -z "${count}" ]
then
        echo "ERROR: No stability loop count specified."
        usage
        exit 1
fi
echo "Executing modular tests without I/O"
x=0
while [ $x -lt $count ]
do
x=$((x+1))
date
insmod $MODULE_NAME
rmmod $MODULE_NAME
done
echo "Executing modular tests with I/O"
x=0
while [ $x -lt $count ]
do
x=$((x+1))
date
insmod $MODULE_NAME
echo ""
echo " ######## lsmod ###############"
lsmod
echo ""
echo " ####### cat /proc/modules #############"
cat /proc/modules
echo ""
echo " ####### cat /proc/ioports #############"
cat /proc/ioports
echo ""
echo " ####### cat /proc/iomem #############"
cat /proc/iomem
echo ""
echo " ####### cat /proc/interrupts #############"
cat /proc/interrupts

echo ""
echo "List of Playback Hardware devices on EVM"
echo "Command: aplay -l"
aplay -l

echo ""
echo "List of Capture Hardware devices on EVM"
echo "Command: arecord -l"
arecord -l

echo ""
echo "List of amixer contents on EVM"
echo "Command: amixer contents"
amixer contents

echo ""
echo "Executing simple loopback test with default params for 10sec duration"
echo "Connect audio input through Line-In"
echo "Audio output through Line-out"
echo "Command: arecord -f dat -d 10 -v | aplay -f dat -d 10 -v"
arecord -f dat -d 10 -v | aplay -f dat -d 10 -v

rmmod $MODULE_NAME
echo ""
echo " ######## lsmod ###############"
lsmod
echo ""
echo " ####### cat /proc/modules #############"
cat /proc/modules
echo ""
echo " ####### cat /proc/ioports #############"
cat /proc/ioports
echo ""
echo " ####### cat /proc/iomem #############"
cat /proc/iomem
echo ""
echo " ####### cat /proc/interrupts #############"
cat /proc/interrupts
done

