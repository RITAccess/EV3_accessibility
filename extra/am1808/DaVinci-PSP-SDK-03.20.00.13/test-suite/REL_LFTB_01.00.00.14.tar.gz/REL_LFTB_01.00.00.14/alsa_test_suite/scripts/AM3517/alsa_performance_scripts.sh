# alsa_performance_scripts.sh
#
#   ============================================================================
#Options that can be exercised in the testsuite
#        -?      --help
#        -v      --version       print current version of Test suite
#        -a      --ACCESS        TYPE TO PCM
#                                        0= mmap interleaved
#                                        1= mmap non interleaved
#                                        2= mmap complex
#                                        3= rw interleaved
#                                        4= rw non interleaved
#        -c      -- CHANNELS
#                                1= Mono
#                                2= Stereo
#        -d      --duration=#    interrupt after # seconds
#        -D      --device=NAME   select PCM by name
#        -F      --file=Name of file
#        -s 	 --total-size	 total-size of the audio data to
#				 capture/playback
#        -f      --format=#      SAMPLE FORMAT
#                                        0= signed 8 bit
#                                        1= unsigned 8 bit
#                                        2= signed 16 bit LE
#                                        3= signed 16 bit BE
#                                        4= unsigned 16 bit LE
#                                        5= signed 16 bit BE
#                                        6= signed 24 bit LE
#                                        7= signed 24 bit BE
#                                        8= unsigned 24 bit LE
#                                        9= signed 24 bit BE
#                                        10= signed 32 bit LE
#                                        11= signed 32 bit BE
#                                        12= unsigned 32 bit LE
#                                        13= signed 32 bit BE
#        -N      --nonblock      Non Blocking Mode
#        -p      --period-size=# Distance between interrupts is # frames
#        -r      --rate=#        Sampling Rate
#        -P      --playback=#    Playback
#                                       0= Playback from buffer (sine wave)
#                                        1= Playback from file
#        -R       --record=#      Record
#                                        0= Capture to a buffer
#                                        1= Capture to a file
#        -t      --throughput      Enable the throughput measurement
#        -l      --CPULoad         Enable the CPULoad measurement
#        -T      --testcaseid      Test case id string for testers reference/logging purpose
#
#
#
# Default values
#DEFAULT_SND_CARD		"hw:0,0"
#DEFAULT_BUFFER_SIZE  		2048
#DEFAULT_PERIOD_SIZE  		64
#DEFAULT_SAMPING_RATE		44100
#DEFAULT_PLAYBACK_DURATION	10
#DEFAULT_CAPTURE_DURATION	10
SND_DEVICE=$1
ACCESS_MODE=$2
FILE_SIZE=$3
PERIOD_SIZE=$4
FILE_OR_BUFFER=$5
usage()
{
        echo "=============================================================================================="
        echo "This program is to calculate the performance numbers for audio (ALSA)."
        echo ""
        echo "Syntax: alsa_performance_scripts.sh<sound_device><access_mode><file_size><period_size><file_or_buffer>"
        echo ""
        echo "options for sound devices: "hw:0,0", "hw:0,1" "
        echo ""
	echo "options for access_mode : "MMAP" "RW" "
        echo ""
	echo "options for file_size = # bytes "
	echo " 			PLAYBACK/CAPTURE file size is #bytes"
       	echo ""
	echo "options for period_size = # "
	echo "			distance between interrupts is # frames"
       	echo ""
 	echo "options for file_or_buffer: 0 or 1 "
	echo " 			pass 0 to play/capture to  file and pass 1 to play/capture to internal buffer" 
        echo ""
        echo "Example:  alsa_performance_scripts.sh hw:0,0 RW 10240000 1024 0"
        echo "================================================================================================"

}
if [ -z "${SND_DEVICE}" ]
then
        echo "ERROR: No SOUND DEVICE specified."
        usage
        exit 1
fi
if [ -z "${ACCESS_MODE}" ]
then
        echo "ERROR: No ACCESS MODE specified."
        usage
        exit 1
fi
if [ -z "${FILE_SIZE}" ]
then
        echo "ERROR: No FILE_SIZE specified."
        usage
        exit 1
fi
if [ -z "${PERIOD_SIZE}" ]
then
        echo "ERROR: No PERIOD SIZE specified."
        usage
        exit 1
fi
if [ "${ACCESS_MODE}" == "MMAP" ]
then
MODE=0
elif [ "${ACCESS_MODE}" == "RW" ]
then
MODE=3
fi
MOUNT_DIR=/mnt/audio_perf_test
mkdir -p $MOUNT_DIR
# Performance Audio Read to File Tests
./alsa_tests -a $MODE -R $FILE_OR_BUFFER  -D $SND_DEVICE -F $MOUNT_DIR/perf_8kHZ.wav -r 8000 -p $PERIOD_SIZE -s $FILE_SIZE -t -l -T ALSA_CAPTURE_8000
./alsa_tests -a $MODE -R $FILE_OR_BUFFER  -D $SND_DEVICE -F $MOUNT_DIR/perf_32kHZ.wav -r 32000 -p $PERIOD_SIZE -s $FILE_SIZE -t -l -T ALSA_CAPTURE_32000
./alsa_tests -a $MODE -R $FILE_OR_BUFFER  -D $SND_DEVICE -F $MOUNT_DIR/perf_44.1kHZ.wav -r 44100 -p $PERIOD_SIZE -s $FILE_SIZE -t -l -T ALSA_CAPTURE_44100
./alsa_tests -a $MODE -R $FILE_OR_BUFFER  -D $SND_DEVICE -F $MOUNT_DIR/perf_48kHZ.wav -r 48000 -p $PERIOD_SIZE -s $FILE_SIZE -t -l -T ALSA_CAPTURE_48000
# Performance Audio Write from File Tests
./alsa_tests -a $MODE -P $FILE_OR_BUFFER  -D $SND_DEVICE -F $MOUNT_DIR/perf_8kHZ.wav -r 8000 -p $PERIOD_SIZE -s $FILE_SIZE -t -l -T ALSA_PLAYBACK_8000
./alsa_tests -a $MODE -P $FILE_OR_BUFFER  -D $SND_DEVICE -F $MOUNT_DIR/perf_32kHZ.wav -r 32000 -p $PERIOD_SIZE -s $FILE_SIZE -t -l -T ALSA_PLAYBACK_32000
./alsa_tests -a $MODE -P $FILE_OR_BUFFER  -D $SND_DEVICE -F $MOUNT_DIR/perf_44.1kHZ.wav -r 44100 -p $PERIOD_SIZE -s $FILE_SIZE -t -l -T ALSA_PLAYBACK_44100
./alsa_tests -a $MODE -P $FILE_OR_BUFFER  -D $SND_DEVICE -F $MOUNT_DIR/perf_48kHZ.wav -r 48000 -p $PERIOD_SIZE -s $FILE_SIZE -t -l -T ALSA_PLAYBACK_48000
if [  ${FILE_OR_BUFFER} == 1 ]
then
	rm $MOUNT_DIR/*.wav
fi
rm -rf $MOUNT_DIR
