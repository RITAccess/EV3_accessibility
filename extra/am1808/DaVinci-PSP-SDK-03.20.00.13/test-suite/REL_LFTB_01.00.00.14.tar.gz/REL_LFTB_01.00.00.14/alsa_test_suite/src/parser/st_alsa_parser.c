/*
 * st_alsa_parser.c 
 *
 * This file is parser for alsa test suite
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/ 
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/        

#include "st_alsa_common.h"


/* Test case options structure */
extern tcDevParams testoptions_capture;
extern tcDevParams testoptions_playback;

/* Declare global variables here */
static int quit 		= FALSE;
static int playback 	= FALSE;
static int record 	= FALSE;

/* Function parses the command line options */
static void st_alsa_parse_test_options(int argc, char **argv);

/* Function to print the test suite help */
static void st_alsa_test_suite_help(void);

/* Function to print the test params */
void st_alsa_print_test_params(tcDevParams *test_opt);

/****************************************************************************
 * Function             	- Main function
 * Functionality       	- This is where the execution begins
 * Input Params      	- argc,argv
 * Return Value         	- None
 * Note                 		- None
 ****************************************************************************/

int main(int argc , char *argv[])
{

	/*Initializing capture default options*/
	st_alsa_init_capture_test_params();

	/*Initializing playback default options*/
	st_alsa_init_playback_test_params();

	/*Processing the command line options*/
	st_alsa_parse_test_options(argc, argv); 

	/* Initialize Timer module */
   	 initTimerModule();
	if (quit == FALSE) {
		if (playback == TRUE) {
			st_alsa_print_test_params(&testoptions_playback);
			if ( testoptions_playback.play_from_file == TRUE)
				st_audio_file_playback(&testoptions_playback);
			else 
				st_audio_playback(&testoptions_playback);
			return 0;
		}
		if (record == TRUE) {
			st_alsa_print_test_params(&testoptions_capture);
			if ( testoptions_capture.capture_to_file == TRUE)
				st_audio_file_capture (&testoptions_capture);
			else				
				st_audio_capture(&testoptions_capture);
				
			return 0;
		}
		else {
			st_audio_loopback ();
			return 0; 
		}
	} 

	return 0;
}

/****************************************************************************
 * Function             - st_alsa_parse_test_options
 * Functionality        - This function parses the command line options and values passed for the options
 * Input Params         -  argc,argv
 * Return Value         -  None
 * Note                 -  None
 ****************************************************************************/

static void st_alsa_parse_test_options(int argc, char **argv)
{

	for (;;) {
		int option_index = 0;

		static struct option long_options[] = { 
			{"access",		optional_argument,	NULL,	'a'},
			{"channels",	optional_argument,	NULL,	'c'},	
			{"device",  	optional_argument,	NULL,	'D'},
			{"format",  	optional_argument,	NULL,	'f'},
			{"file",  		optional_argument,	NULL,	'F'},
			{"period-size",	optional_argument,	NULL,	'p'},
			{"total-size",	optional_argument,	NULL,	's'},	
			{"rate",		optional_argument,	NULL,	'r'},
			{"playback",    optional_argument,  NULL,   'P'},
			{"record",      optional_argument,  NULL,   'R'},
			{"testcaseid",  optional_argument,  NULL,   'T'}, 
			{"nonblock",	no_argument,	    NULL,	'N'},
			{"throughput",	no_argument,	    NULL,   't'},
			{"cpuload",	    no_argument,	    NULL,   'l'},
			{"help",	    no_argument,	    NULL,   '?'},
			{"version",	    no_argument,	    NULL,   'v'},
			{NULL, 		    0,      	 	    NULL,     0}
		};
		int c = 0; 
		c = getopt_long(argc, argv,"a:c:d:D:f:F:p:s:r:P:R:T::v?Ntl", long_options, &option_index ) ; 
		if (c == -1)
		{ 
			break;
		}

		switch(c) {

			case 'a':

				if (NULL != optarg) {
					testoptions_capture.access_type= atoi(optarg);
					testoptions_playback.access_type= atoi(optarg);

				}else if (optind < argc && argv[optind]){
					testoptions_capture.access_type= atoi(argv[optind]);
					testoptions_playback.access_type= atoi(optarg);
				}
				break;

			case 'c': 

				if (NULL != optarg) {
					testoptions_capture.channel= atoi(optarg);
					testoptions_playback.channel= atoi(optarg);

				}else if (optind < argc && argv[optind]){
					testoptions_capture.channel= atoi(argv[optind]);
					testoptions_playback.channel= atoi(argv[optind]);
				}      
				break;

			case 'D': 

				if (NULL != optarg) {
					testoptions_capture.card_name= optarg;
					testoptions_playback.card_name= optarg;

				}else if (optind < argc && argv[optind]){
					testoptions_capture.card_name= argv[optind];
					testoptions_playback.card_name= argv[optind];
				}      
				break;


			case 'f': 

				if (NULL != optarg) {
					testoptions_capture.format= atoi(optarg);
					testoptions_playback.format= atoi(optarg);

				}else if (optind < argc && argv[optind]){
					testoptions_capture.format= atoi(argv[optind]);
					testoptions_playback.format= atoi(argv[optind]);
				}
				break;

			case 'F': 

				if (NULL != optarg) {
					testoptions_capture.file_name= optarg;
					testoptions_playback.file_name= optarg;

				}else if (optind < argc && argv[optind]){
					testoptions_capture.file_name= argv[optind];
					testoptions_playback.file_name= argv[optind];
				}    
				break;



			case 'N': 

				if (NULL != optarg) {
					testoptions_capture.io_opmode= NON_BLOCKING;
					testoptions_playback.io_opmode= NON_BLOCKING;

				}else if (optind < argc && argv[optind]){
					testoptions_capture.io_opmode= NON_BLOCKING;
					testoptions_playback.io_opmode= NON_BLOCKING;

				}      
				break;	

			case 'p': 

				if (NULL != optarg) {
					testoptions_capture.period_size= atoi(optarg);
					testoptions_playback.period_size= atoi(optarg);

				}else if (optind < argc && argv[optind]){
					testoptions_capture.period_size= atoi(argv[optind]);
					testoptions_playback.period_size= atoi(argv[optind]);

				}      
				break;
		
			case 's': 

				if (NULL != optarg) {
					testoptions_capture.total_size= atoi(optarg);
					testoptions_playback.total_size= atoi(optarg);

				}else if (optind < argc && argv[optind]){
					testoptions_capture.total_size= atoi(argv[optind]);
					testoptions_playback.total_size= atoi(argv[optind]);

				}      
				break;
			

			case 'r': 
				if (NULL != optarg) {
					testoptions_capture.sampling_rate= atoi(optarg);
					testoptions_playback.sampling_rate= atoi(optarg);

				}else if (optind < argc && argv[optind]){
					testoptions_capture.sampling_rate= atoi(argv[optind]);
					testoptions_playback.sampling_rate= atoi(argv[optind]);
				}      
				break;	


			
			case 'v':
				quit = TRUE; 
				printf("TestSuite V %s\n", VERSION_STRING);
				break;

			case '?':
				st_alsa_test_suite_help();
				quit = TRUE;
				break;

			case 'P': 
				playback = TRUE; 
				if (NULL != optarg) {
					testoptions_playback.play_from_file= atoi(optarg);

				}else if (optind < argc && argv[optind]) {
					testoptions_playback.play_from_file= atoi(argv[optind]);
				}      
				break;

			case 'R': 
				record = TRUE; 
				if (NULL != optarg) {
					testoptions_capture.capture_to_file= atoi(optarg);

				}else if (optind < argc && argv[optind]) {
					testoptions_capture.capture_to_file= atoi(argv[optind]);
				}   
				break; 
			case 't':
				testoptions_playback.throughput= TRUE;
				testoptions_capture.throughput= TRUE;
				break;

			case 'l':
				testoptions_playback.cpuload= TRUE;
				testoptions_capture.cpuload= TRUE;
				break;

			case 'T': 

				if (NULL != optarg) {
					testoptions_capture.testcaseid= optarg;
					testoptions_playback.testcaseid= optarg;

				}else if (optind < argc && argv[optind]){
					testoptions_capture.testcaseid= argv[optind];
					testoptions_playback.testcaseid= argv[optind];
				}    
				break;

		}

	}

}

/****************************************************************************
 * Function             - st_alsa_print_test_params
 * Functionality        - This function prints the test params
 * Input Params         -  test_opt
 * Return Value         -  None
 * Note                 -  None
 ****************************************************************************/

void st_alsa_print_test_params(tcDevParams *test_opt)
{
	int num_bits = 0;
	switch(test_opt->format)
    {
   
                case PCM_FORMAT_S8:
                    num_bits = 8;
                break;
                case PCM_FORMAT_S16_LE:
                    num_bits = 16;
                break;
                case PCM_FORMAT_S24_LE:
                    num_bits = 24;
                break;
                case PCM_FORMAT_S32_LE:
                    num_bits = 32;
                break;
                default:
                break;
    }
	if (test_opt->stream == CAPTURE){
		DBG_PRINT_TST_START((test_opt->testcaseid));
		DBG_PRINT_TRC0(("CAPTURE Test is going to start with following values "));
		DBG_PRINT_TRC0(("Card name 		|%s", test_opt->card_name));		
		DBG_PRINT_TRC0(("Device Number 	|%d",test_opt->device));
		DBG_PRINT_TRC0(("Access Type 	|%d",test_opt->access_type));
		DBG_PRINT_TRC0(("Period Size requested	 	|%d",test_opt->period_size));
		DBG_PRINT_TRC0(("Sampling Rate 	|%d",test_opt->sampling_rate));	
		DBG_PRINT_TRC0(("Channels    	|%d",test_opt->channel));
		DBG_PRINT_TRC0(("number of bits per channlel	|%d",num_bits));
		if ( test_opt->capture_to_file== TRUE) {
			DBG_PRINT_TRC0(("File name 		|%s", test_opt->file_name));
		}
		DBG_PRINT_TRC0(("Total Size 	|%d",test_opt->total_size));

	}	

	else if (test_opt->stream == PLAYBACK) {
		DBG_PRINT_TST_START((test_opt->testcaseid));
		DBG_PRINT_TRC0(("PLAYBACK Test is going to start with following values "));
		DBG_PRINT_TRC0(("Card name 		|%s", test_opt->card_name));
		DBG_PRINT_TRC0(("Device Number 	|%d",test_opt->device));
		DBG_PRINT_TRC0(("Access Type 	|%d",test_opt->access_type));
		DBG_PRINT_TRC0(("Period Size requested 		|%d",test_opt->period_size));
		DBG_PRINT_TRC0(("Sampling Rate 	|%d",test_opt->sampling_rate));	
		DBG_PRINT_TRC0(("Channels    	|%d",test_opt->channel));
		DBG_PRINT_TRC0(("number of bits per channlel	|%d",num_bits));
		if ( test_opt->play_from_file == TRUE) {
			DBG_PRINT_TRC0(("File name 		|%s", test_opt->file_name));
		}
		DBG_PRINT_TRC0(("Total Size 	|%d",test_opt->total_size));
	}
}

/****************************************************************************
 * Function             - st_alsa_test_suite_help
 * Functionality        - This function prints the usage help for the test suite
 * Input Params         -  None
 * Return Value         -  None
 * Note                 -  None
 ****************************************************************************/

static void st_alsa_test_suite_help(void)
{
	printf("\nAdvanced Linux Sound Architecture(ALSA) TestSuite V %s\n", VERSION_STRING);
	printf("Usage: ../alsa_tests [options].....\n");
	printf("-?    --help    	help\n");
	printf("-v    --version 	print current version of Test suite\n");
	printf("-a    --access=# 	ACCESS TYPE TO PCM, \n");
	printf("\t  	0= mmap interleaved\n");
	printf("\t  	1= mmap non interleaved\n");
	printf("\t  	2= mmap complex\n");
	printf("\t  	3= rw interleaved\n");
	printf("\t  	4= rw non interleaved\n");
	printf("-c    --channels=# 	CHANNELS\n");
	printf("\t  	1= Mono\n");
	printf("\t  	2= Stereo\n");
	printf("-D    --device=NAME	select PCM by name\n");
	printf("-F    --file=Name	Name of file  \n");
	printf("-s    --total-size=#	Total size of the auido data to capture/playback  \n");
	printf("-f    --format=#  	SAMPLE FORMAT\n");	
	printf("\t   	0= signed 8 bit\n");
	printf("\t   	1= unsigned 8 bit\n");
	printf("\t   	2= signed 16 bit LE\n");
	printf("\t   	3= signed 16 bit BE\n");
	printf("\t   	4= unsigned 16 bit LE\n");
	printf("\t   	5= signed 16 bit BE\n");
	printf("\t   	6= signed 24 bit LE\n");
	printf("\t   	7= signed 24 bit BE\n");
	printf("\t   	8= unsigned 24 bit LE\n");
	printf("\t   	9= unsigned 24 bit BE\n");
	printf("\t  	10= signed 32 bit LE\n");
	printf("\t  	11= signed 32 bit BE\n");
	printf("\t  	12= unsigned 32 bit LE\n");
	printf("\t  	13= unsigned 32 bit BE\n");
	printf("-N    --nonblock	Non Blocking Mode\n");
	printf("-p    --period-size=#Distance between interrupts is # frames\n");
	printf("-r    --rate=# 		Sampling Rate\n");
	printf("-P    --playback=#	Playback\n");
	printf("\t		0= Playback from buffer (sine wave)\n");
	printf("\t		1= Playback from file\n");
	printf("-R    --record=#	Record\n");
	printf("\t		0= Capture to a buffer\n");
	printf("\t		1= Capture to a file\n");
	printf("-t    --throughput	Enable the throughput measurement\n");
	printf("-l    --cpuload		Enable the CPULoad measurement\n");
	printf("-T    --testcaseid=caseid	Test case id string for testers reference/logging purpose\n");

}

