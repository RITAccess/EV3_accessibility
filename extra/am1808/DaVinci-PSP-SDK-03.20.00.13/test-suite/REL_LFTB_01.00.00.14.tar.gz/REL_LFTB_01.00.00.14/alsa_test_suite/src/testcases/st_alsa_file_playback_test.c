/*
 * st_alsa_file_playback_test.c 
 *
 * This file plays audio data  from the  file
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/ 
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/


#include "st_alsa_common.h"

/***************************************************************************
 * Function             - st_audio_file_playback
 * Functionality        - Function to configure the PCM device and perfrom Playback from file.
 * Input Params         - Device name,stream,mode.
 * Return Value         - Success = 0
 * Note                 - None
 ****************************************************************************/

int st_audio_file_playback ( tcDevParams *pcmParam)

{

    long loops;
    int rc = SUCCESS;
    int size;
    char *buffer= NULL; 
    int fd_audio = 0;
	unsigned int total_size = 0;
	ST_TIMER_ID start_time;
    unsigned long elapsed_usecs = 0;
    double elapsed_secs       = 0;
    ST_CPU_STATUS_ID cpu_status_id;
    float percentage_cpu_load = 0;

    /*Open and Configure the PCM*/
    size = st_audio_open_config_hw_interface(pcmParam);
    if (size == FAILURE) {
        DBG_PRINT_ERR(("Unable to open pcm device"));
		DBG_PRINT_TST_RESULT_FAIL((pcmParam->testcaseid));
		return FAILURE;
    }


    /*Allocating memory to store the data from audio input*/
	buffer = (char*)st_allocate_buffer(size);
	if (NULL == buffer)
    {
    	st_perror("buffer");
		DBG_PRINT_ERR(("Unable to allocatea"));
		DBG_PRINT_TST_RESULT_FAIL((pcmParam->testcaseid));
		rc = FAILURE;
		goto close_audio_intfc;
    }

    /*Number of times to loop */
   	total_size = pcmParam->total_size;
	loops = total_size/size;
     
    fd_audio = st_open((const char *)(pcmParam->file_name),O_RDONLY);	
	if(-1 == fd_audio)
    {
    	DBG_PRINT_ERR(("file open failed "));
        DBG_PRINT_TST_RESULT_FAIL((pcmParam->testcaseid));
		rc = FAILURE;
		goto free_mem;
   	}

	if (pcmParam->cpuload == TRUE)
		/* Start CPU Load calcaulation */ 
		startCpuLoadMeasurement (&cpu_status_id);
	if (pcmParam->throughput == TRUE)
		/* Start the Timer */
		startTimer(&start_time); 

    while (loops > 0){
        loops--;
		rc = st_read(fd_audio,buffer,size);
		if(size != rc)
        {
        	DBG_PRINT_ERR(("file read failed "));
            DBG_PRINT_TST_RESULT_FAIL((pcmParam->testcaseid));
			rc = FAILURE;
			goto close_file;
        }
        rc = st_audio_write(buffer, pcmParam->access_type);
        if (rc == RUN_ERROR) {
            DBG_PRINT_ERR(("Underrun Error"));  
                rc = st_audio_playback_prepare();
				if (rc < 0) {
					DBG_PRINT_ERR(("xrun: prepare error"));
					DBG_PRINT_TST_RESULT_FAIL((pcmParam->testcaseid));
					rc = FAILURE;
					goto drain;
				}
        }
    }

	if (pcmParam->throughput == TRUE) {
		/* Stop the Timer and get the usecs elapsed */
	    elapsed_usecs = stopTimer (&start_time);
		elapsed_secs = (double) elapsed_usecs / 1000000u;
	}

	if (pcmParam->cpuload == TRUE)
		/* Get CPU Load figures */ 
    	percentage_cpu_load = stopCpuLoadMeasurement (&cpu_status_id);

	if (pcmParam->throughput == TRUE) {
		DBG_PRINT_TRC0(("write: Duration in Sec | %lf", elapsed_secs));
		DBG_PRINT_TRC0(("write: No. of bits/Sec | %.0lf", ((double)(total_size * 8) / elapsed_secs)));
	}
	if (pcmParam->cpuload == TRUE) {
		if((percentage_cpu_load >= 0) && (percentage_cpu_load <= 100)) {
			DBG_PRINT_TRC0(("write: percentage cpu load | %.2f%%", percentage_cpu_load));
		}
	}	
	
drain:
    st_audio_playback_drain();
close_file:
	rc = st_close(fd_audio);
	if(-1 == rc)
	{
		DBG_PRINT_ERR(("file close failed "));
		rc = FAILURE;
	}
free_mem:
	if (NULL != buffer)
	{
		st_free_buffer(buffer);
	}
close_audio_intfc:
	st_audio_playback_close();

	if (rc != FAILURE) {
		DBG_PRINT_TST_RESULT_PASS((pcmParam->testcaseid));
		DBG_PRINT_TST_END((pcmParam->testcaseid));
	}
	
 	 return rc;

}



/* vim: set ts=4 sw=4 tw=80 et:*/
