/*
 * st_alsa_loopback.c 
 *
 * This file loopbacks the audio data
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/ 
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/        


#include "st_alsa_common.h"


static char *buffer= NULL;
static char *testcaseid = "Capture & Playback";

static void st_playback(void);
static void st_record(void);
static void st_audio_capture_multitask(tcDevParams *pcmParam);
static void st_audio_playback_multitask(tcDevParams *pcmParam);

/***************************************************************************
 * Function             - st_audio_loopback 
 * Functionality        - Function to configure the PCM device and perfrom Capture and Playback.
 * Input Params         - None
 * Return Value         - Success = 0
 * Note                 - None
 ****************************************************************************/

int st_audio_loopback (void)
{
    st_pthread_t playback_ID;
    st_pthread_t record_ID;
    int result=FAILURE;

    DBG_PRINT_TST_START((testcaseid));

    /*Thread Handling*/	
    result = st_pcm_pthread_create(&record_ID, (void*)st_record);
    if (result != SUCCESS) {
        DBG_PRINT_ERR(("%d..Creating Thread for Record",result)); 
    }
    result = st_pcm_pthread_create(&playback_ID,(void*)st_playback);
    if (result != SUCCESS) {
        DBG_PRINT_ERR((" %d..Creating Thread for Playback",result));
    }
    st_pcm_pthread_join(record_ID);
    st_pcm_pthread_join(playback_ID);

    /* print status of the test case */
    if (FAILURE == result) {
        DBG_PRINT_TST_RESULT_FAIL((testcaseid));
    } else if (SUCCESS == result) {
        DBG_PRINT_TST_RESULT_PASS((testcaseid));
    }

    DBG_PRINT_TST_END((testcaseid));	
    return 0;

}
/***************************************************************************
 * Function             - st_playback
 * Functionality        - Function to Playback the audio data.
 * Input Params         - None
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/

static void st_playback(void)
{
    ST_SLEEP(1);
    st_audio_playback_multitask ( &testoptions_playback);
}

/***************************************************************************
 * Function             - st_record
 * Functionality        - Function to record the audio data.
 * Input Params         - None
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/

static void st_record(void)
{
    st_audio_capture_multitask ( &testoptions_capture);
}

/***************************************************************************
 * Function             - st_audio_capture_multitask
 * Functionality        - Function to record the audio data.
 * Input Params         - ALSA params
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/

static void st_audio_capture_multitask(tcDevParams *pcmParam)
{

    int rc;
    int size;
    long loops;
	unsigned int total_size = 0;

    /*Open and Configure the PCM*/
    size = st_audio_open_config_hw_interface(pcmParam);
	if (size == FAILURE) {
		DBG_PRINT_ERR(("Unable to open pcm device"));
	   	DBG_PRINT_TST_RESULT_FAIL((testcaseid));
		rc = FAILURE;
	   	st_pcm_pthread_exit(NULL);
   	}


    /*Allocating memory to store the data from audio input*/
    buffer = (char*)st_allocate_buffer(size);
  	if (NULL == buffer)
	{
		st_perror("buffer");
		DBG_PRINT_TST_RESULT_FAIL((testcaseid));
		rc = FAILURE;
		goto close_audio_intfc;
	}
     /*Number of times to loop */
   	total_size = pcmParam->total_size;
	loops = total_size/size;

    while (loops > 0){
        loops--; 	
        rc = st_audio_read(buffer, pcmParam->access_type);
        if (rc == RUN_ERROR) {
            DBG_PRINT_ERR(("Overrun Error"));  
            rc = st_audio_capture_prepare();
			if (rc < 0) {
					DBG_PRINT_ERR(("rrun: prepare error"));
					DBG_PRINT_TST_RESULT_FAIL((testcaseid));
					rc = FAILURE;
					goto free_mem;

			}
        }
    }

	st_audio_capture_drain();
	
free_mem:
	if (NULL != buffer)
	{
		st_free_buffer(buffer);
	}
close_audio_intfc:
	st_audio_capture_close();


}

/***************************************************************************
 * Function             - st_audio_playback_multitask
 * Functionality        - Function to playback the audio data.
 * Input Params         - ALSA params
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/

static void st_audio_playback_multitask(tcDevParams *pcmParam)
{
    int rc;
    long loops = 0;
    int size =0 ;
	unsigned int total_size = 0;

    /*Open and Configure the PCM*/
    size = st_audio_open_config_hw_interface(pcmParam);
	if (size == FAILURE) {
		DBG_PRINT_ERR(("Unable to open pcm device"));
	   	DBG_PRINT_TST_RESULT_FAIL((testcaseid));
		rc = FAILURE;
	  	st_pcm_pthread_exit(NULL);
   	}


    /*Allocating memory to store the data from audio input*/
    buffer = (char*)st_allocate_buffer(size);
	if (NULL == buffer)
	{
		st_perror("buffer");
		DBG_PRINT_TST_RESULT_FAIL((testcaseid));
		rc = FAILURE;
		goto close_audio_intfc;
	}
     /*Number of times to loop */
   	total_size = pcmParam->total_size;
	loops = total_size/size;

    while (loops > 0){
        loops--;
        rc = st_audio_write(buffer, pcmParam->access_type);
        if (rc == RUN_ERROR) {
            DBG_PRINT_ERR(("Underrun Error"));  
            st_audio_playback_prepare();
			if (rc < 0) {
					DBG_PRINT_ERR(("xrun: prepare error"));
					DBG_PRINT_TST_RESULT_FAIL((testcaseid));
					rc = FAILURE;
					goto free_mem;

			}

			
        }
    }
	st_audio_playback_drain();
	
free_mem:
	if (NULL != buffer)
	{
		st_free_buffer(buffer);
	}
close_audio_intfc:
	st_audio_playback_close();


}


/* vim: set ts=4 sw=4 tw=80 et:*/

