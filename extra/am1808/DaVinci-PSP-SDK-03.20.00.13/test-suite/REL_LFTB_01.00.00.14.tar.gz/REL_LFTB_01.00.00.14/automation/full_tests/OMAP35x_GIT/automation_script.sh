TEST_LEVEL=$1
usage()
{
        echo "================================================================================================="
        echo "This program is to run Functional and performance tests automatically except video,ethernet and audio"
        echo ""
        echo "Syntax: automation_script.sh<TEST_LEVEL>"
	echo ""
        echo "options for TEST_LEVEL: sanity,full"

        echo "===================================================================================================="
}
if [ -z "${TEST_LEVEL}" ]
then
        echo "ERROR: No test level specified."
        usage
        exit 1
fi

if [ "${TEST_LEVEL}" == "full" ]
then
file_size_functional=250
fi
if [ "${TEST_LEVEL}" == "sanity" ]
then
file_size_functional=1
fi

echo ""
echo "############### USB /dev/sda1 ################################"
echo "The script assumes the USB device is partitioned into two partitions with each 1GB size"
echo "The script also assumes mkfs is available on the nfs "
echo "Please take care to partition the second partition as logical drive"
echo "If possible connect the other EVM as USB slave so as to complete the whole USB testing in one shot"
echo ""
echo "Executing USB functional tests with the following params"
echo "Filesystem on partition 1 - VFAT"
echo "Filesystem on partition 2 - EXT2"
echo "mkfs_availability - available"
echo "File size - $file_size_functionalMB"
echo "No of files on each partition - 3"
echo ""
echo "Executing functional tests with vfat on primary partition and ext2 on logical partion"
./filesystem_functional_tests.sh  /dev/sda1 vfat /dev/sda5 ext2 mkfs_avail $file_size_functional 3 1 USB

if [ "${TEST_LEVEL}" == "full" ]
then
echo "Executing USB functional tests with the following params"
echo "Filesystem on partition 1 - EXT2"
echo "Filesystem on partition 2 - VFAT"
echo "mkfs_availability - available"
echo "File size - $file_size_functionalMB"
echo "No of files on each partition - 3"
echo ""
echo "Executing functional tests with ext2 on primary partition and vfat on logical partion"
./filesystem_functional_tests.sh  /dev/sda1 ext2 /dev/sda5 vfat mkfs_avail $file_size_functional 3 1 USB

echo "Executing USB functional tests with the following params"
echo "Filesystem on partition 1 - EXT2"
echo "Filesystem on partition 2 - EXT3"
echo "mkfs_availability - available"
echo "File size - $file_size_functionalMB"
echo "No of files on each partition - 3"
echo ""
echo "Executing functional tests with ext2 on primary partition and ext3 on logical partion"
./filesystem_functional_tests.sh  /dev/sda1 ext2 /dev/sda5 ext3 mkfs_avail $file_size_functional 3 1 USB

echo ""
echo "Executing USB performance tests for VFAT with the following params"
echo "Filesystem on partition  - VFAT"
echo "mount sync mode - async"
echo "mkfs_availability - available"
echo "File size - 100MB"
./filesystem_performance_tests.sh vfat /dev/sda1 async mkfs_avail 100
echo ""
echo "Executing USB performance tests for EXT2 with the following params"
echo "Filesystem on partition  - EXT2"
echo "mount sync mode - async"
echo "mkfs_availability - available"
echo "File size - 100MB"
./filesystem_performance_tests.sh ext2 /dev/sda1 async mkfs_avail 100
echo ""
echo "Executing USB performance tests for EXT3 with the following params"
echo "Filesystem on partition  - EXT3"
echo "mount sync mode - async"
echo "mkfs_availability - available"
echo "File size - 100MB"
./filesystem_performance_tests.sh ext3 /dev/sda1 async mkfs_avail 100
fi
echo ""
echo "############### USB /dev/sdb1 ################################"
echo "The script assumes the USB device is partitioned into two partitions with each 1GB size"
echo "The script also assumes mkfs is available on the nfs "
echo "Please take care to partition the second partition as logical drive"
echo "If possible connect the other EVM as USB slave so as to complete the whole USB testing in one shot"
echo ""
echo "Executing USB functional tests with the following params"
echo "Filesystem on partition 1 - VFAT"
echo "Filesystem on partition 2 - EXT2"
echo "mkfs_availability - available"
echo "File size - $file_size_functionalMB"
echo "No of files on each partition - 3"
echo ""
echo "Executing functional tests with vfat on primary partition and ext2 on logical partion"
./filesystem_functional_tests.sh  /dev/sdb1 vfat /dev/sdb5 ext2 mkfs_avail $file_size_functional 3 1 USB

if [ "${TEST_LEVEL}" == "full" ]
then
echo "Executing USB functional tests with the following params"
echo "Filesystem on partition 1 - EXT2"
echo "Filesystem on partition 2 - VFAT"
echo "mkfs_availability - available"
echo "File size - $file_size_functionalMB"
echo "No of files on each partition - 3"
echo ""
echo "Executing functional tests with ext2 on primary partition and vfat on logical partion"
./filesystem_functional_tests.sh  /dev/sdb1 ext2 /dev/sdb5 vfat mkfs_avail $file_size_functional 3 1 USB

echo "Executing USB functional tests with the following params"
echo "Filesystem on partition 1 - EXT2"
echo "Filesystem on partition 2 - EXT3"
echo "mkfs_availability - available"
echo "File size - $file_size_functionalMB"
echo "No of files on each partition - 3"
echo ""
echo "Executing functional tests with ext2 on primary partition and ext3 on logical partion"
./filesystem_functional_tests.sh  /dev/sdb1 ext2 /dev/sdb5 ext3 mkfs_avail $file_size_functional 3 1 USB

echo ""
echo "Executing USB performance tests for VFAT with the following params"
echo "Filesystem on partition  - VFAT"
echo "mount sync mode - async"
echo "mkfs_availability - available"
echo "File size - 100MB"
./filesystem_performance_tests.sh vfat /dev/sdb1 async mkfs_avail 100
echo ""
echo "Executing USB performance tests for EXT2 with the following params"
echo "Filesystem on partition  - EXT2"
echo "mount sync mode - async"
echo "mkfs_availability - available"
echo "File size - 100MB"
./filesystem_performance_tests.sh ext2 /dev/sdb1 async mkfs_avail 100
echo ""
echo "Executing USB performance tests for EXT3 with the following params"
echo "Filesystem on partition  - EXT3"
echo "mount sync mode - async"
echo "mkfs_availability - available"
echo "File size - 100MB"
./filesystem_performance_tests.sh ext3 /dev/sdb1 async mkfs_avail 100
fi
echo ""
echo "############### MMC/SD ################################"
echo "The script assumes the MMC device is partitioned into two partitions with each 1GB size"
echo "The script also mkfs is available on the nfs "
echo "Please take care to partition the second partition as logical drive"
echo ""
echo "Executing MMC/SD functional tests with the following params"
echo "Filesystem on partition 1 - VFAT"
echo "Filesystem on partition 2 - EXT2"
echo "mkfs_availability - available"
echo "File size - $file_size_functionalMB"
echo "No of files on each partition - 3"
echo ""
echo "Executing functional tests with vfat on primary partition and ext2 on logical partion"
./filesystem_functional_tests.sh  /dev/mmcblk0p1 vfat /dev/mmcblk0p5 ext2 mkfs_avail $file_size_functional 3 1 MMC

if [ "${TEST_LEVEL}" == "full" ]
then
echo ""
echo "Executing functional tests with ext2 on primary partition and vfat on logical partion"
./filesystem_functional_tests.sh  /dev/mmcblk0p1 ext2 /dev/mmcblk0p5 vfat mkfs_avail $file_size_functional 3 1 MMC

echo ""
echo "Executing functional tests with ext2 on primary partition and ext3 on logical partion"
./filesystem_functional_tests.sh  /dev/mmcblk0p1 ext2 /dev/mmcblk0p5 ext3 mkfs_avail $file_size_functional 3 1 MMC

echo ""
echo "Executing MMC/SD performance tests for VFAT with the following params"
echo "Filesystem on partition  - VFAT"
echo "mount sync mode - async"
echo "mkfs_availability - available"
echo "File size - 100MB"
./filesystem_performance_tests.sh vfat /dev/mmcblk0p1 async mkfs_avail 100
echo ""
echo "Executing MMC/SD performance tests for EXT2 with the following params"
echo "Filesystem on partition  - EXT2"
echo "mount sync mode - async"
echo "mkfs_availability - available"
echo "File size - 100MB"
./filesystem_performance_tests.sh ext2 /dev/mmcblk0p1 async mkfs_avail 100
echo ""
echo "Executing MMC/SD performance tests for EXT3 with the following params"
echo "Filesystem on partition  - EXT3"
echo "mount sync mode - async"
echo "mkfs_availability - available"
echo "File size - 100MB"
./filesystem_performance_tests.sh ext3 /dev/mmcblk0p1 async mkfs_avail 100
fi
partition_number=4
erase_size=131072
file_size_performance=100
if [ "${TEST_LEVEL}" == "full" ]
then
size_of_partition=126353408
max_file_size_in_MB=115
fi
if [ "${TEST_LEVEL}" == "sanity" ]
then
size_of_partition=10485100
max_file_size_in_MB=10
fi

echo ""
echo "############### NAND ################################"
echo "Please verify the partition size and erase size are correct or not"
echo "The script also mkfs for ext2 is available on the nfs "
echo ""
echo "Executing NAND functional tests with the following params"
echo "Partition number  - $partition_number"
echo "total_size_of_the_partion_in_decimal_bytes - $size_of_partition"
echo "erase_size_in_decimal_bytes - $erase_size"
echo "mkfs_availability - available"
echo "Max_file_size_in_MB - $max_file_size_in_MB"
./flash_functional_script.sh $partition_number $size_of_partition $erase_size $max_file_size_in_MB
if [ "${TEST_LEVEL}" == "full" ]
then

echo ""
echo "Executing NAND performance tests for JFFS2 with the following params"
echo "Filesystem on partition  - JFFS2"
echo "mount sync mode - async"
echo "mkfs_availability - unavailable"
echo "File size - 100MB"
flash_eraseall -j /dev/mtd$partition_number
./filesystem_performance_tests.sh jffs2 /dev/mtdblock$partition_number async mkfs_unavail $file_size_performance
echo ""
echo "Executing NAND performance tests for VFAT with the following params"
echo "Filesystem on partition  - VFAT"
echo "mount sync mode - async"
echo "mkfs_availability - available"
echo "File size - 100MB"
./filesystem_performance_tests.sh vfat /dev/mtdblock$partition_number async mkfs_avail $file_size_performance
echo ""
echo "Executing NAND performance tests for EXT2 with the following params"
echo "Filesystem on partition  - EXT2"
echo "mount sync mode - async"
echo "mkfs_availability - available"
echo "File size - 100MB"
./filesystem_performance_tests.sh ext2 /dev/mtdblock$partition_number async mkfs_avail $file_size_performance
fi

echo ""
echo "################# AUDIO ############################"
echo "Executing alsa functional tests using alsa utils"
./alsa_test.sh
if [ "${TEST_LEVEL}" == "full" ]
then
echo ""
echo "Executing alsa performance tests for various sample rates with the following params"
echo "sound device - hw:0,0"
echo "access_mode - RW"
echo "file_or_buffer - buffer"
echo "period_size - 1024"
#./alsa_performance_scripts.sh hw:0,0 RW 10240000 1024 0
fi

