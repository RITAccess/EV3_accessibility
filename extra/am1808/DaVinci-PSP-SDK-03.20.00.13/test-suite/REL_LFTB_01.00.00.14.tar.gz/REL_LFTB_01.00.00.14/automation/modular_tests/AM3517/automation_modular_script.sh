file_size=$1
LOOP_COUNT=$2
usage()
{
        echo "================================================================================================="
        echo "This program is to run modular tests automatically "
        echo ""
        echo "Syntax: automation_script.sh<File_size><LOOP_COUNT>"
        echo ""
        echo "options for file size: 5,10, 100 etc"
        echo ""
        echo "options for LOOP_COUNT: 10, 15 etc"
        echo "===================================================================================================="
}
if [ -z "${file_size}" ]
then
        echo "ERROR: No file_size specified."
        usage
        exit 1
fi
if [ -z "${LOOP_COUNT}" ]
then
        echo "ERROR: No LOOP_COUNT specified."
        usage
        exit 1
fi


echo ""
echo "############### MMC ################################"
echo ""
module_name="omap_hsmmc.ko"
./filesystem_modular_tests.sh $module_name $LOOP_COUNT /dev/mmcblk0p1 vfat /dev/mmcblk0p5 ext2 $file_size 3 MMC mkfs_avail

echo ""
echo "############### USB OTG HOST ################################"
echo ""
./filesystem_modular_tests.sh musb_hdrc.ko $LOOP_COUNT /dev/sda1 vfat /dev/sda5 ext2 $file_size 3 USB mkfs_avail


echo ""
echo "############### USB EHCI ################################"
echo ""
./filesystem_modular_tests.sh ehci-hcd.ko $LOOP_COUNT /dev/sda1 vfat /dev/sda5 ext2 $file_size 3 USB mkfs_avail


