file_size=$1
LOOP_COUNT=$2
usage()
{
        echo "================================================================================================="
        echo "This program is to run modular tests automatically "
        echo ""
        echo "Syntax: automation_script.sh<File_size><LOOP_COUNT>"
        echo ""
        echo "options for file size: 5,10, 100 etc"
        echo ""
        echo "options for LOOP_COUNT: 10, 15 etc"
        echo "===================================================================================================="
}
if [ -z "${file_size}" ]
then
        echo "ERROR: No file_size specified."
        usage
        exit 1
fi
if [ -z "${LOOP_COUNT}" ]
then
        echo "ERROR: No LOOP_COUNT specified."
        usage
        exit 1
fi


echo ""
echo "############### MMC ################################"
echo ""
module_name="davinci_mmc.ko"
./filesystem_modular_tests.sh $module_name $LOOP_COUNT /dev/mmcblk0p1 vfat /dev/mmcblk0p5 ext2 $file_size 3 MMC mkfs_avail

echo ""
echo "############### USB OTG HOST ################################"
echo ""
./filesystem_modular_tests.sh musb_hdrc.ko $LOOP_COUNT /dev/sda1 vfat /dev/sda5 ext2 $file_size 3 USB mkfs_avail

echo ""
echo "############### USB OHCI ################################"
echo ""
./filesystem_modular_tests.sh ohci-hcd.ko $LOOP_COUNT /dev/sda1 vfat /dev/sda5 ext2 $file_size 3 USB mkfs_avail



file_size=5
partition_number=4
echo ""
echo "############### NAND ################################"
echo ""
./flash_modular_tests.sh davinci_nand.ko $LOOP_COUNT $partition_number $file_size


partition_number=2
echo ""
echo "############### NOR ################################"
echo ""
./flash_modular_tests.sh physmap.ko $LOOP_COUNT $partition_number $file_size


partition_number=2
echo ""
echo "############### SPI ################################"
echo ""
./flash_modular_tests.sh davinci_spi_master.ko $LOOP_COUNT $partition_number $file_size

echo ""
echo "############### SATA ####################################"
echo ""
./filesystem_modular_tests.sh ahci.ko $LOOP_COUNT /dev/sda1 vfat /dev/sda5 ext2 $file_size 3 USB mkfs_avail



echo ""
echo "############### Audio ################################"
echo ""
./alsa_modular_tests.sh snd-soc-evm.ko 10 15 OMAPL138

echo ""
echo "############### WDT ################################"
echo ""
./wdt_modular_tests.sh  davinci_wdt.ko 10
