ipaddr=$1
file=$2
usage()
{
        echo "================================================================================================="
        echo "This program is to run system tests on Freon"
        echo ""
        echo "Syntax: system_test.sh<ipaddr><file>"
        echo ""
        echo "options for ipaddr: ipaddr of the host machine on which tftp server is running"
        echo ""
        echo "options for file: file name of size 100mb which is available in the tftp directory"
        echo "The script assumes the set-up as follows"
        echo " Configure the kernel for Audio,Video,USB MSC,USB ISO Video,USB ISO Audio,USB HID,Ethernet"
        echo "RTC,NAND,NOR,SPI,MMC,SATA"
        echo "Audio :           Connect the EVM Line-in to Line-out of a PC with media player running"
        echo "                  Connect the EVM Line-out to Speakers or Headphone"
        echo "Video V4L2:       Connect DVD Player to EVM S-Video or Composite"
        echo "                  Connect TV through EVM S-Video or Composite"
        echo "USB ISO Video:    Connect UVC class USB Webcam to both the hosts through HUB"
        echo "USB ISO Audio:    Connect two USB Headphones with Mic to both USB Hosts throgh Hub"
        echo "Ethernet:         Connect the EVM to PC with tftp server running in which tftp server root directory"
        echo "                  contatins the file. Pass the file name and ipaddress of the PC as arguments to the script"
        echo "MMC/SD:           Connect the MMC/SD card with one partition of size greater than 100 MB"
        echo "USB:              Connect the USB devices of partition size greater than 100 MB to both the hosts through HUBs"
        echo "SATA:             Connect the SATA hard disk of partition size greater than 100 MB to SATA"
        echo "===================================================================================================="
}
if [ -z "${ipaddr}" ]
then
        echo "ERROR: No ipaddress  specified."
        usage
        exit 1
fi
if [ -z "${file}" ]
then
        echo "ERROR: No file name specified."
        usage
        exit 1
fi

#Audio
while true&
do
date >> audio.txt
arecord -f dat -d 10 2>> audio.txt | aplay -f dat -d 10 2>> audio.txt
done&
#V4L2 Loopback
./v4l2_capture_tests >> v4l2_loopback.txt&
#FBDeV Display
./fbdev_display_tests >> fbdev_display.txt&
#USB ISO Video
./saMmapLoopback -u 1 >> iso_video.txt&
#USB ISO Audio
while true&
do
date >> audio.txt
arecord -f dat -D hw:1,0 -d 10 2>> iso_audio.txt | aplay -f dat -D hw:1,0 -d 10 2>> iso_audio.txt
done&
#RTC
hwclock -w 2>> rtc.txt
while true&
do
echo "display the system date" >> rtc.txt 	
date >> rtc.txt
echo "display the system date" >> rtc.txt 	
hwclock >> rtc.txt
done&
#ethernet
while true&
do
date >> ethernet.txt
echo "tftp the file $file from $ipaddr" >> ethernet.txt 	
tftp -g -r $file $ipaddr >> ethernet.txt
done&
cwd=$PWD
#MMC/SD
umount /media/* 2>>  mmc.txt
mkfs.vfat /dev/mmcblk0p1 >> mmc.txt
mkdir -p /mnt/mmc
mount -t vfat /dev/mmcblk0p1 /mnt/mmc
echo "listing the mounted partitions" >> mmc.txt
mount >> mmc.txt
cd /mnt/mmc
while true&
do
date >> $cwd/mmc.txt
dd if=/dev/zero of=100mb.txt bs=1M count=100 2>> $cwd/mmc.txt
echo "Verify whether the file 100mb.txt with size 100mb is created or not" >> $cwd/mmc.txt
ls -lart
rm 100mb.txt 2>> $cwd/mmc.txt
done&
cd -
#Storage device sda1 (May be USB MSC 2.0 or 1.1 or SATA)
umount /media/* 2>>  sda1.tx
mkfs.vfat /dev/sda1 >> sda1.txt
mkdir -p /mnt/sda1
mount -t vfat /dev/sda1 /mnt/sda1
echo "listing the mounted partitions" >> sda1.txt
mount >> sda1.txt
cd /mnt/sda1
while true&
do
date >> $cwd/sda1.txt
dd if=/dev/zero of=100mb.txt bs=1M count=100 2>> $cwd/sda1.txt
echo "Verify whether the file 100mb.txt with size 100mb is created or not" >> $cwd/sda1.txt
ls -lart
rm 100mb.txt 2>> $cwd/sda1.txt
done&
cd -
#Storage device sdb1 (May be USB MSC 2.0 or 1.1 or SATA)
umount /media/*  2>> sdb1.txt
mkfs.vfat /dev/sdb1 >> sdb1.txt
mkdir -p /mnt/sdb1
mount -t vfat /dev/sdb1 /mnt/sdb1
echo "listing the mounted partitions" >> sdb1.txt
mount >> sdb1.txt
cd /mnt/sdb1
while true&
do
date >> $cwd/sdb1.txt
echo "Verify whether the file 100mb.txt with size 100mb is created or not" >> $cwd/sdb1.txt
ls -lart
dd if=/dev/zero of=100mb.txt bs=1M count=100 2>> $cwd/sdb1.txt
rm 100mb.txt 2>> $cwd/sdb1.txt
done&
cd -
#Storage device sdc1 (May be USB MSC 2.0 or 1.1 or SATA)
umount /media/*  2>> sdc1.txt
mkfs.vfat /dev/sdc1 >> sdc1.txt
mkdir -p /mnt/sdc1
mount -t vfat /dev/sdc1 /mnt/sdc1
echo "listing the mounted partitions" >> sdc1.txt
mount >> sdc1.txt
cd /mnt/sdc1
while true&
do
date >> $cwd/sdc1.txt
echo "Verify whether the file 100mb.txt with size 100mb is created or not" >> $cwd/sdc1.txt
ls -lart
dd if=/dev/zero of=100mb.txt bs=1M count=100 2>> $cwd/sdc1.txt
rm 100mb.txt 2>> $cwd/sdc1.txt
done&
cd -
#NAND
flash_eraseall /dev/mtd7 >> nand.txt
mkdir -p /mnt/nand
mount -t jffs2 /dev/mtdblock7 /mnt/nand >> nand.txt
cd /mnt/nand
while true&
do
date >> $cwd/nand.txt
dd if=/dev/zero of=1mb.txt bs=1M count=1 2>> $cwd/nand.txt
echo "Verify whether the file 1mb.txt with size 1mb is created or not" >> $cwd/nand.txt
ls -lart
rm 1mb.txt 2>> $cwd/nand.txt
done&
cd -
#NOR
flash_eraseall /dev/mtd2 >> nor.txt
mkdir -p /mnt/nor
mount -t jffs2 /dev/mtdblock2 /mnt/nor >> nor.txt
cd /mnt/nor
while true&
do
date >> $cwd/nor.txt
echo "Verify whether the file 1mb.txt with size 1mb is created or not" >> $cwd/nor.txt
ls -lart
dd if=/dev/zero of=1mb.txt bs=1M count=1 2>> $cwd/nor.txt
rm 1mb.txt 2>> $cwd/nor.txt
done&
cd -
#SPI
flash_eraseall /dev/mtd10 >> spi.txt
mkdir -p /mnt/spi
mount -t jffs2 /dev/mtdblock10 /mnt/spi >> spi.txt
cd /mnt/spi
while true&
do
date >> $cwd/spi.txt
echo "Verify whether the file 1mb.txt with size 1mb is created or not" >> $cwd/spi.txt
ls -lart
dd if=/dev/zero of=1mb.txt bs=1M count=1 2>> $cwd/spi.txt
rm 1mb.txt 2>> $cwd/spi.txt
done&
cd -
#USB 2.0 HID
./evtest /dev/input/event0
./evtest /dev/input/event1
#USB 1.0 HID
./evtest /dev/input/event2
./evtest /dev/input/event3






