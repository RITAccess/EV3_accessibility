#  edma_functional_tests.sh
#
#   ============================================================================
#Params that can be passed to the kernel module
#
#performance -	Enables the performance measurement. 
#		By default performance=0, Ignore this for functional test
#acnt -		EDMA ACNT
#bnct -		EDMA BCNT
#ccnt - 	EDMA CCNT
#numTCs -	Number of Transfer controllers on the platform
#qdma -	 	Pass qdma=1 to test QDMA channels
#chain - 	Pass chain=1 to test EDMA chaining mechanism
#link - 		Pass link=1 to test EDMA linking mechanism	  
#
# Default values
# 
# performance=0
# acnt=512
# bcnt=8
# ccnt=8
# numTCs=2
# qdma=0
# chain=0
# link=0
#
#
ACNT=$1
BCNT=$2
CCNT=$3
NUMTCS=$4
PRODUCT=$5
usage()
{
        echo "=============================================================================================="
        echo "This program is to run functional tests on EDMA."
        echo ""
        echo "Syntax: edma_functional_script.sh<acnt><bcnt><ccnt><numTCs><PRODUCT>"
        echo ""
        echo "options for acnt,bcnt,ccnt: Pass any value"
        echo ""
        echo "options for numTCs: 2 , 4 etc"
        echo "Please check the data sheet for number of Transfer controllers"
        echo ""
        echo "options for product: Pass the LSP pacakage "
	echo "				Possible values are LSP-2.00, LSP-2.10, LSP-2.20, LSP-3.20"		
        echo ""
        echo "Example: edma_functional_script.sh 1024 16 16 2 LSP-2.20 to run functional tests"
	echo "for acount = 1024 , bcount = 16, ccount = 16 on EDMA with 2 transfer controllers on LSP-2.20"
        echo "================================================================================================"

}
if [ -z "${ACNT}" ]
then
        echo "ERROR: No ACNT type specified."
        usage
        exit 1
fi
if [ -z "${BCNT}" ]
then
        echo "ERROR: No BCNT specified."
        usage
        exit 1
fi
if [ -z "${CCNT}" ]
then
        echo "ERROR: No CCNT specified."
        usage
        exit 1
fi
if [ -z "${NUMTCS}" ]
then
        echo "ERROR: No number of transfer controllers specified."
        usage
        exit 1
fi
if [ -z "${PRODUCT}" ]
then
        echo "ERROR: No LSP Package specified."
        usage
        exit 1
fi

insmod kStTimer.ko
#Runs the functional test for EDMA channels
insmod edma_test.ko acnt=$ACNT bcnt=$BCNT ccnt=$CCNT numTCs=$NUMTCS
rmmod edma_test.ko
#Runs the functional test on EDMA channels for ASYNC MODE only
insmod edma_test.ko async=1 acnt=$ACNT bcnt=$BCNT ccnt=$CCNT numTCs=$NUMTCS 
rmmod edma_test.ko
#Runs the functional test on EDMA channels for ABSYNC MODE only
insmod edma_test.ko absync=1 acnt=$ACNT bcnt=$BCNT ccnt=$CCNT numTCs=$NUMTCS
rmmod edma_test.ko
if  [ "${PRODUCT}" != "LSP-3.20" ] 
then
#Runs the functional test for QDMA channels
insmod edma_test.ko qdma=1 acnt=$ACNT bcnt=$BCNT ccnt=$CCNT numTCs=$NUMTCS
rmmod edma_test.ko
fi
#Runs the functional test for EDMA linking mechanism
insmod edma_test.ko link=1 acnt=$ACNT bcnt=$BCNT ccnt=$CCNT numTCs=$NUMTCS
rmmod edma_test.ko
#Runs the functional test for EDMA chaining mechanism
insmod edma_test.ko chain=1 acnt=$ACNT bcnt=$BCNT ccnt=$CCNT numTCs=$NUMTCS
rmmod edma_test.ko
rmmod kStTimer.ko
