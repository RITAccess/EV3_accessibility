/*
 * kSt_edma_interface.c
 *
 * This file demonstrates the simple edma mem to mem copy
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation version 2.
 *
 * This program is distributed <93>as is<94> WITHOUT ANY WARRANTY of any
 * kind, whether express or implied; without even the implied warranty
 * of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */


/*Testcode related header files */
#include "kSt_edma.h"


/****************************************************************************
 * Function            		- kSt_davinci_request_dma
 * Functionality      		- This function acts as an interface for the channel request API
 * Input Params   	 	- dev_id, dev_name, callback, data, lch, tcc, eventq_no
 * Return Value        	 -0 - Succes, -1 - Failure
 * Note                 		-  None
 ****************************************************************************/


int kSt_davinci_request_dma(int dev_id, const char *dev_name,
			void (*callback)(int lch, u16 ch_status, void *data),
			void *data, int *lch, int *tcc,enum dma_event_q eventq_no)
{

	int result;

	result = davinci_request_dma(dev_id, dev_name, callback, data, lch, tcc, eventq_no);
	if (0 != result) 
		return FAILURE;
	return SUCCESS;

}

/****************************************************************************
 * Function            		- kSt_davinci_set_dma_src_params
 * Functionality      		- This function acts as an interface for the set src parms API
 * Input Params   	 	- lch, src_port, mode, width
 * Return Value        	 -0 - Succes, -1 - Failure
 * Note                 		-  None
 ****************************************************************************/

int kSt_davinci_set_dma_src_params(int lch, u32 src_port,
			       enum address_mode mode, enum fifo_width width)
{

	int result = 0;

	result = davinci_set_dma_src_params(lch, src_port, mode, width);

	if ( FAILURE == result)
		return FAILURE;
	return SUCCESS;

}

/****************************************************************************
 * Function            		- kSt_davinci_set_dma_dest_params
 * Functionality      		- This function acts as an interface for the set dest parms API
 * Input Params   	 	- lch, dest_port, mode, width
 * Return Value        	 -0 - Succes, -1 - Failure
 * Note                 		-  None
 ****************************************************************************/

int kSt_davinci_set_dma_dest_params(int lch, u32 dest_port,
				enum address_mode mode, enum fifo_width width) 
{
	int result = 0;
	result = davinci_set_dma_dest_params(lch, dest_port, mode, width);

	if ( FAILURE == result)
		return FAILURE;
	return SUCCESS;

}

/****************************************************************************
 * Function            		- kSt_davinci_set_dma_src_index
 * Functionality      		- This function acts as an interface for the set src index API
 * Input Params   	 	- lch, src_bidx, src_cidx
 * Return Value        	 -0 - Succes, -1 - Failure
 * Note                 		-  None
 ****************************************************************************/


int kSt_davinci_set_dma_src_index(int lch, u16 src_bidx, u16 src_cidx)
{

	int result = 0;
	result = davinci_set_dma_src_index(lch, src_bidx, src_cidx);
	if ( FAILURE == result)
		return FAILURE;
	return SUCCESS;

}

/****************************************************************************
 * Function            		- kSt_davinci_set_dma_dest_index
 * Functionality      		- This function acts as an interface for the set dest index API
 * Input Params   	 	- lch, dest_bidx, dest_cidx
 * Return Value        	 -0 - Succes, -1 - Failure
 * Note                 		-  None
 ****************************************************************************/

int kSt_davinci_set_dma_dest_index(int lch, u16 dest_bidx, u16 dest_cidx)
{

	int result = 0;
	result = davinci_set_dma_dest_index(lch, dest_bidx, dest_cidx);
	if ( FAILURE == result)
		return FAILURE;
	return SUCCESS;


}

/****************************************************************************
 * Function            		- kSt_davinci_set_dma_transfer_params
 * Functionality      		- This function acts as an interface for the set dma transfer params API
 * Input Params   	 	- lch, acnt, bcnt, ccnt, bcntrld, sync_mode
 * Return Value        	 -0 - Succes, -1 - Failure
 * Note                 		-  None
 ****************************************************************************/

int kSt_davinci_set_dma_transfer_params(int lch, u16 acnt, u16 bcnt, u16 ccnt,
				    u16 bcntrld, enum sync_dimension sync_mode)
{
	int result = 0;
	result = davinci_set_dma_transfer_params(lch, acnt, bcnt, ccnt, bcntrld, sync_mode);
	
	if ( FAILURE == result)
		return FAILURE;
	return SUCCESS;

}

/****************************************************************************
 * Function            		- kSt_davinci_get_dma_params
 * Functionality      		- This function acts as an interface for the get dma  params API
 * Input Params   	 	- lch, param_set
 * Return Value        	 -0 - Succes, -1 - Failure
 * Note                 		-  None
 ****************************************************************************/


int kSt_davinci_get_dma_params(int lch, st_edma_param_set *param_set)
{
	int result = 0;
	result = davinci_get_dma_params(lch, param_set);
	if ( FAILURE == result)
		return FAILURE;
	return SUCCESS;

}

/****************************************************************************
 * Function            		- kSt_davinci_set_dma_params
 * Functionality      		- This function acts as an interface for the set dma  params API
 * Input Params   	 	- lch, param_set
 * Return Value        	 -0 - Succes, -1 - Failure
 * Note                 		-  None
 ****************************************************************************/

int kSt_davinci_set_dma_params(int lch, st_edma_param_set *param_set)
{
	int result = 0;	
	result = davinci_set_dma_params(lch, param_set);
	if ( FAILURE == result)
		return FAILURE;
	return SUCCESS;
}

/****************************************************************************
 * Function            		- kSt_davinci_start_dma
 * Functionality      		- This function acts as an interface for the start dma API
 * Input Params   	 	- lch
 * Return Value        	 -Return value from start dma API
 * Note                 		-  None
 ****************************************************************************/

int kSt_davinci_start_dma(int lch)
{
	return davinci_start_dma(lch);

}

/****************************************************************************
 * Function            		- kSt_davinci_stop_dma
 * Functionality      		- This function acts as an interface for the stop dma API
 * Input Params   	 	- lch
 * Return Value        	 -Return value from stop dma API
 * Note                 		-  None
 ****************************************************************************/

int kSt_davinci_stop_dma(int lch)
{
	return davinci_stop_dma(lch);
}

/****************************************************************************
 * Function            		- kSt_davinci_free_dma
 * Functionality      		- This function acts as an interface for the free dma API
 * Input Params   	 	- lch
 * Return Value        	 -Return value from free dma API
 * Note                 		-  None
 ****************************************************************************/

int kSt_davinci_free_dma(int lch)
{
	return davinci_free_dma(lch);
}

/****************************************************************************
 * Function            		- kSt_davinci_dma_link_lch
 * Functionality      		- This function acts as an interface for the link dma API
 * Input Params   	 	- lch_head, lch_queue
 * Return Value        	 -Return value from link dma API
 * Note                 		-  None
 ****************************************************************************/

int kSt_davinci_dma_link_lch(int lch_head, int lch_queue)
{
	return davinci_dma_link_lch(lch_head, lch_queue);
}




