# fbdev_test_script

#   ============================================================================

#Options that can be exercised in the testsuite 
#
# -n       --devicename      Device name on which display test is to be run
# -w       --width           Width of the image to be displayed
# -h       --height          Height of the image to be displayed
# -m       --mode            The video mode 
# -f       --noofframes      Number of frames to be displayed
# -F       --Filename        Name of the image file to display
# -p       --pixel_format    Pixel formats
# -c	   --stability_count Number of times to run stability test
# -t       --testname        Name of the special test
# -T       --testcaseid      Test case id string for testers reference/logging purpose
# -?       --help            Displays the help/usage
# -v       --version         Version of Display Test suite

# Default values with which the driver is initialized
# DEFAULT_NODE "/dev/fb0"
# DEFAULT_WIDTH 320
# DEFAULT_HEIGHT 240
# DEFAULT_MODE "INTERLACED"
# DEFAULT_INTERFACE "LCD"
# DEFAULT_RESOLUTION  "VGA"
# DEFAULT_BPP 16
# DEFAULT_ZOOM_X 0
# DEFAULT_ZOOM_Y 0
# DEFAULT_WINDOW_NAME "/dev/fb0"
# DEFAULT_NO_OF_FRAMES 500
# ST_OSD_NUM_BUFS1 1



#Prints the usage/help
./fbdev_display_tests --help

#Prints the version
./fbdev_display_tests -v

#Runs the default color bar display-No options provided- Runs by default on LCD
./fbdev_display_tests 

#Runs the default color bar display- for VGA -width  and -height provided
./fbdev_display_tests -w 640 -h 480 -T FBDEV_VGA_STANDARD_RESOLUTION_TEST 

#Runs the default color bar display- -width  and -height provided
./fbdev_display_tests -w 320 -h 240 -T FBDEV_QVGA_STANDARD_RESOLUTION_TEST 
./fbdev_display_tests -w 160 -h 120 -T FBDEV_QQVGA_STANDARD_RESOLUTION_TEST 

./fbdev_display_tests -w 300 -h 200 -T FBDEV_NON_STANDARD_RESOLUTION_TEST 
#Runs the default color bar display- -mode set to progressive
./fbdev_display_tests -m PROGRESSIVE -T FBDEV_MODE_PROGRESSIVE
./fbdev_display_tests -m INTERLACED -T FBDEV_MODE_INTERLACED 



#Runs the default color bar display- - Variation in the number of frames 
./fbdev_display_tests -f 50 -T FBDEV_TEST_50_FRAMES 
./fbdev_display_tests -f 100 -T FBDEV_TEST_100_FRAMES 
./fbdev_display_tests -f 200 -T FBDEV_TEST_200_FRAMES 
./fbdev_display_tests -f 250 -T FBDEV_TEST_250_FRAMES 
./fbdev_display_tests -f 300 -T FBDEV_TEST_300_FRAMES 
./fbdev_display_tests -f 700 -T FBDEV_TEST_700_FRAMES 
./fbdev_display_tests -f 1000 -T FBDEV_TEST_1000_FRAMES 

#Runs the default color bar display- -Horizontal or verical format
./fbdev_display_tests -p H_PATTERN  -T FBDEV_TEST_PIXEL_FORMAT_H_PATTERN 
./fbdev_display_tests -p V_PATTERN   -T FBDEV_TEST_PIXEL_FORMAT_V_PATTERN

#Runs the default color bar display- - p pixel format
#./fbdev_display_tests -F in.yuv -T FBDEV_TEST_DISPLAYING_IN.YUV_FILE

#Runs the API tests
./fbdev_display_tests -t api -T FBDEV_TEST_ALL_API_TESTS 

#Runs the API tests
./fbdev_display_tests -t ioctl -T FBDEV_TEST_ALL_IOCTL_TESTS 

#Runs the GLCD display test
./fbdev_display_tests -t square -T FBDEV_TEST_GLCD_SQUARE_PATTERN_TESTS 

#Runs the GLCD display test
./fbdev_display_tests -t chessboard -T FBDEV_TEST_GLCD_SQUARE_PATTERN_TESTS 

#Runs the GLCD display test
./fbdev_display_tests -t image -T FBDEV_TEST_GLCD_SQUARE_PATTERN_TESTS 

