
#   dm644x_sample_usage_sample_script


#Prints the usage/help
./fbdev_display_tests --help

#Prints the version
./fbdev_display_tests -v

#Runs the default color bar display-No options provided- Runs by default on TV out over composite interface
./fbdev_display_tests -T Displaytests_Default 

#Run the display test- Displays default color bar with width (-w) 720, height (-h) 480, number of buffers queued is (-c) 3 and number of iterations (-n) 1000
./fbdev_display_tests -w 720 -h 480 -s NTSC -i COMPOSITE -T Displaytests  

#Run the display test- Displays default color bar with width (-w) 720, height (-h) 480(long options support)
./fbdev_display_tests --width 720 --height 480 -T Displaytests

#Run the zoom test-Display color bar default values and zoom_x(-x)1 and zoom_y(-y)1 
./fbdev_display_tests -x 1 -y 1 -T Zoomtests

#Run the zoom test-Display color bar default values and repos_x(-X)100 and repos_y(-Y)100 
./fbdev_display_tests -X 100 -Y 100 -T Repositiontests

#Run the API test- Runs all APIs supported. -T stands for special tests like api,stability. Wheraes the smsmall letter -t stands for test name(will be logged) and helpful for testers reference. User can pass any string to small -t option but string shouldn't have any spaces.
./fbdev_display_tests -t api -T apitests

#Run the ioctl test- Runs all ioctl supported. -T stands for special tests like api,stability. Wheraes the smsmall letter -t stands for test name(will be logged) and helpful for testers reference. User can pass any string to small -t option but string shouldn't have any spaces.

./fbdev_display_tests -t ioctl -T ioctltests

#Run the stability test for 10 times on .By changing -C to high value, it can run over night and detect for any memory leak/crash.
./fbdev_display_tests -t stability -c 10 -T Stabilitytests

#runs the default color bar test with PAL standard on composite interface
./fbdev_display_tests -s PAL -i COMPOSITE -w 720 -h 576 -T Displaytests_pal

#Stress Test- Run the display test overnight- Displays default color bar with number of buffers queued is 4 overnight
./fbdev_display_tests -t stress

#Run the display test- Displays default color bar with width (-w) 720, height (-h) 480
./fbdev_display_tests -w 720 -h 480 -i COMPONENT -s NTSC -T Displaytests


#Run the display test- Displays default color bar with width (-w) 720, height (-h) 480
./fbdev_display_tests -w 720 -h 480 -i SVIDEO -T Displaytests



#Displays default color bar with some reference log useful for testers reference. The option passed will be printed as part of logging
./fbdev_display_tests -t Nov07_lsprelease_060_test



