
#   omap35x_sample_usage_sample_script


#Prints the usage/help
./fbdev_display_tests --help

#Prints the version
./fbdev_display_tests -v

#Runs the default color bar display-No options provided- Runs by default on LCD 
./fbdev_display_tests -T Displaytests_Default 

#Run the display test- Displays default color bar with width (-w) 640, height (-h) 480
./fbdev_display_tests -w 640 -h 480 -s VGA -i LCD -d LCD  -T Displaytests

#Run the display test- Displays default color bar with width (-w) 720, height (-h) 400
./fbdev_display_tests --width 640 --height 400 --standard VGA --interface LCD 

#Run the API test- Runs all APIs supported. -T stands for special tests like api,stability. Wheraes the smsmall letter -t stands for test name(will be logged) and helpful for testers reference. User can pass any string to small -t option but string shouldn't have any spaces.
./fbdev_display_tests -t api -T apitests

#Run the ioctl test- Runs all ioctl supported. -T stands for special tests like api,stability. Wheraes the smsmall letter -t stands for test name(will be logged) and helpful for testers reference. User can pass any string to small -t option but string shouldn't have any spaces.

./fbdev_display_tests -t ioctl -T ioctltests

#Runs the stability test taking stability count as an input

./fbdev_display_tests -t stability -c 100

#Runs the stress test
./fbdev_display_tests -t stress


#Displays default color bar with some reference log useful for testers reference. The option passed will be printed as part of logging
./fbdev_display_tests -t Nov07_lsprelease_060_test

#To use the display out as TV , interface as SVIDEO and standard as ntsc use the following options
#./fbdev_display_tests -d TV -w 720 -h 480 -i SVIDEO -s ntsc_m 


