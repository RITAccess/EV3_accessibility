/*
 * st_fbdev_interface.c
 *
 * This file contains the interface specific funtions
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/ 
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/


/* FBDEV specific header file */
#include "st_fbdev_common.h"

/* FBDEV structs, enums, macros defined */
#define DEFAULT_NODE "/dev/fb0"
#define DEFAULT_WIDTH 480
#define DEFAULT_HEIGHT 272 
#define DEFAULT_MODE "INTERLACED"
#define DEFAULT_INTERFACE "LCD"
#define DEFAULT_RESOLUTION  "VGA"
#define DEFAULT_BPP 16
#define DEFAULT_ZOOM_X 0
#define DEFAULT_ZOOM_Y 0
#define DEFAULT_WINDOW_NAME "/dev/fb0"
#define DEFAULT_NO_OF_FRAMES 500
#define ST_OSD_NUM_BUFS1 2
#define  LOOP_COUNT_NUM 50

struct fbdev_display_testparams testoptions;
struct fb_var_screeninfo vid_varInfo;

Int32 st_img_type = 0;
/* Global Variables */

int fd_dev0 = -1;
int fd_dev2 = -1;
static int fd_invalid = -1;

/* fbdev window file descriptors */

/* dev 0 size */
static int dev_size = 0;

/* display buffers for fbdev dev 0 windows */
unsigned char *dev_display[ST_OSD_NUM_BUFS1];


static short ycbcr[8] = {
    (0x1F << 11) | (0x3F << 5) | (0x1F),
    (0x00 << 11) | (0x00 << 5) | (0x00),
    (0x1F << 11) | (0x00 << 5) | (0x00),
    (0x00 << 11) | (0x3F << 5) | (0x00),
    (0x00 << 11) | (0x00 << 5) | (0x1F),
    (0x1F << 11) | (0x3F << 5) | (0x00),
    (0x1F << 11) | (0x00 << 5) | (0x1F),
    (0x00 << 11) | (0x3F << 5) | (0x1F),
};

static short ycbcr_2[2][8] = {
	{
		(0x1F << 11) | (0x3F << 5) | (0x1F),
		(0x00 << 11) | (0x00 << 5) | (0x00),
		(0x1F << 11) | (0x00 << 5) | (0x00),
		(0x00 << 11) | (0x3F << 5) | (0x00),
		(0x00 << 11) | (0x00 << 5) | (0x1F),
		(0x1F << 11) | (0x3F << 5) | (0x00),
		(0x1F << 11) | (0x00 << 5) | (0x1F),
		(0x00 << 11) | (0x3F << 5) | (0x1F),
	}, {
		(0x00 << 11) | (0x3F << 5) | (0x1F),
		(0x1F << 11) | (0x00 << 5) | (0x1F),
		(0x1F << 11) | (0x3F << 5) | (0x00),
		(0x00 << 11) | (0x00 << 5) | (0x1F),
		(0x00 << 11) | (0x3F << 5) | (0x00),
		(0x1F << 11) | (0x00 << 5) | (0x00),
		(0x00 << 11) | (0x00 << 5) | (0x00),
		(0x1F << 11) | (0x3F << 5) | (0x1F),
	}
};



/****************************************************************************
 * Function             - st_init_fbdev_display_test_params
 * Functionality        - This function initilaizes the default values for
 * various test case options(which will be exposed as command line arguments)
 * Input Params         -  None
 * Return Value         -  None
 * Note                 -  None
 ****************************************************************************/
void st_init_fbdev_display_test_params()
{
    testoptions.device_name = DEFAULT_NODE;
    testoptions.width = DEFAULT_WIDTH;
    testoptions.height = DEFAULT_HEIGHT;
    testoptions.mode = DEFAULT_MODE;
    testoptions.interface = DEFAULT_INTERFACE;
    testoptions.standard = DEFAULT_RESOLUTION;
    testoptions.bits_per_pixel = DEFAULT_BPP;
    testoptions.zoom_x = DEFAULT_ZOOM_X;
    testoptions.zoom_x = DEFAULT_ZOOM_Y;
    testoptions.window_name = DEFAULT_WINDOW_NAME;
    testoptions.no_of_frames = DEFAULT_NO_OF_FRAMES;
    testoptions.framerate = FALSE;
    testoptions.cpuload = FALSE;
    testoptions.queue = FALSE;
}

/****************************************************************************
 * Function             - display_help
 * Functionality        - This function displays the help/usage
 * Input Params         - None
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/
void st_display_fbdev_display_test_suite_help(void)
{
    printf("FbdevDisplayTestSuite V %s\n", VERSION_STRING);
    printf("Usage:\n"
           "./OMAP35x_GIT_fbdev_display_tests <options>\n\n"
           "-n      --devicename       	Device name on which display test is to be run\n"
           "\t\t\t\tPossible values-/dev/fb/0,/dev/fb/1\n"
           "-w      --width            	Width of the image to be displayed\n"
           "-h      --height           	Height of the image to be displayed\n"
           "-m      --mode             	The video mode \n"
           "\t\t\t\t Possible values are INTERLACED or PROGRESSIVE\n"
           "-s      --standard        	Name of the standard\n"
           "\t\t\t\tPossible values-ntsc,pal\n"
           "-f      --noofframes     	  Number of frames to be displayed\n"
           "-F      --Filename         	Name of the image file to display\n"
           "\t\t\t\t Make sure the file is as per -w(width),-h(height) configured & in YUV format\n and device node\n"
           "-t      --testcasename     	Name of the special test\n"
           "\t\t\t\tPossible values-stability,api\n"
           "-p      --pixel_format     	Pixel formats\n"
           "\t\t\t\tPossible values-RGB565,RGB888\n"
           "-c      --stability_count    	Number of times to run stability test\n"
           "-L      --loopcount   		Number of times to run loop for ioctl test\n"
           "-I      --ioctl_no	    	IOCTL number\n"
           "\t\t\t\tPossible values-0:putVscreenInfo and getVscreenInfo , 1:getFscreenInfo , 2:fbioqueryplane , 3:fbioqueryMem , 4:fbioGetUpdateMode \n"
           "-t      --testname         	Name of the special test\n"
           "\t\t\t\tPossible values-stability,api, ioctl (need L and I values)\n"
           "-T      --testcaseid       	Test case id string for testers reference/logging purpose\n"
           "-A     --greyscale, 		Grey scale\n"
           "-B     --redlength, 		Red Length\n"
           "-C     --redoffset, 		Red Offset\n"
           "-D     --redmsb, 			Red MSB\n"
           "-E     --greenlength, 		Green Length\n"
           "-G     --greenoffset, 		Green Offset\n"
           "-H     --greenmsb, 			Green MSB\n"
           "-K     --bluelength, 		Blue Length\n"
           "-M     --blueoffset, 		Blue Offset\n"
           "-N     --bluemsb, 			Blue MSB\n"
           "-O     --translength, 		Transperent Length\n"
           "-P     --transoffset, 		Transperent Offset\n"
           "-Q     --transmsb, 			Transperent MSB\n"
           "-R     --leftmargin, 		Left Margin\n"
           "-S     --rightmargin, 		Right Margin\n"
           "-U     --lowermargin, 		Lower Margin\n"
           "-V     --uppermargin, 		Upper Margin\n"
           "-Z     --hsynclen, 			Hsync len\n"
           "-a     --vsynclen, 			Vsync len\n"
           "-e     --sync, 				Sync\n"
           "\t\t\t\tPossible values- 	Any String without spaces\n"
           "-r      --framerate      	Displays the frame rate in fps(frames per sec)\n"
           "-l      --cpuload         	Displays the cpu load in percenatge\n"
           "-g      --queue         	Displays panning (no values required just pass -g)\n"
           "-?      --help            	Displays the help/usage\n"
           "-v      --version         	Version of Display Test suite\n");
    exit(0);
}
/****************************************************************************
 * Function             - print_test_params
 * Functionality        - This function prints the test option values
 * Input Params         - Test params structure
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/
void st_print_fbdev_display_test_params(struct fbdev_display_testparams
                                        *testoptions,char *test_id)
{
    DBG_PRINT_TST_START((test_id));
    DBG_PRINT_TRC0(("The Test is going to start with following values"));
    DBG_PRINT_TRC0(("The device node | %s", testoptions->device_name));
    DBG_PRINT_TRC0(("The height of the image | %d", testoptions->height));
    DBG_PRINT_TRC0(("The width  of the image | %d", testoptions->width));
    DBG_PRINT_TRC0(("The name of the interface is| %s",
                    testoptions->interface));
}


/****************************************************************************
 * Function             - check_interface
 * Functionality        - This function checks the interface
 * Input Params         - None
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/
int st_check_interface(char *interface)
{
    if (strcmp(interface, "LCD") == 0) {
        return SUCCESS;
    } else {
        DBG_PRINT_ERR(("Interface not supported\n"));
        return FAILURE;
    }
}


/****************************************************************************
 * Function             - st_check_std
 * Functionality        - This function checks the user input fot standard 
 * Input Params         - standard and interface
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/
int st_check_std(char *standard)
{

    if ((!strcmp(standard, "VGA") == TRUE))
        return SUCCESS;
    else if ((!strcmp(standard, "QVGA") == TRUE))
        return SUCCESS;
    else
        return FAILURE;

}


/****************************************************************************
 * Function             - st_set_std_interface
 * Functionality        - This function checks the user input for standard and interface
 * Input Params         - standard and interface
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/
int st_set_std_interface(char *standard, char *interface)
{

    return SUCCESS;
}


/****************************************************************************
 * Function             - check_pixel_format
 * Functionality        - This function checks the user input
 * Input Params         - None
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/
int st_check_pixel_format(char *pixel_format)
{

    if (strcmp(pixel_format, "RGB565") == 0) {
        st_img_type = ST_RGB_565;
        return SUCCESS;
    }

    else if (strcmp(pixel_format, "YUV") == 0) {
        st_img_type = ST_YUV;
        return SUCCESS;
    }

    else if (strcmp(pixel_format, "BITMAP_1") == 0) {
        st_img_type = ST_BITMAP_1;
        return SUCCESS;
    }

    else if (strcmp(pixel_format, "RGB888") == 0) {
        st_img_type = ST_RGB_888;
        return SUCCESS;
    } else if (strcmp(pixel_format, "H_PATTERN") == 0) {
        st_img_type = ST_H_PATTERN;
        return SUCCESS;
    } else if (strcmp(pixel_format, "V_PATTERN") == 0) {
        st_img_type = ST_V_PATTERN;
        return SUCCESS;
    }

    else {
        DBG_PRINT_ERR(("Wrong format entered- Please enter either RGB565, YUYV, UYVY or RGB888\n"));
        return FAILURE;
    }
    return SUCCESS;
}


/****************************************************************************
 * Function             - fill_color_bar
 * Functionality        - This function is used to fill up buffer with color bars.
 * Input Params         - 
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/
void fill_color_bar(unsigned char *addr, int width, int height)
{
    unsigned short *start = (unsigned short *) addr;
    unsigned int size = width * (height / 8);
    int i, j;

    for (i = 0; i < 8; i++) {
        for (j = 0; j < size / 2; j++) {
            *start = ycbcr[i];
            start++;
        }
    }
}

/****************************************************************************
 * Function             - fill_color_bar
 * Functionality        - This function is used to fill up buffer with color bars.
 * Input Params         - 
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/
void fill_color_bar_vertical(unsigned char *addr, int width, int height)
{
    unsigned short *start = (unsigned short *) addr;
    int i, j, k;

    for (j = 0; j < height / 2; j++) {
        for (i = 0; i < 8; i++) {
            for (k = 0; k < width / 8; k++) {
                *start = ycbcr[i];
                start++;
            }
        }
    }
}


/****************************************************************************
 * Function             - st_fbdev_open_interface
 * Functionality        - This function opens FBDEV window
 * Input Params         - FBDEV device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_open_interface(int dev)
{
    int fd = -1;

    if (FBDEV_DEV5 == dev) {
        fd_dev2 = open(FB_DEV5, O_RDWR);
        fd = fd_dev2;
    }
      else if (FBDEV_DEV4 == dev) {
        fd_dev0 = open(FB_DEV4, O_RDWR);
        fd = fd_dev0;
    } else if (FBDEV_INVALID == dev) {
        fd_invalid = open(FB_DEV_INVALID, O_RDWR);
        fd = fd_invalid;
    } else {
        return E_DEV_NOT_AVAILABLE;
    }

    if (0 >= fd)
        return FAILURE;

    return SUCCESS;
}


/****************************************************************************
 * Function             - st_fbdev_close_fbdev_inteface
 * Functionality        - This function closes FBDEV window
 * Input Params         - FBDEV device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_close_interface(int dev)
{

    int status = SUCCESS;
    int fd;

    if (FBDEV_DEV4 == dev){
        status = close(fd_dev0);
        fd = fd_dev0;
    }
    else if (FBDEV_DEV5 == dev){
	        status = close(fd_dev2);
	        fd = fd_dev2;
    }
    else {
        return E_DEV_NOT_AVAILABLE;
    }

    if (SUCCESS != status)
        return FAILURE;

    fd = -1;
    return status;

}



/****************************************************************************
 * Function             - st_fbdev_setpos_interface
 * Functionality        - This function sets FBDEV window position
 * Input Params         - FBDEV, device number, x and Y position
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_setpos_interface(int dev, st_vpbe_window_position * st_pos)
{
    return E_IOCTL_NOT_SUPPORTED;
}


/****************************************************************************
 * Function             - st_fbdev_mmap_vid0_interface
 * Functionality        - This function maps FBDEV windowbuffers to user space
 * Input Params         - device number, line length and y resolution
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_mmap_interface(int dev, int st_lineLength, int st_yres)
{
    int status = SUCCESS;
    int vid_size = 0;
    int i = 0;

    vid_size = st_lineLength * st_yres;

    if (FBDEV_DEV4 == dev) {
        /* Map the fbdev dev0 buffers to user space */
        dev_display[0] =
            (unsigned char *) mmap(NULL, vid_size * ST_OSD_NUM_BUFS1,
                                   PROT_READ | PROT_WRITE, MAP_SHARED,
                                   fd_dev0, 0);
        dev_size = vid_size;
        if (MAP_FAILED == dev_display[0]) {
            status = FAILURE;
            return status;
        }

         for (i = 1; i < ST_OSD_NUM_BUFS1; i++) {
          dev_display[i] = dev_display[i-1] + dev_size;
        }
    }
    else if (FBDEV_DEV5 == dev) {
          /* Map the fbdev dev0 buffers to user space */
	       dev_display[0] =
	           (unsigned char *) mmap(NULL, vid_size * ST_OSD_NUM_BUFS1,
	                                  PROT_READ | PROT_WRITE, MAP_SHARED,
	                                  fd_dev2, 0);
	       dev_size = vid_size;
	       if (MAP_FAILED == dev_display[0]) {
	           status = FAILURE;
	           return status;
	       }

	        for (i = 1; i < ST_OSD_NUM_BUFS1; i++) {
	         dev_display[i] = dev_display[i-1] + dev_size;
	       }
    }
    else {
        return E_DEV_NOT_AVAILABLE;
    }

    return status;

}

/****************************************************************************
 * Function             - st_fbdev_display_square_interface
 * Functionality        - This function unmaps buffers
 * Input Params         - device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_display_square_interface(int dev,st_fb_var_screeninfo
fb_var,st_fb_fix_screeninfo fb_fix)
{

    return SUCCESS; 
}
/****************************************************************************
 * Function             - st_fbdev_display_chess_interface
 * Functionality        - This function unmaps buffers
 * Input Params         - device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_display_chess_interface(int dev,st_fb_var_screeninfo
fb_var,st_fb_fix_screeninfo fb_fix)
{
    return SUCCESS; 

}
/****************************************************************************
 * Function             - st_fbdev_display_natural_image_interface
 * Functionality        - This function unmaps buffers
 * Input Params         - device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_display_natural_image_interface(int dev,st_fb_var_screeninfo
fb_var,st_fb_fix_screeninfo fb_fix)
{
                    return SUCCESS;

}
/****************************************************************************
 * Function             - st_fbdev_unmap_interface
 * Functionality        - This function unmaps buffers
 * Input Params         - device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_unmap_interface(int dev)
{
    int retVal = SUCCESS;

    if ((FBDEV_DEV4 == dev) || (FBDEV_DEV5 == dev)) {
        retVal = munmap(dev_display[0], dev_size * ST_OSD_NUM_BUFS1);
        dev_size = 0;
    } else {
        return E_DEV_NOT_AVAILABLE;
    }

    if (SUCCESS != retVal)
        return FAILURE;

    return SUCCESS;
}


/****************************************************************************
 * Function             - st_fbdev_display_interface
 * Functionality        - This function displays buffers on FBDEV window
 * Input Params         - device number, width and height of the image
 * Return Value         - -1 on failure, else display ID is returned
 * Note                 - None
 ****************************************************************************/
int st_fbdev_display_interface(int dev, int width, int height,
                               int st_img_type, char *image_name)
{

    static unsigned int nDisplayIdx = 0;
    static unsigned int nWorkingIndex = 0;
    unsigned char *src = NULL;
    FILE *fp = NULL;
    int numBufs = 0;
    int size = 0;
    int i = 0;
    unsigned char r, g, b;

    size = width * height * 2;

    if (image_name != NULL) {
        fp = fopen(image_name, "rb");
        if (fp == NULL) {
            return FAILURE;
        }
        src = dev_display[nWorkingIndex];
        for (i = 0; i < (width * height * 2) / 4; i++) {
            fscanf(fp, "%c%c%c", &r, &g, &b);
            *src = r;
            src++;
            *src = g;
            src++;
            *src = b;
            src++;
        }
        fclose(fp);
        numBufs = ST_OSD_NUM_BUFS1;
    }
    if (ST_OMAP_IMAGE == st_img_type) {
        fp = fopen(PAL_RGB565_IMAGE, "rb");
        if (fp == NULL) {
            return FAILURE;
        }
        src = dev_display[nWorkingIndex];
        for (i = 0; i < (width * height * 2) / 4; i++) {
            fscanf(fp, "%c%c%c", &r, &g, &b);
            *src = r;
            src++;
            *src = g;
            src++;
            *src = b;
            src++;
        }
        fclose(fp);
        numBufs = ST_OSD_NUM_BUFS1;
    } else if (ST_H_PATTERN == st_img_type) {

for (nWorkingIndex=0; nWorkingIndex < ST_OSD_NUM_BUFS1; nWorkingIndex++ )
{
       fill_color_bar(dev_display[nWorkingIndex], width * 2, height);
}
       numBufs = ST_OSD_NUM_BUFS1;
    } else if (ST_V_PATTERN == st_img_type) {

for (nWorkingIndex=0; nWorkingIndex < ST_OSD_NUM_BUFS1; nWorkingIndex++ )
{
        fill_color_bar_vertical(dev_display[nWorkingIndex], width,
                                height *2);
}
        numBufs = ST_OSD_NUM_BUFS1;
    }
    else if (ST_RGB_565 == st_img_type) {

        fill_color_bar(dev_display[nWorkingIndex], width * 2, height);
        numBufs = ST_OSD_NUM_BUFS1;
    }
    else if (ST_YUV == st_img_type) {

        fill_color_bar(dev_display[nWorkingIndex], width * 2, height);
        numBufs = ST_OSD_NUM_BUFS1;
    }
    else if (ST_BITMAP_1 == st_img_type) {

        fill_color_bar(dev_display[nWorkingIndex], width * 2, height);
        numBufs = ST_OSD_NUM_BUFS1;
    }
    else if (ST_RGB_888 == st_img_type) {

        fill_color_bar(dev_display[nWorkingIndex], width * 2, height);
        numBufs = ST_OSD_NUM_BUFS1;
    }

    if (FBDEV_DEV4 != dev) {
        return E_DEV_NOT_AVAILABLE;
    }

    nWorkingIndex = (nWorkingIndex + 1) % numBufs;
    nDisplayIdx = (nDisplayIdx + 1) % numBufs;

    return nDisplayIdx;


}



/****************************************************************************
 * Function             - st_fbdev_getFscreenInfo_interface
 * Functionality        - This function gets fixed screen info 
 * Input Params         - device number and fix screen info structure pointer
 * Return Value         - -1 on failure, else display ID is returned
 * Note                 - None
 ****************************************************************************/
int st_fbdev_getFscreenInfo_interface(int dev,
                                      st_fb_fix_screeninfo * fixInfo)
{
    int retVal = SUCCESS;
    struct fb_fix_screeninfo fInfo;

    if (FBDEV_DEV4 == dev) {
        retVal = ioctl(fd_dev0, FBIOGET_FSCREENINFO, &fInfo);
    }
    else if (FBDEV_DEV5 == dev) {
        retVal = ioctl(fd_dev2, FBIOGET_FSCREENINFO, &fInfo);
    }
    else if (FBDEV_INVALID == dev) {
        retVal = ioctl(fd_invalid, FBIOGET_FSCREENINFO, &fInfo);
    }
    else {
        return E_DEV_NOT_AVAILABLE;
    }
    if (SUCCESS != retVal)
	{
	    perror ("FBIOGET_FSCREENINFO");  
        return FAILURE;
	}	

    /* copy data to testcase user structure */
    strcpy(fixInfo->id, fInfo.id);
    fixInfo->smem_start = fInfo.smem_start;
    fixInfo->smem_len = fInfo.smem_len;
    fixInfo->type = fInfo.type;
    fixInfo->type_aux = fInfo.type_aux;
    fixInfo->visual = fInfo.visual;
    fixInfo->xpanstep = fInfo.xpanstep;
    fixInfo->ypanstep = fInfo.ypanstep;
    fixInfo->ywrapstep = fInfo.ywrapstep;
    fixInfo->line_length = fInfo.line_length;
    fixInfo->mmio_start = fInfo.mmio_start;

    fixInfo->mmio_len = fInfo.mmio_len;
    fixInfo->accel = fInfo.accel;

    fixInfo->reserved[0] = fInfo.reserved[0];
    fixInfo->reserved[1] = fInfo.reserved[1];
    fixInfo->reserved[2] = fInfo.reserved[2];

    return retVal;
}



/****************************************************************************
 * Function             - st_fbdev_getVscreenInfo_interface
 * Functionality        - This function gets variable info of the screen
 * Input Params         - device number and variable screen info structure
 *                          pointer
 * Return Value         - -1 on failure, else display ID is returned
 * Note                 - None
 ****************************************************************************/
int st_fbdev_getVscreenInfo_interface(int dev,
                                      st_fb_var_screeninfo * varInfo)
{
    int retVal = SUCCESS;

    struct fb_var_screeninfo vInfo;

    if (FBDEV_DEV4 == dev) {
        retVal = ioctl(fd_dev0, FBIOGET_VSCREENINFO, &vInfo);
    }
    else if (FBDEV_DEV5 == dev) {
        retVal = ioctl(fd_dev2, FBIOGET_VSCREENINFO, &vInfo);
    }
    else {
        return E_DEV_NOT_AVAILABLE;
    }
    if (SUCCESS != retVal)
	{
	    perror ("FBIOGET_VSCREENINFO");  
        return FAILURE;
	}	

    /* copy data to testcase user structure */
    varInfo->xres = vInfo.xres;
    varInfo->yres = vInfo.yres;
    varInfo->xres_virtual = vInfo.xres_virtual;
    varInfo->yres_virtual = vInfo.yres_virtual;
    varInfo->xoffset = vInfo.xoffset;
    varInfo->yoffset = vInfo.yoffset;
    varInfo->bits_per_pixel = vInfo.bits_per_pixel;
    varInfo->grayscale = vInfo.grayscale;

    varInfo->red.offset = vInfo.red.offset;
    varInfo->red.length = vInfo.red.length;
    varInfo->red.msb_right = vInfo.red.msb_right;

    varInfo->green.offset = vInfo.green.offset;
    varInfo->green.length = vInfo.green.length;
    varInfo->green.msb_right = vInfo.green.msb_right;

    varInfo->blue.offset = vInfo.blue.offset;
    varInfo->blue.length = vInfo.blue.length;
    varInfo->blue.msb_right = vInfo.blue.msb_right;

    varInfo->transp.offset = vInfo.transp.offset;
    varInfo->transp.length = vInfo.transp.length;
    varInfo->transp.msb_right = vInfo.transp.msb_right;

    varInfo->nonstd = vInfo.nonstd;
    varInfo->activate = vInfo.activate;
    varInfo->height = vInfo.height;
    varInfo->width = vInfo.width;
    varInfo->accel_flags = vInfo.accel_flags;
    varInfo->pixclock = vInfo.pixclock;
    varInfo->left_margin = vInfo.left_margin;
    varInfo->right_margin = vInfo.right_margin;
    varInfo->upper_margin = vInfo.upper_margin;
    varInfo->lower_margin = vInfo.lower_margin;
    varInfo->hsync_len = vInfo.hsync_len;
    varInfo->vsync_len = vInfo.vsync_len;
    varInfo->sync = vInfo.sync;
    varInfo->vmode = vInfo.vmode;
    varInfo->rotate = vInfo.rotate;
    varInfo->reserved[0] = vInfo.reserved[0];
    varInfo->reserved[1] = vInfo.reserved[1];
    varInfo->reserved[2] = vInfo.reserved[2];
    varInfo->reserved[3] = vInfo.reserved[3];
    varInfo->reserved[4] = vInfo.reserved[4];

    return retVal;

}


/****************************************************************************
 * Function             - st_fbdev_getVscreenInfo_interface
 * Functionality        - device number and variable screen info structure
 *                          pointer
 * Return Value         - -1 on failure, else display ID is returned
 * Note                 - None
 ****************************************************************************/
int st_fbdev_putVscreenInfo_interface(int dev,
                                      st_fb_var_screeninfo * varInfo)
{
    int retVal = SUCCESS;
    struct fb_var_screeninfo vid_varInfo;

    /* copy data to testcase user structure */
    vid_varInfo.xres = varInfo->xres;
    vid_varInfo.yres = varInfo->yres;
    vid_varInfo.xres_virtual = varInfo->xres_virtual;
    vid_varInfo.yres_virtual = varInfo->yres_virtual;
    vid_varInfo.xoffset = varInfo->xoffset;
    vid_varInfo.yoffset = varInfo->yoffset;
    vid_varInfo.bits_per_pixel = varInfo->bits_per_pixel;
    vid_varInfo.grayscale = varInfo->grayscale;

    vid_varInfo.red.offset = varInfo->red.offset;
    vid_varInfo.red.length = varInfo->red.length;
    vid_varInfo.red.msb_right = varInfo->red.msb_right;

    vid_varInfo.green.offset = varInfo->green.offset;
    vid_varInfo.green.length = varInfo->green.length;
    vid_varInfo.green.msb_right = varInfo->green.msb_right;

    vid_varInfo.blue.offset = varInfo->blue.offset;
    vid_varInfo.blue.length = varInfo->blue.length;
    vid_varInfo.blue.msb_right = varInfo->blue.msb_right;

    vid_varInfo.transp.offset = varInfo->transp.offset;
    vid_varInfo.transp.length = varInfo->transp.length;
    vid_varInfo.transp.msb_right = varInfo->transp.msb_right;

    vid_varInfo.nonstd = varInfo->nonstd;
    vid_varInfo.activate = varInfo->activate;
    vid_varInfo.height = varInfo->height;
    vid_varInfo.width = varInfo->width;
    vid_varInfo.accel_flags = varInfo->accel_flags;
    vid_varInfo.pixclock = varInfo->pixclock;
    vid_varInfo.left_margin = varInfo->left_margin;
    vid_varInfo.right_margin = varInfo->right_margin;
    vid_varInfo.upper_margin = varInfo->upper_margin;
    vid_varInfo.lower_margin = varInfo->lower_margin;
    vid_varInfo.hsync_len = varInfo->hsync_len;
    vid_varInfo.vsync_len = varInfo->vsync_len;
    vid_varInfo.sync = varInfo->sync;
    vid_varInfo.vmode = varInfo->vmode;
    vid_varInfo.rotate = varInfo->rotate;
    vid_varInfo.reserved[0] = varInfo->reserved[0];
    vid_varInfo.reserved[1] = varInfo->reserved[1];
    vid_varInfo.reserved[2] = varInfo->reserved[2];
    vid_varInfo.reserved[3] = varInfo->reserved[3];
    vid_varInfo.reserved[4] = varInfo->reserved[4];

    /* call Ioctl */
    if (FBDEV_DEV4 == dev) {
        retVal = ioctl(fd_dev0, FBIOPUT_VSCREENINFO, &vid_varInfo);
    }
    else if (FBDEV_DEV5 == dev) {
        retVal = ioctl(fd_dev2, FBIOPUT_VSCREENINFO, &vid_varInfo);
    }
    else {
        return E_DEV_NOT_AVAILABLE;
    }
    if (SUCCESS != retVal)
	{
	    perror ("FBIOPUT_VSCREENINFO");  
        return FAILURE;
	}	

    return retVal;

}



/****************************************************************************
 * Function             - st_fbdev_blank_window_interface
 * Functionality        - This function enables or disables FBDEV window
 * Input Params         - window name, enable/disable option
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_blank_window_interface(int dev, Bool st_blank)
{
    int retVal = SUCCESS;

    if (FBDEV_DEV4 == dev) {
        retVal = ioctl(fd_dev0, FBIOBLANK, st_blank);
    }
    else if (FBDEV_DEV5 == dev) {
        retVal = ioctl(fd_dev2, FBIOBLANK, st_blank);
    }
    else {
        return E_DEV_NOT_AVAILABLE;
    }

    if (SUCCESS != retVal)
	{
	    perror ("FBIOBLANK");  
        return FAILURE;
	}	

    return SUCCESS;
}


/****************************************************************************
 * Function             - st_fbdev_waitforsync_interface
 * Functionality        - This function executes FBIO_WAITFORVSYNC ioctl
 * Input Params         - device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_waitforsync_interface(int dev)
{
    int retVal = SUCCESS;

    if (FBDEV_DEV4 == dev) {
        retVal = ioctl(fd_dev0, OMAPFB_WAITFORVSYNC, 0);
    }

    else if (FBDEV_DEV5 == dev) {
        retVal = ioctl(fd_dev2, OMAPFB_WAITFORVSYNC, 0);
    }
    else {
        return E_DEV_NOT_AVAILABLE;
    }

    if (SUCCESS != retVal)
	{
	    perror ("OMAPFB_WAITFORVSYNC");  
        return FAILURE;
	}	
    return retVal;

}

/****************************************************************************
 * Function             - st_fbdev_pandisplay_interface
 * Functionality        - This function executes FBIOPAN_DISPLAY ioctl
 * Input Params         - device number and variable screen info structure
 *                          pointer
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_fbioMirror_ioctl_interface(int dev, Uint32 * st_mirror)
{
	return SUCCESS;

}
/****************************************************************************
 * Function             - st_fbdev_pandisplay_interface
 * Functionality        - This function executes FBIOPAN_DISPLAY ioctl
 * Input Params         - device number and variable screen info structure
 *                          pointer
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_pandisplay_interface(int dev, st_fb_var_screeninfo * varInfo)
{
    int retVal = SUCCESS;

    /* call Ioctl */
    if (FBDEV_DEV4 == dev) {
        retVal = ioctl(fd_dev0, FBIOPAN_DISPLAY, varInfo);
    }
    else if (FBDEV_DEV5 == dev) {
        retVal = ioctl(fd_dev2, FBIOPAN_DISPLAY, varInfo);
    }
    else {
        return E_DEV_NOT_AVAILABLE;
    }
    if (SUCCESS != retVal)
	{
	    perror ("FBIOPAN_DISPLAY");  
        return FAILURE;
	}	

    return retVal;
    return SUCCESS;
}


/****************************************************************************
 * Function             - st_fbdev_setBitmatBlendFactor_ioctl_interface
 * Functionality        - This function executes st_fbdev_setBitmatBlendFactor_ioctl_interface ioctl
 * Input Params         - device number and st_vpbe_bitmap_blend_params structurepointer
 *                          pointer
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_setBitmatBlendFactor_ioctl_interface(int dev,
                                                  st_vpbe_bitmap_blend_params
                                                  * st_bFactor)
{
    return E_IOCTL_NOT_SUPPORTED;
}


/****************************************************************************
 * Function             - st_fbdev_setBlinkInterval_ioctl_interface
 * Functionality        - This function executes FBIO_SET_BLINK_INTERVAL  ioctl
 * Input Params         - device number and st_vpbe_blink_option structurepointer
 *                          pointer
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_setBlinkInterval_ioctl_interface(int st_dev,
                                              st_vpbe_blink_option *
                                              st_setBlink)
{
    return E_IOCTL_NOT_SUPPORTED;
}



/****************************************************************************
 * Function             - st_fbdev_setBitmatBlendFactor_ioctl_interface
 * Functionality        - This function executes FBIO_GET_BLINK_INTERVAL ioctl
 * Input Params         - device number and st_vpbe_blink_option structurepointer
 *                          pointer
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_getBlinkInterval_ioctl_interface(int st_dev,
                                              st_vpbe_blink_option *
                                              st_getBlink)
{
    return E_IOCTL_NOT_SUPPORTED;
}


/****************************************************************************
 * Function             - st_fbdev_getVideoConfigParams_ioctl_interface
 * Functionality        - This function executes FBIO_GET_VIDEO_CONFIG_PARAMS ioctl
 * Input Params         - device number and st_vpbe_video_config_params structurepointer
 *                          pointer
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_getVideoConfigParams_ioctl_interface(int dev,
                                                  st_vpbe_video_config_params
                                                  * st_getparams)
{
    return E_IOCTL_NOT_SUPPORTED;
}


/****************************************************************************
 * Function             - st_fbdev_setVideoConfigParams_ioctl_interface
 * Functionality        - This function executes FBIO_SET_VIDEO_CONFIG_PARAMS ioctl
 * Input Params         - device number and st_vpbe_video_config_params structurepointer
 *                          pointer
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_setVideoConfigParams_ioctl_interface(int dev,
                                                  st_vpbe_video_config_params
                                                  * st_setparams)
{
    return E_IOCTL_NOT_SUPPORTED;
}


/****************************************************************************
 * Function             - st_fbdev_getBitmapConfigParams_ioctl_interface
 * Functionality        - This function executes FBIO_GET_BITMAP_CONFIG_PARAMS ioctl
 * Input Params         - device number and st_vpbe_bitmap_config_params structure pointer
 *                          pointer
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_getBitmapConfigParams_ioctl_interface(int dev,
                                                   st_vpbe_bitmap_config_params
                                                   * st_getparams)
{
    return E_IOCTL_NOT_SUPPORTED;
}


/****************************************************************************
 * Function             - st_fbdev_setBitmapConfigParams_ioctl_interface
 * Functionality        - This function executes FBIO_SET_BITMAP_CONFIG_PARAMS ioctl
 * Input Params         - device number and st_vpbe_bitmap_config_params structure pointer
 *                          pointer
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_setBitmapConfigParams_ioctl_interface(int dev,
                                                   st_vpbe_bitmap_config_params
                                                   * st_setparams)
{
    return E_IOCTL_NOT_SUPPORTED;
}



/****************************************************************************
 * Function             - st_fbdev_setZoom_ioctl_interface
 * Functionality        - This function sets zoom factor for a window
 * Input Params         - device number and st_zoom_params structure pointer
 *                          pointer
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_setZoom_ioctl_interface(int dev, st_zoom_params * st_zoom)
{
    return E_IOCTL_NOT_SUPPORTED;
}


/****************************************************************************
 * Function             - st_fbdev_setPosx_ioctl_interface
 * Functionality        - This function sets x-pos of window
 * Input Params         - device number and st_zoom_params structure pointer
 *                          pointer
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_setPosx_ioctl_interface(int dev, Uint32 * st_xpos)
{
    return E_IOCTL_NOT_SUPPORTED;
}


/****************************************************************************
 * Function             - st_fbdev_setPosy_ioctl_interface
 * Functionality        - This function sets y-pos of window
 * Input Params         - device number and st_zoom_params structure pointer
 *                          pointer
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_setPosy_ioctl_interface(int dev, Uint32 * st_ypos)
{
    return E_IOCTL_NOT_SUPPORTED;
}


/****************************************************************************
 * Function             - st_fbdev_setCursor_ioctl_interface
 * Functionality        - This function sets cursor position
 * Input Params         - device number and st_fb_cursor structure pointer
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_setCursor_ioctl_interface(int dev, st_fb_cursor * st_cursor)
{
    return E_IOCTL_NOT_SUPPORTED;
}


/****************************************************************************
 * Function             - st_fbdev_setBackGroundColor_ioctl_interface
 * Functionality        - This function sets background color
 * Input Params         - device number and st_fb_cursor structure pointer
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_setBackGroundColor_ioctl_interface(int dev,
                                                st_vpbe_backg_color *
                                                st_color)
{
    return E_IOCTL_NOT_SUPPORTED;
}

/****************************************************************************
 * Function             - st_fbdev_getCmap_ioctl_interface
 * Functionality        - This function gets cmap
 * Input Params         - device number and st_fb_cmap_user structure pointer
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_getCmap_ioctl_interface(int dev, struct st_fb_cmap_t *st_cmap)
{
	  
    int retVal = SUCCESS;
    struct fb_cmap fbcmap;

    if (FBDEV_DEV4 == dev) {
        retVal = ioctl(fd_dev0, FBIOGETCMAP, &fbcmap);
    }
    else if (FBDEV_DEV5 == dev) {
        retVal = ioctl(fd_dev2, FBIOGETCMAP, &fbcmap);
    }
    else if (FBDEV_INVALID == dev) {
        retVal = ioctl(fd_invalid, FBIOGETCMAP, &fbcmap);
    } else {
        return E_DEV_NOT_AVAILABLE;
    }

    DBG_PRINT_TRC0(("Ret value %d |",retVal));

    if (SUCCESS != retVal)
	{
	    perror ("FBIOGETCMAP");  
        return FAILURE;
	}	
    

    st_cmap->start = fbcmap.start;
    st_cmap->len = fbcmap.len;
	st_cmap->red = fbcmap.red;                 /* Red values   */
    st_cmap->green = fbcmap.green;
    st_cmap->blue = fbcmap.blue;
    st_cmap->transp = fbcmap.transp;              /* transparency, can be NULL */


    return retVal;

}


/****************************************************************************
 * Function             - st_fbdev_getCmap_ioctl_interface
 * Functionality        - This function gets cmap
 * Input Params         - device number and st_fb_cmap_user structure pointer
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_putCmap_ioctl_interface(int dev, struct st_fb_cmap_t * st_cmap)
{
    int retVal = SUCCESS;

    if (FBDEV_DEV4 == dev) {
        retVal = ioctl(fd_dev0, FBIOPUTCMAP, &st_cmap);
    }
    else if (FBDEV_DEV5 == dev) {
        retVal = ioctl(fd_dev2, FBIOPUTCMAP, &st_cmap);
    }
    else if (FBDEV_INVALID == dev) {
        retVal = ioctl(fd_invalid, FBIOPUTCMAP, &st_cmap);
    } else {
        return E_DEV_NOT_AVAILABLE;
    }

    if (SUCCESS != retVal)
	{
	    perror ("FBIOPUTCMAP");  
        return FAILURE;
	}	
    
    return SUCCESS;
}


/****************************************************************************
 * Function             - st_fbdev_getCon2Fb_ioctl_interface
 * Functionality        - This function Gets the con2fbmap structure.
 * Input Params         - device number and st_fb_con2fbmap structure pointer
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_getCon2Fb_ioctl_interface(int dev, st_fb_con2fbmap * st_con)
{
    return E_IOCTL_NOT_SUPPORTED;
}



/****************************************************************************
 * Function             - st_fbdev_getCon2Fb_ioctl_interface
 * Functionality        - This function sets the con2fbmap structure.
 * Input Params         - device number and st_fb_con2fbmap structure pointer
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_setCon2Fb_ioctl_interface(int dev, st_fb_con2fbmap * st_con)
{
    return E_IOCTL_NOT_SUPPORTED;
}



/****************************************************************************
 * Function             - st_fbdev_fbioQueryPlaneInfo_ioctl_interface
 * Functionality        - This function is to set the mirror of the FBDEV window position
 * Input Params         - FBDEV, device number, x and Y position
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None 
 ****************************************************************************/
int st_fbdev_fbioQueryPlaneInfo_ioctl_interface(int dev, struct st_omapfb_plane_info *st_planeinfo)
{

    int retVal = SUCCESS;
    struct st_omapfb_plane_info qInfo;

    if (FBDEV_DEV4 == dev) {
        retVal = ioctl(fd_dev0, OMAPFB_QUERY_PLANE, &qInfo);
    }
    else if (FBDEV_DEV5 == dev) {
        retVal = ioctl(fd_dev2, OMAPFB_QUERY_PLANE, &qInfo);
    }
    else if (FBDEV_INVALID == dev) {
        retVal = ioctl(fd_invalid, OMAPFB_QUERY_PLANE, &qInfo);
    } else {
        return E_DEV_NOT_AVAILABLE;
    }

    if (SUCCESS != retVal)
	{
	    perror ("OMAPFB_QUERY_PLANE");  
        return FAILURE;
	}	
    
    /* copy data to testcase user structure */
    st_planeinfo->pos_x = qInfo.pos_x;
	st_planeinfo->pos_y = qInfo.pos_y;
	st_planeinfo->enabled = qInfo.enabled;
	st_planeinfo->channel_out = qInfo.channel_out;
	st_planeinfo->mirror = qInfo.mirror;
	st_planeinfo->reserved1 = qInfo.reserved1;
	st_planeinfo->out_width = qInfo.out_width;
	st_planeinfo->out_height = qInfo.out_height;
    st_planeinfo->reserved2[0] = qInfo.reserved2[0];
    st_planeinfo->reserved2[1] = qInfo.reserved2[1];
    st_planeinfo->reserved2[2] = qInfo.reserved2[2];
    st_planeinfo->reserved2[3] = qInfo.reserved2[3];
    st_planeinfo->reserved2[4] = qInfo.reserved2[4];
    st_planeinfo->reserved2[5] = qInfo.reserved2[5];
    st_planeinfo->reserved2[6] = qInfo.reserved2[6];
    st_planeinfo->reserved2[7] = qInfo.reserved2[7];
    st_planeinfo->reserved2[8] = qInfo.reserved2[8];
    st_planeinfo->reserved2[9] = qInfo.reserved2[9];
    st_planeinfo->reserved2[10] = qInfo.reserved2[10];
    st_planeinfo->reserved2[11] = qInfo.reserved2[11];

    return retVal;
}

/****************************************************************************
 * Function             - st_fbdev_SetMemInfo_interface
 * Functionality        - Set Mem information for FB
 * Input Params         - st_omapfb_mem_info
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None 
 ****************************************************************************/
int st_fbdev_SetMemInfo_interface(int dev, struct st_omapfb_mem_info *st_meminfo)
{

    int retVal = SUCCESS;

    if (FBDEV_DEV4 == dev) {
        retVal = ioctl(fd_dev0, OMAPFB_SETUP_MEM, st_meminfo);
    }
    else if (FBDEV_DEV5 == dev) {
        retVal = ioctl(fd_dev2, OMAPFB_SETUP_MEM, st_meminfo);
    }
    else if (FBDEV_INVALID == dev) {
        retVal = ioctl(fd_invalid, OMAPFB_SETUP_MEM, st_meminfo);
    } else {
        return E_DEV_NOT_AVAILABLE;
    }

    if (SUCCESS != retVal)
	{
	    perror ("OMAPFB_SETUP_MEM");  
        return FAILURE;
	}	
    

    return retVal;
}

/****************************************************************************
 * Function             - st_fbdev_QueryMemInfo_interfacef
 * Functionality        - Set Mem information for FB
 * Input Params         - st_omapfb_mem_info
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None 
 ****************************************************************************/
int st_fbdev_QueryMemInfo_interface(int dev, struct st_omapfb_mem_info *st_meminfo)
{

    int retVal = SUCCESS;
	struct st_omapfb_mem_info qmeminfo;

    if (FBDEV_DEV4 == dev) {
        retVal = ioctl(fd_dev0, OMAPFB_QUERY_MEM, &qmeminfo);
    }
    else if (FBDEV_DEV5 == dev) {
        retVal = ioctl(fd_dev2, OMAPFB_QUERY_MEM, &qmeminfo);
    }
    else if (FBDEV_INVALID == dev) {
        retVal = ioctl(fd_invalid, OMAPFB_QUERY_MEM, &qmeminfo);
    } else {
        return E_DEV_NOT_AVAILABLE;
    }

    if (SUCCESS != retVal)
	{
	    perror ("OMAPFB_QUERY_MEM");  
        return FAILURE;
	}	
    

    /* copy data to testcase user structure */
    st_meminfo->size = qmeminfo.size;
    st_meminfo->type = qmeminfo.type;
    st_meminfo->reserved[0] = qmeminfo.reserved[0];
    st_meminfo->reserved[1] = qmeminfo.reserved[1];
	st_meminfo->reserved[2] = qmeminfo.reserved[2];


    return retVal;
}

/****************************************************************************
 * Function             - st_fbdev_GetUpdatedMode_interface
 * Functionality        - Gets the current update mode.
 * Input Params         - st_omapfb_update_mode
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None 
 ****************************************************************************/

int st_fbdev_GetUpdatedMode_interface(int dev, int *st_updateinfo)
{
    int retVal = SUCCESS;
	enum omapfb_update_mode qupdateinfo;


    if (FBDEV_DEV4 == dev) {
        retVal = ioctl(fd_dev0, OMAPFB_GET_UPDATE_MODE, &qupdateinfo);
    }
    else if (FBDEV_DEV5 == dev) {
        retVal = ioctl(fd_dev2, OMAPFB_GET_UPDATE_MODE, &qupdateinfo);
    }
    else if (FBDEV_INVALID == dev) {
        retVal = ioctl(fd_invalid, OMAPFB_GET_UPDATE_MODE, &qupdateinfo);
    } else {
        return E_DEV_NOT_AVAILABLE;
    }
    if (SUCCESS != retVal)
	{
	    perror ("OMAPFB_GET_UPDATE_MODE");  
        return FAILURE;
	}	
    

    /* copy data to testcase user structure */
    *st_updateinfo = qupdateinfo ;


    return retVal;

}

/****************************************************************************
 * Function             - st_fbdev_SetUpdatedMode_interface
 * Functionality        - Gets the current update mode.
 * Input Params         - st_omapfb_update_mode
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None 
 ****************************************************************************/

int st_fbdev_SetUpdatedMode_interface(int dev, int st_updateinfo)
{
    int retVal = SUCCESS;
	enum omapfb_update_mode supdateinfo;

       if(st_updateinfo == DSS_DISABLED)
       { 
            supdateinfo = OMAPFB_UPDATE_DISABLED;
       }
       else
       { 
            supdateinfo = OMAPFB_AUTO_UPDATE;
       }
    
    

    if (FBDEV_DEV4 == dev) {
        retVal = ioctl(fd_dev0, OMAPFB_SET_UPDATE_MODE, &supdateinfo);
    }
    else if (FBDEV_DEV5 == dev) {
        retVal = ioctl(fd_dev2, OMAPFB_SET_UPDATE_MODE, &supdateinfo);
    }
    else if (FBDEV_INVALID == dev) {
        retVal = ioctl(fd_invalid, OMAPFB_SET_UPDATE_MODE, &supdateinfo);
    } else {
        return E_DEV_NOT_AVAILABLE;
    }
    if (SUCCESS != retVal)
	{
	    perror ("OMAPFB_SET_UPDATE_MODE");  
        return FAILURE;
	}	

    return retVal;

}



/****************************************************************************
 * Function             - st_fbdev_set_colorkey_interface
 * Functionality        - This function executes OMAPFB_SET_COLOR_KEY ioctl
 * Input Params         - device number and variable screen info structure
 *                          pointer
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_set_colorkey_interface(int dev, struct st_omapfb_color_key *st_ckInfo)
{

	int retVal = SUCCESS;
        return retVal;

}

/****************************************************************************
 * Function             - st_fbdev_get_colorkey_interface
 * Functionality        - This function executes OMAPFB_GET_COLOR_KEY ioctl
 * Input Params         - device number and variable screen info structure
 *                          pointer
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_get_colorkey_interface(int dev, struct st_omapfb_color_key *st_ckInfo)
{

	int retVal = SUCCESS;
         return retVal;
}

/****************************************************************************
 * Function             - st_fbdev_change_sysfs_interface
 * Functionality        - This function sets sysfs variables
 * Input Params         - mode_output number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None 
 ****************************************************************************/
int st_fbdev_change_sysfs_interface(char *mode, char *output)
{
    return SUCCESS;
}
/****************************************************************************
 * Function             - video_thread
 * Functionality        - 
 * Input Params         - void
 * Return Value         - 0
 * Note                 - None 
 ****************************************************************************/
void video_thread(void)
{
	int mode = O_RDWR, ret, j, i;
	int fd, a, numbuffers = NUMBUFFERS;
	struct v4l2_requestbuffers req;
	struct v4l2_buffer buf;
	struct buf_info *buff_info;
	struct v4l2_format fmt;
	struct v4l2_crop crop;
	struct v4l2_framebuffer framebuffer;
        static char video_dev_name[20] = {"/dev/video1"};

	/* Open the video1 device */
	fd = open((const char *)video_dev_name, mode); 
	if (fd <= 0) {
		printf("Cannot open = %s device\n", video_dev_name);
		exit(0);
	}

	ret = ioctl (fd, VIDIOC_G_FBUF, &framebuffer);
	if (ret < 0) {
		  perror(("VIDIOC_G_FBUF"));
		exit(1);

	}
	if(framebuffer.capability & V4L2_FBUF_CAP_LOCAL_ALPHA) {

		framebuffer.flags |= V4L2_FBUF_FLAG_LOCAL_ALPHA;
		framebuffer.flags &= ~(V4L2_FBUF_FLAG_CHROMAKEY |
				V4L2_FBUF_FLAG_SRC_CHROMAKEY);

		ret = ioctl (fd, VIDIOC_S_FBUF, &framebuffer);
		if (ret < 0) {
			  perror(("VIDIOC_S_FBUF"));
			exit(1);

		}
	}

	fmt.type = V4L2_BUF_TYPE_VIDEO_OUTPUT;
	ret = ioctl(fd, VIDIOC_G_FMT, &fmt);
	if (ret < 0) {
		  perror(("VIDIOC_G_FMT"));
		close(fd);
		exit(0);
	}
	/* Set the image size pixel format and device type*/
	fmt.fmt.pix.width = IMG_WIDTH;
	fmt.fmt.pix.height = IMG_HEIGHT;

	/* Video1 does not support ARGB so it takes
	 * RGB32 as unpack RGB24
	 */
	fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_RGB32;
	ret = ioctl(fd, VIDIOC_S_FMT, &fmt);
	if (ret < 0) {
		  perror(("VIDIOC_S_FMT"));
		close(fd);
		exit(0);
	}

	crop.type = V4L2_BUF_TYPE_VIDEO_OUTPUT;
	ret = ioctl(fd, VIDIOC_G_CROP, &crop);
	if (ret < 0) {
		  perror(("VIDIOC_G_CROP"));
		close(fd);
		exit(0);
	}
	/* Set the Cropping parameters */
	crop.c.left = 0;
	crop.c.top = 0;
	crop.c.width = IMG_WIDTH;
	crop.c.height = IMG_HEIGHT;
	ret = ioctl(fd, VIDIOC_S_CROP, &crop);
	if (ret < 0) {
		  perror(("VIDIOC_S_CROP"));
		close(fd);
		exit(0);
	}

	fmt.type = V4L2_BUF_TYPE_VIDEO_OVERLAY;
	ret = ioctl(fd, VIDIOC_G_FMT, &fmt);
	if (ret < 0) {
		  perror(("VIDIOC_G_FMT 2"));
		close(fd);
		exit(0);
	}
	/* Set the window size */
	fmt.fmt.win.w.left = 0;
	fmt.fmt.win.w.top = 0;
	fmt.fmt.win.w.width = IMG_WIDTH;
	fmt.fmt.win.w.height = IMG_HEIGHT;
	ret = ioctl(fd, VIDIOC_S_FMT, &fmt);
	if (ret < 0) {
		  perror(("VIDIOC_S_FMT 2"));
		close(fd);
		exit(0);
	}

	fmt.type = V4L2_BUF_TYPE_VIDEO_OUTPUT;
	ret = ioctl(fd, VIDIOC_G_FMT, &fmt);
	if (ret < 0) {
		  perror(("VIDIOC_G_FMT"));
		close(fd);
		exit(0);
	}

	/* Request buffers from driver
	 * Buffer can be driver allocated type MMAP
	 * or userptr
	 */
	req.count = numbuffers;
	req.type = V4L2_BUF_TYPE_VIDEO_OUTPUT;
	req.memory = V4L2_MEMORY_MMAP;

	ret = ioctl(fd, VIDIOC_REQBUFS, &req);
	if (ret < 0) {
		perror(("cannot allocate memory"));
		close(fd);
		exit(0);
	}

	buff_info =
		(struct buf_info *) malloc(sizeof(struct buf_info) *
					   req.count);
	if (!buff_info) {
		printf("cannot allocate memory for buff_info\n");
		close(fd);
		exit(0);
	}
	/* Query the buffer to get the physical address of the allocated
	 * buffers. Get the virtual  address of the buffer by
	 * passing the physical address to mmap call of the driver
	 */
	for (i = 0; i < req.count; i++) {
		buf.type = V4L2_BUF_TYPE_VIDEO_OUTPUT;
		buf.index = i;
		ret = ioctl(fd, VIDIOC_QUERYBUF, &buf);
		if (ret < 0) {
			  perror(("VIDIOC_QUERYCAP"));
			for (j = 0; j < i; j++)
				munmap(buff_info[j].start,
						buff_info[j].length);
			close(fd);
			exit(0);
		}
		buff_info[i].length = buf.length;
		buff_info[i].start =
			mmap(NULL, buf.length, PROT_READ | PROT_WRITE,
					MAP_SHARED, fd, buf.m.offset);

		if ((unsigned int) buff_info[i].start ==
				MAP_SHARED) {
			printf("Cannot mmap = %d buffer\n", i);
			for (j = 0; j < i; j++)
				munmap(buff_info[j].start,
						buff_info[j].length);
			close(fd);
			exit(0);
		}
		memset(buff_info[i].start, 0x80, buff_info[i].length);
		/* Initially fill the buffer */
		fill(buff_info[i].start, fmt.fmt.pix.width,
				fmt.fmt.pix.height, 0);
	}
	memset(&buf, 0, sizeof(buf));

	/* Enqueue buffers */
	for (i = 0; i < req.count; i++) {
		buf.type = V4L2_BUF_TYPE_VIDEO_OUTPUT;
		buf.index = i;
		buf.memory = V4L2_MEMORY_MMAP;
		ret = ioctl(fd, VIDIOC_QBUF, &buf);
		if (ret < 0) {
			  perror(("VIDIOC_QBUF"));
			for (j = 0; j < req.count; j++)
				munmap(buff_info[j].start,
						buff_info[j].length);
			exit(0);
		}
	}
	/* Start streamon */
	a = 0;
	ret = ioctl(fd, VIDIOC_STREAMON, &a);
	if (ret < 0) {
		  perror(("VIDIOC_STREAMON"));
		for (i = 0; i < req.count; i++)
			munmap(buff_info[i].start, buff_info[i].length);
		exit(0);
	}

	/* Forever looop for streaming */
	for(i = 0 ; i < LOOP_COUNT_NUM ; i ++) {
          	ret = ioctl(fd, VIDIOC_DQBUF, &buf);
		if(ret < 0){
			  perror(("VIDIOC_DQBUF"));
			for (j = 0; j < req.count; j++)
				munmap(buff_info[j].start, buff_info[j].length);
			close(fd);
			exit(0);
		}
		/* Filling the buffer without alpha value since video1 does not
		 * support ARGB
		 */
		fill(buff_info[buf.index].start, fmt.fmt.pix.width,
				fmt.fmt.pix.height, 0);
		ret = ioctl(fd, VIDIOC_QBUF, &buf);
		if(ret < 0){
			  perror(("VIDIOC_QBUF"));
			for (j = 0; j < req.count; j++)
				munmap(buff_info[j].start, buff_info[j].length);
			close(fd);
			exit(0);
		}
		sleep(1);
	}

	/* Streaming off */
	ret = ioctl(fd, VIDIOC_STREAMOFF, &a);
	if (ret < 0) {
		  perror(("VIDIOC_STREAMOFF"));
		for (i = 0; i < req.count; i++)
			munmap(buff_info[i].start, buff_info[i].length);
		close(fd);
		exit(0);
	}
	/* Unmap all the buffers */
	for (i = 0; i < req.count; i++)
		munmap(buff_info[i].start, buff_info[i].length);

	ret = ioctl (fd, VIDIOC_G_FBUF, &framebuffer);
	if (ret < 0) {
		  perror(("VIDIOC_G_FBUF"));
		exit(1);

	}
	if(framebuffer.capability & V4L2_FBUF_CAP_LOCAL_ALPHA) {

		framebuffer.flags &= ~V4L2_FBUF_FLAG_LOCAL_ALPHA;

		ret = ioctl (fd, VIDIOC_S_FBUF, &framebuffer);
		if (ret < 0) {
			  perror(("VIDIOC_S_FBUF"));
			exit(1);

		}
	}

	close(fd);
	return;
}
/****************************************************************************
 * Function             - st_fbdev_map_and_disp_interface
 * Functionality        - This function maps FBDEV windowbuffers to user space
 * Input Params         - device number, line length and y resolution
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_map_and_disp_interface(int dev, int st_lineLength, int st_yres)
{
    int status = SUCCESS;
    int vid_size = 0;
    int i = 0;
    unsigned char *buffer_addr = 0;


    vid_size = st_lineLength * st_yres;

    if (FBDEV_DEV4 == dev) {
        /* Map the fbdev dev0 buffers to user space */
        buffer_addr =
            (unsigned char *) mmap(NULL, vid_size,
                                   PROT_READ | PROT_WRITE, MAP_SHARED,
                                   fd_dev0, 0);
            if (MAP_FAILED == dev_display[0]) {
            status = FAILURE;
            return status;
        }

	/* Main loop */
	for (i = 0 ; i < LOOP_COUNT_NUM ; i ++) {
		/* Fill the buffers with the color bars */
		fill_color_bar_second(buffer_addr,  st_lineLength,
				st_yres, i%2);
		sleep(1);
        }
    }  
    DBG_PRINT_TRC0(("Unmaping buffers"));
    
    munmap(buffer_addr, vid_size);
  
    return status;
}
/****************************************************************************
 * Function             - fill_color_bar_second
 * Functionality        - fill_color_bar_second without assigning buffer at bootargs
 * Input Params         - buffer, line length and y resolution
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
void fill_color_bar_second(unsigned char *addr, int width, int height, int index)
{
	unsigned short *start = (unsigned short *)addr;
	unsigned int size = width * (height / 8);
	int i, j;

	if (index) {
		for(i = 0 ; i < 8 ; i ++) {
			for(j = 0 ; j < size / 2 ; j ++) {
				*start = ycbcr_2[1][i];
				start ++;
			}
		}
	} else {
		for(i = 0 ; i < 8 ; i ++) {
			for(j = 0 ; j < size / 2 ; j ++) {
				*start = ycbcr_2[0][i];
				start ++;
			}
		}
	}
}



/* vim: set ts=4 sw=4 tw=80 et:*/
