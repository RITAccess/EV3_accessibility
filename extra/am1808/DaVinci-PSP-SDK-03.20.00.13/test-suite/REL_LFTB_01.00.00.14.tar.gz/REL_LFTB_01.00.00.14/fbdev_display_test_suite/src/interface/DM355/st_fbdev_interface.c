/*
 * st_fbdev_interface.c
 *
 * This file contains the interface specific funtions
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/ 
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/


/*Testcode header file*/
#include "st_fbdev_common.h"


/* macros,structures and enums are defined here*/

#define DEFAULT_NODE "/dev/fb/0"
#define DEFAULT_WIDTH 720
#define DEFAULT_HEIGHT 480
#define DEFAULT_MODE "INTERLACED"
#define DEFAULT_INTERFACE "COMPOSITE"
#define DEFAULT_RESOLUTION  "NTSC"
#define DEFAULT_BPP 16
#define DEFAULT_ZOOM_X 0
#define DEFAULT_ZOOM_Y 0
#define DEFAULT_WINDOW_NAME "/dev/fb/2"
#define DEFAULT_NO_OF_FRAMES 500

/* Global Variables */
struct fbdev_display_testparams testoptions;

/* fbdev window file descriptors */
static int fd_dev0 = -1;
static int fd_dev1 = -1;
static int fd_dev2 = -1;
static int fd_dev3 = -1;
static int fd_invalid = -1;


Int32 st_img_type=0;
/* dev 0 size */
static int dev0_size = 0;
/* dev 1 size */
static int dev1_size = 0;
/* dev 2 size */
static int dev2_size = 0;
/* dev 3 size */
static int dev3_size = 0;


/* display buffers for vid0, vid1, osd0 and osd1 windows */
static unsigned char *dev0_display[ST_OSD_NUM_BUFS];
static unsigned char *dev1_display[ST_VIDEO_NUM_BUFS];
static unsigned char *dev2_display[ST_OSD_NUM_BUFS];
static unsigned char *dev3_display[ST_VIDEO_NUM_BUFS];


/****************************************************************************
 * Function             - st_init_fbdev_display_test_params
 * Functionality        - This function initilaizes the default values for
 * various test case options(which will be exposed as command line arguments)
 * Input Params         -  None
 * Return Value         -  None
 * Note                 -  None
 ****************************************************************************/
void st_init_fbdev_display_test_params()
{
    testoptions.device_name = DEFAULT_NODE;
    testoptions.width = DEFAULT_WIDTH;
    testoptions.height = DEFAULT_HEIGHT;
    testoptions.mode = DEFAULT_MODE;
    testoptions.interface = DEFAULT_INTERFACE;
    testoptions.standard = DEFAULT_RESOLUTION;
    testoptions.bits_per_pixel = DEFAULT_BPP;
    testoptions.zoom_x = DEFAULT_ZOOM_X;
    testoptions.zoom_y = DEFAULT_ZOOM_Y;
    testoptions.window_name = DEFAULT_WINDOW_NAME;
    testoptions.no_of_frames = DEFAULT_NO_OF_FRAMES;

}

/****************************************************************************
 * Function             - display_help
 * Functionality        - This function displays the help/usage
 * Input Params         - None
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/

void st_display_fbdev_display_test_suite_help(void)
{
    printf("FbdevDisplayTestSuite V %s\n", VERSION_STRING);
    printf("Usage:\n"
           "./dm355FbdevDisplayTests <options>\n\n"
           "-n       --devicename     Device name on which display test is to be run\n"
           "\t\t\t\tPossible values-/dev/fb/0,/dev/fb/1\n"
           "-w       --width           Width of the image to be displayed\n"
           "-h       --height          Height of the image to be displayed\n"
           "-m       --mode           The video mode \n"
           "\t\t\t\t Possible values are INTERLACED or PROGRESSIVE\n"
           "-i       --interface	   The interface name \n"
           "\t\t\t\tPossible values are COMPOSITE, COMPONENT and SVIDEO\n"
           "-s       --standard        Name of the standard\n"
           "\t\t\t\tPossible values-ntsc,pal\n"
           "-f       --noofframes      Number of frames to be displayed\n"
           "-b       --bits_per_pixel      The bits per pixel\n"
           "-d       --displayout      Name of the Displayoutput\n"
           "\t\t\t\tPossible values-LCD or TV\n"
           "-t       --testcase name        Name of the special test\n"
           "\t\t\t\tPossible values-stability,api\n"
           "-p       --pixel_format     Pixel formats\n"
           "\t\t\t\tPossible values-YUYV,UYVY,RGB565,RGB888\n"
           "-W       --window_name The attribute window name\n"
           "\t\t\t\tPossible values-/dev/fb1,/dev/osd0\n"
           "-c	   --stability_count   Number of times to run stability test\n"
           "-x       --zoom_x       zooming factor in x-direction- An integer value like1, 2 etc\n"
           "-y       --zoom_y       zooming factor in y-direction- An integer value like1, 2 etc\n"
           "-X       --repos_x       reposition value for x- An integer value like 10, 20 etc\n"
           "-Y       --repos_y       reposition value for y - An integer value like 10, 20etc\n"
           "-F       --Filename      Name of the image file to display\n"
           "\t\t\t\t Make sure the file is as per -w(width),-h(height) configured & in YUV format\n and device node\n"
           "\t\t\t\t and the device name is either /dev/fb/1 or /dev/fb/2"
           "-t       --testname        Name of the special test\n"
           "\t\t\t\tPossible values-stability,api\n"
           "-T       --testcaseid     Test case id string for testers reference/logging purpose\n"
           "\t\t\t\tPossible values- Any String without spaces\n"
           "-?       --help            Displays the help/usage\n"
           "-v       --version         Version of Display Test suite\n");
    exit(0);
}


/****************************************************************************
 * Function             - print_test_params
 * Functionality        - This function prints the test option values
 * Input Params         - Test params structure
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/
void st_print_fbdev_display_test_params(struct fbdev_display_testparams
                                        *testoptions,char *testcaseid)
{
    DBG_PRINT_TST_START((testcaseid));
    DBG_PRINT_TRC0(("The Test is going to start with following values "));
    DBG_PRINT_TRC0(("The device node | %s", testoptions->device_name));
    DBG_PRINT_TRC0(("The height of the image | %d", testoptions->height));
    DBG_PRINT_TRC0(("The width  of the image | %d", testoptions->width));
    DBG_PRINT_TRC0(("The name of the interface is| %s",
                    testoptions->interface));
}


/****************************************************************************
 * Function             - check_interface
 * Functionality        - This function checks the interface
 * Input Params         - None
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/
int st_check_interface(char *interface)
{
    if (strcmp(interface, "COMPOSITE") == 0) {
        return SUCCESS;
    }

      else if (strcmp(interface, "SVIDEO") == 0) {
        return SUCCESS;
    } else {
        DBG_PRINT_ERR(("Interface not supported\n"));
        return FAILURE;
    }
    return SUCCESS;
}

/****************************************************************************
 * Function             - st_check_std
 * Functionality        - This function checks the user input fot standard 
 * Input Params         - standard and interface
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/
int st_check_std(char *standard)
{

   if((!strcmp(standard,"NTSC") == TRUE) || (!strcmp(standard,"PAL") == TRUE))

        return SUCCESS;
    else
        return FAILURE;

}

/****************************************************************************
 * Function             - st_set_std_interface
 * Functionality        - This function checks the user input for standard and interface
 * Input Params         - standard and interface
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/

int st_set_std_interface(char * standard,char *interface)
{

if((st_fbdev_change_sysfs_interface(standard,interface)) == SUCCESS)

        return SUCCESS;
        else
            return FAILURE;
}


/****************************************************************************
 * Function             - check_pixel_format
 * Functionality        - This function checks the user input
 * Input Params         - None
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/
int st_check_pixel_format(char *pixel_format)
{

    if(strcmp(pixel_format,"RGB565") == 0)
    {
    	st_img_type=ST_RGB_565;
        return SUCCESS;
    }

    else if(strcmp(pixel_format,"YUV") == 0)
    {
    	st_img_type=ST_YUV;
        return SUCCESS;
    }

    else if(strcmp(pixel_format,"BITMAP_1") == 0)
    {
    	st_img_type=ST_BITMAP_1;
        return SUCCESS;
    }

    else if(strcmp(pixel_format,"RGB888") == 0)
    {
    	st_img_type=ST_RGB_888;
        return SUCCESS;
    }
	else if(strcmp(pixel_format,"H_PATTERN") == 0)
    {
    	st_img_type=ST_H_PATTERN;
        return SUCCESS;
    }
	else if(strcmp(pixel_format,"V_PATTERN") == 0)
    {
    	st_img_type=ST_V_PATTERN;
        return SUCCESS;
    }

    else
    {
        DBG_PRINT_ERR(("Wrong format entered- Please enter either RGB565, YUYV, UYVY or RGB888\n"));
        return FAILURE;
    }
    return SUCCESS;
}


/****************************************************************************
 * Function             - st_fbdev_open_interface
 * Functionality        - This function opens FBDEV window
 * Input Params         - FBDEV device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_open_interface(int dev)
{
    int fd = -1;

    if (FBDEV_DEV0 == dev) {
        fd_dev0 = open(FB_DEV0, O_RDWR);
        fd = fd_dev0;
    } else if (FBDEV_DEV1 == dev) {
        fd_dev1 = open(FB_DEV1, O_RDWR);
        fd = fd_dev1;
    } else if (FBDEV_DEV2 == dev) {
        fd_dev2 = open(FB_DEV2, O_RDWR);
        fd = fd_dev2;
    } else if (FBDEV_DEV3 == dev) {
        fd_dev3 = open(FB_DEV3, O_RDWR);
        fd = fd_dev3;
    } else if (FBDEV_INVALID == dev) {
        fd_invalid = open(FB_DEV_INVALID, O_RDWR);
        fd = fd_invalid;
    } else {
        return E_DEV_NOT_AVAILABLE;
    }

    if (0 >= fd)
        return FAILURE;

    return SUCCESS;
}


/****************************************************************************
 * Function             - st_fbdev_close_fbdev_inteface
 * Functionality        - This function closes FBDEV window
 * Input Params         - FBDEV device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_close_interface(int dev)
{

    int status = SUCCESS;
    int fd;

    if (FBDEV_DEV0 == dev) {
        status = close(fd_dev0);
        fd = fd_dev0;
    } else if (FBDEV_DEV1 == dev) {
        status = close(fd_dev1);
        fd = fd_dev1;
    } else if (FBDEV_DEV2 == dev) {
        status = close(fd_dev2);
        fd = fd_dev2;
    } else if (FBDEV_DEV3 == dev) {
        status = close(fd_dev3);
        fd = fd_dev3;
    } else {
        return E_DEV_NOT_AVAILABLE;
    }


    if (SUCCESS != status)
        return FAILURE;

    fd = -1;
    return status;

}


/****************************************************************************
 * Function             - st_fbdev_setpos_interface
 * Functionality        - This function sets FBDEV window position
 * Input Params         - FBDEV, device number, x and Y position
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_setpos_interface(int dev, st_vpbe_window_position * st_pos)
{
    vpbe_window_position_t pos;
    int retVal = SUCCESS;

    pos.xpos = st_pos->xpos;
    pos.ypos = st_pos->ypos;

    if (FBDEV_DEV1 == dev) {
        retVal = ioctl(fd_dev1, FBIO_SETPOS, &pos);
    } else if (FBDEV_DEV3 == dev) {
        retVal = ioctl(fd_dev3, FBIO_SETPOS, &pos);
    } else if (FBDEV_DEV0 == dev) {
        retVal = ioctl(fd_dev0, FBIO_SETPOS, &pos);
    } else if (FBDEV_DEV2 == dev) {
        retVal = ioctl(fd_dev2, FBIO_SETPOS, &pos);
    } else {
        return E_DEV_NOT_AVAILABLE;
    }

    if (SUCCESS != retVal) {
        return FAILURE;
    }

    return SUCCESS;
}

/****************************************************************************
 * Function             - st_fbdev_mmap_vid0_interface
 * Functionality        - This function maps FBDEV windowbuffers to user space
 * Input Params         - device number, line length and y resolution
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_mmap_interface(int dev, int st_lineLength, int st_yres)
{
    int status = SUCCESS;
    int i = 0;
    int vid_size = 0;

    vid_size = st_lineLength * st_yres;

    if (FBDEV_DEV1 == dev) {
        /* Map the video0 buffers to user space */
        dev1_display[0] =
            (unsigned char *) mmap(NULL, vid_size * ST_VIDEO_NUM_BUFS,
                                   PROT_READ | PROT_WRITE, MAP_SHARED,
                                   fd_dev1, 0);
        dev1_size = vid_size;
        if (MAP_FAILED == dev1_display[0]) {
            status = FAILURE;
            return status;
        }
        for (i = 0; i < ST_VIDEO_NUM_BUFS - 1; i++) {
            dev1_display[i + 1] = dev1_display[i] + dev1_size;
        }
    } else if (FBDEV_DEV3 == dev) {
        /* Map the video0 buffers to user space */
        dev3_display[0] =
            (unsigned char *) mmap(NULL, vid_size * ST_VIDEO_NUM_BUFS,
                                   PROT_READ | PROT_WRITE, MAP_SHARED,
                                   fd_dev3, 0);
        dev3_size = vid_size;
        if (MAP_FAILED == dev3_display[0]) {
            status = FAILURE;
            return status;
        }
        for (i = 0; i < ST_VIDEO_NUM_BUFS - 1; i++) {
            dev3_display[i + 1] = dev3_display[i] + dev3_size;
        }
    } else if (FBDEV_DEV0 == dev) {
        /* Map the video0 buffers to user space */
        dev0_display[0] =
            (unsigned char *) mmap(NULL, vid_size * ST_OSD_NUM_BUFS,
                                   PROT_READ | PROT_WRITE, MAP_SHARED,
                                   fd_dev0, 0);
        dev0_size = vid_size;
        if (MAP_FAILED == dev0_display[0]) {
            status = FAILURE;
            return status;
        }
        for (i = 0; i < ST_OSD_NUM_BUFS - 1; i++) {
            dev0_display[i + 1] = dev0_display[i] + dev0_size;
        }
    } else if (FBDEV_DEV2 == dev) {
        /* Map the video0 buffers to user space */
        dev2_display[0] =
            (unsigned char *) mmap(NULL, vid_size * ST_OSD_NUM_BUFS,
                                   PROT_READ | PROT_WRITE, MAP_SHARED,
                                   fd_dev2, 0);
        dev2_size = vid_size;
        if (MAP_FAILED == dev2_display[0]) {
            status = FAILURE;
            return status;
        }
        for (i = 0; i < ST_OSD_NUM_BUFS - 1; i++) {
            dev2_display[i + 1] = dev2_display[i] + dev2_size;
        }
    } else {
        return E_DEV_NOT_AVAILABLE;
    }

    return status;

}

/****************************************************************************
 * Function             - st_fbdev_unmap_interface
 * Functionality        - This function unmaps buffers
 * Input Params         - device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_unmap_interface(int dev)
{
    int retVal = SUCCESS;

    if (FBDEV_DEV1 == dev) {
        retVal = munmap(dev1_display[0], dev1_size * ST_VIDEO_NUM_BUFS);
        dev1_size = 0;
    } else if (FBDEV_DEV3 == dev) {
        retVal = munmap(dev3_display[0], dev3_size * ST_VIDEO_NUM_BUFS);
        dev3_size = 0;
    } else if (FBDEV_DEV0 == dev) {
        retVal = munmap(dev0_display[0], dev0_size * ST_OSD_NUM_BUFS);
        dev0_size = 0;
    } else if (FBDEV_DEV2 == dev) {
        retVal = munmap(dev2_display[0], dev2_size * ST_OSD_NUM_BUFS);
        dev2_size = 0;
    } else {
        return E_DEV_NOT_AVAILABLE;
    }

    if (SUCCESS != retVal)
        return FAILURE;
    /*restore the windows*/
    if (FBDEV_DEV0 == dev)
        system("fbset -fb /dev/fb/0 -xres 720 -yres 480 -vxres 720 -vyres 960 -depth 16");
    else if (FBDEV_DEV1 == dev)
        system("fbset -fb /dev/fb/1 -xres 720 -yres 480 -vxres 720 -vyres 1440 -depth 16");
    else if (FBDEV_DEV2 == dev)
        system("fbset -fb /dev/fb/2 -xres 720 -yres 480 -vxres 720 -vyres 960 -depth 4");
    else if (FBDEV_DEV3 == dev)
        system("fbset -fb /dev/fb/3 -xres 720 -yres 480 -vxres 720 -vyres 1440 -depth 16");
    return SUCCESS;
}


/****************************************************************************
 * Function             - st_fbdev_display_interface
 * Functionality        - This function displays buffers on FBDEV window
 * Input Params         - device number, width and height of the image
 * Return Value         - -1 on failure, else display ID is returned
 * Note                 - None
 ****************************************************************************/
int st_fbdev_display_interface(int dev, int width, int height,
                               int st_img_type, char *image_name)
{

    static unsigned int nDisplayIdx = 0;
    static unsigned int nWorkingIndex = 1;
    unsigned char *src = NULL;
    unsigned char *vidiPtr = NULL;
    static unsigned int vidlineNo = 0;
    FILE *fp = NULL;
    int numBufs = 0;
    int size = 0;


    vidlineNo = vidlineNo % (height - 1);

    if (image_name != NULL) {
        fp = fopen(image_name, "rb");
        if (fp == NULL) {
            return FAILURE;
        }
    } else if (ST_YUV == st_img_type) {
        fp = fopen(PAL_IMAGE, "rb");
        if (fp == NULL) {
            return FAILURE;
        }
    } else if (ST_RGB_565 == st_img_type) {
        fp = fopen(PAL_RGB565_IMAGE, "rb");
        if (fp == NULL) {
            return FAILURE;
        }
    } else if (ST_BITMAP_1 == st_img_type) {
        fp = fopen(BITMAP_1, "rb");
        if (fp == NULL) {
            return FAILURE;
        }
    } else if (ST_BITMAP_8 == st_img_type) {
        fp = fopen(BITMAP_8, "rb");
        if (fp == NULL) {
            return FAILURE;
        }
    } else if (ST_RGB_888 == st_img_type) {
        fp = fopen(PAL_RGB888_IMAGE, "rb");
        if (fp == NULL) {
            return FAILURE;
        }
    }

    if (FBDEV_DEV1 == dev) {
        src = dev1_display[nWorkingIndex];
        fread(src, dev1_size, 1, fp);
        fclose(fp);
        numBufs = ST_VIDEO_NUM_BUFS;
        size = dev1_size;
    } else if (FBDEV_DEV3 == dev) {
        src = dev3_display[nWorkingIndex];
        fread(src, dev3_size, 1, fp);
        fclose(fp);
        numBufs = ST_VIDEO_NUM_BUFS;
        size = dev3_size;
    } else if (FBDEV_DEV0 == dev) {
        src = dev0_display[nWorkingIndex];
        fread(src, dev0_size, 1, fp);
        fclose(fp);
        numBufs = ST_OSD_NUM_BUFS;
    } else if (FBDEV_DEV2 == dev) {
        if (ST_ATTRIB == st_img_type) {
            src = dev2_display[nWorkingIndex];
            memset(dev2_display, 0xC2 /*attribute */ , dev2_size);
        } else {

            src = dev2_display[nWorkingIndex];
            fread(src, dev2_size, 1, fp);
            fclose(fp);
            numBufs = ST_OSD_NUM_BUFS;
        }
    } else {
        return E_DEV_NOT_AVAILABLE;
    }

    if (dev == FBDEV_DEV1 || dev == FBDEV_DEV3) {
        /* set scrolling line */
        vidiPtr = src;
        if (NULL != vidiPtr) {
            memset((vidiPtr + ((size / height) * vidlineNo)), 0xFFFFFFFF,
                   ((size / height) * 2));
            vidlineNo++;
        }
    }
    nWorkingIndex = (nWorkingIndex + 1) % numBufs;
    nDisplayIdx = (nDisplayIdx + 1) % numBufs;

    return nDisplayIdx;


}



/****************************************************************************
 * Function             - st_fbdev_getFscreenInfo_interface
 * Functionality        - This function gets fixed screen info 
 * Input Params         - device number and fix screen info structure pointer
 * Return Value         - -1 on failure, else display ID is returned
 * Note                 - None
 ****************************************************************************/
int st_fbdev_getFscreenInfo_interface(int dev,
                                      st_fb_fix_screeninfo * fixInfo)
{
    int retVal = SUCCESS;
    struct fb_fix_screeninfo fInfo;

    if (FBDEV_DEV1 == dev) {
        retVal = ioctl(fd_dev1, FBIOGET_FSCREENINFO, &fInfo);
    } else if (FBDEV_DEV3 == dev) {
        retVal = ioctl(fd_dev3, FBIOGET_FSCREENINFO, &fInfo);
    } else if (FBDEV_DEV0 == dev) {
        retVal = ioctl(fd_dev0, FBIOGET_FSCREENINFO, &fInfo);
    } else if (FBDEV_DEV2 == dev) {
        retVal = ioctl(fd_dev2, FBIOGET_FSCREENINFO, &fInfo);
    } else if (FBDEV_INVALID == dev) {
        retVal = ioctl(fd_invalid, FBIOGET_FSCREENINFO, &fInfo);
    } else {
        return E_DEV_NOT_AVAILABLE;
    }

    if (SUCCESS != retVal)
        return FAILURE;

    /* copy data to testcase user structure */
    strcpy(fixInfo->id, fInfo.id);
    fixInfo->smem_start = fInfo.smem_start;
    fixInfo->smem_len = fInfo.smem_len;
    fixInfo->type = fInfo.type;
    fixInfo->type_aux = fInfo.type_aux;
    fixInfo->visual = fInfo.visual;
    fixInfo->xpanstep = fInfo.xpanstep;
    fixInfo->ypanstep = fInfo.ypanstep;
    fixInfo->ywrapstep = fInfo.ywrapstep;
    fixInfo->line_length = fInfo.line_length;
    fixInfo->mmio_start = fInfo.mmio_start;

    fixInfo->mmio_len = fInfo.mmio_len;
    fixInfo->accel = fInfo.accel;

    fixInfo->reserved[0] = fInfo.reserved[0];
    fixInfo->reserved[1] = fInfo.reserved[1];
    fixInfo->reserved[2] = fInfo.reserved[2];

    return retVal;
}



/****************************************************************************
 * Function             - st_fbdev_getVscreenInfo_interface
 * Functionality        - This function gets variable info of the screen
 * Input Params         - device number and variable screen info structure
 *                          pointer
 * Return Value         - -1 on failure, else display ID is returned
 * Note                 - None
 ****************************************************************************/
int st_fbdev_getVscreenInfo_interface(int dev,
                                      st_fb_var_screeninfo * varInfo)
{
    int retVal = SUCCESS;

    struct fb_var_screeninfo vInfo;

    if (FBDEV_DEV1 == dev) {
        retVal = ioctl(fd_dev1, FBIOGET_VSCREENINFO, &vInfo);
    } else if (FBDEV_DEV3 == dev) {
        retVal = ioctl(fd_dev3, FBIOGET_VSCREENINFO, &vInfo);
    } else if (FBDEV_DEV0 == dev) {
        retVal = ioctl(fd_dev0, FBIOGET_VSCREENINFO, &vInfo);
    } else if (FBDEV_DEV2 == dev) {
        retVal = ioctl(fd_dev2, FBIOGET_VSCREENINFO, &vInfo);
    } else {
        return E_DEV_NOT_AVAILABLE;
    }

    if (SUCCESS != retVal)
        return FAILURE;

    /* copy data to testcase user structure */
    varInfo->xres = vInfo.xres;
    varInfo->yres = vInfo.yres;
    varInfo->xres_virtual = vInfo.xres_virtual;
    varInfo->yres_virtual = vInfo.yres_virtual;
    varInfo->xoffset = vInfo.xoffset;
    varInfo->yoffset = vInfo.yoffset;
    varInfo->bits_per_pixel = vInfo.bits_per_pixel;
    varInfo->grayscale = vInfo.grayscale;

    varInfo->red.offset = vInfo.red.offset;
    varInfo->red.length = vInfo.red.length;
    varInfo->red.msb_right = vInfo.red.msb_right;

    varInfo->green.offset = vInfo.green.offset;
    varInfo->green.length = vInfo.green.length;
    varInfo->green.msb_right = vInfo.green.msb_right;

    varInfo->blue.offset = vInfo.blue.offset;
    varInfo->blue.length = vInfo.blue.length;
    varInfo->blue.msb_right = vInfo.blue.msb_right;

    varInfo->transp.offset = vInfo.transp.offset;
    varInfo->transp.length = vInfo.transp.length;
    varInfo->transp.msb_right = vInfo.transp.msb_right;

    varInfo->nonstd = vInfo.nonstd;
    varInfo->activate = vInfo.activate;
    varInfo->height = vInfo.height;
    varInfo->width = vInfo.width;
    varInfo->accel_flags = vInfo.accel_flags;
    varInfo->pixclock = vInfo.pixclock;
    varInfo->left_margin = vInfo.left_margin;
    varInfo->right_margin = vInfo.right_margin;
    varInfo->upper_margin = vInfo.upper_margin;
    varInfo->lower_margin = vInfo.lower_margin;
    varInfo->hsync_len = vInfo.hsync_len;
    varInfo->vsync_len = vInfo.vsync_len;
    varInfo->sync = vInfo.sync;
    varInfo->vmode = vInfo.vmode;
    varInfo->rotate = vInfo.rotate;
    varInfo->reserved[0] = vInfo.reserved[0];
    varInfo->reserved[1] = vInfo.reserved[1];
    varInfo->reserved[2] = vInfo.reserved[2];
    varInfo->reserved[3] = vInfo.reserved[3];
    varInfo->reserved[4] = vInfo.reserved[4];

    return retVal;

}


/****************************************************************************
 * Function             - st_fbdev_getVscreenInfo_interface
 * Functionality        - device number and variable screen info structure
 *                          pointer
 * Return Value         - -1 on failure, else display ID is returned
 * Note                 - None
 ****************************************************************************/
int st_fbdev_putVscreenInfo_interface(int dev,
                                      st_fb_var_screeninfo * varInfo)
{
    int retVal = SUCCESS;
    struct fb_var_screeninfo vid_varInfo;

    /* copy data to testcase user structure */
    vid_varInfo.xres = varInfo->xres;
    vid_varInfo.yres = varInfo->yres;
    vid_varInfo.xres_virtual = varInfo->xres_virtual;
    vid_varInfo.yres_virtual = varInfo->yres_virtual;
    vid_varInfo.xoffset = varInfo->xoffset;
    vid_varInfo.yoffset = varInfo->yoffset;
    vid_varInfo.bits_per_pixel = varInfo->bits_per_pixel;
    vid_varInfo.grayscale = varInfo->grayscale;

    vid_varInfo.red.offset = varInfo->red.offset;
    vid_varInfo.red.length = varInfo->red.length;
    vid_varInfo.red.msb_right = varInfo->red.msb_right;

    vid_varInfo.green.offset = varInfo->green.offset;
    vid_varInfo.green.length = varInfo->green.length;
    vid_varInfo.green.msb_right = varInfo->green.msb_right;

    vid_varInfo.blue.offset = varInfo->blue.offset;
    vid_varInfo.blue.length = varInfo->blue.length;
    vid_varInfo.blue.msb_right = varInfo->blue.msb_right;

    vid_varInfo.transp.offset = varInfo->transp.offset;
    vid_varInfo.transp.length = varInfo->transp.length;
    vid_varInfo.transp.msb_right = varInfo->transp.msb_right;

    vid_varInfo.nonstd = varInfo->nonstd;
    vid_varInfo.activate = varInfo->activate;
    vid_varInfo.height = varInfo->height;
    vid_varInfo.width = varInfo->width;
    vid_varInfo.accel_flags = varInfo->accel_flags;
    vid_varInfo.pixclock = varInfo->pixclock;
    vid_varInfo.left_margin = varInfo->left_margin;
    vid_varInfo.right_margin = varInfo->right_margin;
    vid_varInfo.upper_margin = varInfo->upper_margin;
    vid_varInfo.lower_margin = varInfo->lower_margin;
    vid_varInfo.hsync_len = varInfo->hsync_len;
    vid_varInfo.vsync_len = varInfo->vsync_len;
    vid_varInfo.sync = varInfo->sync;
    vid_varInfo.vmode = varInfo->vmode;
    vid_varInfo.rotate = varInfo->rotate;
    vid_varInfo.reserved[0] = varInfo->reserved[0];
    vid_varInfo.reserved[1] = varInfo->reserved[1];
    vid_varInfo.reserved[2] = varInfo->reserved[2];
    vid_varInfo.reserved[3] = varInfo->reserved[3];
    vid_varInfo.reserved[4] = varInfo->reserved[4];

    if (ST_ROTATE_0 != vid_varInfo.rotate) {
        return E_ROTATION_NOT_SUPPORTED;
    }

    /* call Ioctl */
    if (FBDEV_DEV1 == dev) {
        retVal = ioctl(fd_dev1, FBIOPUT_VSCREENINFO, &vid_varInfo);
    } else if (FBDEV_DEV3 == dev) {
        retVal = ioctl(fd_dev3, FBIOPUT_VSCREENINFO, &vid_varInfo);
    } else if (FBDEV_DEV0 == dev) {
        retVal = ioctl(fd_dev0, FBIOPUT_VSCREENINFO, &vid_varInfo);
    } else if (FBDEV_DEV2 == dev) {
        retVal = ioctl(fd_dev2, FBIOPUT_VSCREENINFO, &vid_varInfo);
    } else {
        return E_DEV_NOT_AVAILABLE;
    }

    if (SUCCESS != retVal)
        return FAILURE;

    return retVal;

}



/****************************************************************************
 * Function             - st_fbdev_blank_window_interface
 * Functionality        - This function enables or disables FBDEV window
 * Input Params         - window name, enable/disable option
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_blank_window_interface(int dev, Bool st_blank)
{
    int retVal = SUCCESS;

    if (FBDEV_DEV1 == dev) {
        retVal = ioctl(fd_dev1, FBIOBLANK, st_blank);
    } else if (FBDEV_DEV3 == dev) {
        retVal = ioctl(fd_dev3, FBIOBLANK, st_blank);
    } else if (FBDEV_DEV0 == dev) {
        retVal = ioctl(fd_dev0, FBIOBLANK, st_blank);
    } else if (FBDEV_DEV2 == dev) {
        retVal = ioctl(fd_dev2, FBIOBLANK, st_blank);
    } else {
        return E_DEV_NOT_AVAILABLE;
    }

    if (SUCCESS != retVal)
        return FAILURE;

    return SUCCESS;
}


/****************************************************************************
 * Function             - st_fbdev_waitforsync_interface
 * Functionality        - This function executes FBIO_WAITFORVSYNC ioctl
 * Input Params         - device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_waitforsync_interface(int dev)
{
    int retVal = SUCCESS;
    int dummy;

    /* Wait for vertical sync */
    if (FBDEV_DEV1 == dev) {
        retVal = ioctl(fd_dev1, FBIO_WAITFORVSYNC, &dummy);
    } else if (FBDEV_DEV3 == dev) {
        retVal = ioctl(fd_dev3, FBIO_WAITFORVSYNC, &dummy);
    } else if (FBDEV_DEV0 == dev) {
        retVal = ioctl(fd_dev0, FBIO_WAITFORVSYNC, &dummy);
    } else if (FBDEV_DEV2 == dev) {
        retVal = ioctl(fd_dev2, FBIO_WAITFORVSYNC, &dummy);
    } else {
        return E_DEV_NOT_AVAILABLE;
    }

    if (SUCCESS != retVal)
        return FAILURE;

    return retVal;

}


/****************************************************************************
 * Function             - st_fbdev_pandisplay_interface
 * Functionality        - This function executes FBIOPAN_DISPLAY ioctl
 * Input Params         - device number and variable screen info structure
 *                          pointer
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_pandisplay_interface(int dev, st_fb_var_screeninfo * varInfo)
{

    int retVal = SUCCESS;
    struct fb_var_screeninfo vid_varInfo;
    int fd = -1;

    if (FBDEV_DEV1 == dev) {
        fd = fd_dev1;
    } else if (FBDEV_DEV3 == dev) {
        fd = fd_dev3;
    } else if (FBDEV_DEV0 == dev) {
        fd = fd_dev0;
    } else if (FBDEV_DEV2 == dev) {
        fd = fd_dev2;
    } else {
        return E_DEV_NOT_AVAILABLE;
    }
    /* copy data to testcase user structure */
    vid_varInfo.xres = varInfo->xres;
    vid_varInfo.yres = varInfo->yres;
    vid_varInfo.xres_virtual = varInfo->xres_virtual;
    vid_varInfo.yres_virtual = varInfo->yres_virtual;
    vid_varInfo.xoffset = varInfo->xoffset;
    vid_varInfo.yoffset = varInfo->yoffset;
    vid_varInfo.bits_per_pixel = varInfo->bits_per_pixel;
    vid_varInfo.grayscale = varInfo->grayscale;

    vid_varInfo.red.offset = varInfo->red.offset;
    vid_varInfo.red.length = varInfo->red.length;
    vid_varInfo.red.msb_right = varInfo->red.msb_right;

    vid_varInfo.green.offset = varInfo->green.offset;
    vid_varInfo.green.length = varInfo->green.length;
    vid_varInfo.green.msb_right = varInfo->green.msb_right;

    vid_varInfo.blue.offset = varInfo->blue.offset;
    vid_varInfo.blue.length = varInfo->blue.length;
    vid_varInfo.blue.msb_right = varInfo->blue.msb_right;

    vid_varInfo.transp.offset = varInfo->transp.offset;
    vid_varInfo.transp.length = varInfo->transp.length;
    vid_varInfo.transp.msb_right = varInfo->transp.msb_right;

    vid_varInfo.nonstd = varInfo->nonstd;
    vid_varInfo.activate = varInfo->activate;
    vid_varInfo.height = varInfo->height;
    vid_varInfo.width = varInfo->width;
    vid_varInfo.accel_flags = varInfo->accel_flags;
    vid_varInfo.pixclock = varInfo->pixclock;
    vid_varInfo.left_margin = varInfo->left_margin;
    vid_varInfo.right_margin = varInfo->right_margin;
    vid_varInfo.upper_margin = varInfo->upper_margin;
    vid_varInfo.lower_margin = varInfo->lower_margin;
    vid_varInfo.hsync_len = varInfo->hsync_len;
    vid_varInfo.vsync_len = varInfo->vsync_len;
    vid_varInfo.sync = varInfo->sync;
    vid_varInfo.vmode = varInfo->vmode;
    vid_varInfo.rotate = varInfo->rotate;
    vid_varInfo.reserved[0] = varInfo->reserved[0];
    vid_varInfo.reserved[1] = varInfo->reserved[1];
    vid_varInfo.reserved[2] = varInfo->reserved[2];
    vid_varInfo.reserved[3] = varInfo->reserved[3];
    vid_varInfo.reserved[4] = varInfo->reserved[4];

    /* Swap the working buffer for the displayed buffer */
    retVal = ioctl(fd, FBIOPAN_DISPLAY, &vid_varInfo);
    if (retVal != SUCCESS)
        return FAILURE;

    return retVal;

}



/****************************************************************************
 * Function             - st_fbdev_setBitmatBlendFactor_ioctl_interface
 * Functionality        - This function executes st_fbdev_setBitmatBlendFactor_ioctl_interface ioctl
 * Input Params         - device number and st_vpbe_bitmap_blend_params structurepointer
 *                          pointer
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_setBitmatBlendFactor_ioctl_interface(int dev,
                                                  st_vpbe_bitmap_blend_params
                                                  * st_bFactor)
{
    int retVal = SUCCESS;
    vpbe_bitmap_blend_params_t bFactor;
    int fd = -1;

    bFactor.bf = st_bFactor->bf;
    bFactor.colorkey = st_bFactor->colorkey;
    bFactor.enable_colorkeying = st_bFactor->enable_colorkeying;

    if (FBDEV_DEV1 == dev) {
        fd = fd_dev1;
    } else if (FBDEV_DEV3 == dev) {
        fd = fd_dev3;
    } else if (FBDEV_DEV0 == dev) {
        fd = fd_dev0;
    } else if (FBDEV_DEV2 == dev) {
        fd = fd_dev2;
    } else {
        return E_DEV_NOT_AVAILABLE;
    }

    retVal = ioctl(fd, FBIO_SET_BITMAP_BLEND_FACTOR, &bFactor);
    if (retVal != SUCCESS)
        return FAILURE;

    return retVal;

}


/****************************************************************************
 * Function             - st_fbdev_setBlinkInterval_ioctl_interface
 * Functionality        - This function executes FBIO_SET_BLINK_INTERVAL  ioctl
 * Input Params         - device number and st_vpbe_blink_option structurepointer
 *                          pointer
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_setBlinkInterval_ioctl_interface(int st_dev,
                                              st_vpbe_blink_option *
                                              st_setBlink)
{
    int retVal = SUCCESS;
    vpbe_blink_option_t setBlink;
    int fd = -1;

    setBlink.blinking = st_setBlink->blinking;
    setBlink.interval = st_setBlink->interval;

    if (FBDEV_DEV1 == st_dev) {
        fd = fd_dev1;
    } else if (FBDEV_DEV3 == st_dev) {
        fd = fd_dev3;
    } else if (FBDEV_DEV0 == st_dev) {
        fd = fd_dev0;
    } else if (FBDEV_DEV2 == st_dev) {
        fd = fd_dev2;
    } else {
        return E_DEV_NOT_AVAILABLE;
    }

    retVal = ioctl(fd, FBIO_SET_BLINK_INTERVAL, &setBlink);
    if (retVal != SUCCESS)
        return FAILURE;

    return retVal;

}



/****************************************************************************
 * Function             - st_fbdev_setBitmatBlendFactor_ioctl_interface
 * Functionality        - This function executes FBIO_GET_BLINK_INTERVAL ioctl
 * Input Params         - device number and st_vpbe_blink_option structurepointer
 *                          pointer
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_getBlinkInterval_ioctl_interface(int st_dev,
                                              st_vpbe_blink_option *
                                              st_getBlink)
{
    int retVal = SUCCESS;
    vpbe_blink_option_t getBlink;
    int fd = -1;

    if (FBDEV_DEV1 == st_dev) {
        fd = fd_dev1;
    } else if (FBDEV_DEV3 == st_dev) {
        fd = fd_dev3;
    } else if (FBDEV_DEV0 == st_dev) {
        fd = fd_dev0;
    } else if (FBDEV_DEV2 == st_dev) {
        fd = fd_dev2;
    } else {
        return E_DEV_NOT_AVAILABLE;
    }

    retVal = ioctl(fd, FBIO_GET_BLINK_INTERVAL, &getBlink);
    if (retVal != SUCCESS)
        return FAILURE;

    st_getBlink->blinking = getBlink.blinking;
    st_getBlink->interval = getBlink.interval;


    return retVal;

}


/****************************************************************************
 * Function             - st_fbdev_getVideoConfigParams_ioctl_interface
 * Functionality        - This function executes FBIO_GET_VIDEO_CONFIG_PARAMS ioctl
 * Input Params         - device number and st_vpbe_video_config_params structurepointer
 *                          pointer
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_getVideoConfigParams_ioctl_interface(int dev,
                                                  st_vpbe_video_config_params
                                                  * st_getparams)
{
    int retVal = SUCCESS;
    vpbe_video_config_params_t getParams;
    int fd = -1;

    if (FBDEV_DEV1 == dev) {
        fd = fd_dev1;
    } else if (FBDEV_DEV3 == dev) {
        fd = fd_dev3;
    } else if (FBDEV_DEV0 == dev) {
        fd = fd_dev0;
    } else if (FBDEV_DEV2 == dev) {
        fd = fd_dev2;
    } else {
        return E_DEV_NOT_AVAILABLE;
    }

    retVal = ioctl(fd, FBIO_GET_VIDEO_CONFIG_PARAMS, &getParams);
    if (retVal != SUCCESS)
        return FAILURE;

    st_getparams->cb_cr_order = getParams.cb_cr_order;
    st_getparams->exp_info.horizontal = getParams.exp_info.horizontal;
    st_getparams->exp_info.vertical = getParams.exp_info.vertical;

    return retVal;

}


/****************************************************************************
 * Function             - st_fbdev_setVideoConfigParams_ioctl_interface
 * Functionality        - This function executes FBIO_SET_VIDEO_CONFIG_PARAMS ioctl
 * Input Params         - device number and st_vpbe_video_config_params structurepointer
 *                          pointer
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_setVideoConfigParams_ioctl_interface(int dev,
                                                  st_vpbe_video_config_params
                                                  * st_setparams)
{
    int retVal = SUCCESS;
    vpbe_video_config_params_t setParams;
    int fd = -1;

    setParams.cb_cr_order = st_setparams->cb_cr_order;
    setParams.exp_info.horizontal = st_setparams->exp_info.horizontal;
    setParams.exp_info.vertical = st_setparams->exp_info.vertical;


    if (FBDEV_DEV1 == dev) {
        fd = fd_dev1;
    } else if (FBDEV_DEV3 == dev) {
        fd = fd_dev3;
    } else if (FBDEV_DEV0 == dev) {
        fd = fd_dev0;
    } else if (FBDEV_DEV2 == dev) {
        fd = fd_dev2;
    } else {
        return E_DEV_NOT_AVAILABLE;
    }

    retVal = ioctl(fd, FBIO_SET_VIDEO_CONFIG_PARAMS, &setParams);
    if (retVal != SUCCESS)
        return FAILURE;

    return retVal;

}


/****************************************************************************
 * Function             - st_fbdev_getBitmapConfigParams_ioctl_interface
 * Functionality        - This function executes FBIO_GET_BITMAP_CONFIG_PARAMS ioctl
 * Input Params         - device number and st_vpbe_bitmap_config_params structure pointer
 *                          pointer
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_getBitmapConfigParams_ioctl_interface(int dev,
                                                   st_vpbe_bitmap_config_params
                                                   * st_getparams)
{
    int retVal = SUCCESS;
    int fd = -1;
    vpbe_bitmap_config_params_t getparams;

    if (FBDEV_DEV1 == dev) {
        fd = fd_dev1;
    } else if (FBDEV_DEV3 == dev) {
        fd = fd_dev3;
    } else if (FBDEV_DEV0 == dev) {
        fd = fd_dev0;
    } else if (FBDEV_DEV2 == dev) {
        fd = fd_dev2;
    } else {
        return E_DEV_NOT_AVAILABLE;
    }

    retVal = ioctl(fd, FBIO_GET_BITMAP_CONFIG_PARAMS, &getparams);
    if (retVal != SUCCESS)
        return FAILURE;

    st_getparams->attenuation_enable = getparams.attenuation_enable;
    st_getparams->clut_select = getparams.clut_select;

    st_getparams->clut_idx.st_for_1bit_bitmap_t.bitmap_val_0 =
        getparams.clut_idx.for_1bit_bitmap.bitmap_val_0;
    st_getparams->clut_idx.st_for_1bit_bitmap_t.bitmap_val_1 =
        getparams.clut_idx.for_1bit_bitmap.bitmap_val_1;

    st_getparams->clut_idx.st_for_2bit_bitmap_t.bitmap_val_0 =
        getparams.clut_idx.for_2bit_bitmap.bitmap_val_0;
    st_getparams->clut_idx.st_for_2bit_bitmap_t.bitmap_val_1 =
        getparams.clut_idx.for_2bit_bitmap.bitmap_val_1;
    st_getparams->clut_idx.st_for_2bit_bitmap_t.bitmap_val_2 =
        getparams.clut_idx.for_2bit_bitmap.bitmap_val_2;
    st_getparams->clut_idx.st_for_2bit_bitmap_t.bitmap_val_3 =
        getparams.clut_idx.for_2bit_bitmap.bitmap_val_3;

    st_getparams->clut_idx.st_for_4bit_bitmap_t.bitmap_val_0 =
        getparams.clut_idx.for_4bit_bitmap.bitmap_val_0;
    st_getparams->clut_idx.st_for_4bit_bitmap_t.bitmap_val_1 =
        getparams.clut_idx.for_4bit_bitmap.bitmap_val_1;
    st_getparams->clut_idx.st_for_4bit_bitmap_t.bitmap_val_2 =
        getparams.clut_idx.for_4bit_bitmap.bitmap_val_2;
    st_getparams->clut_idx.st_for_4bit_bitmap_t.bitmap_val_3 =
        getparams.clut_idx.for_4bit_bitmap.bitmap_val_3;
    st_getparams->clut_idx.st_for_4bit_bitmap_t.bitmap_val_4 =
        getparams.clut_idx.for_4bit_bitmap.bitmap_val_4;
    st_getparams->clut_idx.st_for_4bit_bitmap_t.bitmap_val_5 =
        getparams.clut_idx.for_4bit_bitmap.bitmap_val_5;
    st_getparams->clut_idx.st_for_4bit_bitmap_t.bitmap_val_6 =
        getparams.clut_idx.for_4bit_bitmap.bitmap_val_6;
    st_getparams->clut_idx.st_for_4bit_bitmap_t.bitmap_val_7 =
        getparams.clut_idx.for_4bit_bitmap.bitmap_val_7;
    st_getparams->clut_idx.st_for_4bit_bitmap_t.bitmap_val_8 =
        getparams.clut_idx.for_4bit_bitmap.bitmap_val_8;
    st_getparams->clut_idx.st_for_4bit_bitmap_t.bitmap_val_9 =
        getparams.clut_idx.for_4bit_bitmap.bitmap_val_9;
    st_getparams->clut_idx.st_for_4bit_bitmap_t.bitmap_val_10 =
        getparams.clut_idx.for_4bit_bitmap.bitmap_val_10;
    st_getparams->clut_idx.st_for_4bit_bitmap_t.bitmap_val_11 =
        getparams.clut_idx.for_4bit_bitmap.bitmap_val_11;
    st_getparams->clut_idx.st_for_4bit_bitmap_t.bitmap_val_12 =
        getparams.clut_idx.for_4bit_bitmap.bitmap_val_12;
    st_getparams->clut_idx.st_for_4bit_bitmap_t.bitmap_val_13 =
        getparams.clut_idx.for_4bit_bitmap.bitmap_val_13;
    st_getparams->clut_idx.st_for_4bit_bitmap_t.bitmap_val_14 =
        getparams.clut_idx.for_4bit_bitmap.bitmap_val_14;
    st_getparams->clut_idx.st_for_4bit_bitmap_t.bitmap_val_15 =
        getparams.clut_idx.for_4bit_bitmap.bitmap_val_15;
    return retVal;

}


/****************************************************************************
 * Function             - st_fbdev_setBitmapConfigParams_ioctl_interface
 * Functionality        - This function executes FBIO_SET_BITMAP_CONFIG_PARAMS ioctl
 * Input Params         - device number and st_vpbe_bitmap_config_params structure pointer
 *                          pointer
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_setBitmapConfigParams_ioctl_interface(int dev,
                                                   st_vpbe_bitmap_config_params
                                                   * st_setparams)
{
    int retVal = SUCCESS;
    int fd = -1;
    vpbe_bitmap_config_params_t setparams;

    if (FBDEV_DEV1 == dev) {
        fd = fd_dev1;
    } else if (FBDEV_DEV3 == dev) {
        fd = fd_dev3;
    } else if (FBDEV_DEV0 == dev) {
        fd = fd_dev0;
    } else if (FBDEV_DEV2 == dev) {
        fd = fd_dev2;
    } else {
        return E_DEV_NOT_AVAILABLE;
    }

    setparams.attenuation_enable = st_setparams->attenuation_enable;
    setparams.clut_select = st_setparams->clut_select;

    setparams.clut_idx.for_1bit_bitmap.bitmap_val_0 =
        st_setparams->clut_idx.st_for_1bit_bitmap_t.bitmap_val_0;
    setparams.clut_idx.for_1bit_bitmap.bitmap_val_1 =
        st_setparams->clut_idx.st_for_1bit_bitmap_t.bitmap_val_1;

    setparams.clut_idx.for_2bit_bitmap.bitmap_val_0 =
        st_setparams->clut_idx.st_for_2bit_bitmap_t.bitmap_val_0;
    setparams.clut_idx.for_2bit_bitmap.bitmap_val_1 =
        st_setparams->clut_idx.st_for_2bit_bitmap_t.bitmap_val_1;
    setparams.clut_idx.for_2bit_bitmap.bitmap_val_2 =
        st_setparams->clut_idx.st_for_2bit_bitmap_t.bitmap_val_2;
    setparams.clut_idx.for_2bit_bitmap.bitmap_val_3 =
        st_setparams->clut_idx.st_for_2bit_bitmap_t.bitmap_val_3;

    setparams.clut_idx.for_4bit_bitmap.bitmap_val_0 =
        st_setparams->clut_idx.st_for_4bit_bitmap_t.bitmap_val_0;
    setparams.clut_idx.for_4bit_bitmap.bitmap_val_1 =
        st_setparams->clut_idx.st_for_4bit_bitmap_t.bitmap_val_1;
    setparams.clut_idx.for_4bit_bitmap.bitmap_val_2 =
        st_setparams->clut_idx.st_for_4bit_bitmap_t.bitmap_val_2;
    setparams.clut_idx.for_4bit_bitmap.bitmap_val_3 =
        st_setparams->clut_idx.st_for_4bit_bitmap_t.bitmap_val_3;
    setparams.clut_idx.for_4bit_bitmap.bitmap_val_4 =
        st_setparams->clut_idx.st_for_4bit_bitmap_t.bitmap_val_4;
    setparams.clut_idx.for_4bit_bitmap.bitmap_val_5 =
        st_setparams->clut_idx.st_for_4bit_bitmap_t.bitmap_val_5;
    setparams.clut_idx.for_4bit_bitmap.bitmap_val_6 =
        st_setparams->clut_idx.st_for_4bit_bitmap_t.bitmap_val_6;
    setparams.clut_idx.for_4bit_bitmap.bitmap_val_7 =
        st_setparams->clut_idx.st_for_4bit_bitmap_t.bitmap_val_7;
    setparams.clut_idx.for_4bit_bitmap.bitmap_val_8 =
        st_setparams->clut_idx.st_for_4bit_bitmap_t.bitmap_val_8;
    setparams.clut_idx.for_4bit_bitmap.bitmap_val_9 =
        st_setparams->clut_idx.st_for_4bit_bitmap_t.bitmap_val_9;
    setparams.clut_idx.for_4bit_bitmap.bitmap_val_10 =
        st_setparams->clut_idx.st_for_4bit_bitmap_t.bitmap_val_10;
    setparams.clut_idx.for_4bit_bitmap.bitmap_val_11 =
        st_setparams->clut_idx.st_for_4bit_bitmap_t.bitmap_val_11;
    setparams.clut_idx.for_4bit_bitmap.bitmap_val_12 =
        st_setparams->clut_idx.st_for_4bit_bitmap_t.bitmap_val_12;
    setparams.clut_idx.for_4bit_bitmap.bitmap_val_13 =
        st_setparams->clut_idx.st_for_4bit_bitmap_t.bitmap_val_13;
    setparams.clut_idx.for_4bit_bitmap.bitmap_val_14 =
        st_setparams->clut_idx.st_for_4bit_bitmap_t.bitmap_val_14;
    setparams.clut_idx.for_4bit_bitmap.bitmap_val_15 =
        st_setparams->clut_idx.st_for_4bit_bitmap_t.bitmap_val_15;


    retVal = ioctl(fd, FBIO_SET_BITMAP_CONFIG_PARAMS, &setparams);
    if (retVal != SUCCESS)
        return FAILURE;

    return retVal;

}



/****************************************************************************
 * Function             - st_fbdev_setZoom_ioctl_interface
 * Functionality        - This function sets zoom factor for a window
 * Input Params         - device number and st_zoom_params structure pointer
 *                          pointer
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_setZoom_ioctl_interface(int dev, st_zoom_params * st_zoom)
{
    int retVal = SUCCESS;
    int fd = -1;
    zoom_params_t zoomParams;

    if (FBDEV_DEV1 == dev) {
        fd = fd_dev1;
    } else if (FBDEV_DEV3 == dev) {
        fd = fd_dev3;
    } else if (FBDEV_DEV0 == dev) {
        fd = fd_dev0;
    } else if (FBDEV_DEV2 == dev) {
        fd = fd_dev2;
    } else {
        return E_DEV_NOT_AVAILABLE;
    }

    zoomParams.window_id = st_zoom->window_id;
    zoomParams.zoom_h = st_zoom->zoom_h;
    zoomParams.zoom_v = st_zoom->zoom_v;

    retVal = ioctl(fd, FBIO_SETZOOM, &zoomParams);
    if (retVal != SUCCESS)
        return FAILURE;

    return retVal;

}


/****************************************************************************
 * Function             - st_fbdev_setPosx_ioctl_interface
 * Functionality        - This function sets x-pos of window
 * Input Params         - device number and st_zoom_params structure pointer
 *                          pointer
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_setPosx_ioctl_interface(int dev, Uint32 * st_xpos)
{
    int retVal = SUCCESS;
    int fd = -1;
    unsigned int x_pos;

    if (FBDEV_DEV1 == dev) {
        fd = fd_dev1;
    } else if (FBDEV_DEV3 == dev) {
        fd = fd_dev3;
    } else if (FBDEV_DEV0 == dev) {
        fd = fd_dev0;
    } else if (FBDEV_DEV2 == dev) {
        fd = fd_dev2;
    } else {
        return E_DEV_NOT_AVAILABLE;
    }

    x_pos = *st_xpos;

    retVal = ioctl(fd, FBIO_SETPOSX, x_pos);
    if (retVal != SUCCESS)
        return FAILURE;

    return retVal;

}


/****************************************************************************
 * Function             - st_fbdev_setPosy_ioctl_interface
 * Functionality        - This function sets y-pos of window
 * Input Params         - device number and st_zoom_params structure pointer
 *                          pointer
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_setPosy_ioctl_interface(int dev, Uint32 * st_ypos)
{
    int retVal = SUCCESS;
    int fd = -1;
    unsigned int y_pos;

    if (FBDEV_DEV1 == dev) {
        fd = fd_dev1;
    } else if (FBDEV_DEV3 == dev) {
        fd = fd_dev3;
    } else if (FBDEV_DEV0 == dev) {
        fd = fd_dev0;
    } else if (FBDEV_DEV2 == dev) {
        fd = fd_dev2;
    } else {
        return E_DEV_NOT_AVAILABLE;
    }

    y_pos = *st_ypos;

    retVal = ioctl(fd, FBIO_SETPOSY, y_pos);
    if (retVal != SUCCESS)
        return FAILURE;

    return retVal;

}


/****************************************************************************
 * Function             - st_fbdev_setCursor_ioctl_interface
 * Functionality        - This function sets cursor position
 * Input Params         - device number and st_fb_cursor structure pointer
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_setCursor_ioctl_interface(int dev, st_fb_cursor * st_cursor)
{
    int retVal = SUCCESS;
    int fd = -1;
    struct fb_cursor cursor;

    if (FBDEV_DEV1 == dev) {
        fd = fd_dev1;
    } else if (FBDEV_DEV3 == dev) {
        fd = fd_dev3;
    } else if (FBDEV_DEV0 == dev) {
        fd = fd_dev0;
    } else if (FBDEV_DEV2 == dev) {
        fd = fd_dev2;
    } else {
        return E_DEV_NOT_AVAILABLE;
    }

    cursor.enable = st_cursor->enable;
    cursor.set = st_cursor->set;
    cursor.rop = st_cursor->rop;
    cursor.mask = st_cursor->mask;
    cursor.hot.x = st_cursor->hot.x;
    cursor.hot.y = st_cursor->hot.y;
    cursor.image.dx = st_cursor->image.dx;
    cursor.image.dy = st_cursor->image.dy;
    cursor.image.width = st_cursor->image.width;
    cursor.image.height = st_cursor->image.height;
    cursor.image.fg_color = st_cursor->image.fg_color;
    cursor.image.bg_color = st_cursor->image.bg_color;
    cursor.image.depth = st_cursor->image.depth;
    cursor.image.data = st_cursor->image.data;
    cursor.image.cmap.start = st_cursor->image.cmap.start;
    cursor.image.cmap.len = st_cursor->image.cmap.len;
    cursor.image.cmap.red = st_cursor->image.cmap.red;
    cursor.image.cmap.green = st_cursor->image.cmap.green;
    cursor.image.cmap.blue = st_cursor->image.cmap.blue;
    cursor.image.cmap.transp = st_cursor->image.cmap.transp;

    retVal = ioctl(fd, FBIO_SET_CURSOR, &cursor);
    if (retVal != SUCCESS)
        return FAILURE;

    return retVal;

}


/****************************************************************************
 * Function             - st_fbdev_setBackGroundColor_ioctl_interface
 * Functionality        - This function sets background color
 * Input Params         - device number and st_fb_cursor structure pointer
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_setBackGroundColor_ioctl_interface(int dev,
                                                st_vpbe_backg_color *
                                                st_color)
{

    int retVal = SUCCESS;
    int fd = -1;
    vpbe_backg_color_t color;

    if (FBDEV_DEV1 == dev) {
        fd = fd_dev1;
    } else if (FBDEV_DEV3 == dev) {
        fd = fd_dev3;
    } else if (FBDEV_DEV0 == dev) {
        fd = fd_dev0;
    } else if (FBDEV_DEV2 == dev) {
        fd = fd_dev2;
    } else {
        return E_DEV_NOT_AVAILABLE;
    }

    color.clut_select = st_color->clut_select;
    color.color_offset = st_color->color_offset;

    retVal = ioctl(fd, FBIO_SET_BACKG_COLOR, &color);
    if (retVal != SUCCESS)
        return FAILURE;

    return retVal;

}

/****************************************************************************
 * Function             - st_fbdev_getCmap_ioctl_interface
 * Functionality        - This function gets cmap
 * Input Params         - device number and st_fb_cmap_user structure pointer
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_getCmap_ioctl_interface(int dev, struct st_fb_cmap_t * st_cmap)
{
    return E_IOCTL_NOT_SUPPORTED;;
}


/****************************************************************************
 * Function             - st_fbdev_getCmap_ioctl_interface
 * Functionality        - This function gets cmap
 * Input Params         - device number and st_fb_cmap_user structure pointer
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_putCmap_ioctl_interface(int dev, struct st_fb_cmap_t * st_cmap)
{
    return E_IOCTL_NOT_SUPPORTED;;
}


/****************************************************************************
 * Function             - st_fbdev_getCon2Fb_ioctl_interface
 * Functionality        - This function Gets the con2fbmap structure.
 * Input Params         - device number and st_fb_con2fbmap structure pointer
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_getCon2Fb_ioctl_interface(int dev, st_fb_con2fbmap * st_con)
{

    int retVal = SUCCESS;
    int fd = -1;
    struct fb_con2fbmap con;

    if (FBDEV_DEV1 == dev) {
        fd = fd_dev1;
    } else if (FBDEV_DEV3 == dev) {
        fd = fd_dev3;
    } else if (FBDEV_DEV0 == dev) {
        fd = fd_dev0;
    } else if (FBDEV_DEV2 == dev) {
        fd = fd_dev2;
    } else {
        return E_DEV_NOT_AVAILABLE;
    }

    retVal = ioctl(fd, FBIOGET_CON2FBMAP, &con);
    if (retVal != SUCCESS)
        return FAILURE;

    st_con->console = con.console;
    st_con->framebuffer = con.framebuffer;

    return retVal;

}



/****************************************************************************
 * Function             - st_fbdev_getCon2Fb_ioctl_interface
 * Functionality        - This function sets the con2fbmap structure.
 * Input Params         - device number and st_fb_con2fbmap structure pointer
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_setCon2Fb_ioctl_interface(int dev, st_fb_con2fbmap * st_con)
{
    return E_IOCTL_NOT_SUPPORTED;
}


/****************************************************************************
 * Function             - st_fbdev_fbioMirror_ioctl_interface
 * Functionality        - executes FBIO_MIRRIR ioctl
 * Input Params         - device number 
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_fbioMirror_ioctl_interface(int dev, Uint32 * st_mirror)
{
    return E_IOCTL_NOT_SUPPORTED;
}

/****************************************************************************
 * Function             - st_fbdev_change_sysfs_interface
 * Functionality        - This function sets sysfs variables
 * Input Params         - mode_output number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_change_sysfs_interface(char *mode, char *output)
{

    char command[80];
    /* set output path */
    strcpy(command, "echo ");
    strcat(command, output);
    strcat(command, " > ");
    strcat(command, OUTPUTPATH);

    if (system(command)) {
        return FAILURE;
    }

    /* set mode */
    strcpy(command, "echo ");
    strcat(command, mode);
    strcat(command, " > ");
    strcat(command, STDPATH);

    if (system(command)) {
        return FAILURE;
    } else
        return SUCCESS;
}

/****************************************************************************
 * Function             - st_fbdev_display_square_interface
 * Functionality        - This function unmaps buffers
 * Input Params         - device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_display_square_interface(int dev,st_fb_var_screeninfo
fb_var,st_fb_fix_screeninfo fb_fix)
{

    return SUCCESS; 
}
/****************************************************************************
 * Function             - st_fbdev_display_chess_interface
 * Functionality        - This function unmaps buffers
 * Input Params         - device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_display_chess_interface(int dev,st_fb_var_screeninfo
fb_var,st_fb_fix_screeninfo fb_fix)
{
    return SUCCESS; 

}
/****************************************************************************
 * Function             - st_fbdev_display_natural_image_interface
 * Functionality        - This function unmaps buffers
 * Input Params         - device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_display_natural_image_interface(int dev,st_fb_var_screeninfo
fb_var,st_fb_fix_screeninfo fb_fix)
{
                    return SUCCESS;

}

/****************************************************************************
 * Function             - st_fbdev_GetUpdatedMode_interface
 * Functionality        - Gets the current update mode.
 * Input Params         - st_omapfb_update_mode
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None 
 ****************************************************************************/

int st_fbdev_GetUpdatedMode_interface(int dev, int *st_updateinfo)
{

    return SUCCESS;

}

/****************************************************************************
 * Function             - st_fbdev_SetUpdatedMode_interface
 * Functionality        - Gets the current update mode.
 * Input Params         - st_omapfb_update_mode
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None 
 ****************************************************************************/

int st_fbdev_SetUpdatedMode_interface(int dev, int st_updateinfo)
{
    int retVal = SUCCESS;

    return retVal;

}

/****************************************************************************
 * Function             - st_fbdev_SetMemInfo_interface
 * Functionality        - Set Mem information for FB
 * Input Params         - st_omapfb_mem_info
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None 
 ****************************************************************************/
int st_fbdev_SetMemInfo_interface(int dev, struct st_omapfb_mem_info *st_meminfo)
{

    int retVal = SUCCESS;


    return retVal;
}

/****************************************************************************
 * Function             - st_fbdev_QueryMemInfo_interfacef
 * Functionality        - Set Mem information for FB
 * Input Params         - st_omapfb_mem_info
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None 
 ****************************************************************************/
int st_fbdev_QueryMemInfo_interface(int dev, struct st_omapfb_mem_info *st_meminfo)
{

    int retVal = SUCCESS;

    return retVal;
}


/****************************************************************************
 * Function             - st_fbdev_fbioQueryPlaneInfo_ioctl_interface
 * Functionality        - This function is to set the mirror of the FBDEV window position
 * Input Params         - FBDEV, device number, x and Y position
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None 
 ****************************************************************************/
int st_fbdev_fbioQueryPlaneInfo_ioctl_interface(int dev, struct st_omapfb_plane_info *st_planeinfo)
{

    int retVal = SUCCESS;

    return retVal;
}

/****************************************************************************
 * Function             - st_fbdev_set_colorkey_interface
 * Functionality        - This function executes OMAPFB_SET_COLOR_KEY ioctl
 * Input Params         - device number and variable screen info structure
 *                          pointer
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_set_colorkey_interface(int dev, struct st_omapfb_color_key *st_ckInfo)
{

	int retVal = SUCCESS;
        return retVal;

}

/****************************************************************************
 * Function             - st_fbdev_get_colorkey_interface
 * Functionality        - This function executes OMAPFB_GET_COLOR_KEY ioctl
 * Input Params         - device number and variable screen info structure
 *                          pointer
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_get_colorkey_interface(int dev, struct st_omapfb_color_key *st_ckInfo)
{

	int retVal = SUCCESS;
         return retVal;
}
/****************************************************************************
 * Function             - video_thread
 * Functionality        - 
 * Input Params         - void
 * Return Value         - 0
 * Note                 - None 
 ****************************************************************************/
void video_thread(void)
{
return;
}
/****************************************************************************
 * Function             - st_fbdev_map_and_disp_interface
 * Functionality        - This function maps FBDEV windowbuffers to user space
 * Input Params         - device number, line length and y resolution
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_fbdev_map_and_disp_interface(int dev, int st_lineLength, int st_yres)
{
    return FAILURE;
}
/* vim: set ts=4 sw=4 tw=80 et:*/
