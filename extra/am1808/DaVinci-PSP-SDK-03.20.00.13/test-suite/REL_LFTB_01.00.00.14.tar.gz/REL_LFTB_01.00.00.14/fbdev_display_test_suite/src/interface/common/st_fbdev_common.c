/*
 * st_fbdev_common.c 
 *
 * File contains some common function definitions
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/ 
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/



/* Testcode header files*/
#include "st_fbdev_common.h"
/*structures , enums , external variables are defined here*/
extern char *displayOut;


/****************************************************************************
 * Function             - st_fbdev_set_device_number
 * Functionality        - Function sets device number for a device string
 * Input Params         - device name and numberNone
 * Note                 - None
 ****************************************************************************/
Int32 st_fbdev_set_device_number(char *devname)
{
    if (!strcmp(devname, FB_DEV0)) {
        return FBDEV_DEV0;
    } else if (!strcmp(devname, FB_DEV1)) {
        return FBDEV_DEV1;
    } else if (!strcmp(devname, FB_DEV2)) {
        return FBDEV_DEV2;
    } else if (!strcmp(devname, FB_DEV3)) {
        return FBDEV_DEV3;
    } else if (!strcmp(devname, FB_DEV4)) {
        return FBDEV_DEV4;
    } else {
        return E_INVALID_DEVICE;
    }

}



/****************************************************************************
 * Function             - st_fbdev_openAndreturn
 * Functionality        - This function opens device and returns status
 * Input Params         - dev number, name
 * Return Value         - status
 * Note                 - None
 ****************************************************************************/
Int32 st_fbdev_openAndreturn(Int32 * st_dev, char *devname)
{
    Int32 retVal = SUCCESS;
    Int32 status = SUCCESS;

    /* open FBDEV display device */
    retVal = st_fbdev_open_interface(*st_dev);
    if (SUCCESS != retVal) {
        if (E_DEV_NOT_AVAILABLE == retVal) {
            DBG_PRINT_TRC(("Device is not available"));
            status = NOT_SUPPORTED;
        } else {
            DBG_PRINT_ERR(("Failed to open FBDEV device %s", devname));
            status = FAILURE;
        }
    } else {
        DBG_PRINT_TRC0(("FBDEV %s device opened", devname));
        status = SUCCESS;
    }

    return status;
}



/****************************************************************************
 * Function             - st_fbdev_closeAndreturn
 * Functionality        - This function closes device and returns status
 * Input Params         - dev number, name
 * Return Value         - status
 * Note                 - None
 ****************************************************************************/
Int32 st_fbdev_closeAndreturn(Int32 * st_dev, char *devname)
{
    Int32 retVal = SUCCESS;
    Int32 status = SUCCESS;

    /* close FBDEV device */
    retVal = st_fbdev_close_interface(*st_dev);
    if (SUCCESS != retVal) {
        DBG_PRINT_ERR(("FBDEV %s device not closed", devname));
        status = FAILURE;
    } else {
        DBG_PRINT_TRC0(("FBDEV %s device closed", devname));
    }

    return status;
}


/****************************************************************************
 * Function             - st_fbdev_checkRetVal_test
 * Functionality        - This function checks return value and returns appropriate status
 * Input Params         - retval
 * Return Value         - status
 * Note                 - None
 ****************************************************************************/
Int32 st_fbdev_checkRetVal(Int32 retVal)
{
    Int32 status = SUCCESS;

    if (E_DEV_NOT_AVAILABLE == retVal) {
        DBG_PRINT_TRC(("Device is not available"));
        status = NOT_SUPPORTED;
    } else if (FAILURE == retVal) {
        DBG_PRINT_ERR(("Function failed"));
        status = FAILURE;
    } else if (E_IOCTL_NOT_SUPPORTED == retVal) {
        DBG_PRINT_TRC(("Ioctl not supported "));
        /*status = E_IOCTL_NOT_SUPPORTED;*//*For now we return success*/
        status = SUCCESS;
    } else if (E_MODEOUTPUT_NOT_SUPPORTED == retVal) {
        DBG_PRINT_TRC(("Mode or output is not supported "));
        status = E_MODEOUTPUT_NOT_SUPPORTED;
    } else
        status = SUCCESS;


    return status;
}

/* vim: set ts=4 sw=4 tw=80 et:*/
