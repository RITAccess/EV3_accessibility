/*
 * st_fbdev_common.h
 *
 * This file contains common definions
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/

#ifndef _ST_FBDEV_COMMON_H_
#define _ST_FBDEV_COMMON_H_

/*testcode releated Header files*/
#include "st_fbdev_interface.h"
/*Testcode related Header files*/
#include <stDefines.h>
#include <stLog.h>
#include <stTimer.h>
#include <pthread.h>
#include <stBufferMgr.h>
#include <stCpuLoad.h>
#define MAXLOOPCOUNT    1000

#include <stdio.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/mman.h>
#include <getopt.h>
#include <sys/mman.h>
#include <sys/time.h>
#include <linux/videodev.h>
#include <linux/videodev2.h>
#include <linux/fb.h>
#include <pthread.h>
//#include <linux/omapfb.h>

#define IMG_WIDTH			400
#define IMG_HEIGHT			272
#define NUMBUFFERS		3
#define OMAP_TI_BMP		"omap_ti.rgb"
#define OMAP_TI_BLANK_BMP	"omap_ti_blank.rgb"
//static unsigned int  video1[IMG_WIDTH][IMG_HEIGHT];
//static unsigned int  graphics[IMG_WIDTH][IMG_HEIGHT];

struct buf_info {
	unsigned int length;
	char *start;
};

/*Structure for holding the test options */
struct fbdev_display_testparams
{
    /* Device node name */
    char *device_name;
    /* Width of the input image to be displayed */
    int width;
    /* Height of the input image to be displayed */
    int height;
    /* Video mode*/
    char *mode;
    /* Display interface name */
    char *interface;
    /* Display Standard*/
    char *standard;
    /* BitsPerPixel of the image to be displayed*/
    int bits_per_pixel;
    /* Zoom factor in x-direction*/
    int zoom_x;
    /*Zoom factor in y-direction*/
    int zoom_y;
    /* Reposition of X*/
    int repos_x;
    /*Reposition of Y*/
    int repos_y;
    /* The number of frames to be displayed*/
    int no_of_frames;
    /* The name of the window name*/
    char *window_name;
    /* Variable to enable frame rate info*/
    Bool framerate; 
    /* Variable to enable cpu load info*/
    Bool cpuload;
    Bool queue;
   /*For ioctl test */
   int ioctl_no;
   int loopcount; 
/*
char *window_name;
int blend_factor;
int blinking_interval;
int Color_key;
int Cursor_xpos;
int cursor_ypos;
int cursor_xres;
int cursor_yres;
int cursor_thickness;
int cursor_color;
*/

/* For put screen */
int greyscale;
int redlength;
int redoffset;
int redmsb;
int greenlength;
int greenoffset;
int greenmsb;
int bluelength;
int blueoffset;
int bluemsb;
int translength;
int transoffset;
int transmsb;
int leftmargin;
int rightmargin;
int lowermargin;
int uppermargin;
int hsynclen;
int vsynclen;
int sync;
};

/*Structure for holding the query plane information options*/

struct st_omapfb_plane_info {
	Uint32 pos_x;
	Uint32 pos_y;
	Uint8 enabled;
	Uint8 channel_out;
	Uint8 mirror;
	Uint8 reserved1;
	Uint32 out_width;
	Uint32 out_height;
	Uint32 reserved2[12];
};

struct st_omapfb_mem_info
{
	Uint32 size;
	Uint8 type;
	Uint8 reserved[3];

};


struct st_omapfb_color_key {
	Uint8  channel_out;
	Uint32 background;
	Uint32 trans_key;
	Uint8  key_type;
};




/* common function */
Int32 st_fbdev_set_device_number(char *devname);


/* opens and closes device and returns status */
Int32 st_fbdev_openAndreturn(Int32 * st_dev, char *devname);
Int32 st_fbdev_closeAndreturn(Int32 * st_dev, char *devname);

/* prints test status */
void st_fbdev_display_test_status(Int32 status, char *test_id);

/* check retVal */
Int32 st_fbdev_checkRetVal(Int32 retVal);

/* display tests */
void st_fbdev_display_test(struct fbdev_display_testparams *info,
                           char *test_id, Bool stressTest);


/* glcd display tests */

void st_fbdev_display_glcd_test(struct fbdev_display_testparams *info,
                           char *testname, char *test_id);
/* display test from file*/
void st_fbdev_display_test_from_file(struct fbdev_display_testparams *info,
                           char *test_id,char *filename);
/*stability test*/
void st_fbdev_stability_test(struct fbdev_display_testparams *info,
                             char *test_id, int stability_count);
/*ioctl test*/
void st_fbdev_ioctl_test_parser(char *device_name,char *filename);

/* api tests */
void st_fbdev_api_test_parser(char *device_name,char *filename);

/*colorkey test*/
void st_fbdev_colorkey_test(struct fbdev_display_testparams *info, char *testname, char *test_id);

/*alphablending test*/
void st_fbdev_alphablending_test(struct fbdev_display_testparams *info, char *testname, char *test_id);


/* The Declarations of implementation defined in the interface.c */

/*  Macros */
#define MAX_CMD_LENGTH 200

/* Device parameters */
#define FB_DEV0 		"/dev/fb/0"     // OSD0
#define FB_DEV1     	"/dev/fb/1"     // VID0
#define FB_DEV2 		"/dev/fb/2"     // OSD1
#define FB_DEV3	       "/dev/fb/3"      // VID1
#define FB_DEV4		"/dev/fb0"      //omap device0
#define FB_DEV5		"/dev/fb2"      //omap device2
#define FB_DEV_INVALID		"/dev/fb/10"    //invalid device

/* dev ids for test logic */
#define FBDEV_DEV0    0         //OSD0
#define FBDEV_DEV1	 1      // VID0
#define FBDEV_DEV2	 2      //OSD1
#define FBDEV_DEV3    3         //VID1
#define FBDEV_DEV4    4         //omap device0
#define FBDEV_DEV5    5         //omap device2


#define FBDEV_INVALID	-10     // invalid device
#define MAX_DEV		  5     // This value can be changed when more FBDEV devices are introduced

/* Display files names */
#define NTSC_IMAGE  "ntsc.yuv"
#define PAL_IMAGE   "pal.yuv"
#define NTSC_RGB565_IMAGE	"ntsc_rgb565.raw"
#define PAL_RGB565_IMAGE	"pal_rgb565.raw"
#define VGA_RGB565_IMAGE	"vga_rgb.rgb"
#define BITMAP_8			"bitmap_8.bmp"
#define BITMAP_1			"bitmap_1.bmp"
#define PAL_RGB888_IMAGE 	"pal_rgb888.bmp"


/* Height and width of supported resolutions */

#define DSS_DISABLED   0
#define DSS_ENABLED    1


#define QQVGA_WIDTH    	160
#define QQVGA_HEIGHT   	120

#define QVGA_WIDTH	    	320
#define QVGA_HEIGHT    	240

#define VGA_WIDTH	    	640
#define VGA_HEIGHT	    	480

#define NTSC_WIDTH	    	720
#define NTSC_HEIGHT	    	480

#define PAL_WIDTH	    	720
#define PAL_HEIGHT	    	576

#define WIDTH_720P      	1280
#define HEIGHT_720P     	720

#define WIDTH_1080I     	1920
#define HEIGHT_1080I    	1080

#define WIDTH_640		640
#define HEIGHT_400		400

#define HEIGHT_350		350

#define 	MAX_HEIGHT 	576


#define OUTPUTPATH  "/sys/class/davinci_display/ch0/output"
#define STDPATH     "/sys/class/davinci_display/ch0/mode"

#define CHANNEL_OMAP            "/sys/class/display_control/omap_disp_control/graphics"
#define CHANNEL0_OUTPUT_OMAP    "/sys/class/display_control/omap_disp_control/ch0_output"
#define CHANNEL0_MODE_OMAP      "/sys/class/display_control/omap_disp_control/ch0_mode"

#define CHANNEL1_OUTPUT_OMAP    "/sys/class/display_control/omap_disp_control/ch1_output"
#define CHANNEL1_MODE_OMAP      "/sys/class/display_control/omap_disp_control/ch1_mode"

/* BPP */
#define ST_BPP_32       32
#define ST_BPP_24       24
#define ST_BPP_16       16
#define ST_BPP_4       4
#define ST_BPP_8       8
#define ST_BPP_2       2
#define ST_BPP_1       1
#define ST_INVALID_BPP  44


/* image formats */

#define ST_IMAGE_BPP1		0
#define ST_IMAGE_BPP2		1
#define ST_IMAGE_BPP4		3
#define ST_IMAGE_BPP8		4
#define ST_IMAGE_BPP12		5
#define ST_IMAGE_RGB565	6
#define ST_IMAGE_RGB24		7
#define ST_IMAGE_RGBA		8
#define ST_IMAGE_ATTRIBUTE 9
#define ST_IMAGE_UYVY		10
#define ST_IMAGE_YUYV		11

/* image types */
#define ST_YUV			0
#define ST_BITMAP_1		1
#define ST_BITMAP_2	 	2
#define ST_BITMAP_4	 	3
#define ST_BITMAP_8	 	4
#define ST_RGB_565		5
#define ST_RGB_888		6
#define ST_ATTRIB       7
#define ST_OMAP_IMAGE     8
#define ST_H_PATTERN 	11
#define ST_V_PATTERN		12
#define ST_USER_IMAGE		13


/* scanning modes */
#define ST_FB_VMODE_NONINTERLACED  0    /* non interlaced */
#define ST_FB_VMODE_INTERLACED	1       /* interlaced   */


/* max, min and default number of buffers */
#define MAX_BUFFERS     10
#define MIN_BUFFERS		3
#define ST_VIDEO_NUM_BUFS   3
#define ST_OSD_NUM_BUFS   2
#define ST_OSD_NUM_BUFS1   2

/* FBIOBLANK Ioctl params */
#define ST_ENABLE_WIN   0
#define ST_DISABLE_WIN  1


/* blend factors */
#define BLEND_FACTOR_0		0
#define BLEND_FACTOR_1		1
#define BLEND_FACTOR_2		2
#define BLEND_FACTOR_3		3
#define BLEND_FACTOR_4		4
#define BLEND_FACTOR_5		5
#define BLEND_FACTOR_6		6
#define BLEND_FACTOR_7		7

#define INVALID_BLEND_FACTOR 8
/* window position */
#define XPOS_DEFAULT		0       // for display test
#define YPOS_DEFAULT		0       // for display test
#define XPOS_TEST			50      // for ioctl test
#define YPOS_TEST			50      // for ioctl test

/* CLUT */
#define ROM_CLUT_DM270		0
#define ROM_CLUT_DM320		1
#define RAM_CLUT			2

/* background color */
#define BACKG_COLOR			0xF9

/*CMAP test definitions lenght */
#define CMAP_LENGHT			0x4
//unsigned short test_red[4]={0xFF,0x00, 0x00, 0xFF};
//unsigned short test_green[4]={0x00, 0xFF, 0x00, 0xFF};
//unsigned short test_blue[4]={0x00, 0x00, 0xFF, 0x00};



/*  cursor info */
#define ST_CURSOR_XPOS			100
#define ST_CURSOR_YPOS			100
#define ST_CURSOR_XRES			50
#define ST_CURSOR_YRES			50
#define ST_CURSOR_THICKNESS	1
#define ST_CURSOR_COLOR		0xF9

/*Frame buffer memory related information*/
#define OMAPFB_MEMTYPE_SDRAM 0
#define OMAPFB_MEMTYPE_SRAM 1
#define OMAPFB_MEMTYPE_MAX 1



/* ERROR CODES */
#define E_DEV_NOT_AVAILABLE   			-10
#define E_ROTATION_NOT_SUPPORTED		-11
#define E_MODEOUTPUT_NOT_SUPPORTED 	-12
#define E_INVALID_DEVICE				-13
#define E_IOCTL_NOT_SUPPORTED			-14



/* enums */

/*  Enable/Disable enum */
typedef enum
{
    DISABLE,
    ENABLE
} ST_ATTENUATION, ST_EXPANSION, ST_BLINKING;


/* blink interval */
enum st_davinci_blink_interval
{
    ST_BLINK1,
    ST_BLINK2,
    ST_BLINK3,
    ST_BLINK4,
};


/*  Enum for Boolean variables  */
typedef enum
{
    ST_SET_0,
    ST_SET_1,
} ST_CB_CR_ORDER, ST_ATTRIBUTE;


enum st_rotate_factor
{
    ST_ROTATE_0 = 0,
    ST_ROTATE_90 = 90,
    ST_ROTATE_180 = 180,
    ST_ROTATE_270 = 270,
};
enum st_davinci_zoom_factor
{
    ST_ZOOM_X1,
    ST_ZOOM_X2,
    ST_ZOOM_X4,
    ST_ZOOM_INVALID = 8,
};

/* unions */
/*
 * Union of structures giving the CLUT index for the 1, 2, 4 bit bitmap values
 */
typedef union st_vpbe_clut_idx_t
{
    struct st_for_4bit_bitmap
    {
        unsigned char bitmap_val_0;
        unsigned char bitmap_val_1;
        unsigned char bitmap_val_2;
        unsigned char bitmap_val_3;
        unsigned char bitmap_val_4;
        unsigned char bitmap_val_5;
        unsigned char bitmap_val_6;
        unsigned char bitmap_val_7;
        unsigned char bitmap_val_8;
        unsigned char bitmap_val_9;
        unsigned char bitmap_val_10;
        unsigned char bitmap_val_11;
        unsigned char bitmap_val_12;
        unsigned char bitmap_val_13;
        unsigned char bitmap_val_14;
        unsigned char bitmap_val_15;
    } st_for_4bit_bitmap_t;
    struct st_for_2bit_bitmap
    {
        unsigned char bitmap_val_0;
        unsigned char dummy0[4];
        unsigned char bitmap_val_1;
        unsigned char dummy1[4];
        unsigned char bitmap_val_2;
        unsigned char dummy2[4];
        unsigned char bitmap_val_3;
    } st_for_2bit_bitmap_t;
    struct st_for_1bit_bitmap
    {
        unsigned char bitmap_val_0;
        unsigned char dummy0[14];
        unsigned char bitmap_val_1;
    } st_for_1bit_bitmap_t;
} st_vpbe_clut_idx;

/* structures */


typedef struct st_fb_con2fbmap_t
{
    __u32 console;
    __u32 framebuffer;
} st_fb_con2fbmap;


/*  Structure for background color  */
typedef struct st_vpbe_backg_color_t
{
    unsigned char clut_select;  /* 2: RAM CLUT 1:ROM1 CLUT 0:ROM0 CLUT */
    unsigned char color_offset; /* index of color */
} st_vpbe_backg_color;

typedef struct st_fb_cmap_user_t
{
    __u32 start;                /* First entry  */
    __u32 len;                  /* Number of entries */
} st_fb_cmap_user;

typedef struct st_fb_cmap_t
{
    __u32 start;                /* First entry  */
    __u32 len;                  /* Number of entries */
    __u16 *red;                 /* Red values   */
    __u16 *green;
    __u16 *blue;
    __u16 *transp;              /* transparency, can be NULL */
} st_fb_cmap;

typedef struct st_fb_image_t
{
    __u32 dx;                   /* Where to place image */
    __u32 dy;
    __u32 width;                /* Size of image */
    __u32 height;
    __u32 fg_color;             /* Only used when a mono bitmap */
    __u32 bg_color;
    __u8 depth;                 /* Depth of the image */
    const char *data;           /* Pointer to image data */
    struct st_fb_cmap_t cmap;   /* color map info */
} st_fb_image;

/*
 * hardware cursor control
 */

typedef struct st_fbcurpos_t
{
    __u16 x, y;
} st_fbcurpos;

typedef struct st_fb_cursor_t
{
    __u16 set;                  /* what to set */
    __u16 enable;               /* cursor on/off */
    __u16 rop;                  /* bitop operation */
    const char *mask;           /* cursor mask bits */
    struct st_fbcurpos_t hot;   /* cursor hot spot */
    struct st_fb_image_t image; /* Cursor image */
} st_fb_cursor;


/* structure to hold mode and output and scanning technique*/
typedef struct st_info_t
{
    Uint32 mode;
    Uint32 output;
    Uint32 vmode;
    Uint32 width;
    Uint32 height;
} st_info;


/* structure to hold zoom parameters */
typedef struct st_zoom_params_t
{
    Uint32 window_id;
    Uint32 zoom_h;
    Uint32 zoom_v;
} st_zoom_params;

/* Structure for transparency and the blending factor for the bitmap window */
typedef struct st_vpbe_bitmap_blend_params_t
{
    unsigned int colorkey;      /* color key to be blended */
    unsigned int enable_colorkeying;    /* enable color keying */
    unsigned int bf;            /* valid range from 0 to 7 only. */
} st_vpbe_bitmap_blend_params;

/*  Structure for OSD window blinking options */
typedef struct st_vpbe_blink_option_t
{
    ST_BLINKING blinking;       /* 1: Enable blinking 0: Disable */
    unsigned int interval;      /* Valid only if blinking is 1 */
} st_vpbe_blink_option;


/*  Structure for window expansion  */
typedef struct st_vpbe_win_expansion
{
    ST_EXPANSION horizontal;
    ST_EXPANSION vertical;      /* 1: Enable 0:disable */
} st_vpbe_win_expansion_t;


/*  Structure for Video window configurable parameters  */
typedef struct st_vpbe_video_config_params_t
{
    ST_CB_CR_ORDER cb_cr_order; /* Cb/Cr order in input data for a pixel. */
    /*    0: cb cr  1:  cr cb */
    st_vpbe_win_expansion_t exp_info;   /* HZ/VT Expansion enable disable */
} st_vpbe_video_config_params;


/* Structure for bitmap window configurable parameters */
typedef struct st_vpbe_bitmap_config_params_t
{
    /* Only for bitmap width = 1,2,4 bits */
    st_vpbe_clut_idx clut_idx;
    /* Attenuation value for YUV o/p for bitmap window */
    unsigned char attenuation_enable;
    /* 0: ROM DM270, 1:ROM DM320, 2:RAM CLUT */
    unsigned char clut_select;
} st_vpbe_bitmap_config_params;


/* Structure to hold window position */
typedef struct st_vpbe_window_position_t
{
    unsigned int xpos;          /* X position of the window */
    unsigned int ypos;          /* Y position of the window */
} st_vpbe_window_position;

/* Structure to hold bitfields */
typedef struct st_bitfield
{
    Uint32 offset;              /* beginning of bitfield        */
    Uint32 length;              /* length of bitfield           */
    Uint32 msb_right;           /* != 0 : Most significant bit is */
    /* right */
} st_fb_bitfield;


/* structure to hold fix screen info */
typedef struct st_fix_screeninfo
{
    char id[16];                /* identification string eg "TT Builtin" */
    unsigned long smem_start;   /* Start of frame buffer mem */
    /* (physical address) */
    Uint32 smem_len;            /* Length of frame buffer mem */
    Uint32 type;                /* see FB_TYPE_*                */
    Uint32 type_aux;            /* Interleave for interleaved Planes */
    Uint32 visual;              /* see FB_VISUAL_*              */
    Uint32 xpanstep;            /* zero if no hardware panning  */
    Uint32 ypanstep;            /* zero if no hardware panning  */
    Uint32 ywrapstep;           /* zero if no hardware ywrap    */
    Uint32 line_length;         /* length of a line in bytes    */
    unsigned long mmio_start;   /* Start of Memory Mapped I/O   */
    /* (physical address) */
    Uint32 mmio_len;            /* Length of Memory Mapped I/O  */
    Uint32 accel;               /* Indicate to driver which     */
    /*  specific chip/card we have      */
    Uint32 reserved[3];         /* Reserved for future compatibility */
} st_fb_fix_screeninfo;


/* structure to hold variable screen info */
typedef struct st_var_screeninfo
{
    Uint32 xres;                /* visible resolution           */
    Uint32 yres;
    Uint32 xres_virtual;        /* virtual resolution           */
    Uint32 yres_virtual;
    Uint32 xoffset;             /* offset from virtual to visible */
    Uint32 yoffset;             /* resolution                   */

    Uint32 bits_per_pixel;      /* guess what                   */
    Uint32 grayscale;           /* != 0 Graylevels instead of colors */

    st_fb_bitfield red;         /* bitfield in fb mem if true color, */
    st_fb_bitfield green;       /* else only length is significant */
    st_fb_bitfield blue;
    st_fb_bitfield transp;      /* transparency                 */

    Uint32 nonstd;              /* != 0 Non standard pixel format */

    Uint32 activate;            /* see FB_ACTIVATE_*            */

    Uint32 height;              /* height of picture in mm    */
    Uint32 width;               /* width of picture in mm     */

    Uint32 accel_flags;         /* (OBSOLETE) see fb_info.flags */

    /* Timing: All values in pixclocks, except pixclock (of course) */
    Uint32 pixclock;            /* pixel clock in ps (pico seconds) */
    Uint32 left_margin;         /* time from sync to picture    */
    Uint32 right_margin;        /* time from picture to sync    */
    Uint32 upper_margin;        /* time from sync to picture    */
    Uint32 lower_margin;
    Uint32 hsync_len;           /* length of horizontal sync    */
    Uint32 vsync_len;           /* length of vertical sync      */
    Uint32 sync;                /* see FB_SYNC_*                */
    Uint32 vmode;               /* see FB_VMODE_*               */
    Uint32 rotate;              /* angle we rotate counter clockwise */
    Uint32 reserved[5];         /* Reserved for future compatibility */
} st_fb_var_screeninfo;


/* function prototype */
int st_fbdev_open_interface(int dev);
int st_fbdev_close_interface(int dev);
int st_fbdev_mmap_interface(int dev, int st_lineLength, int st_yres);
int st_fbdev_unmap_interface(int dev);
int st_fbdev_display_interface(int dev, int width, int height,
                               int st_img_type, char *image_name);

int st_fbdev_getFscreenInfo_interface(int dev,
                                      st_fb_fix_screeninfo * fixInfo);
int st_fbdev_getVscreenInfo_interface(int dev,
                                      st_fb_var_screeninfo * varInfo);
int st_fbdev_putVscreenInfo_interface(int dev,
                                      st_fb_var_screeninfo * varInfo);
int st_fbdev_waitforsync_interface(int dev);
int st_fbdev_pandisplay_interface(int dev, st_fb_var_screeninfo * varInfo);
int st_fbdev_setpos_interface(int dev, st_vpbe_window_position * st_pos);
int st_fbdev_blank_window_interface(int dev, Bool st_blank);
int st_fbdev_setBitmatBlendFactor_ioctl_interface(int dev,
                                                  st_vpbe_bitmap_blend_params
                                                  * st_bFactor);
int st_fbdev_getBlinkInterval_ioctl_interface(int st_dev,
                                              st_vpbe_blink_option *
                                              st_getBlink);
int st_fbdev_setBlinkInterval_ioctl_interface(int st_dev,
                                              st_vpbe_blink_option *
                                              st_setBlink);
int st_fbdev_getVideoConfigParams_ioctl_interface(int dev,
                                                  st_vpbe_video_config_params
                                                  * st_getparams);
int st_fbdev_setVideoConfigParams_ioctl_interface(int dev,
                                                  st_vpbe_video_config_params
                                                  * st_setparams);
int st_fbdev_getBitmapConfigParams_ioctl_interface(int dev,
                                                   st_vpbe_bitmap_config_params
                                                   * st_getparams);
int st_fbdev_setBitmapConfigParams_ioctl_interface(int dev,
                                                   st_vpbe_bitmap_config_params
                                                   * st_setparams);
int st_fbdev_setZoom_ioctl_interface(int dev, st_zoom_params * st_zoom);
int st_fbdev_setPosx_ioctl_interface(int dev, Uint32 * st_xpos);
int st_fbdev_setPosy_ioctl_interface(int dev, Uint32 * st_ypos);
int st_fbdev_setCursor_ioctl_interface(int dev, st_fb_cursor * st_cursor);
int st_fbdev_setBackGroundColor_ioctl_interface(int dev,
                                                st_vpbe_backg_color *
                                                st_color);
int st_fbdev_getCmap_ioctl_interface(int dev, struct st_fb_cmap_t * st_cmap);
int st_fbdev_putCmap_ioctl_interface(int dev, struct st_fb_cmap_t * st_cmap);
int st_fbdev_getCon2Fb_ioctl_interface(int dev, st_fb_con2fbmap * st_con);
int st_fbdev_setCon2Fb_ioctl_interface(int dev, st_fb_con2fbmap * st_con);

int st_fbdev_fbioMirror_ioctl_interface(int dev, Uint32 * st_mirror);

int st_fbdev_fbioQueryPlaneInfo_ioctl_interface(int dev, struct st_omapfb_plane_info *st_planeinfo);

int st_fbdev_SetMemInfo_interface(int dev, struct st_omapfb_mem_info *st_meminfo);

int st_fbdev_QueryMemInfo_interface(int dev, struct st_omapfb_mem_info *st_meminfo);

int st_fbdev_GetUpdatedMode_interface(int dev, int *mode);

int st_fbdev_SetUpdatedMode_interface(int dev, int mode);

int st_fbdev_set_colorkey_interface(int dev, struct st_omapfb_color_key *st_ckInfo);

int st_fbdev_get_colorkey_interface(int dev, struct st_omapfb_color_key *st_ckInfo);

int st_fbdev_change_sysfs_interface(char *mode, char *output);

int st_fbdev_display_square_interface(int dev,st_fb_var_screeninfo
fb_var,st_fb_fix_screeninfo fb_fix);
int st_fbdev_display_natural_image_interface(int dev,st_fb_var_screeninfo
fb_var,st_fb_fix_screeninfo fb_fix);
int st_fbdev_display_chess_interface(int dev,st_fb_var_screeninfo
fb_var,st_fb_fix_screeninfo fb_fix);
int st_check_std(char *standard);
int st_check_pixel_format(char *pixel_format);

void st_print_fbdev_display_test_params(struct fbdev_display_testparams
                                        *testoptions, char *test_id);
void st_init_fbdev_display_test_params();
void video_thread(void);
void fill(void *start, unsigned int w, unsigned int h, unsigned int output_device);

int st_fbdev_map_and_disp_interface(int dev, int st_lineLength, int st_yres);
void fill_color_bar_second(unsigned char *addr, int width, int height, int index);

#endif                          /* _ST_FBDEV_COMMON_H_ */

/* vim: set ts=4 et sw=4: */
