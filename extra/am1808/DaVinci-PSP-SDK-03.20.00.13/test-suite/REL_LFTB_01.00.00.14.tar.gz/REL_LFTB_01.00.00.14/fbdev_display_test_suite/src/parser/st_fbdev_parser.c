/*
 * st_fbdev_parser.c
 *
 * This file contains fbdev parser and gives user selectable test cases
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/


/*Testcode related header files */
#include "st_fbdev_common.h"

/*macros and enum are defined here*/
#define DEFAULT_STABILITY_COUNT 1000

//struct fbdev_display_testparams testoptions;
char *testcaseid = "DisplayTests";
char *testname = "Functionality";
char *displayOut = "LCD";
char *pixel_format = "H_PATTERN";
char *filename="ntsc.yuv";

/* Test case options structure */
extern struct fbdev_display_testparams testoptions;

/*Function to display test suite version */
void st_display_fbdev_testsuite_version();

/* Place all extern functions here */
/* Function to display help/usage instructions */
extern void st_display_fbdev_display_test_suite_help();

/* Function to check interface */
extern int st_check_interface(char *);

/* Function to check standard */
extern int st_check_std(char *);

/* To set the interface and standard using sysfs*/
extern int st_set_std_interface(char *,char *);

/* check the pixel format*/
extern int st_chech_pixel_format(char *);




/****************************************************************************
 * Function             - process_fbdev_display_test_options
 * Functionality        - This function parses the command line options and vallues passed for the options
 * Input Params         -  argc,argv
 * Return Value         -  None
 * Note                 -  None
 ****************************************************************************/

static void st_process_fbdev_display_test_options(int argc, char **argv)
{
    int error = FALSE;
    int version = FALSE;
    int help = FALSE;
    int othertests = FALSE;
    int displayfromfile = FALSE;
    int stability_count = DEFAULT_STABILITY_COUNT;
    for (;;) {
        int option_index = 0;
        /** Options for getopt - New test case options added need to be
         * populated here*/
        static struct option long_options[] = {
            {"devicename", optional_argument, NULL, 'n'},
            {"width", optional_argument, NULL, 'w'},
            {"height", optional_argument, NULL, 'h'},
            {"mode", optional_argument, NULL, 'm'},
            {"interface", optional_argument, NULL, 'i'},
            {"standard", optional_argument, NULL, 's'},
            {"noofframes", optional_argument, NULL, 'f'},
            {"bits_per_pixel", optional_argument, NULL, 'b'},
            {"displayOut", optional_argument, NULL, 'd'},
            {"pixel_format", optional_argument, NULL, 'p'},
            {"window_name", optional_argument, NULL, 'W'},
            {"stability_count", optional_argument, NULL, 'c'},
            {"zoom_x", optional_argument, NULL, 'x'},
            {"zoom_y", optional_argument, NULL, 'y'},
            {"repos_x", optional_argument, NULL, 'X'},
            {"repos_y", optional_argument, NULL, 'Y'},
            {"loopcount", optional_argument, NULL, 'L'},
            {"ioctl_no", optional_argument, NULL, 'I'},
            {"greyscale", optional_argument, NULL, 'A'},
            {"redlength", optional_argument, NULL, 'B'},
            {"redoffset", optional_argument, NULL, 'C'},
            {"redmsb", optional_argument, NULL, 'D'},
            {"greenlength", optional_argument, NULL, 'E'},
            {"greenoffset", optional_argument, NULL, 'G'},
            {"greenmsb", optional_argument, NULL, 'H'},
            {"bluelength", optional_argument, NULL, 'K'},
            {"blueoffset", optional_argument, NULL, 'M'},
            {"bluemsb", optional_argument, NULL, 'N'},
            {"translength", optional_argument, NULL, 'O'},
            {"transoffset", optional_argument, NULL, 'P'},
            {"transmsb", optional_argument, NULL, 'Q'},
            {"leftmargin", optional_argument, NULL, 'R'},
            {"rightmargin", optional_argument, NULL, 'S'},
            {"lowermargin", optional_argument, NULL, 'U'},
            {"uppermargin", optional_argument, NULL, 'V'},
            {"hsynclen", optional_argument, NULL, 'Z'},
            {"vsynclen", optional_argument, NULL, 'a'},
            {"sync", optional_argument, NULL, 'e'},
            {"filename",optional_argument,NULL,'F'},
            {"testname", optional_argument, NULL, 't'},
            {"testcaseid", optional_argument, NULL, 'T'},
            {"framerate", no_argument, NULL, 'r'},
            {"cpuload", no_argument, NULL, 'l'},
            {"queue", optional_argument, NULL, 'g'},
            {"version", no_argument, NULL, 'v'},
            {"help", no_argument, NULL, '?'},
            {NULL, 0, NULL, 0}
        };
        int c =
            getopt_long(argc, argv,
                        "n:w:h:m:i:s:f:b:d:p:W:c:x:y:X:Y:L:I:A:B:C:D:E:G:H:K:M:N:O:P:Q:R:S:U:V:Z:a:e:F:t:T::rlgv?",
                        long_options, &option_index);
        if (c == -1) {
            break;
        }

        switch (c) {
        case 'n':
            if (optarg != NULL) {
                testoptions.device_name = optarg;
            } else if (optind < argc && argv[optind]) {
                testoptions.device_name = argv[optind];
            }
            break;
        case 'w':
            if (optarg != NULL) {
                testoptions.width = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                testoptions.width = atoi(argv[optind]);
            }
            break;
        case 'h':
            if (optarg != NULL) {
                testoptions.height = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                testoptions.height = atoi(argv[optind]);
            }
            break;

        case 'm':
            if (optarg != NULL) {
                testoptions.mode = optarg;
            } else if (optind < argc && argv[optind]) {
                testoptions.mode = argv[optind];
            }
            break;

        case 'i':
            if (optarg != NULL) {
                testoptions.interface = optarg;
            } else if (optind < argc && argv[optind]) {
                testoptions.interface = argv[optind];
            }
            break;
        case 's':
            if (optarg != NULL) {
                testoptions.standard = optarg;
            } else if (optind < argc && argv[optind]) {
                testoptions.standard = argv[optind];
            }
            break;
        case 'f':
            if (optarg != NULL) {
                testoptions.no_of_frames = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                testoptions.no_of_frames = atoi(argv[optind]);
            }
            break;
        case 'b':
            if (optarg != NULL) {
                testoptions.bits_per_pixel = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                testoptions.bits_per_pixel = atoi(argv[optind]);
            }
            break;
        case 'd':
            if (optarg != NULL) {
                displayOut = optarg;
            } else if (optind < argc && argv[optind]) {
                displayOut = argv[optind];
            }
            break;
        case 'p':
            if (optarg != NULL) {
                pixel_format = optarg;
            } else if (optind < argc && argv[optind]) {
                pixel_format = argv[optind];
            }
            break;
        case 'W':
            if (optarg != NULL) {
                testoptions.window_name = optarg;
            } else if (optind < argc && argv[optind]) {
                testoptions.window_name = argv[optind];
            }
            break;
        case 'c':
            if (optarg != NULL) {
                stability_count = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                stability_count = atoi(argv[optind]);
            }
            break;
        case 'x':
            if (optarg != NULL) {
                testoptions.zoom_x = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                testoptions.zoom_x = atoi(argv[optind]);
            }
            break;
        case 'y':
            if (optarg != NULL) {
                testoptions.zoom_y = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                testoptions.zoom_y = atoi(argv[optind]);
            }
            break;
        case 'X':
            if (optarg != NULL) {
                testoptions.repos_x = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                testoptions.repos_x = atoi(argv[optind]);
            }
            break;
        case 'L':
            if (optarg != NULL) {
                testoptions.loopcount = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                testoptions.loopcount = atoi(argv[optind]);
            }
            break;
        case 'I':
            if (optarg != NULL) {
                testoptions.ioctl_no = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                testoptions.ioctl_no = atoi(argv[optind]);
            }
            break;
        case 'A':
            if (optarg != NULL) {
                testoptions.greyscale = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                testoptions.greyscale = atoi(argv[optind]);
            }
            break;
        case 'B':
            if (optarg != NULL) {
                testoptions.redlength = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                testoptions.redlength = atoi(argv[optind]);
            }
            break;
        case 'C':
            if (optarg != NULL) {
                testoptions.redoffset = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                testoptions.redoffset = atoi(argv[optind]);
            }
            break;
        case 'D':
            if (optarg != NULL) {
                testoptions.redmsb = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                testoptions.redmsb = atoi(argv[optind]);
            }
            break;
        case 'E':
            if (optarg != NULL) {
                testoptions.greenlength = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                testoptions.greenlength = atoi(argv[optind]);
            }
            break;
        case 'G':
            if (optarg != NULL) {
                testoptions.greenoffset = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                testoptions.greenoffset = atoi(argv[optind]);
            }
            break;
        case 'H':
            if (optarg != NULL) {
                testoptions.greenmsb = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                testoptions.greenmsb = atoi(argv[optind]);
            }
            break;
        case 'K':
            if (optarg != NULL) {
                testoptions.bluelength = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                testoptions.bluelength = atoi(argv[optind]);
            }
            break;
        case 'M':
            if (optarg != NULL) {
                testoptions.blueoffset = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                testoptions.blueoffset = atoi(argv[optind]);
            }
            break;
        case 'N':
            if (optarg != NULL) {
                testoptions.bluemsb = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                testoptions.bluemsb = atoi(argv[optind]);
            }
            break;
        case 'O':
            if (optarg != NULL) {
                testoptions.translength = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                testoptions.translength = atoi(argv[optind]);
            }
            break;
        case 'P':
            if (optarg != NULL) {
                testoptions.transoffset = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                testoptions.transoffset = atoi(argv[optind]);
            }
            break;
        case 'Q':
            if (optarg != NULL) {
                testoptions.transmsb = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                testoptions.transmsb = atoi(argv[optind]);
            }
            break;
        case 'R':
            if (optarg != NULL) {
                testoptions.leftmargin = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                testoptions.leftmargin = atoi(argv[optind]);
            }
            break;
        case 'S':
            if (optarg != NULL) {
                testoptions.rightmargin = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                testoptions.rightmargin = atoi(argv[optind]);
            }
            break;
        case 'U':
            if (optarg != NULL) {
                testoptions.lowermargin = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                testoptions.lowermargin = atoi(argv[optind]);
            }
            break;
        case 'V':
            if (optarg != NULL) {
                testoptions.uppermargin = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                testoptions.uppermargin = atoi(argv[optind]);
            }
            break;
        case 'Z':
            if (optarg != NULL) {
                testoptions.hsynclen= atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                testoptions.hsynclen = atoi(argv[optind]);
            }
            break;
        case 'a':
            if (optarg != NULL) {
                testoptions.vsynclen = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                testoptions.vsynclen = atoi(argv[optind]);
            }
            break;
        case 'e':
            if (optarg != NULL) {
                testoptions.sync = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                testoptions.sync = atoi(argv[optind]);
            }
		case 'F':
	    if (optarg != NULL) {
                filename = optarg;
            } else if (optind < argc && argv[optind]) {
                filename = argv[optind];
            }
			displayfromfile=TRUE;
            break;

        case 'Y':
            if (optarg != NULL) {
                testoptions.repos_y = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                testoptions.repos_y = atoi(argv[optind]);
            }
            break;
        case 't':
            if (optarg != NULL) {
                testname = optarg;
            } else if (optind < argc && argv[optind]) {
                testname = argv[optind];
            }

            othertests = TRUE;
            break;
        case 'T':
            if (optarg != NULL) {
                testcaseid = optarg;
            } else if (optind < argc && argv[optind]) {
                testcaseid = argv[optind];
            }
            break;
        case 'r':
            testoptions.framerate = TRUE; 
            break;
        case 'l':
            testoptions.cpuload = TRUE; 
            break;
        case 'g':
            testoptions.queue = TRUE; 
            break;
        case 'v':
            st_display_fbdev_testsuite_version();
            version = TRUE;
            break;
        case '?':
            help = TRUE;
            break;

        }
    }

    if (version != TRUE && help != TRUE) {
		if (FAILURE == st_check_interface(testoptions.interface)
            || FAILURE == st_check_std(testoptions.standard) || FAILURE == st_set_std_interface(testoptions.standard,testoptions.interface)|| FAILURE == st_check_pixel_format(pixel_format)){
            error = TRUE;

        }
    }
    if (error == TRUE || help == TRUE) {
        st_display_fbdev_display_test_suite_help();
    }
    if ((version != TRUE && help != TRUE) && (error != TRUE)) {

        st_print_fbdev_display_test_params(&testoptions,testcaseid);
        if (othertests != TRUE) {
			if(displayfromfile!=TRUE){
            st_fbdev_display_test(&testoptions, testcaseid, FALSE);
        } else {

        	st_fbdev_display_test_from_file(&testoptions,testcaseid,filename);
        	}
        	}


        else if (strcmp(testname, "stability") == SUCCESS) {
            st_fbdev_stability_test(&testoptions, testcaseid,
                                    stability_count);
        } else if (strcmp(testname, "stress") == SUCCESS) {
            st_fbdev_display_test(&testoptions, testcaseid, TRUE);
        } else if (strcmp(testname, "api") == SUCCESS) {
            st_fbdev_api_test_parser(testoptions.device_name, testcaseid);
        } else if (strcmp(testname, "ioctl") == SUCCESS) {
            st_fbdev_ioctl_test_parser(testoptions.device_name,
                                       testcaseid);
        } else if (strcmp(testname, "square") == SUCCESS) {
            st_fbdev_display_glcd_test(&testoptions,
                                       (char*)testname,testcaseid);
        } else if (strcmp(testname, "chessboard") == SUCCESS) {
            st_fbdev_display_glcd_test(&testoptions,
                                       (char*)testname,testcaseid);
        } else if (strcmp(testname, "image") == SUCCESS) {
            st_fbdev_display_glcd_test(&testoptions,
                                       (char*)testname,testcaseid);
		}else if (strcmp(testname, "colorkey") == SUCCESS) {
            st_fbdev_colorkey_test(&testoptions,
                                      (char*)testname,testcaseid);
		}else if (strcmp(testname, "alpha") == SUCCESS) {
            st_fbdev_alphablending_test(&testoptions,
                                      (char*)testname,testcaseid);
		}
    }
}
void st_display_fbdev_testsuite_version()
{
    printf("FbdevDisplayTestSuite V %s\n", VERSION_STRING);
}




int main(int argc, char *argv[])
{
    /* Initialize options with default vales */
    st_init_fbdev_display_test_params();

    /* Invoke the parser function to process the command line options */
    st_process_fbdev_display_test_options(argc, argv);
    return 0;
}
