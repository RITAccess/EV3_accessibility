/*
 * st_fbdev_api_tests.c
 *
 * This file contains code to test api used by FBDEV driver
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/ 
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/



/* Testcode header files*/

#include "st_fbdev_common.h"



/****************************************************************************
 * Function             - st_fbdev_open_api_test
 * Functionality       - Functiont to check open api used by FBDEV device driver
 * Input Params      - device name, test case id
 * Return Value       - None.
 * Note                   - None
 ****************************************************************************/
void st_fbdev_open_api_test(char *devname, char *test_id)
{

    Int32 retVal = SUCCESS;
    Int32 status = SUCCESS;
    Int32 st_dev = -1;


    /* get device number for a device string to avoid further string operations */
    st_dev = st_fbdev_set_device_number(devname);

    /* open FBDEV display device */
    retVal = st_fbdev_open_interface(st_dev);
    if (SUCCESS != retVal) {
        if (E_DEV_NOT_AVAILABLE == retVal) {
            DBG_PRINT_TRC(("Device is not available"));
            status = NOT_SUPPORTED;
        } else {
            DBG_PRINT_ERR(("Failed to open FBDEV device %s", devname));
            status = FAILURE;
        }
    } else {
        DBG_PRINT_TRC0(("FBDEV %s device opened", devname));
    }

    /* print status of the test case */
    if (FAILURE == status) {
        DBG_PRINT_TST_RESULT_FAIL((test_id));
    } else if (SUCCESS == status) {
        DBG_PRINT_TST_RESULT_PASS((test_id));
    }

    /* end test case */
    DBG_PRINT_TST_END((test_id));

    return;

}


/****************************************************************************
 * Function             - st_fbdev_close_api_test
 * Functionality       - Functiont to check close api used by FBDEV device driver
 * Input Params      - device name, test case id
 * Return Value       - None.
 * Note                   - None
 ****************************************************************************/
void st_fbdev_close_api_test(char *devname, char *test_id)
{

    Int32 retVal = SUCCESS;
    Int32 status = SUCCESS;
    Int32 st_dev = -1;


    /* get device number for a device string to avoid further string operations */
    st_dev = st_fbdev_set_device_number(devname);


    /* close FBDEV device */
    retVal = st_fbdev_close_interface(st_dev);
    if (SUCCESS != retVal) {
        if (E_DEV_NOT_AVAILABLE == retVal) {
            DBG_PRINT_TRC(("Device is not available"));
            status = NOT_SUPPORTED;
        } else {
            DBG_PRINT_ERR(("Failed to close FBDEV device %s", devname));
            status = FAILURE;
        }
    } else {
        DBG_PRINT_TRC0(("FBDEV %s device closed", devname));
    }


    /* print status of the test case */
    if (FAILURE == status) {
        DBG_PRINT_TST_RESULT_FAIL((test_id));
    } else if (SUCCESS == status) {
        DBG_PRINT_TST_RESULT_PASS((test_id));
    }

    /* end test case */
    DBG_PRINT_TST_END((test_id));

    return;

}




/****************************************************************************
 * Function             - st_fbdev_mmap_api_test
 * Functionality       - Functiont to check mmap api used of FBDEV device driver
 * Input Params      - device name, test case id
 * Return Value       - None.
 * Note                   - None
 ****************************************************************************/
void st_fbdev_mmap_api_test(char *devname, char *test_id)
{
    Int32 retVal = SUCCESS;
    Int32 status = SUCCESS;
    st_fb_fix_screeninfo st_fInfo;
    Int32 st_dev = -1;

    /* setting width and height to NTSC resolution- this test is to check functionality of mmap and unmap */
    /* hence resolution is not taken as parameter */
    Int32 st_height = NTSC_HEIGHT;



    /* get device number for a device string to avoid further string operations */
    st_dev = st_fbdev_set_device_number(devname);

    do {
        /* get fixed screen info */
        retVal = st_fbdev_getFscreenInfo_interface(st_dev, &st_fInfo);
        if (SUCCESS != retVal) {
            if (E_DEV_NOT_AVAILABLE == retVal) {
                DBG_PRINT_TRC(("Device is not available"));
                status = NOT_SUPPORTED;
            } else {
                DBG_PRINT_ERR(("FBIOGET_FSCREENINFO Ioctl Failed"));
                status = FAILURE;
            }
            break;
        }
        DBG_PRINT_TRC0(("FBIOGET_FSCREENINFO Ioctl Passed"));

        /* map buffers to user space */
        retVal =
            st_fbdev_mmap_interface(st_dev, st_fInfo.line_length,
                                    st_height);
        if (SUCCESS != retVal) {
            DBG_PRINT_ERR(("FBDEV buffers mapping failed"));
            status = FAILURE;
            break;
        }
        DBG_PRINT_TRC0(("FBDEV buffers mapped to user space"));
        break;
    } while (SUCCESS == retVal);

    /* print status of the test case */
    if (FAILURE == status) {
        DBG_PRINT_TST_RESULT_FAIL((test_id));
    } else if (SUCCESS == status) {
        DBG_PRINT_TST_RESULT_PASS((test_id));
    }

    /* end test case */
    DBG_PRINT_TST_END((test_id));

    return;
}



/****************************************************************************
 * Function             - st_fbdev_unmap_api_test
 * Functionality       - Functiont to check unmap api used of FBDEV device driver
 * Input Params      - device name, test case id
 * Return Value       - None.
 * Note                   - None
 ****************************************************************************/
void st_fbdev_unmap_api_test(char *devname, char *test_id)
{
    Int32 retVal = SUCCESS;
    Int32 status = SUCCESS;
    Int32 st_dev = -1;


    /* get device number for a device string to avoid further string operations */
    st_dev = st_fbdev_set_device_number(devname);

    /* unmap buffers */
    retVal = st_fbdev_unmap_interface(st_dev);
    if (SUCCESS != retVal) {
        if (E_DEV_NOT_AVAILABLE == retVal) {
            DBG_PRINT_TRC(("Device is not available"));
            status = NOT_SUPPORTED;
        } else {
            DBG_PRINT_ERR(("Buffers could not be unmapped"));
            status = FAILURE;
        }
    } else {
        DBG_PRINT_TRC0(("Buffers unmapped"));
    }

    /* print status of the test case */
    if (FAILURE == status) {
        DBG_PRINT_TST_RESULT_FAIL((test_id));
    } else if (SUCCESS == status) {
        DBG_PRINT_TST_RESULT_PASS((test_id));
    }

    /* end test case */
    DBG_PRINT_TST_END((test_id));

    return;
}


/****************************************************************************
 * Function             - st_fbdev_ioctl_api_test
 * Functionality       - Functiont to check ioctl api used of FBDEV device driver
 * Input Params      - device name, test case id
 * Return Value       - None.
 * Note                   - None
 ****************************************************************************/
void st_fbdev_ioctl_api_test(char *devname, char *test_id)
{
    Int32 retVal = SUCCESS;
    Int32 status = SUCCESS;
    st_fb_fix_screeninfo st_fInfo;
    Int32 st_dev = -1;


    /* get device number for a device string to avoid further string operations */
    st_dev = st_fbdev_set_device_number(devname);

    /* get fixed screen info */
    retVal = st_fbdev_getFscreenInfo_interface(st_dev, &st_fInfo);
    if (SUCCESS != retVal) {
        if (E_DEV_NOT_AVAILABLE == retVal) {
            DBG_PRINT_TRC(("Device is not available"));
            status = NOT_SUPPORTED;
        } else {
            DBG_PRINT_ERR(("FBIOGET_FSCREENINFO Ioctl Failed"));
            status = FAILURE;
        }
    } else {
        DBG_PRINT_TRC0(("FBIOGET_FSCREENINFO Ioctl Passed"));
    }

    /* print status of the test case */
    if (FAILURE == status) {
        DBG_PRINT_TST_RESULT_FAIL((test_id));
    } else if (SUCCESS == status) {
        DBG_PRINT_TST_RESULT_PASS((test_id));
    }

    /* end test case */
    DBG_PRINT_TST_END((test_id));

    return;
}


void st_fbdev_api_test_parser(char *devname, char *testcaseid)
{
    st_fbdev_open_api_test(devname, testcaseid);
    st_fbdev_mmap_api_test(devname, testcaseid);
    st_fbdev_ioctl_api_test(devname, testcaseid);
    st_fbdev_unmap_api_test(devname, testcaseid);
    st_fbdev_close_api_test(devname, testcaseid);
}

/* vim: set ts=4 sw=4 tw=80 et:*/
