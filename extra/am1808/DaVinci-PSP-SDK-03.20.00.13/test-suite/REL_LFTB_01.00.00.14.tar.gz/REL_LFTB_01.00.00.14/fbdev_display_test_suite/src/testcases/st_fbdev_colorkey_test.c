/*
 * st_fbdev_colorkey_tests.c
 *
 * This file calls FBDEV driver functions to display color bar on the interface with color keying function,
 * it makes Yellow color transperent from top pipeline and displays vertical color bar of below pipeline. 
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/ 
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/
/* Testcode header files*/
#include "st_fbdev_common.h"
extern Int32 st_img_type;
extern int fd_dev;
Int32 CK_STATUS_T1;
Int32 CK_STATUS_T2;

#define	ENABLE_COLOR_KEY	1
#define	COLOR_KEY			65504
#define	KEY_CHANNEL_OUT		0	
#define	LOOP_COUNT_1		1000		  
#define LOOP_COUNT_2            1000

/* Thread for graphics device 0 */

void *Fbdev0_display(void *ptr) {

    Int32 retVal = SUCCESS;
    Int32 status = SUCCESS;
    st_fb_fix_screeninfo st_fInfo;
    st_fb_var_screeninfo st_vInfo;
    Int32 st_dev = FBDEV_DEV4;			//Frame buffer device 0 
    Uint32 j = 0; 
    struct fbdev_display_testparams * info = (struct fbdev_display_testparams *) ptr;
    Int32 st_width = info->width;
    Int32 st_height = info->height;
	
	/* variables to track device state, mapping of buffers and state of FBDEV window */
    Bool openStatus = FALSE;
    Bool mmapStatus = FALSE;


	/* open FBDEV display device */
        retVal = st_fbdev_open_interface(st_dev);
        status = st_fbdev_checkRetVal(retVal);

		if (SUCCESS != status) {
        }

        openStatus = TRUE;      // device is opened

        DBG_PRINT_TRC0(("FBDEV %s device opened",  FB_DEV4));
				
	  
	  /* get fixed screen info */
        retVal = st_fbdev_getFscreenInfo_interface(st_dev, &st_fInfo);
        if (SUCCESS != retVal) {
            DBG_PRINT_ERR(("FBIOGET_FSCREENINFO Ioctl Failed"));
            status = FAILURE;
        }

        DBG_PRINT_TRC0(("FBIOGET_FSCREENINFO Ioctl Passed"));

        /* get variable screen info */
        retVal = st_fbdev_getVscreenInfo_interface(st_dev, &st_vInfo);
        if (SUCCESS != retVal) {
            DBG_PRINT_ERR(("FBIOGET_VSCREENINFO Ioctl Failed"));
            status = FAILURE;
        }

        DBG_PRINT_TRC0(("FBIOGET_VSCREENINFO Ioctl Passed"));

			st_vInfo.xres = st_width;
			st_vInfo.yres = st_height;
			st_vInfo.xres_virtual = st_width;
			st_vInfo.yres_virtual = st_height*ST_OSD_NUM_BUFS1;
			st_vInfo.red.length= 5;
			st_vInfo.green.length = 6;
			st_vInfo.blue.length = 5;
			st_vInfo.red.offset = 11;
			st_vInfo.green.offset = 5;
			st_vInfo.blue.offset = 0;
			st_vInfo.bits_per_pixel=16;
			st_vInfo.reserved[0] = 255;

		/* put variable screen info */
        retVal = st_fbdev_putVscreenInfo_interface(st_dev, &st_vInfo);
        if (SUCCESS != retVal) {
            DBG_PRINT_ERR(("FBIOPUT_VSCREENINFO Ioctl Failed"));
            status = FAILURE;
        }

        DBG_PRINT_TRC0(("FBIOPUT_VSCREENINFO Ioctl passed"));

        /* get variable screen info */
        retVal = st_fbdev_getFscreenInfo_interface(st_dev, &st_fInfo);
        if (SUCCESS != retVal) {
            DBG_PRINT_ERR(("FBIOGET_FSCREENINFO Ioctl Failed"));
            status = FAILURE;
        }

        DBG_PRINT_TRC0(("FBIOGET_FSCREENINFO Ioctl Passed"));

		/* map vid0 buffers to user space */
        retVal =
            st_fbdev_mmap_interface(st_dev, st_fInfo.line_length,
                                    st_vInfo.yres);
        if (SUCCESS != retVal) {
            DBG_PRINT_ERR(("FBDEV buffers mapping failed"));
            status = FAILURE;
        }

        mmapStatus = TRUE;      // buffers are mapped

        DBG_PRINT_TRC0(("FBDEV buffers mapped to user space"));

        DBG_PRINT_TRC0(("Displaying Buffers"));

        st_img_type = ST_H_PATTERN;				//	For horizontal color bar

		retVal = st_fbdev_display_interface(st_dev, st_vInfo.xres,
		                                             st_vInfo.yres, st_img_type,
		                                             NULL);
		    if (FAILURE == retVal) {
		    	    	  DBG_PRINT_ERR(("FBDEV buffer not set for display"));
		                   status = FAILURE;
		    }
			
		for (j = 0; j < LOOP_COUNT_1; j++) {
				/* get variable screen info */
				retVal = st_fbdev_getVscreenInfo_interface(st_dev, &st_vInfo);
					if (SUCCESS != retVal) {
						DBG_PRINT_ERR(("FBIOGET_VSCREENINFO Ioctl Failed"));
						status = FAILURE;
						break;
					}

				/* set buffer for display */
				retVal = st_fbdev_waitforsync_interface(st_dev);
					if (SUCCESS != retVal) {
						DBG_PRINT_ERR(("FBIO_WAITFORSYNC Ioctl failed"));
						status = FAILURE;
						break;
					}
		}

		/* close device if opened */
		 if (TRUE == openStatus) {
			/* close FBDEV device */
			retVal = st_fbdev_close_interface(st_dev);
			if (SUCCESS != retVal) {
				DBG_PRINT_ERR(("FBDEV %s device not closed",
							    FB_DEV4));
				status = FAILURE;
			}

			openStatus = FALSE;     // device is closed

			DBG_PRINT_TRC0(("FBDEV %s device closed", FB_DEV4));

		}

CK_STATUS_T1 = status; 

return NULL;
}


/* Thread for graphics device 0 */
void *Fbdev1_key_display(void *ptr) {

    Int32 retVal = SUCCESS;
    Int32 status = SUCCESS;
    st_fb_fix_screeninfo st_fInfo;
    st_fb_var_screeninfo st_vInfo;
    struct st_omapfb_color_key  st_ckInfo;
    Int32 st_dev = FBDEV_DEV5;			//Frame buffer device 1 
    Uint32 j = 0;
    struct fbdev_display_testparams * info = (struct fbdev_display_testparams *) ptr;
    Int32 st_width =  info->width;
    Int32 st_height = info->height;
	
	/* variables to track device state, mapping of buffers and state of FBDEV window */
    Bool openStatus = FALSE;
    Bool mmapStatus = FALSE;


	/* open FBDEV display device */
        retVal = st_fbdev_open_interface(st_dev);
        status = st_fbdev_checkRetVal(retVal);

		if (SUCCESS != status) {
        }

        openStatus = TRUE;      // device is opened

        DBG_PRINT_TRC0(("FBDEV %s device opened",  FB_DEV5));
				
	  
	  /* get fixed screen info */
        retVal = st_fbdev_getFscreenInfo_interface(st_dev, &st_fInfo);
        if (SUCCESS != retVal) {
            DBG_PRINT_ERR(("FBIOGET_FSCREENINFO Ioctl Failed"));
            status = FAILURE;
        }

        DBG_PRINT_TRC0(("FBIOGET_FSCREENINFO Ioctl Passed"));

        /* get variable screen info */
        retVal = st_fbdev_getVscreenInfo_interface(st_dev, &st_vInfo);
        if (SUCCESS != retVal) {
            DBG_PRINT_ERR(("FBIOGET_VSCREENINFO Ioctl Failed"));
            status = FAILURE;
        }

        DBG_PRINT_TRC0(("FBIOGET_VSCREENINFO Ioctl Passed"));

		retVal = st_fbdev_get_colorkey_interface(st_dev, &st_ckInfo);
		if (SUCCESS != retVal) {
        	DBG_PRINT_ERR(("OMAPFB_GET_COLOR_KEY Ioctl failed"));
		    status = FAILURE;
               
    	}
		
		DBG_PRINT_TRC0(("OMAPFB_GET_COLOR_KEY Ioctl Passed"));

	    /*Color key parameters*/
		
			st_ckInfo.channel_out = KEY_CHANNEL_OUT;
			st_ckInfo.trans_key = COLOR_KEY;
			st_ckInfo.key_type = ENABLE_COLOR_KEY;

		retVal = st_fbdev_set_colorkey_interface(st_dev, &st_ckInfo);
		if (SUCCESS != retVal) {
        	DBG_PRINT_ERR(("OMAPFB_SET_COLOR_KEY Ioctl failed"));
		    status = FAILURE;
               
    	}

		DBG_PRINT_TRC0(("OMAPFB_SET_COLOR_KEY Ioctl Passed"));
			
		      st_vInfo.xres = st_width;
			st_vInfo.yres = st_height;
			st_vInfo.xres_virtual = st_width;
			st_vInfo.yres_virtual = st_height*ST_OSD_NUM_BUFS1;
			st_vInfo.red.length= 5;
			st_vInfo.green.length = 6;
			st_vInfo.blue.length = 5;
			st_vInfo.red.offset = 11;
			st_vInfo.green.offset = 5;
			st_vInfo.blue.offset = 0;
			st_vInfo.bits_per_pixel=16;
			st_vInfo.reserved[0] = 255;

		/* put variable screen info */
        retVal = st_fbdev_putVscreenInfo_interface(st_dev, &st_vInfo);
        if (SUCCESS != retVal) {
            DBG_PRINT_ERR(("FBIOPUT_VSCREENINFO Ioctl Failed"));
            status = FAILURE;
        }

        DBG_PRINT_TRC0(("FBIOPUT_VSCREENINFO Ioctl passed"));

        /* get variable screen info */
        retVal = st_fbdev_getFscreenInfo_interface(st_dev, &st_fInfo);
        if (SUCCESS != retVal) {
            DBG_PRINT_ERR(("FBIOGET_FSCREENINFO Ioctl Failed"));
            status = FAILURE;
        }

        DBG_PRINT_TRC0(("FBIOGET_FSCREENINFO Ioctl Passed"));

		/* map vid0 buffers to user space */
        retVal =
            st_fbdev_mmap_interface(st_dev, st_fInfo.line_length,
                                    st_vInfo.yres);
        if (SUCCESS != retVal) {
            DBG_PRINT_ERR(("FBDEV buffers mapping failed"));
            status = FAILURE;
        }

        mmapStatus = TRUE;      // buffers are mapped

        DBG_PRINT_TRC0(("FBDEV buffers mapped to user space"));

        DBG_PRINT_TRC0(("Displaying Buffers"));

        st_img_type = ST_V_PATTERN;				//	For vertical color bar

		retVal = st_fbdev_display_interface(st_dev, st_vInfo.xres,
		                                             st_vInfo.yres, st_img_type,
		                                             NULL);
		    if (FAILURE == retVal) {
		    	    	  DBG_PRINT_ERR(("FBDEV buffer not set for display"));
		                   status = FAILURE;
		    }
			
		for (j = 0; j < LOOP_COUNT_2; j++) {
				/* get variable screen info */
				retVal = st_fbdev_getVscreenInfo_interface(st_dev, &st_vInfo);
					if (SUCCESS != retVal) {
						DBG_PRINT_ERR(("FBIOGET_VSCREENINFO Ioctl Failed"));
						status = FAILURE;
						break;
					}


				/* set buffer for display */
				retVal = st_fbdev_waitforsync_interface(st_dev);
					if (SUCCESS != retVal) {
						DBG_PRINT_ERR(("FBIO_WAITFORSYNC Ioctl failed"));
						status = FAILURE;
						break;
					}
		}

		/* close device if opened */
		 if (TRUE == openStatus) {
			/* close FBDEV device */
			retVal = st_fbdev_close_interface(st_dev);
			if (SUCCESS != retVal) {
				DBG_PRINT_ERR(("FBDEV %s device not closed",
							    FB_DEV5));
				status = FAILURE;
			}

			openStatus = FALSE;     // device is closed

			DBG_PRINT_TRC0(("FBDEV %s device closed", FB_DEV5));

		}

CK_STATUS_T2 = status; 

return NULL;
}

void st_fbdev_colorkey_test(struct fbdev_display_testparams *info,
                           char *testname, char* test_id)
{
	int ret1, ret2;
	Int32 status = FAILURE;
	pthread_t t1, t2;

      DBG_PRINT_TRC0(("Test to display horizontal color bar on FBDEV0 pipeline and vertical color bar on FBDEV1 pipeline"));
      DBG_PRINT_TRC0(("Colorkeying enable makes Yellow bar from FBDEV0 transperent and you can see vertical color bar from FBDEV1 there"));
 
	ret1 = pthread_create(&t1, NULL, Fbdev0_display, (void *)info); 			//Thread one for displaying horizontal color bar
	ret2 = pthread_create(&t2, NULL, Fbdev1_key_display, (void *)info);			//Thread two for displaying verical color bar with keying enable
	pthread_join(t1, NULL);
	pthread_join(t2, NULL);

	if (SUCCESS == CK_STATUS_T1) {
		if (SUCCESS == CK_STATUS_T2) {
			status = SUCCESS;
		}
	} 
	
    /* end test case */
	st_fbdev_display_test_status(status, test_id);
	
 	return;
}
