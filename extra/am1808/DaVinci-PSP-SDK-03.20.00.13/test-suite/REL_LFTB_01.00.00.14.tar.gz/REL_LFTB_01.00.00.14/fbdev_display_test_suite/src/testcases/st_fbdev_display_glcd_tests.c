/*
 * st_fbdev_display_glcd_tests.c
 *
 * This file contains code to test glcd interface used by FBDEV driver
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/ 
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/

/* Testcode header files*/
#include "st_fbdev_common.h"

extern char *displayOut;
extern Int32 st_img_type;

/****************************************************************************
 * Function             - st_fbdev_display_test
 * Functionality       - Function to display image of given width*height on the
 *                              all FBDEV supported windows
 * Input Params      - mode and interface. resolution of the image,  test case id.
 * Return Value       - None.
 * Note                   - None
 ****************************************************************************/
void st_fbdev_display_glcd_test(struct fbdev_display_testparams *info,
                           char *testname, char* test_id)
{

    Int32 retVal = SUCCESS;
    Int32 status = SUCCESS;
    st_fb_fix_screeninfo st_fInfo;
    st_fb_var_screeninfo st_vInfo;
    Int32 st_dev = -1;
    Bool endLoop = FALSE;
    
    
    /* variables to track device state, mapping of buffers and state of FBDEV window */
    Bool openStatus = FALSE;
    Bool mmapStatus = FALSE;
    /* get device number for a device string to avoid further string operations */
    st_dev = st_fbdev_set_device_number(info->device_name);
    do {

        retVal = st_fbdev_change_sysfs_interface(info->standard,info->interface);
        status = st_fbdev_checkRetVal(retVal);
        if (SUCCESS != status)
        {
            break;
        }

        DBG_PRINT_TRC0(("sysfs variables set"));
        /* open FBDEV display device */
        retVal = st_fbdev_open_interface(st_dev);
        status = st_fbdev_checkRetVal(retVal);
        if (SUCCESS != status) {
            break;
        }

        openStatus = TRUE;      // device is opened

        DBG_PRINT_TRC0(("FBDEV %s device opened", info->device_name));
    

        /* get fixed screen info */
        retVal = st_fbdev_getFscreenInfo_interface(st_dev, &st_fInfo);
        if (SUCCESS != retVal) {
            DBG_PRINT_ERR(("FBIOGET_FSCREENINFO Ioctl Failed"));
            status = FAILURE;
            break;
        }

        DBG_PRINT_TRC0(("FBIOGET_FSCREENINFO Ioctl Passed"));

        /* get variable screen info */
        retVal = st_fbdev_getVscreenInfo_interface(st_dev, &st_vInfo);
        if (SUCCESS != retVal) {
            DBG_PRINT_ERR(("FBIOGET_VSCREENINFO Ioctl Failed"));
            status = FAILURE;
            break;
        }

        DBG_PRINT_TRC0(("FBIOGET_VSCREENINFO Ioctl Passed"));
        
        /* map the fbdev buffers to user space */
        retVal =
            st_fbdev_mmap_interface(st_dev, st_fInfo.line_length,
                                    st_vInfo.yres);
        if (SUCCESS != retVal) {
            DBG_PRINT_ERR(("FBDEV buffers mapping failed"));
            status = FAILURE;
            break;
        }
        mmapStatus = TRUE;      // buffers are mapped

        DBG_PRINT_TRC0(("FBDEV buffers mapped to user space"));

        DBG_PRINT_TRC0(("Displaying Buffers"));

        /* display buffers */
        do {

               if (strcmp(testname, "square") == SUCCESS) {
                         retVal =
                                st_fbdev_display_square_interface(st_dev,st_vInfo,st_fInfo);
                        if (SUCCESS != retVal) {
                              DBG_PRINT_ERR(("Displaying square pattern failed"));
                              status = FAILURE;
                              break;
                            }
                        DBG_PRINT_TRC0(("Displaying square pattern Pass"));
                        
                        sleep(10);
                     endLoop = TRUE;

                }
               else if (strcmp(testname, "chessboard") == SUCCESS) {
                     retVal =
                                st_fbdev_display_chess_interface(st_dev,st_vInfo,st_fInfo);
                        if (SUCCESS != retVal) {
                              DBG_PRINT_ERR(("Displaying Chess board pattern failed"));
                              status = FAILURE;
                              break;
                            }
                        DBG_PRINT_TRC0(("Displaying Chess board pattern Pass"));
                        
                        sleep(10);
                     endLoop = TRUE;
                }
                else
                {
                     retVal =
                        st_fbdev_display_natural_image_interface(st_dev,st_vInfo,st_fInfo);
                        if (SUCCESS != retVal) {
                              DBG_PRINT_ERR(("Displaying Image failed"));
                              status = FAILURE;
                              break;
                            }
                        DBG_PRINT_TRC0(("Displaying Image Pass"));
                        
                        sleep(10);
                     endLoop = TRUE;
                }
             } while (FALSE == endLoop);

              break;      
            
        } while (SUCCESS == retVal);

    /* unmap buffers if mapped */
    if (TRUE == mmapStatus) {
        /* unmap buffers */
        retVal = st_fbdev_unmap_interface(st_dev);
        if (FAILURE == retVal) {
            DBG_PRINT_ERR(("Buffers could not be unmapped"));
            status = FAILURE;
        }

        mmapStatus = FALSE;     // buffers not mapped

        DBG_PRINT_TRC0(("Buffers unmapped"));
    }


    /* close device if opened */
    if (TRUE == openStatus) {
        /* close FBDEV device */
        retVal = st_fbdev_close_interface(st_dev);
        if (SUCCESS != retVal) {
            DBG_PRINT_ERR(("FBDEV %s device not closed",
                           info->device_name));
            status = FAILURE;
        }

        openStatus = FALSE;     // device is closed

        DBG_PRINT_TRC0(("FBDEV %s device closed", info->device_name));
    }



    /* end test case */
    DBG_PRINT_TST_END((test_id));

    return;

}

/* vim: set ts=4 sw=4 tw=80 et:*/
