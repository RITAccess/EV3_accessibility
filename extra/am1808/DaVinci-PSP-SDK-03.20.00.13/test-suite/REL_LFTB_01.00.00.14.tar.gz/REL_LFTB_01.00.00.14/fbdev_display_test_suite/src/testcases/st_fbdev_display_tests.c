/*
 * st_fbdev_display_tests.c
 *
 * This file calls FBDEV driver functions to display color bar on the interface 
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/ 
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */
/* Testcode header files*/
#include "st_fbdev_common.h"

extern char *displayOut;
extern Int32 st_img_type;

/****************************************************************************
 * Function             - st_fbdev_display_test_status
 * Functionality        - This function prints test status
 * Input Params         - status, test id
 * Return Value         - none
 * Note                 - None
 ****************************************************************************/
void st_fbdev_display_test_status(Int32 status, char *test_id)
{
    /* print status of the test case */
    if (FAILURE == status) {
        DBG_PRINT_TST_RESULT_FAIL((test_id));
    } else if (SUCCESS == status) {
        DBG_PRINT_TST_RESULT_PASS((test_id));
    }

    /* end test case */
    DBG_PRINT_TST_END((test_id));
}


/****************************************************************************
 * Function             - st_fbdev_display_test
 * Functionality       - Function to display image of given width*height on the
 *                              all FBDEV supported windows
 * Input Params      - mode and interface. resolution of the image,  test case id.
 * Return Value       - None.
 * Note                   - None
 ****************************************************************************/
void st_fbdev_display_test(struct fbdev_display_testparams *info,
        char *test_id, Bool stressTest)
{

    Int32 retVal = SUCCESS;
    Int32 status = SUCCESS;
    st_fb_fix_screeninfo st_fInfo;
    st_fb_var_screeninfo st_vInfo;
    st_zoom_params st_zoomprms;
    st_vpbe_window_position def_pos;
    Int32 st_dev = -1;
    Uint32 i = 0;
    Int32 st_width = info->width;
    Int32 st_height = info->height;
    //   int st_mode;
    ST_TIMER_ID currentTime;
    ST_CPU_STATUS_ID cpuStatusId;
    float percentageCpuLoad = 0;
    long dtime[MAXLOOPCOUNT];
    double diffd[MAXLOOPCOUNT];
    int frmd=0,j=0 ;
    float avgd=0.0, sumd=0.0;


    /* variables to track device state, mapping of buffers and state of FBDEV window */
    Bool openStatus = FALSE;
    Bool mmapStatus = FALSE;
    Bool winStatus = FALSE;
    /* get device number for a device string to avoid further string operations */
    st_dev = st_fbdev_set_device_number(info->device_name);
    do {

        retVal = st_fbdev_change_sysfs_interface(info->standard,info->interface);
        status = st_fbdev_checkRetVal(retVal);
        if (SUCCESS != status)
        {
            break;
        }

        DBG_PRINT_TRC0(("sysfs variables set"));
        /* open FBDEV display device */
        retVal = st_fbdev_open_interface(st_dev);
        status = st_fbdev_checkRetVal(retVal);
        if (SUCCESS != status) {
            break;
        }

        openStatus = TRUE;      // device is opened

        DBG_PRINT_TRC0(("FBDEV %s device opened", info->device_name));


        if (FBDEV_DEV4 != st_dev) {
            /* Enable window */
            retVal =
                st_fbdev_blank_window_interface(st_dev, ST_DISABLE_WIN);
            if (SUCCESS != retVal) {
                DBG_PRINT_ERR(("FBDEV window not disabled"));
                status = FAILURE;
                break;
            }

            winStatus = FALSE;  // window is enabled

            DBG_PRINT_TRC0(("FBDEV window disabled"));
        }

        /* get fixed screen info */
        retVal = st_fbdev_getFscreenInfo_interface(st_dev, &st_fInfo);
        if (SUCCESS != retVal) {
            DBG_PRINT_ERR(("FBIOGET_FSCREENINFO Ioctl Failed"));
            status = FAILURE;
            break;
        }

        DBG_PRINT_TRC0(("FBIOGET_FSCREENINFO Ioctl Passed"));

        /* get variable screen info */
        retVal = st_fbdev_getVscreenInfo_interface(st_dev, &st_vInfo);
        if (SUCCESS != retVal) {
            DBG_PRINT_ERR(("FBIOGET_VSCREENINFO Ioctl Failed"));
            status = FAILURE;
            break;
        }

        DBG_PRINT_TRC0(("FBIOGET_VSCREENINFO Ioctl Passed"));

        st_vInfo.xres                = st_width ;
        st_vInfo.yres               = st_height ; 

        /* Modify the resolution, bpp, vmode  as required */
        if (info->repos_x == 0 && info->repos_y == 0) { /*if it is not a reposition test */
            st_vInfo.xres = st_width;
            st_vInfo.yres = st_height;
        } else {
            st_vInfo.xres = st_width - info->repos_x;
            st_vInfo.yres = st_height - info->repos_y;
        }

        if (!strcmp(info->mode, "INTERLACED")) {
            st_vInfo.vmode = ST_FB_VMODE_INTERLACED;
        } else if (!strcmp(info->mode, "PROGRESSIVE")) {
            st_vInfo.vmode = ST_FB_VMODE_NONINTERLACED;
        }

        /* Change the virtual Y-resolution for buffer flipping (3 buffers) */
        if (FBDEV_DEV3 == st_dev || FBDEV_DEV1 == st_dev) {
            st_vInfo.yres_virtual = MAX_HEIGHT * ST_VIDEO_NUM_BUFS;     
            st_vInfo.xres_virtual = st_fInfo.line_length / 2;
            st_vInfo.bits_per_pixel = info->bits_per_pixel;
        } else if (FBDEV_DEV0 == st_dev) {
            st_vInfo.xres                = st_width ;
            st_vInfo.yres               = st_height ;
            st_vInfo.yres_virtual = st_vInfo.yres * ST_OSD_NUM_BUFS;
            st_vInfo.bits_per_pixel = info->bits_per_pixel;
        } else if (FBDEV_DEV2 == st_dev) {
            st_vInfo.yres_virtual = st_vInfo.yres * ST_OSD_NUM_BUFS;
            st_vInfo.bits_per_pixel = info->bits_per_pixel;
        } else if (FBDEV_DEV4 == st_dev) {
           // if (!strcmp(displayOut, "LCD")) {
                st_vInfo.xres = st_width;
                st_vInfo.yres = st_height;
          //  }

            st_vInfo.xres_virtual = st_vInfo.xres;
            st_vInfo.yres_virtual = st_vInfo.yres * ST_OSD_NUM_BUFS;
            st_vInfo.bits_per_pixel = info->bits_per_pixel;
            st_vInfo.red.length = 5;
            st_vInfo.green.length = 6;
            st_vInfo.blue.length = 5;
            st_vInfo.red.offset = 11;
            st_vInfo.green.offset = 5;
            st_vInfo.blue.offset = 0;
        }

        /* put variable screen info */
        retVal = st_fbdev_putVscreenInfo_interface(st_dev, &st_vInfo);
        if (SUCCESS != retVal) {
            DBG_PRINT_ERR(("FBIOPUT_VSCREENINFO Ioctl Failed"));
            status = FAILURE;
            break;
        }
        DBG_PRINT_TRC0(("FBIOPUT_VSCREENINFO Ioctl passed"));
        if (info->zoom_x != 0 && info->zoom_y != 0) {
            st_zoomprms.window_id = st_dev;
            st_zoomprms.zoom_h = info->zoom_x;
            st_zoomprms.zoom_v = info->zoom_y;
            retVal =
                st_fbdev_setZoom_ioctl_interface(st_dev, &st_zoomprms);
            status = st_fbdev_checkRetVal(retVal);
            if (SUCCESS != status) {
                break;
            }
        } else if (info->repos_x != 0 && info->repos_y != 0) {
            def_pos.xpos = XPOS_DEFAULT;
            def_pos.ypos = YPOS_DEFAULT;
            retVal = st_fbdev_setpos_interface(st_dev, &def_pos);
            status = st_fbdev_checkRetVal(retVal);
            if (SUCCESS != status) {
                break;
            }
        }

        /* get variable screen info */
        retVal = st_fbdev_getFscreenInfo_interface(st_dev, &st_fInfo);
        if (SUCCESS != retVal) {
            DBG_PRINT_ERR(("FBIOGET_FSCREENINFO Ioctl Failed"));
            status = FAILURE;
            break;
        }

        DBG_PRINT_TRC0(("FBIOGET_FSCREENINFO Ioctl Passed"));

        if (FBDEV_DEV4 != st_dev) {
            /* Enable window */
            retVal =
                st_fbdev_blank_window_interface(st_dev, ST_ENABLE_WIN);
            if (SUCCESS != retVal) {
                DBG_PRINT_ERR(("FBDEV window not enabled"));
                status = FAILURE;
                break;
            }

            winStatus = TRUE;   // window is enabled

            DBG_PRINT_TRC0(("FBDEV window enabled"));
        }

     if (info->queue != TRUE)
     {
        DBG_PRINT_TRC0(("Displaying"));

        /* map vid0 buffers to user space */
        retVal =
            st_fbdev_map_and_disp_interface(st_dev, st_fInfo.line_length,
                    st_vInfo.yres);
        if (SUCCESS != retVal) {
            DBG_PRINT_ERR(("FBDEV buffers mapping and display failed"));
            status = FAILURE;
            break;
        }
        break;
      }

    if (info->queue == TRUE)
    {
        /* map vid0 buffers to user space */
        retVal =
            st_fbdev_mmap_interface(st_dev, st_fInfo.line_length,
                    st_vInfo.yres);
        if (SUCCESS != retVal) {
            DBG_PRINT_ERR(("FBDEV buffers mapping failed"));
            status = FAILURE;
            break;
        }
        mmapStatus = TRUE;      // buffers are mapped

        DBG_PRINT_TRC0(("FBDEV buffers mapped to user space"));

        DBG_PRINT_TRC0(("Displaying Buffers"));

        retVal =
            st_fbdev_display_interface(st_dev, st_vInfo.xres,
                    st_vInfo.yres, st_img_type,
                    NULL);
        if (FAILURE == retVal) {
            DBG_PRINT_ERR(("FBDEV buffer not set for display"));
            status = FAILURE;
            break;
        }
        /* display buffers */
        if(info->cpuload == TRUE)
        {
            startCpuLoadMeasurement (&cpuStatusId);
        }
        for(i=0;i<info->no_of_frames;i++)
        { 

            retVal = st_fbdev_getVscreenInfo_interface(st_dev, &st_vInfo);
            if (SUCCESS != retVal) {
                DBG_PRINT_ERR(("FBIOGET_VSCREENINFO Ioctl Failed"));
                status = FAILURE;
                break;
            }
            if (ST_H_PATTERN == st_img_type)
                st_vInfo.yoffset = i % st_vInfo.yres;
            else
                st_vInfo.yoffset = st_vInfo.yres * retVal;      //retVal contains the buffer index

            retVal = st_fbdev_pandisplay_interface(st_dev, &st_vInfo);
            if (SUCCESS != retVal) {
                DBG_PRINT_ERR(("FBIOPAN_DISPLAY Ioctl failed"));
                status = FAILURE;
                break;
            }

            if(info->framerate == TRUE)
            {
                getTime(&currentTime);
                dtime[j++]= currentTime.tv_usec;
            }
            retVal = st_fbdev_waitforsync_interface(st_dev);
            if (SUCCESS != retVal) {
                DBG_PRINT_ERR(("FBIO_WAITFORSYNC Ioctl failed"));
                status = FAILURE;
                break;
            }

        } 

        if(info->cpuload == TRUE)
        {
            percentageCpuLoad = stopCpuLoadMeasurement (&cpuStatusId);
        }
        if(info->framerate == TRUE)
        {
            /*Calculate the frame rate */
            for(j=0;j<((info->no_of_frames)-1);j++)
            {       if(dtime[j+1] > dtime[j])
                {       diffd[j]=dtime[j+1]-dtime[j];
                    diffd[j]= (1/(diffd[j]/1000000));
                }
                else
                {       diffd[j] = (1000000 - dtime[j]) + dtime[j+1];
                    diffd[j]= (1/(diffd[j]/1000000));
                }
            }

            for(j=0; j<((info->no_of_frames)-1); j++)
            {
                if(diffd[j]>0)
                {   sumd=sumd+diffd[j];
                    frmd++;
                }
            }
            avgd=sumd/(frmd-1);
            DBG_PRINT_TRC0(("The Fbdev Display : Frame rate = %lf",avgd));
        }

        if(info->cpuload == TRUE)
        {
            DBG_PRINT_TRC0(("The Fbdev Display : Percentage CPU Load:%.2f%%",percentageCpuLoad));
        }

        break;                  // break out of while loop after display
}

    } while (SUCCESS == retVal);
    if (info->queue == TRUE)
    {
    /* unmap buffers if mapped */
    if (TRUE == mmapStatus) {
        /* unmap buffers */
        retVal = st_fbdev_unmap_interface(st_dev);
        if (FAILURE == retVal) {
            DBG_PRINT_ERR(("Buffers could not be unmapped"));
            status = FAILURE;
        }

        mmapStatus = FALSE;     // buffers not mapped

        DBG_PRINT_TRC0(("Buffers unmapped"));
    }

    /* disable win if enabled */
    if (TRUE == winStatus) {
        /* disable FBDEV window */
        retVal = st_fbdev_blank_window_interface(st_dev, ST_DISABLE_WIN);
        if (SUCCESS != retVal) {
            DBG_PRINT_ERR(("FBDEV window not disabled"));
            status = FAILURE;
        }

        winStatus = FALSE;      // window is disabled

        DBG_PRINT_TRC0(("window disabled"));
    }
    }
    /* close device if opened */
    if (TRUE == openStatus) {
        /* close FBDEV device */
        retVal = st_fbdev_close_interface(st_dev);
        if (SUCCESS != retVal) {
            DBG_PRINT_ERR(("FBDEV %s device not closed",
                        info->device_name));
            status = FAILURE;
        }

        openStatus = FALSE;     // device is closed

        DBG_PRINT_TRC0(("FBDEV %s device closed", info->device_name));
    }


    /* print status of the test case */
    if (FAILURE == status) {
        DBG_PRINT_TST_RESULT_FAIL((test_id));
    } else if (SUCCESS == status) {
        DBG_PRINT_TST_RESULT_PASS((test_id));
    }

    /* end test case */
    DBG_PRINT_TST_END((test_id));

    return;

}

/* vim: set ts=4 sw=4 tw=80 et:*/
