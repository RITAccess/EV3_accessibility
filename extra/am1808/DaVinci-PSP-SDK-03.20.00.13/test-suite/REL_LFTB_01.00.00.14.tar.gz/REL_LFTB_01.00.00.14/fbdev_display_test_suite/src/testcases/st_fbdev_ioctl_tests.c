/*
 * st_fbdev_ioctl_tests.c
 *
 * This file calls FBDEV driver functions to test all the ioctls
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/ 
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/
/*Testcode related header files*/
#include "st_fbdev_common.h"

/* FBDEV structs, enums, macros defined */
extern struct fbdev_display_testparams testoptions;

/****************************************************************************
 * Function             - st_fbdev_setBitmapBlendFactor_ioctl_test
 * Functionality       - Function to set bitmap blend factor
 * Input Params      - automated, devname and test case id.
 * Return Value       - None.
 * Note                   - None
 ****************************************************************************/
void st_fbdev_setBitmapBlendFactor_ioctl_test(char *devname, char *test_id)
{

    Int32 retVal = SUCCESS;
    Int32 status = SUCCESS;
    st_vpbe_bitmap_blend_params st_bFactor;
    Int32 st_dev = -1;
    Uint32 bf = BLEND_FACTOR_0;

    /* variables to track device state, mapping of buffers and state of FBDEV window */
    Bool openStatus = FALSE;
    Bool endLoop = FALSE;


    /* get device number for a device string to avoid further string operations */
    st_dev = st_fbdev_set_device_number(devname);

    /* initialize st_vpbe_bitmap_blend_params structure object */
    st_bFactor.enable_colorkeying = 0;  // disable color keying
    st_bFactor.colorkey = 0;    // set color key to 0

    /* check that ioctl is being executed on ghraphics window */
    if (FBDEV_DEV1 == st_dev || FBDEV_DEV3 == st_dev) {
        DBG_PRINT_TRC(("This ioctl is not supported on video windows"));
        status = NOT_SUPPORTED;
    } else {
        /* open device */
        status = st_fbdev_openAndreturn(&st_dev, devname);
        if (SUCCESS == status)  // open is success
        {
            openStatus = TRUE;  // device is opened
            DBG_PRINT_TRC0(("FBDEV %s device opened", devname));

            do {

                st_bFactor.bf = bf;
                retVal =
                    st_fbdev_setBitmatBlendFactor_ioctl_interface(st_dev,
                                                                  &st_bFactor);
                if (SUCCESS != retVal) {
                    if (E_DEV_NOT_AVAILABLE == retVal) {
                        DBG_PRINT_TRC(("Device is not available"));
                        status = NOT_SUPPORTED;
                    } else {
                        DBG_PRINT_ERR(("FBIO_SET_BITMAP_BLEND_FACTOR ioctl Failed for %d blend factor", st_bFactor.bf));
                        status = FAILURE;
                    }
                }
                DBG_PRINT_TRC(("FBIO_SET_BITMAP_BLEND_FACTOR ioctl  successful for %d blend factor", st_bFactor.bf));
                bf++;           // increment the blend factor

                if (BLEND_FACTOR_7 < bf) {
                    endLoop = TRUE;     //break out of do-while 

                }
            } while (FALSE == endLoop);
        }
    }

    /* close device if opened */
    if (TRUE == openStatus) {
        /* close FBDEV device */
         st_fbdev_closeAndreturn(&st_dev, devname);
    }


    st_fbdev_display_test_status(status, test_id);

    return;

}



/****************************************************************************
 * Function             - st_fbdev_getBlinkInterval_ioctl_test
 * Functionality       - Function to get blink interval
 * Input Params      - device name,  test case id.
 * Return Value       - None.
 * Note                   - None
 ****************************************************************************/
void st_fbdev_getBlinkInterval_ioctl_test(char *devname, char *test_id)
{
    Int32 retVal = SUCCESS;
    Int32 status = SUCCESS;
    Int32 st_dev = -1;
    st_vpbe_blink_option st_getBlink;

    /* variables to track device state, mapping of buffers and state of FBDEV window */
    Bool openStatus = FALSE;


    /* get device number for a device string to avoid further string operations */
    st_dev = st_fbdev_set_device_number(devname);

    if (FBDEV_DEV2 != st_dev) {
        DBG_PRINT_TRC(("This ioctl is supported only on attribute window"));
        status = NOT_SUPPORTED;
    } else {
        /* open device */
        status = st_fbdev_openAndreturn(&st_dev, devname);
        if (SUCCESS == status)  // open is success
        {
            openStatus = TRUE;  // device is opened
            DBG_PRINT_TRC0(("FBDEV %s device opened", devname));

            /* get blink interval */
            retVal =
                st_fbdev_getBlinkInterval_ioctl_interface(st_dev,
                                                          &st_getBlink);
            if (SUCCESS != retVal) {
                if (E_DEV_NOT_AVAILABLE == retVal) {
                    DBG_PRINT_TRC(("Device is not available"));
                    status = NOT_SUPPORTED;
                } else {
                    DBG_PRINT_ERR(("FBIO_GET_BLINK_INTERVAL ioctl Failed"));
                    status = FAILURE;
                }
            }
            /* print values */
            if (ENABLE == st_getBlink.blinking) {
                DBG_PRINT_TRC(("Blinking is enabled"));
            } else {
                DBG_PRINT_TRC(("Blinking is disabled"));
            }

            DBG_PRINT_TRC(("Blinking interval is %d",
                           st_getBlink.interval));

            DBG_PRINT_TRC(("FBIO_GET_BLINK_INTERVAL ioctl  successful"));

        }
    }

    /* close device if opened */
    if (TRUE == openStatus) {
        /* close FBDEV device */
        status = st_fbdev_closeAndreturn(&st_dev, devname);
        if (SUCCESS == status) {
            openStatus = FALSE; // device is closed
        }
    }

    /* print status of the test case */
    st_fbdev_display_test_status(status, test_id);

    return;
}



/****************************************************************************
 * Function             - st_fbdev_setBlinkInterval_ioctl_test
 * Functionality       - Function to get blink interval
 * Input Params      - device name,  test case id.
 * Return Value       - None.
 * Note                   - None
 ****************************************************************************/
void st_fbdev_setBlinkInterval_ioctl_test(char *devname, char *test_id)
{
    Int32 retVal = SUCCESS;
    Int32 status = SUCCESS;
    Int32 st_dev = -1;
    st_vpbe_blink_option st_setBlink;
    st_vpbe_blink_option st_getBlink;
    Int32 st_blink = ST_BLINK1;

    /* variables to track device state, mapping of buffers and state of FBDEV window */
    Bool openStatus = FALSE;
    Bool endLoop = FALSE;


    /* get device number for a device string to avoid further string operations */
    st_dev = st_fbdev_set_device_number(devname);

    if (FBDEV_DEV2 != st_dev) {
        DBG_PRINT_TRC(("This ioctl is supported only on attribute window"));
        status = NOT_SUPPORTED;
    } else {
        /* open device */
        status = st_fbdev_openAndreturn(&st_dev, devname);
        if (SUCCESS == status)  // open is success
        {
            openStatus = TRUE;  // device is opened
            DBG_PRINT_TRC0(("FBDEV %s device opened", devname));

            do {

                st_setBlink.blinking = ENABLE;
                st_setBlink.interval = st_blink;

                /* set blink interval */
                retVal =
                    st_fbdev_setBlinkInterval_ioctl_interface(st_dev,
                                                              &st_setBlink);
                if (SUCCESS != retVal) {
                    if (E_DEV_NOT_AVAILABLE == retVal) {
                        DBG_PRINT_TRC(("Device is not available"));
                        status = NOT_SUPPORTED;
                    } else {
                        DBG_PRINT_ERR(("FBIO_SET_BLINK_INTERVAL ioctl Failed for %d blink factor", st_setBlink.interval));
                        status = FAILURE;
                    }
                }
                DBG_PRINT_TRC(("FBIO_SET_BLINK_INTERVAL ioctl  successful for %d blend factor", st_setBlink.interval));

                /* get blink interval */
                retVal =
                    st_fbdev_getBlinkInterval_ioctl_interface(st_dev,
                                                              &st_getBlink);
                if (SUCCESS != retVal) {
                    if (E_DEV_NOT_AVAILABLE == retVal) {
                        DBG_PRINT_TRC(("Device is not available"));
                        status = NOT_SUPPORTED;
                    } else {
                        DBG_PRINT_ERR(("FBIO_GET_BLINK_INTERVAL ioctl Failed"));
                        status = FAILURE;
                    }
                }
                DBG_PRINT_TRC(("FBIO_GET_BLINK_INTERVAL ioctl  successful"));

                /* compare if get and set values are same or not */
                if (st_setBlink.interval != st_getBlink.interval) {
                    status = FAILURE;
                }

                st_blink++;     // increment the blend factor

                if (ST_BLINK4 < st_blink) {
                    endLoop = TRUE;     //break out of do-while 
                }

            } while (FALSE == endLoop);



        }
    }

    /* close device if opened */
    if (TRUE == openStatus) {
        /* close FBDEV device */
        status = st_fbdev_closeAndreturn(&st_dev, devname);
        if (SUCCESS == status) {
            openStatus = FALSE; // device is closed
        }
    }

    /* print status of the test case */
    st_fbdev_display_test_status(status, test_id);

    return;

}


/****************************************************************************
 * Function             - st_fbdev_getVideoConfigParams_ioctl_test
 * Functionality       - Function to get config params
 * Input Params      - device name,  test case id.
 * Return Value       - None.
 * Note                   - None
 ****************************************************************************/
void st_fbdev_getVideoConfigParams_ioctl_test(char *devname, char *test_id)
{
    Int32 retVal = SUCCESS;
    Int32 status = SUCCESS;
    Int32 st_dev = -1;
    st_vpbe_video_config_params st_getparams;

    /* variables to track device state, mapping of buffers and state of FBDEV window */
    Bool openStatus = FALSE;


    /* get device number for a device string to avoid further string operations */
    st_dev = st_fbdev_set_device_number(devname);

    /* open device */
    status = st_fbdev_openAndreturn(&st_dev, devname);
    if (SUCCESS == status)      // open is success
    {
        openStatus = TRUE;      // device is opened
        DBG_PRINT_TRC0(("FBDEV %s device opened", devname));

        /* get config params */
        retVal =
            st_fbdev_getVideoConfigParams_ioctl_interface(st_dev,
                                                          &st_getparams);
        if (SUCCESS != retVal) {
            if (E_DEV_NOT_AVAILABLE == retVal) {
                DBG_PRINT_TRC(("Device is not available"));
                status = NOT_SUPPORTED;
            } else {
                DBG_PRINT_ERR(("FBIO_GET_VIDEO_CONFIG_PARAMS ioctl Failed"));
                status = FAILURE;
            }
        } else                  // if ioctl is success
        {
            if (ST_SET_0 == st_getparams.cb_cr_order) {
                DBG_PRINT_TRC0(("Pixel Data Order is CbCr"));
            } else if (ST_SET_1 == st_getparams.cb_cr_order) {
                DBG_PRINT_TRC0(("Pixel Data Order is CrCb"));
            } else {
                DBG_PRINT_TRC0(("Invalid Pixel Data Order"));
            }

            if (ENABLE == st_getparams.exp_info.horizontal) {
                DBG_PRINT_TRC0(("Horizontal Expansion is enabled"));
            } else if (DISABLE == st_getparams.exp_info.horizontal) {
                DBG_PRINT_TRC0(("Horizontal Expansion is disabled"));
            } else {
                DBG_PRINT_TRC0(("Invalid selection of Horizontal Expansion"));
            }

            if (ENABLE == st_getparams.exp_info.vertical) {
                DBG_PRINT_TRC0(("Vertical Expansion is enabled"));
            } else if (DISABLE == st_getparams.exp_info.vertical) {
                DBG_PRINT_TRC0(("Vertical Expansion is disabled"));
            } else {
                DBG_PRINT_TRC0(("Invalid selection of Vertical Expansion"));
            }

            DBG_PRINT_TRC0(("FBIO_GET_VIDEO_CONFIG_PARAMS ioctl  successful"));
        }
    }


    /* close device if opened */
    if (TRUE == openStatus) {
        /* close FBDEV device */
        status = st_fbdev_closeAndreturn(&st_dev, devname);
        if (SUCCESS == status) {
            openStatus = FALSE; // device is closed
        }
    }

    /* print status of the test case */
    st_fbdev_display_test_status(status, test_id);

    return;

}


/****************************************************************************
 * Function             - st_fbdev_setVideoConfigParams_ioctl_test
 * Functionality       - Function to set config params
 * Input Params      - device name,  test case id.
 * Return Value       - None.
 * Note                   - None
 ****************************************************************************/
void st_fbdev_setVideoConfigParams_ioctl_test(char *devname, char *test_id)
{
    Int32 retVal = SUCCESS;
    Int32 status = SUCCESS;
    Int32 st_dev = -1;
    st_vpbe_video_config_params st_getparams;
    st_vpbe_video_config_params st_setparams;

    /* variables to track device state, mapping of buffers and state of FBDEV window */
    Bool openStatus = FALSE;


    /* get device number for a device string to avoid further string operations */
    st_dev = st_fbdev_set_device_number(devname);

    /* open device */
    status = st_fbdev_openAndreturn(&st_dev, devname);
    if (SUCCESS == status)      // open is success
    {
        openStatus = TRUE;      // device is opened
        DBG_PRINT_TRC0(("FBDEV %s device opened", devname));

        /* initiailze structure variables */
        st_setparams.cb_cr_order = ST_SET_1;
        st_setparams.exp_info.horizontal = ENABLE;
        st_setparams.exp_info.vertical = ENABLE;

        /* set config params */
        retVal =
            st_fbdev_setVideoConfigParams_ioctl_interface(st_dev,
                                                          &st_setparams);
        if (SUCCESS != retVal) {
            if (E_DEV_NOT_AVAILABLE == retVal) {
                DBG_PRINT_TRC(("Device is not available"));
                status = NOT_SUPPORTED;
            } else {
                DBG_PRINT_ERR(("FBIO_SET_VIDEO_CONFIG_PARAMS ioctl Failed"));
                status = FAILURE;
            }
        } else                  // if ioctl  is success
        {
            DBG_PRINT_TRC(("FBIO_SET_VIDEO_CONFIG_PARAMS ioctl successfull"));
            /* get config params */
            retVal =
                st_fbdev_getVideoConfigParams_ioctl_interface(st_dev,
                                                              &st_getparams);
            if (SUCCESS != retVal) {
                if (E_DEV_NOT_AVAILABLE == retVal) {
                    DBG_PRINT_TRC(("Device is not available"));
                    status = NOT_SUPPORTED;
                } else {
                    DBG_PRINT_ERR(("FBIO_GET_VIDEO_CONFIG_PARAMS ioctl Failed"));
                    status = FAILURE;
                }
            } else              // if ioctl is success
            {
                if (st_getparams.cb_cr_order != st_setparams.cb_cr_order) {
                    DBG_PRINT_ERR(("CbCr order not set properly"));
                    status = FAILURE;
                }

                if (st_getparams.exp_info.horizontal !=
                    st_setparams.exp_info.horizontal) {
                    DBG_PRINT_ERR(("Horizontal expansion not set properly"));
                    status = FAILURE;
                }

                if (st_getparams.exp_info.vertical !=
                    st_setparams.exp_info.vertical) {
                    DBG_PRINT_ERR(("Vertical expansion not set properly"));
                    status = FAILURE;
                }
                DBG_PRINT_TRC0(("FBIO_GET_VIDEO_CONFIG_PARAMS ioctl  successful"));
            }                   // get ioctl
        }                       // set ioctl

    }                           //open


    /* set back to default values */
    st_setparams.cb_cr_order = ST_SET_0;
    st_setparams.exp_info.horizontal = DISABLE;
    st_setparams.exp_info.vertical = DISABLE;

    /* set config params */
    st_fbdev_setVideoConfigParams_ioctl_interface(st_dev, &st_setparams);


    /* close device if opened */
    if (TRUE == openStatus) {
        /* close FBDEV device */
        status = st_fbdev_closeAndreturn(&st_dev, devname);
        if (SUCCESS == status) {
            openStatus = FALSE; // device is closed
        }
    }

    /* print status of the test case */
    st_fbdev_display_test_status(status, test_id);

    return;
}


/****************************************************************************
 * Function             - st_fbdev_getBitmapConfigParams_ioctl_test
 * Functionality       - Function to get bitmap config params
 * Input Params      - device name,  test case id.
 * Return Value       - None.
 * Note                   - None
 ****************************************************************************/
void st_fbdev_getBitmapConfigParams_ioctl_test(char *devname,
                                               char *test_id)
{
    Int32 retVal = SUCCESS;
    Int32 status = SUCCESS;
    Int32 st_dev = -1;
    st_vpbe_bitmap_config_params st_getparams;

    /* variables to track device state, mapping of buffers and state of FBDEV window */
    Bool openStatus = FALSE;


    /* get device number for a device string to avoid further string operations */
    st_dev = st_fbdev_set_device_number(devname);

    if (FBDEV_DEV0 != st_dev && FBDEV_DEV2 != st_dev
        && FBDEV_DEV4 != st_dev) {
        DBG_PRINT_TRC(("This ioctl is supported only on graphics window"));
        status = NOT_SUPPORTED;
    } else {
        /* open device */
        status = st_fbdev_openAndreturn(&st_dev, devname);
        if (SUCCESS == status)  // open is success
        {
            openStatus = TRUE;
            DBG_PRINT_TRC0(("FBDEV %s device opened", devname));

            /* get config params */
            retVal =
                st_fbdev_getBitmapConfigParams_ioctl_interface(st_dev,
                                                               &st_getparams);
            if (SUCCESS != retVal) {
                if (E_DEV_NOT_AVAILABLE == retVal) {
                    DBG_PRINT_TRC(("Device is not available"));
                    status = NOT_SUPPORTED;
                } else {
                    DBG_PRINT_ERR(("FBIO_GET_BITMAP_CONFIG_PARAMS ioctl Failed"));
                    status = FAILURE;
                }
            } else {

                DBG_PRINT_TRC0(("Attenuation				: %d", st_getparams.attenuation_enable));
                DBG_PRINT_TRC0(("Clut Select 				: %d\n", st_getparams.clut_select));
                DBG_PRINT_TRC0(("Clut index for Bitmap 1	: %d",
                                st_getparams.clut_idx.
                                st_for_1bit_bitmap_t.bitmap_val_0));
                DBG_PRINT_TRC0(("Clut index for Bitmap 1	: %d\n",
                                st_getparams.clut_idx.
                                st_for_1bit_bitmap_t.bitmap_val_1));

                DBG_PRINT_TRC0(("Clut index for Bitmap 2	: %d",
                                st_getparams.clut_idx.
                                st_for_2bit_bitmap_t.bitmap_val_0));
                DBG_PRINT_TRC0(("Clut index for Bitmap 2	: %d",
                                st_getparams.clut_idx.
                                st_for_2bit_bitmap_t.bitmap_val_1));
                DBG_PRINT_TRC0(("Clut index for Bitmap 2	: %d",
                                st_getparams.clut_idx.
                                st_for_2bit_bitmap_t.bitmap_val_2));
                DBG_PRINT_TRC0(("Clut index for Bitmap 2	: %d\n",
                                st_getparams.clut_idx.
                                st_for_2bit_bitmap_t.bitmap_val_3));

                DBG_PRINT_TRC0(("Clut index for Bitmap 4	: %d",
                                st_getparams.clut_idx.
                                st_for_4bit_bitmap_t.bitmap_val_0));
                DBG_PRINT_TRC0(("Clut index for Bitmap 4	: %d",
                                st_getparams.clut_idx.
                                st_for_4bit_bitmap_t.bitmap_val_1));
                DBG_PRINT_TRC0(("Clut index for Bitmap 4	: %d",
                                st_getparams.clut_idx.
                                st_for_4bit_bitmap_t.bitmap_val_2));
                DBG_PRINT_TRC0(("Clut index for Bitmap 4	: %d",
                                st_getparams.clut_idx.
                                st_for_4bit_bitmap_t.bitmap_val_3));
                DBG_PRINT_TRC0(("Clut index for Bitmap 4	: %d",
                                st_getparams.clut_idx.
                                st_for_4bit_bitmap_t.bitmap_val_4));
                DBG_PRINT_TRC0(("Clut index for Bitmap 4	: %d",
                                st_getparams.clut_idx.
                                st_for_4bit_bitmap_t.bitmap_val_5));
                DBG_PRINT_TRC0(("Clut index for Bitmap 4	: %d",
                                st_getparams.clut_idx.
                                st_for_4bit_bitmap_t.bitmap_val_6));
                DBG_PRINT_TRC0(("Clut index for Bitmap 4	: %d",
                                st_getparams.clut_idx.
                                st_for_4bit_bitmap_t.bitmap_val_7));
                DBG_PRINT_TRC0(("Clut index for Bitmap 4	: %d",
                                st_getparams.clut_idx.
                                st_for_4bit_bitmap_t.bitmap_val_8));
                DBG_PRINT_TRC0(("Clut index for Bitmap 4	: %d",
                                st_getparams.clut_idx.
                                st_for_4bit_bitmap_t.bitmap_val_9));
                DBG_PRINT_TRC0(("Clut index for Bitmap 4	: %d",
                                st_getparams.clut_idx.
                                st_for_4bit_bitmap_t.bitmap_val_10));
                DBG_PRINT_TRC0(("Clut index for Bitmap 4	: %d",
                                st_getparams.clut_idx.
                                st_for_4bit_bitmap_t.bitmap_val_11));
                DBG_PRINT_TRC0(("Clut index for Bitmap 4	: %d",
                                st_getparams.clut_idx.
                                st_for_4bit_bitmap_t.bitmap_val_12));
                DBG_PRINT_TRC0(("Clut index for Bitmap 4	: %d",
                                st_getparams.clut_idx.
                                st_for_4bit_bitmap_t.bitmap_val_13));
                DBG_PRINT_TRC0(("Clut index for Bitmap 4	: %d",
                                st_getparams.clut_idx.
                                st_for_4bit_bitmap_t.bitmap_val_14));
                DBG_PRINT_TRC0(("Clut index for Bitmap 4	: %d\n",
                                st_getparams.clut_idx.
                                st_for_4bit_bitmap_t.bitmap_val_15));


                DBG_PRINT_TRC(("FBIO_GET_BITMAP_CONFIG_PARAMS ioctl  successful"));
            }

        }

    }

    /* close device if opened */
    if (TRUE == openStatus) {
        /* close FBDEV device */
        status = st_fbdev_closeAndreturn(&st_dev, devname);
        if (SUCCESS == status) {
            openStatus = FALSE; // device is closed
        }
    }

    /* print status of the test case */
    st_fbdev_display_test_status(status, test_id);

    return;
}


/****************************************************************************
 * Function             - st_fbdev_setBitmapConfigParams_ioctl_test
 * Functionality       - Function to set bitmap config params
 * Input Params      - device name,  test case id.
 * Return Value       - None.
 * Note                   - None
 ****************************************************************************/
void st_fbdev_setBitmapConfigParams_ioctl_test(char *devname,
                                               char *test_id)
{
    Int32 retVal = SUCCESS;
    Int32 status = SUCCESS;
    Int32 st_dev = -1;
    st_vpbe_bitmap_config_params st_setparams;
    st_vpbe_bitmap_config_params st_getparams;

    /* variables to track device state, mapping of buffers and state of FBDEV window */
    Bool openStatus = FALSE;


    /* get device number for a device string to avoid further string operations */
    st_dev = st_fbdev_set_device_number(devname);

    if (FBDEV_DEV0 != st_dev && FBDEV_DEV2 != st_dev
        && FBDEV_DEV4 != st_dev) {
        DBG_PRINT_TRC(("This ioctl is supported only on graphics window"));
        status = NOT_SUPPORTED;
    } else {
        /* open device */
        status = st_fbdev_openAndreturn(&st_dev, devname);
        if (SUCCESS == status)  // open is success
        {
            openStatus = TRUE;
            DBG_PRINT_TRC0(("FBDEV %s device opened", devname));

            /* get config params and then modify it */
            st_fbdev_getBitmapConfigParams_ioctl_interface(st_dev,
                                                           &st_setparams);

            st_setparams.attenuation_enable = ENABLE;
            st_setparams.clut_select = RAM_CLUT;

            /* set config params */
            retVal =
                st_fbdev_setBitmapConfigParams_ioctl_interface(st_dev,
                                                               &st_setparams);
            if (SUCCESS != retVal) {
                if (E_DEV_NOT_AVAILABLE == retVal) {
                    DBG_PRINT_TRC(("Device is not available"));
                    status = NOT_SUPPORTED;
                } else {
                    DBG_PRINT_ERR(("FBIO_SET_BITMAP_CONFIG_PARAMS ioctl Failed"));
                    status = FAILURE;
                }
            } else              // FBIO_SET_BITMAP_CONFIG_PARAMS ioctl is success
            {

                DBG_PRINT_TRC(("FBIO_SET_BITMAP_CONFIG_PARAMS ioctl  successful"));
                /* get values again and compare */
                retVal =
                    st_fbdev_getBitmapConfigParams_ioctl_interface(st_dev,
                                                                   &st_getparams);
                if (SUCCESS != retVal) {
                    if (E_DEV_NOT_AVAILABLE == retVal) {
                        DBG_PRINT_TRC(("Device is not available"));
                        status = NOT_SUPPORTED;
                    } else {
                        DBG_PRINT_ERR(("FBIO_GET_BITMAP_CONFIG_PARAMS ioctl Failed"));
                        status = FAILURE;
                    }
                } else          // FBIO_GET_BITMAP_CONFIG_PARAMS ioctl success
                {
                    DBG_PRINT_TRC0(("FBIO_GET_BITMAP_CONFIG_PARAMS ioctl  successful"));
                    if (st_setparams.attenuation_enable !=
                        st_getparams.attenuation_enable
                        || st_setparams.clut_select !=
                        st_getparams.clut_select) {
                        status = FAILURE;
                    }
                }
            }

        }

    }

    /* close device if opened */
    if (TRUE == openStatus) {
        /* close FBDEV device */
        status = st_fbdev_closeAndreturn(&st_dev, devname);
        if (SUCCESS == status) {
            openStatus = FALSE; // device is closed
        }
    }

    /* print status of the test case */
    st_fbdev_display_test_status(status, test_id);

    return;

}


/****************************************************************************
 * Function             - st_fbdev_fbioBlank_ioctl_test
 * Functionality       - Function to enables/disables window
 * Input Params      - device name,  test case id.
 * Return Value       - None.
 * Note                   - None
 ****************************************************************************/
void st_fbdev_fbioBlank_ioctl_test(char *devname, char *test_id)
{
    Int32 retVal = SUCCESS;
    Int32 status = SUCCESS;
    Int32 st_dev = -1;


    /* variables to track device state, mapping of buffers and state of FBDEV window */
    Bool openStatus = FALSE;


    /* get device number for a device string to avoid further string operations */
    st_dev = st_fbdev_set_device_number(devname);

    /* open device */
    status = st_fbdev_openAndreturn(&st_dev, devname);
    if (SUCCESS == status)      // open is success
    {
        openStatus = TRUE;
        DBG_PRINT_TRC0(("FBDEV %s device opened", devname));

        /* disable window */
        retVal = st_fbdev_blank_window_interface(st_dev, ST_DISABLE_WIN);
        /*blanking the window succeeded*/
        DBG_PRINT_TRC(("Blanking the window succeeded"));
        if (SUCCESS != retVal)
         {
            if (E_DEV_NOT_AVAILABLE == retVal) 
            {
                DBG_PRINT_TRC(("Device is not available"));
                status = NOT_SUPPORTED;
            } 
            else
             {
                DBG_PRINT_ERR(("FBIOBLANK ioctl failed"));
                status = FAILURE;
            }
         } 
         else
         {
            DBG_PRINT_TRC0(("FBDEV device %s disabled", devname));

            /* enable device */
            retVal =
                st_fbdev_blank_window_interface(st_dev, ST_ENABLE_WIN);
            if (SUCCESS != retVal) 
            {
                if (E_DEV_NOT_AVAILABLE == retVal) 
                {
                    DBG_PRINT_TRC(("Device is not available"));
                    status = NOT_SUPPORTED;
                } else 
                {
                    DBG_PRINT_ERR(("FBIOBLANK ioctl failed"));
                    status = FAILURE;
                }
            } 
            else 
            {
                DBG_PRINT_TRC0(("FBDEV device %s enabled", devname));
            }
        }                       // ioctl
    }                           // open

    /* close device if opened */
    if (TRUE == openStatus) {
        /* close FBDEV device */
        status = st_fbdev_closeAndreturn(&st_dev, devname);
        if (SUCCESS == status) {
            openStatus = FALSE; // device is closed
        }
    }

    /* print status of the test case */
    st_fbdev_display_test_status(status, test_id);

    return;
}



/****************************************************************************
 * Function             - st_fbdev_fbioSetPos_ioctl_test
 * Functionality       - Function to set window pos
 * Input Params      - device name,  test case id.
 * Return Value       - None.
 * Note                   - None
 ****************************************************************************/
void st_fbdev_fbioSetPos_ioctl_test(char *devname, char *test_id)
{
    Int32 retVal = SUCCESS;
    Int32 status = SUCCESS;
    Int32 st_dev = -1;
    st_vpbe_window_position st_pos;

    /* variables to track device state, mapping of buffers and state of FBDEV window */
    Bool openStatus = FALSE;


    /* get device number for a device string to avoid further string operations */
    st_dev = st_fbdev_set_device_number(devname);

    /* open device */
    status = st_fbdev_openAndreturn(&st_dev, devname);
    if (SUCCESS == status)      // open is success
    {
        openStatus = TRUE;
        DBG_PRINT_TRC0(("FBDEV %s device opened", devname));

        /* set window position */
        st_pos.xpos = XPOS_TEST;
        st_pos.ypos = XPOS_TEST;

        retVal = st_fbdev_setpos_interface(st_dev, &st_pos);
        if (SUCCESS != retVal) {
            if (E_DEV_NOT_AVAILABLE == retVal) {
                DBG_PRINT_TRC(("Device is not available"));
                status = NOT_SUPPORTED;
            } else {
                DBG_PRINT_ERR(("FBIO_SETPOS ioctl failed"));
                status = FAILURE;
            }
        } else {
            DBG_PRINT_TRC(("FBIO_SETPOS ioctl succeeded"));
        }                       // ioctl
    }                           // open

    /* close device if opened */
    if (TRUE == openStatus) {
        /* close FBDEV device */
        status = st_fbdev_closeAndreturn(&st_dev, devname);
        if (SUCCESS == status) {
            openStatus = FALSE; // device is closed
        }
    }

    /* print status of the test case */
    st_fbdev_display_test_status(status, test_id);

    return;
}


/****************************************************************************
 * Function             - st_fbdev_getVscreenInfo_ioctl_test
 * Functionality       - Function to get variable screen info
 * Input Params      - device name,  test case id.
 * Return Value       - None.
 * Note                   - None
 ****************************************************************************/
void st_fbdev_getVscreenInfo_ioctl_test(char *devname, char *test_id)
{
   
    Int32 retVal = SUCCESS;
    Int32 status = SUCCESS;
    Int32 st_dev = -1;
    st_fb_var_screeninfo st_vInfo;

    /* variables to track device state, mapping of buffers and state of FBDEV window */
    Bool openStatus = FALSE;

    /* get device number for a device string to avoid further string operations */
    st_dev = st_fbdev_set_device_number(devname);

    /* open device */
    status = st_fbdev_openAndreturn(&st_dev, devname);
    if (SUCCESS == status)      // open is success
    {
        openStatus = TRUE;
        DBG_PRINT_TRC0(("FBDEV %s device opened", devname));

        retVal = st_fbdev_getVscreenInfo_interface(st_dev, &st_vInfo);
        if (SUCCESS != retVal) {
            if (E_DEV_NOT_AVAILABLE == retVal) {
                DBG_PRINT_TRC(("Device is not available"));
                status = NOT_SUPPORTED;
            } else {
                DBG_PRINT_ERR(("FBIOGET_VSCREENINFO ioctl failed"));
                status = FAILURE;
            }
        } else {
            DBG_PRINT_TRC0(("x-resolution          			: %lu", st_vInfo.xres));
            DBG_PRINT_TRC0(("y-resolution				: %lu", st_vInfo.yres));
            DBG_PRINT_TRC0(("x-resolution virtual			: %lu", st_vInfo.xres_virtual));
            DBG_PRINT_TRC0(("y-resolution virtual			: %lu", st_vInfo.yres_virtual));
            DBG_PRINT_TRC0(("x-offset					: %lu", st_vInfo.xoffset));
            DBG_PRINT_TRC0(("y-offset					: %lu\n", st_vInfo.yoffset));

            DBG_PRINT_TRC0(("bits per pixel				: %lu", st_vInfo.bits_per_pixel));
            DBG_PRINT_TRC0(("gray scale					: %lu\n", st_vInfo.grayscale));

            DBG_PRINT_TRC0(("bitfield length for red			: %lu", st_vInfo.red.length));
            DBG_PRINT_TRC0(("bitfield offset for red			: %lu", st_vInfo.red.offset));
            DBG_PRINT_TRC0(("bitfield msb for red			: %lu\n", st_vInfo.red.msb_right));

            DBG_PRINT_TRC0(("bitfield length for green		: %lu",
                            st_vInfo.green.length));
            DBG_PRINT_TRC0(("bitfield offset for green		: %lu", 
                            st_vInfo.green.offset));
            DBG_PRINT_TRC0(("bitfield msb for green			: %lu\n", st_vInfo.green.msb_right));

            DBG_PRINT_TRC0(("bitfield length for blue		: %lu",
                            st_vInfo.blue.length));
            DBG_PRINT_TRC0(("bitfield offset for blue			: %lu", st_vInfo.blue.offset));
            DBG_PRINT_TRC0(("bitfield msb for blue			: %lu\n", st_vInfo.blue.msb_right));

            DBG_PRINT_TRC0(("bitfield length for transparency	: %lu",
                            st_vInfo.transp.length));
            DBG_PRINT_TRC0(("bitfield offset for transparency	: %lu",
                            st_vInfo.transp.offset));
            DBG_PRINT_TRC0(("bitfield msb for transparency	: %lu\n",
                            st_vInfo.transp.msb_right));

            DBG_PRINT_TRC0(("Non Standard 				: %lu", st_vInfo.nonstd));
            DBG_PRINT_TRC0(("Activate					: %lu", st_vInfo.activate));
            DBG_PRINT_TRC0(("height						: %lu", st_vInfo.height));
            DBG_PRINT_TRC0(("width						: %lu", st_vInfo.width));
            DBG_PRINT_TRC0(("Accel flags					: %lu", st_vInfo.accel_flags));
            DBG_PRINT_TRC0(("Pixel Clock					: %lu", st_vInfo.pixclock));
            DBG_PRINT_TRC0(("Left Margin					: %lu", st_vInfo.left_margin));
            DBG_PRINT_TRC0(("Right Margin				: %lu", st_vInfo.right_margin));
            DBG_PRINT_TRC0(("Upper	Margin				: %lu", st_vInfo.upper_margin));
            DBG_PRINT_TRC0(("LowerMargin				: %lu", st_vInfo.lower_margin));
            DBG_PRINT_TRC0(("Hsync len					: %lu", st_vInfo.hsync_len));
            DBG_PRINT_TRC0(("Vsync len					: %lu", st_vInfo.vsync_len));
            DBG_PRINT_TRC0(("sync 						: %lu", st_vInfo.sync));
            DBG_PRINT_TRC0(("Vmode					: %lu", st_vInfo.vmode));
            DBG_PRINT_TRC0(("Rotate angle				: %lu", st_vInfo.rotate));

            DBG_PRINT_TRC(("FBIOGET_VSCREENINFO ioctl succeeded"));
        }                       // ioctl
    }                           // open

    /* close device if opened */
    if (TRUE == openStatus) {
        /* close FBDEV device */
        status = st_fbdev_closeAndreturn(&st_dev, devname);
        if (SUCCESS == status) {
            openStatus = FALSE; // device is closed
        }
    }

    /* print status of the test case */
    st_fbdev_display_test_status(status, test_id);

    return;
}


/****************************************************************************
 * Function             - st_fbdev_putVscreenInfo_ioctl_test
 * Functionality       - Function to sut variable screen info
 * Input Params      - device name,  test case id.
 * Return Value       - None.
 * Note                   - None
 ****************************************************************************/
void st_fbdev_putVscreenInfo_ioctl_test(char *devname, char *test_id)
{
    Int32 retVal = SUCCESS;
    Int32 status = SUCCESS;
    Int32 st_dev = -1;
    st_fb_var_screeninfo st_getvInfo;
    st_fb_var_screeninfo st_putvInfo;

    /* variables to track device state, mapping of buffers and state of FBDEV window */
    Bool openStatus = FALSE;


    /* get device number for a device string to avoid further string operations */
    st_dev = st_fbdev_set_device_number(devname);

    /* open device */
    status = st_fbdev_openAndreturn(&st_dev, devname);
    if (SUCCESS == status)      // open is success
    {
        openStatus = TRUE;
        DBG_PRINT_TRC0(("FBDEV %s device opened", devname));

        /* get variable screen info and then modify it */
        st_fbdev_getVscreenInfo_interface(st_dev, &st_putvInfo);

        st_putvInfo.bits_per_pixel = testoptions.bits_per_pixel;
        st_putvInfo.grayscale = testoptions.greyscale;
        st_putvInfo.red.offset = testoptions.redoffset;
        st_putvInfo.red.length = testoptions.redlength;
        st_putvInfo.red.msb_right = testoptions.redmsb;
        st_putvInfo.green.offset = testoptions.greenoffset;
        st_putvInfo.green.length = testoptions.greenlength;
        st_putvInfo.green.msb_right = testoptions.greenmsb;
        st_putvInfo.blue.offset = testoptions.blueoffset;
        st_putvInfo.blue.length = testoptions.bluelength;
        st_putvInfo.blue.msb_right = testoptions.bluemsb;
        st_putvInfo.transp.offset = testoptions.transoffset;
        st_putvInfo.transp.length = testoptions.translength;
        st_putvInfo.transp.msb_right = testoptions.transmsb;
        st_putvInfo.height = testoptions.height;
        st_putvInfo.width = testoptions.width;
        st_putvInfo.left_margin = testoptions.leftmargin;
        st_putvInfo.right_margin = testoptions.rightmargin;
        st_putvInfo.upper_margin = testoptions.uppermargin;
        st_putvInfo.lower_margin = testoptions.lowermargin;
        st_putvInfo.hsync_len = testoptions.hsynclen;
        st_putvInfo.vsync_len = testoptions.vsynclen;
        st_putvInfo.sync = testoptions.sync;
        st_putvInfo.xres = QQVGA_WIDTH;
        st_putvInfo.yres = QQVGA_HEIGHT;

        retVal = st_fbdev_putVscreenInfo_interface(st_dev, &st_putvInfo);
        if (SUCCESS != retVal) {
            if (E_DEV_NOT_AVAILABLE == retVal) {
                DBG_PRINT_TRC(("Device is not available"));
                status = NOT_SUPPORTED;
            } else {
                DBG_PRINT_ERR(("FBIOPUT_VSCREENINFO ioctl failed"));
                status = FAILURE;
            }
        } else                  // if FBIOPUT_VSCREENINFO ioctl success
        {
            DBG_PRINT_TRC(("FBIOPUT_VSCREENINFO ioctl succeeded"));

            retVal =
                st_fbdev_getVscreenInfo_interface(st_dev, &st_getvInfo);
            if (SUCCESS != retVal) {
                if (E_DEV_NOT_AVAILABLE == retVal) {
                    DBG_PRINT_TRC(("Device is not available"));
                    status = NOT_SUPPORTED;
                } else {
                    DBG_PRINT_ERR(("FBIOGET_VSCREENINFO ioctl failed"));
                    status = FAILURE;
                }
            } else              // if FBIOGET_VSCREENINFO ioctl success
            {
	    DBG_PRINT_TRC0(("x-resolution          			: %lu", st_getvInfo.xres));
            DBG_PRINT_TRC0(("y-resolution				: %lu", st_getvInfo.yres));
            DBG_PRINT_TRC0(("x-resolution virtual			: %lu", st_getvInfo.xres_virtual));
            DBG_PRINT_TRC0(("y-resolution virtual			: %lu", st_getvInfo.yres_virtual));
            DBG_PRINT_TRC0(("x-offset					: %lu", st_getvInfo.xoffset));
            DBG_PRINT_TRC0(("y-offset					: %lu\n", st_getvInfo.yoffset));

            DBG_PRINT_TRC0(("bits per pixel				: %lu", st_getvInfo.bits_per_pixel));
            DBG_PRINT_TRC0(("gray scale					: %lu\n", st_getvInfo.grayscale));

            DBG_PRINT_TRC0(("bitfield length for red			: %lu", st_getvInfo.red.length));
            DBG_PRINT_TRC0(("bitfield offset for red			: %lu", st_getvInfo.red.offset));
            DBG_PRINT_TRC0(("bitfield msb for red			: %lu\n", st_getvInfo.red.msb_right));

            DBG_PRINT_TRC0(("bitfield length for green		: %lu",
                            st_getvInfo.green.length));
            DBG_PRINT_TRC0(("bitfield offset for green		: %lu", 
                            st_getvInfo.green.offset));
            DBG_PRINT_TRC0(("bitfield msb for green			: %lu\n", st_getvInfo.green.msb_right));

            DBG_PRINT_TRC0(("bitfield length for blue		: %lu",
                            st_getvInfo.blue.length));
            DBG_PRINT_TRC0(("bitfield offset for blue			: %lu", st_getvInfo.blue.offset));
            DBG_PRINT_TRC0(("bitfield msb for blue			: %lu\n", st_getvInfo.blue.msb_right));

            DBG_PRINT_TRC0(("bitfield length for transparency	: %lu",
                            st_getvInfo.transp.length));
            DBG_PRINT_TRC0(("bitfield offset for transparency	: %lu",
                            st_getvInfo.transp.offset));
            DBG_PRINT_TRC0(("bitfield msb for transparency	: %lu\n",
                            st_getvInfo.transp.msb_right));

            DBG_PRINT_TRC0(("Non Standard 				: %lu", st_getvInfo.nonstd));
            DBG_PRINT_TRC0(("Activate					: %lu", st_getvInfo.activate));
            DBG_PRINT_TRC0(("height						: %lu", st_getvInfo.height));
            DBG_PRINT_TRC0(("width						: %lu", st_getvInfo.width));
            DBG_PRINT_TRC0(("Accel flags					: %lu", st_getvInfo.accel_flags));
            DBG_PRINT_TRC0(("Pixel Clock					: %lu", st_getvInfo.pixclock));
            DBG_PRINT_TRC0(("Left Margin					: %lu", st_getvInfo.left_margin));
            DBG_PRINT_TRC0(("Right Margin				: %lu", st_getvInfo.right_margin));
            DBG_PRINT_TRC0(("Upper	Margin				: %lu", st_getvInfo.upper_margin));
            DBG_PRINT_TRC0(("LowerMargin				: %lu", st_getvInfo.lower_margin));
            DBG_PRINT_TRC0(("Hsync len					: %lu", st_getvInfo.hsync_len));
            DBG_PRINT_TRC0(("Vsync len					: %lu", st_getvInfo.vsync_len));
            DBG_PRINT_TRC0(("sync 						: %lu", st_getvInfo.sync));
            DBG_PRINT_TRC0(("Vmode					: %lu", st_getvInfo.vmode));
            DBG_PRINT_TRC0(("Rotate angle				: %lu", st_getvInfo.rotate));
            }
            DBG_PRINT_TRC(("FBIOGET_VSCREENINFO ioctl succeeded"));
            }                   

		}                       
                               


    /* close device if opened */
    if (TRUE == openStatus) {
        /* close FBDEV device */
        status = st_fbdev_closeAndreturn(&st_dev, devname);
        if (SUCCESS == status) {
            openStatus = FALSE; // device is closed
        }
    }

    /* print status of the test case */
    st_fbdev_display_test_status(status, test_id);


    return;
}


/****************************************************************************
 * Function             - st_fbdev_getFscreenInfo_ioctl_test
 * Functionality       - Function to get fixed screen info
 * Input Params      - device name,  test case id.
 * Return Value       - None.
 * Note                   - None
 ****************************************************************************/
void st_fbdev_getFscreenInfo_ioctl_test(char *devname, char *test_id)
{
    Int32 retVal = SUCCESS;
    Int32 status = SUCCESS;
    Int32 st_dev = -1;
    st_fb_fix_screeninfo st_fInfo;


    /* variables to track device state, mapping of buffers and state of FBDEV window */
    Bool openStatus = FALSE;


    /* get device number for a device string to avoid further string operations */
    st_dev = st_fbdev_set_device_number(devname);

    /* open device */
    status = st_fbdev_openAndreturn(&st_dev, devname);
    if (SUCCESS == status)      // open is success
    {
        openStatus = TRUE;
        DBG_PRINT_TRC0(("FBDEV %s device opened", devname));

        retVal = st_fbdev_getFscreenInfo_interface(st_dev, &st_fInfo);
        if (SUCCESS != retVal) {
            if (E_DEV_NOT_AVAILABLE == retVal) {
                DBG_PRINT_TRC(("Device is not available"));
                status = NOT_SUPPORTED;
            } else {
                DBG_PRINT_ERR(("FBIOGET_FSCREENINFO ioctl failed"));
                status = FAILURE;
            }
        } else {

            DBG_PRINT_TRC0(("Id				: %s",
                            st_fInfo.id));
            DBG_PRINT_TRC0(("Start of FB mem		: %ld",
                            st_fInfo.smem_start));
            DBG_PRINT_TRC0(("length of FB mem	: %lu", st_fInfo.smem_len));
            DBG_PRINT_TRC0(("FB type			: %lu",
                            st_fInfo.type));
            DBG_PRINT_TRC0(("aux				: %lu",
                            st_fInfo.type_aux));
            DBG_PRINT_TRC0(("Visual				: %lu",
                            st_fInfo.visual));
            DBG_PRINT_TRC0(("x panning 			: %lu",
                            st_fInfo.xpanstep));
            DBG_PRINT_TRC0(("y panning			: %lu",
                            st_fInfo.ypanstep));
            DBG_PRINT_TRC0(("ywrap 				: %lu",
                            st_fInfo.ywrapstep));
            DBG_PRINT_TRC0(("line length			: %lu",
                            st_fInfo.line_length));
            DBG_PRINT_TRC0(("start of mmap IO	: %ld",
                            st_fInfo.mmio_start));
            DBG_PRINT_TRC0(("length of mmap IO	: %lu", st_fInfo.mmio_len));
            DBG_PRINT_TRC0(("Accel		 		: %lu",
                            st_fInfo.accel));

            DBG_PRINT_TRC(("FBIOGET_FSCREENINFO ioctl succeeded"));
        }                       // ioctl
    }                           // open

    /* close device if opened */
    if (TRUE == openStatus) {
        /* close FBDEV device */
        status = st_fbdev_closeAndreturn(&st_dev, devname);
        if (SUCCESS == status) {
            openStatus = FALSE; // device is closed
        }
    }

    /* print status of the test case */
    st_fbdev_display_test_status(status, test_id);
    return;
}



/****************************************************************************
 * Function             - st_fbdev_fbioPanDisplay_ioctl_test
 * Functionality       - FBIOPAN_DISPLAY ioctl test
 * Input Params      - device name and testid
 * Return Value       - None.
 * Note                   - None
 ****************************************************************************/
void st_fbdev_fbioPanDisplay_ioctl_test(char *devname, char *test_id)
{

    Int32 retVal = SUCCESS;
    Int32 status = SUCCESS;
    st_fb_fix_screeninfo st_fInfo;
    st_fb_var_screeninfo st_vInfo;
    Int32 st_img_type = 0;
    Int32 st_dev = -1;

    Uint32 i = 0;
    Int32 st_width = testoptions.width;
    Int32 st_height = testoptions.height;

    /* variables to track device state, mapping of buffers and state of FBDEV window */
    Bool openStatus = FALSE;
    Bool mmapStatus = FALSE;
    Bool winStatus = FALSE;


    /* get device number for a device string to avoid further string operations */
    st_dev = st_fbdev_set_device_number(devname);

    do {

        retVal =
            st_fbdev_change_sysfs_interface(testoptions.standard,
                                            testoptions.interface);
        if (SUCCESS != retVal) {
            if (E_MODEOUTPUT_NOT_SUPPORTED == retVal) {
                DBG_PRINT_TRC(("Mode or output not supported by device"));
                status = NOT_SUPPORTED;
            } else {
                DBG_PRINT_ERR(("sysfs variables not set "));
                status = FAILURE;
            }

            break;
        }

        /* open FBDEV display device */
        status = st_fbdev_openAndreturn(&st_dev, devname);
        if (SUCCESS != status) {
            break;
        }

        openStatus = TRUE;      // device is opened

        /* get fixed screen info */
        retVal = st_fbdev_getFscreenInfo_interface(st_dev, &st_fInfo);
        if (SUCCESS != retVal) {
            DBG_PRINT_ERR(("FBIOGET_FSCREENINFO Ioctl Failed"));
            status = FAILURE;
            break;
        }

        /* get variable screen info */
        retVal = st_fbdev_getVscreenInfo_interface(st_dev, &st_vInfo);
        if (SUCCESS != retVal) {
            DBG_PRINT_ERR(("FBIOGET_VSCREENINFO Ioctl Failed"));
            status = FAILURE;
            break;
        }
        if (FBDEV_DEV4 != st_dev) {
            /* Disable window */
            retVal =
                st_fbdev_blank_window_interface(st_dev, ST_DISABLE_WIN);
            if (SUCCESS != retVal) {
                DBG_PRINT_ERR(("FBDEV window not enabled"));
                status = FAILURE;
                break;
            }
            winStatus = FALSE;
        }
        /* Modify the resolution, bpp, vmode  as required */
        st_vInfo.vmode = ST_FB_VMODE_NONINTERLACED;
        st_vInfo.xres = st_width;
        st_vInfo.yres = st_height;

        /* Change the virtual Y-resolution for buffer flipping (3 buffers) */
        if (FBDEV_DEV3 == st_dev || FBDEV_DEV1 == st_dev) {

            st_vInfo.yres_virtual = MAX_HEIGHT * ST_VIDEO_NUM_BUFS;     // //st_vInfo.yres * ST_VIDEO_NUM_BUFS; // MAX_HEIGHT * ST_VIDEO_NUM_BUFS;  //
            st_vInfo.xres_virtual = st_fInfo.line_length / 2;
            st_vInfo.bits_per_pixel = ST_BPP_16;
            st_img_type = ST_H_PATTERN;
            st_vInfo.nonstd = 1;
        } else if (FBDEV_DEV0 == st_dev) {
            st_vInfo.yres_virtual = st_vInfo.yres * ST_OSD_NUM_BUFS;
            st_vInfo.bits_per_pixel = ST_BPP_16;
            st_img_type = ST_H_PATTERN;
            st_vInfo.nonstd = 0;
        } else if (FBDEV_DEV2 == st_dev) {
            st_vInfo.yres_virtual = st_vInfo.yres * ST_OSD_NUM_BUFS;
            st_vInfo.bits_per_pixel = ST_BPP_8;
            st_vInfo.nonstd = 0;
            st_img_type = ST_BITMAP_8;
        } else if (FBDEV_DEV4 == st_dev) {
            st_vInfo.xres = st_height;
            st_vInfo.yres = st_width;
            st_vInfo.xres_virtual = st_vInfo.xres;
            st_vInfo.yres_virtual = st_vInfo.yres * ST_OSD_NUM_BUFS;
            st_vInfo.bits_per_pixel = ST_BPP_16;
            st_vInfo.nonstd = 0;
            st_img_type = ST_H_PATTERN;
            st_vInfo.red.length = 5;
            st_vInfo.green.length = 6;
            st_vInfo.blue.length = 5;
            st_vInfo.red.offset = 11;
            st_vInfo.green.offset = 5;
            st_vInfo.blue.offset = 0;
        }


        /* put variable screen info */
        retVal = st_fbdev_putVscreenInfo_interface(st_dev, &st_vInfo);
        if (SUCCESS != retVal) {
            DBG_PRINT_ERR(("FBIOPUT_VSCREENINFO Ioctl Failed"));
            status = FAILURE;
            break;
        }

        /* get variable screen info */
        retVal = st_fbdev_getFscreenInfo_interface(st_dev, &st_fInfo);
        if (SUCCESS != retVal) {
            DBG_PRINT_ERR(("FBIOGET_FSCREENINFO Ioctl Failed"));
            status = FAILURE;
            break;
        }
        if (FBDEV_DEV4 != st_dev) {
            /* Enable window */
            retVal =
                st_fbdev_blank_window_interface(st_dev, ST_ENABLE_WIN);
            if (SUCCESS != retVal) {
                DBG_PRINT_ERR(("FBDEV window not enabled"));
                status = FAILURE;
                break;
            }

            winStatus = TRUE;   // window is enabled
        }
        /* map vid0 buffers to user space */
        retVal =
            st_fbdev_mmap_interface(st_dev, st_fInfo.line_length,
                                    st_vInfo.yres);
        if (SUCCESS != retVal) {
            DBG_PRINT_ERR(("FBDEV buffers mapping failed"));
            status = FAILURE;
            break;
        }

        mmapStatus = TRUE;      // buffers are mapped

        /* display buffers */
        for (i = 500; i != 0; i--) {
            /* set buffer for display */
            retVal =
                st_fbdev_display_interface(st_dev, st_vInfo.xres,
                                           st_vInfo.yres, st_img_type,
                                           NULL);
            if (FAILURE == retVal) {
                DBG_PRINT_ERR(("FBDEV buffer not set for display"));
                status = FAILURE;
                break;
            }

            st_vInfo.yoffset = st_vInfo.yres * retVal;  //retVal contains the buffer index

            retVal = st_fbdev_waitforsync_interface(st_dev);
            if (SUCCESS != retVal) {
                DBG_PRINT_ERR(("FBIO_WAITFORSYNC Ioctl failed"));
                status = FAILURE;
                break;
            }

            retVal = st_fbdev_pandisplay_interface(st_dev, &st_vInfo);
            if (SUCCESS != retVal) {
                DBG_PRINT_ERR(("FBIOPAN_DISPLAY Ioctl failed"));
                status = FAILURE;
                break;
            }
        }

        break;                  // break out of while loop after display
    } while (SUCCESS == retVal);

    /* unmap buffers if mapped */
    if (TRUE == mmapStatus) {
        /* unmap buffers */
        retVal = st_fbdev_unmap_interface(st_dev);
        if (FAILURE == retVal) {
            DBG_PRINT_ERR(("Buffers could not be unmapped"));
            status = FAILURE;
        }

        mmapStatus = FALSE;     // buffers not mapped

        DBG_PRINT_TRC0(("Buffers unmapped"));
    }

    /* disable win if enabled */
    if (TRUE == winStatus) {
        /* disable FBDEV window */
        retVal = st_fbdev_blank_window_interface(st_dev, ST_DISABLE_WIN);
        if (SUCCESS != retVal) {
            DBG_PRINT_ERR(("FBDEV window not disabled"));
            status = FAILURE;
        }

        winStatus = FALSE;      // window is disabled

        DBG_PRINT_TRC0(("window disabled"));
    }

    /* close device if opened */
    if (TRUE == openStatus) {
        /* close FBDEV device */
        status = st_fbdev_closeAndreturn(&st_dev, devname);
        if (SUCCESS == status) {
            openStatus = FALSE; // device is closed
        }
    }

    if (SUCCESS == status) {
        DBG_PRINT_TRC(("FBIOPAN_DISPLAY Ioctl is successfull"));
    }

    /* print status of the test case */
    st_fbdev_display_test_status(status, test_id);


    return;

}


/****************************************************************************
 * Function             - st_fbdev_fbioWaitForSync_ioctl_test
 * Functionality       - FBIO_WAITFORSYNC  ioctl test
 * Input Params      - device name and testid
 * Return Value       - None.
 * Note                   - None
 ****************************************************************************/
void st_fbdev_fbioWaitForSync_ioctl_test(char *devname, char *test_id)
{

    Int32 retVal = SUCCESS;
    Int32 status = SUCCESS;
    st_vpbe_window_position st_pos;
    st_fb_fix_screeninfo st_fInfo;
    st_fb_var_screeninfo st_vInfo;
    Int32 st_img_type = 0;
    Int32 st_dev = -1;

    Uint32 i = 0;
    Int32 st_width = testoptions.width;
    Int32 st_height = testoptions.height;

    /* variables to track device state, mapping of buffers and state of FBDEV window */
    Bool openStatus = FALSE;
    Bool mmapStatus = FALSE;
    Bool winStatus = FALSE;

    /* get device number for a device string to avoid further string operations */
    st_dev = st_fbdev_set_device_number(devname);

    do {

        retVal =
            st_fbdev_change_sysfs_interface(testoptions.standard,
                                            testoptions.interface);
        if (SUCCESS != retVal) {
            if (E_MODEOUTPUT_NOT_SUPPORTED == retVal) {
                DBG_PRINT_TRC(("Mode or output not supported by device"));
                status = NOT_SUPPORTED;
            } else {
                DBG_PRINT_ERR(("sysfs variables not set "));
                status = FAILURE;
            }

            break;
        }

        /* open FBDEV display device */
        status = st_fbdev_openAndreturn(&st_dev, devname);
        if (SUCCESS != status) {
            break;
        }

        openStatus = TRUE;      // device is opened

        if (FBDEV_DEV4 != st_dev) {
            /* Enable window */
            retVal =
                st_fbdev_blank_window_interface(st_dev, ST_DISABLE_WIN);
            if (SUCCESS != retVal) {
                DBG_PRINT_ERR(("FBDEV window not disabled"));
                status = FAILURE;
                break;
            }

            winStatus = FALSE;  // window is enabled

            DBG_PRINT_TRC0(("FBDEV window disabled"));
        }

        /* get fixed screen info */
        retVal = st_fbdev_getFscreenInfo_interface(st_dev, &st_fInfo);
        if (SUCCESS != retVal) {
            DBG_PRINT_ERR(("FBIOGET_FSCREENINFO Ioctl Failed"));
            status = FAILURE;
            break;
        }

        /* get variable screen info */
        retVal = st_fbdev_getVscreenInfo_interface(st_dev, &st_vInfo);
        if (SUCCESS != retVal) {
            DBG_PRINT_ERR(("FBIOGET_VSCREENINFO Ioctl Failed"));
            status = FAILURE;
            break;
        }

        /* Modify the resolution, bpp, vmode  as required */
        st_vInfo.vmode = ST_FB_VMODE_NONINTERLACED;
        st_vInfo.xres = st_width;
        st_vInfo.yres = st_height;

        /* Change the virtual Y-resolution for buffer flipping (3 buffers) */
        if (FBDEV_DEV3 == st_dev || FBDEV_DEV1 == st_dev) {

            st_vInfo.yres_virtual = MAX_HEIGHT * ST_VIDEO_NUM_BUFS;     // //st_vInfo.yres * ST_VIDEO_NUM_BUFS; // MAX_HEIGHT * ST_VIDEO_NUM_BUFS;  //
            st_vInfo.xres_virtual = st_fInfo.line_length / 2;
            st_vInfo.bits_per_pixel = ST_BPP_16;
            st_img_type = ST_H_PATTERN;
            st_vInfo.nonstd = 1;
        } else if (FBDEV_DEV0 == st_dev) {
            st_vInfo.yres_virtual = st_vInfo.yres * ST_OSD_NUM_BUFS;
            st_vInfo.bits_per_pixel = ST_BPP_16;
            st_img_type = ST_H_PATTERN;
            st_vInfo.nonstd = 0;
        } else if (FBDEV_DEV2 == st_dev) {
            st_vInfo.yres_virtual = st_vInfo.yres * ST_OSD_NUM_BUFS;
            st_vInfo.bits_per_pixel = ST_BPP_8;
            st_vInfo.nonstd = 0;
            st_img_type = ST_BITMAP_8;
        } else if (FBDEV_DEV4 == st_dev) {
            st_vInfo.xres = st_height;
            st_vInfo.yres = st_width;
            st_vInfo.xres_virtual = st_vInfo.xres;
            st_vInfo.yres_virtual = st_vInfo.yres * ST_OSD_NUM_BUFS;
            st_vInfo.bits_per_pixel = ST_BPP_16;
            st_vInfo.nonstd = 0;
            st_img_type = ST_H_PATTERN;
            st_vInfo.red.length = 5;
            st_vInfo.green.length = 6;
            st_vInfo.blue.length = 5;
            st_vInfo.red.offset = 11;
            st_vInfo.green.offset = 5;
            st_vInfo.blue.offset = 0;
        }


        /* put variable screen info */
        retVal = st_fbdev_putVscreenInfo_interface(st_dev, &st_vInfo);
        if (SUCCESS != retVal) {
            DBG_PRINT_ERR(("FBIOPUT_VSCREENINFO Ioctl Failed"));
            status = FAILURE;
            break;
        }

        /* get variable screen info */
        retVal = st_fbdev_getFscreenInfo_interface(st_dev, &st_fInfo);
        if (SUCCESS != retVal) {
            DBG_PRINT_ERR(("FBIOGET_FSCREENINFO Ioctl Failed"));
            status = FAILURE;
            break;
        }

        /* set window position to (0,0) */
        st_pos.xpos = XPOS_DEFAULT;
        st_pos.ypos = YPOS_DEFAULT;
        retVal = st_fbdev_setpos_interface(st_dev, &st_pos);
        if (SUCCESS != retVal) {
            DBG_PRINT_ERR(("FBIO_SETPOS Ioctl Failed"));
            status = FAILURE;
            break;
        }

        if (FBDEV_DEV4 != st_dev) {
            /* Enable window */
            retVal =
                st_fbdev_blank_window_interface(st_dev, ST_ENABLE_WIN);
            if (SUCCESS != retVal) {
                DBG_PRINT_ERR(("FBDEV window not enabled"));
                status = FAILURE;
                break;
            }

            winStatus = TRUE;   // window is enabled
        }
        /* map vid0 buffers to user space */
        retVal =
            st_fbdev_mmap_interface(st_dev, st_fInfo.line_length,
                                    st_vInfo.yres);
        if (SUCCESS != retVal) {
            DBG_PRINT_ERR(("FBDEV buffers mapping failed"));
            status = FAILURE;
            break;
        }

        mmapStatus = TRUE;      // buffers are mapped

        /* display buffers */
        for (i = 500; i != 0; i--) {
            /* set buffer for display */
            retVal =
                st_fbdev_display_interface(st_dev, st_vInfo.xres,
                                           st_vInfo.yres, st_img_type,
                                           NULL);
            if (FAILURE == retVal) {
                DBG_PRINT_ERR(("FBDEV buffer not set for display"));
                status = FAILURE;
                break;
            }

            st_vInfo.yoffset = st_vInfo.yres * retVal;  //retVal contains the buffer index

            retVal = st_fbdev_waitforsync_interface(st_dev);
            if (SUCCESS != retVal) {
                DBG_PRINT_ERR(("FBIO_WAITFORSYNC Ioctl failed"));
                status = FAILURE;
                break;
            }

            retVal = st_fbdev_pandisplay_interface(st_dev, &st_vInfo);
            if (SUCCESS != retVal) {
                DBG_PRINT_ERR(("FBIOPAN_DISPLAY Ioctl failed"));
                status = FAILURE;
                break;
            }
        }

        break;                  // break out of while loop after display
    } while (SUCCESS == retVal);

    /* unmap buffers if mapped */
    if (TRUE == mmapStatus) {
        /* unmap buffers */
        retVal = st_fbdev_unmap_interface(st_dev);
        if (FAILURE == retVal) {
            DBG_PRINT_ERR(("Buffers could not be unmapped"));
            status = FAILURE;
        }

        mmapStatus = FALSE;     // buffers not mapped

        DBG_PRINT_TRC0(("Buffers unmapped"));
    }

    /* disable win if enabled */
    if (TRUE == winStatus) {
        /* disable FBDEV window */
        retVal = st_fbdev_blank_window_interface(st_dev, ST_DISABLE_WIN);
        if (SUCCESS != retVal) {
            DBG_PRINT_ERR(("FBDEV window not disabled"));
            status = FAILURE;
        }

        winStatus = FALSE;      // window is disabled

        DBG_PRINT_TRC0(("window disabled"));
    }

    /* close device if opened */
    if (TRUE == openStatus) {
        /* close FBDEV device */
        status = st_fbdev_closeAndreturn(&st_dev, devname);
        if (SUCCESS == status) {
            openStatus = FALSE; // device is closed
        }
    }

    if (SUCCESS == status) {
        DBG_PRINT_TRC(("FBIO_WAITFORSYNC Ioctl is successfull"));
    }

    /* print status of the test case */
    st_fbdev_display_test_status(status, test_id);


    return;

}



/****************************************************************************
 * Function             - st_fbdev_fbioSetZoom_ioctl_test
 * Functionality       - FBIO_SETZOOM  ioctl test
 * Input Params      - device name and testid
 * Return Value       - None.
 * Note                   - None
 ****************************************************************************/
void st_fbdev_fbioSetZoom_ioctl_test(char *devname, char *test_id)
{

    Int32 retVal = SUCCESS;
    Int32 status = SUCCESS;
    Int32 st_dev = -1;
    st_zoom_params st_zoom;


    /* variables to track device state, mapping of buffers and state of FBDEV window */
    Bool openStatus = FALSE;


    /* get device number for a device string to avoid further string operations */
    st_dev = st_fbdev_set_device_number(devname);

    /* open device */
    status = st_fbdev_openAndreturn(&st_dev, devname);
    if (SUCCESS == status)      // open is success
    {
        openStatus = TRUE;
        DBG_PRINT_TRC0(("FBDEV %s device opened", devname));

        st_zoom.window_id = st_dev;
        st_zoom.zoom_h = ST_ZOOM_X2;
        st_zoom.zoom_v = ST_ZOOM_X2;

        retVal = st_fbdev_setZoom_ioctl_interface(st_dev, &st_zoom);
        status = st_fbdev_checkRetVal(retVal);

        if (SUCCESS == status)  // if ioctl is success
        {
            DBG_PRINT_TRC(("FBIO_SETZOOM ioctl successful"));

            /* revert back to no- zoom */
            st_zoom.window_id = st_dev;
            st_zoom.zoom_h = ST_ZOOM_X1;
            st_zoom.zoom_v = ST_ZOOM_X1;
            st_fbdev_setZoom_ioctl_interface(st_dev, &st_zoom);
        }
    }

    /* close device if opened */
    if (TRUE == openStatus) {
        /* close FBDEV device */
        status = st_fbdev_closeAndreturn(&st_dev, devname);
        if (SUCCESS == status) {
            openStatus = FALSE; // device is closed
        }
    }

    /* print status of the test case */
    st_fbdev_display_test_status(status, test_id);


    return;

}


/****************************************************************************
 * Function             - st_fbdev_fbioSetPosx_ioctl_test
 * Functionality       - FBIO_SETPOSX  ioctl test
 * Input Params      - device name and testid
 * Return Value       - None.
 * Note                   - None
 ****************************************************************************/
void st_fbdev_fbioSetPosx_ioctl_test(char *devname, char *test_id)
{
    Int32 retVal = SUCCESS;
    Int32 status = SUCCESS;
    Int32 st_dev = -1;
    Uint32 st_xpos = XPOS_DEFAULT;


    /* variables to track device state, mapping of buffers and state of FBDEV window */
    Bool openStatus = FALSE;


    /* get device number for a device string to avoid further string operations */
    st_dev = st_fbdev_set_device_number(devname);

    /* open device */
    status = st_fbdev_openAndreturn(&st_dev, devname);
    if (SUCCESS == status)      // open is success
    {
        openStatus = TRUE;
        DBG_PRINT_TRC0(("FBDEV %s device opened", devname));

        st_xpos = XPOS_TEST;
        retVal = st_fbdev_setPosx_ioctl_interface(st_dev, &st_xpos);
        status = st_fbdev_checkRetVal(retVal);

        if (SUCCESS == status)  // if ioctl is success
        {
            DBG_PRINT_TRC(("FBIO_SETPOSX ioctl successful"));

            /* revert back to default xpos */
            st_xpos = XPOS_DEFAULT;
            st_fbdev_setPosx_ioctl_interface(st_dev, &st_xpos);
        }
    }

    /* close device if opened */
    if (TRUE == openStatus) {
        /* close FBDEV device */
        status = st_fbdev_closeAndreturn(&st_dev, devname);
        if (SUCCESS == status) {
            openStatus = FALSE; // device is closed
        }
    }

    /* print status of the test case */
    st_fbdev_display_test_status(status, test_id);


    return;
}


/****************************************************************************
 * Function             - st_fbdev_fbioSetPosy_ioctl_test
 * Functionality       - FBIO_SETPOSY  ioctl test
 * Input Params      - device name and testid
 * Return Value       - None.
 * Note                   - None
 ****************************************************************************/
void st_fbdev_fbioSetPosy_ioctl_test(char *devname, char *test_id)
{
    Int32 retVal = SUCCESS;
    Int32 status = SUCCESS;
    Int32 st_dev = -1;
    Uint32 st_ypos = YPOS_DEFAULT;


    /* variables to track device state, mapping of buffers and state of FBDEV window */
    Bool openStatus = FALSE;


    /* get device number for a device string to avoid further string operations */
    st_dev = st_fbdev_set_device_number(devname);

    /* open device */
    status = st_fbdev_openAndreturn(&st_dev, devname);
    if (SUCCESS == status)      // open is success
    {
        openStatus = TRUE;
        DBG_PRINT_TRC0(("FBDEV %s device opened", devname));

        st_ypos = YPOS_TEST;
        retVal = st_fbdev_setPosy_ioctl_interface(st_dev, &st_ypos);
        status = st_fbdev_checkRetVal(retVal);

        if (SUCCESS == status)  // if ioctl is success
        {
            DBG_PRINT_TRC(("FBIO_SETPOSY ioctl successful"));

            /* revert back to default xpos */
            st_ypos = YPOS_DEFAULT;
            st_fbdev_setPosy_ioctl_interface(st_dev, &st_ypos);
        }
    }

    /* close device if opened */
    if (TRUE == openStatus) {
        /* close FBDEV device */
        status = st_fbdev_closeAndreturn(&st_dev, devname);
        if (SUCCESS == status) {
            openStatus = FALSE; // device is closed
        }
    }

    /* print status of the test case */
    st_fbdev_display_test_status(status, test_id);


    return;
}


/****************************************************************************
 * Function             - st_fbdev_fbioMirror_ioctl_test
 * Functionality       - FBIO_MIRROR  ioctl test
 * Input Params      - device name and testid
 * Return Value       - None.
 * Note                   - None
 ****************************************************************************/
void st_fbdev_fbioMirror_ioctl_test(char *devname, char *test_id)
{
    Int32 retVal = SUCCESS;
    Int32 status = SUCCESS;
    Int32 st_dev = -1;
    Uint32 st_mirror;

    /* variables to track device state, mapping of buffers and state of FBDEV window */
    Bool openStatus = FALSE;


    /* get device number for a device string to avoid further string operations */
    st_dev = st_fbdev_set_device_number(devname);

    /* open device */
    status = st_fbdev_openAndreturn(&st_dev, devname);
    if (SUCCESS == status)      // open is success
    {
        openStatus = TRUE;
        DBG_PRINT_TRC0(("FBDEV %s device opened", devname));

        /* enable mirroring */
        st_mirror = ENABLE;
        retVal = st_fbdev_fbioMirror_ioctl_interface(st_dev, &st_mirror);
        status = st_fbdev_checkRetVal(retVal);

        if (SUCCESS == status)  // if ioctl is success
        {
            /* disable mirroring */
            st_mirror = DISABLE;
            retVal =
                st_fbdev_fbioMirror_ioctl_interface(st_dev, &st_mirror);
            status = st_fbdev_checkRetVal(retVal);

            if (SUCCESS == status)      // if ioctl is success
            {
                DBG_PRINT_TRC(("FBIO_MIRROR ioctl successful"));
            }
        }
    }

    /* close device if opened */
    if (TRUE == openStatus) {
        /* close FBDEV device */
        status = st_fbdev_closeAndreturn(&st_dev, devname);
        if (SUCCESS == status) {
            openStatus = FALSE; // device is closed
        }
    }

    /* print status of the test case */
    st_fbdev_display_test_status(status, test_id);


    return;
}


/****************************************************************************
 * Function             - st_fbdev_fbioSetCursor_ioctl_test
 * Functionality       - FBIO_SET_CURSOR  ioctl test
 * Input Params      - device name and testid
 * Return Value       - None.
 * Note                   - None
 ****************************************************************************/
void st_fbdev_fbioSetCursor_ioctl_test(char *devname, char *test_id)
{
    Int32 retVal = SUCCESS;
    Int32 status = SUCCESS;
    Int32 st_dev = -1;
    st_fb_cursor st_cursor;

    /* variables to track device state, mapping of buffers and state of FBDEV window */
    Bool openStatus = FALSE;


    /* get device number for a device string to avoid further string operations */
    st_dev = st_fbdev_set_device_number(devname);

    /* open device */
    status = st_fbdev_openAndreturn(&st_dev, devname);
    if (SUCCESS == status)      // open is success
    {
        openStatus = TRUE;
        DBG_PRINT_TRC0(("FBDEV %s device opened", devname));

        st_cursor.enable = ENABLE;
        st_cursor.image.dx = ST_CURSOR_XPOS;
        st_cursor.image.dy = ST_CURSOR_YPOS;
        st_cursor.image.width = ST_CURSOR_XRES;
        st_cursor.image.height = ST_CURSOR_YRES;
        st_cursor.image.depth = ST_CURSOR_THICKNESS;
        st_cursor.image.fg_color = ST_CURSOR_COLOR;

        retVal = st_fbdev_setCursor_ioctl_interface(st_dev, &st_cursor);
        status = st_fbdev_checkRetVal(retVal);

        if (SUCCESS == status)  // if ioctl is success
        {
            DBG_PRINT_TRC(("FBIO_SET_CURSOR ioctl successful"));

            /* disable cursor */
            st_cursor.enable = DISABLE;
            st_fbdev_setCursor_ioctl_interface(st_dev, &st_cursor);
        }
    }

    /* close device if opened */
    if (TRUE == openStatus) {
        /* close FBDEV device */
        status = st_fbdev_closeAndreturn(&st_dev, devname);
        if (SUCCESS == status) {
            openStatus = FALSE; // device is closed
        }
    }

    /* print status of the test case */
    st_fbdev_display_test_status(status, test_id);


    return;
}


/****************************************************************************
 * Function             - st_fbdev_fbioSetBackgColor_ioctl_test
 * Functionality       - FBIO_SET_BACKG_COLOR  ioctl test
 * Input Params      - device name and testid
 * Return Value       - None.
 * Note                   - None
 ****************************************************************************/
void st_fbdev_fbioSetBackgColor_ioctl_test(char *devname, char *test_id)
{
    Int32 retVal = SUCCESS;
    Int32 status = SUCCESS;
    Int32 st_dev = -1;
    st_vpbe_backg_color st_color;

    /* variables to track device state, mapping of buffers and state of FBDEV window */
    Bool openStatus = FALSE;


    /* get device number for a device string to avoid further string operations */
    st_dev = st_fbdev_set_device_number(devname);

    /* open device */
    status = st_fbdev_openAndreturn(&st_dev, devname);
    if (SUCCESS == status)      // open is success
    {
        openStatus = TRUE;
        DBG_PRINT_TRC0(("FBDEV %s device opened", devname));

        /* set background color */
        st_color.clut_select = RAM_CLUT;
        st_color.color_offset = BACKG_COLOR;
        ;
        retVal =
            st_fbdev_setBackGroundColor_ioctl_interface(st_dev, &st_color);
        status = st_fbdev_checkRetVal(retVal);

        if (SUCCESS == status)  // if ioctl is success
        {
            DBG_PRINT_TRC(("FBIO_SET_BACKG_COLOR ioctl successful"));
        }
    }

    /* close device if opened */
    if (TRUE == openStatus) {
        /* close FBDEV device */
        status = st_fbdev_closeAndreturn(&st_dev, devname);
        if (SUCCESS == status) {
            openStatus = FALSE; // device is closed
        }
    }

    /* print status of the test case */
    st_fbdev_display_test_status(status, test_id);


    return;
}


/****************************************************************************
 * Function             - st_fbdev_fbioGetCon2Fbmap_ioctl_test
 * Functionality       - FBIOGET_CON2FBMAP  ioctl test
 * Input Params      - device name and testid
 * Return Value       - None.
 * Note                   - None
 ****************************************************************************/
void st_fbdev_fbioGetCon2Fbmap_ioctl_test(char *devname, char *test_id)
{
    //TBD
}


/****************************************************************************
 * Function             - st_fbdev_fbioSetCon2Fbmap_ioctl_test
 * Functionality       - FBIOSET_CON2FBMAP  ioctl test
 * Input Params      - device name and testid
 * Return Value       - None.
 * Note                   - None
 ****************************************************************************/
void st_fbdev_fbioSetCon2Fbmap_ioctl_test(char *devname, char *test_id)
{
    //TBD
}


/****************************************************************************
 * Function             - st_fbdev_fbioGetCmap_ioctl_test
 * Functionality       - FBIOGETCMAP  ioctl test
 * Input Params      - device name and testid
 * Return Value       - None.
 * Note                   - None
 ****************************************************************************/
void st_fbdev_fbioGetCmap_ioctl_test(char *devname, char *test_id)
{
    Int32 retVal = SUCCESS;
    Int32 status = SUCCESS;
    Int32 st_dev = -1;
    struct st_fb_cmap_t gt_cmap;

    /* variables to track device state, mapping of buffers and state of FBDEV window */
    Bool openStatus = FALSE;


    /* get device number for a device string to avoid further string operations */
    st_dev = st_fbdev_set_device_number(devname);


    /* open device */
    status = st_fbdev_openAndreturn(&st_dev, devname);
    if (SUCCESS == status)  
    {
        openStatus = TRUE;  
        DBG_PRINT_TRC0(("FBDEV %s device opened", devname));

        /* get cmap of the device*/
        retVal =
           st_fbdev_getCmap_ioctl_interface(st_dev, &gt_cmap);
                                                     
        if (SUCCESS != retVal) {
            if (E_DEV_NOT_AVAILABLE == retVal) {
                DBG_PRINT_TRC(("Device is not available"));
                status = NOT_SUPPORTED;
            } else {
                DBG_PRINT_ERR(("FBIOGETCMAP ioctl Failed"));
                status = FAILURE;
            }
        }
		else
		{
			/* print values */
			DBG_PRINT_TRC0(("CMAP Start	: %d\n",gt_cmap.start));

			DBG_PRINT_TRC0(("CMAP Length	: %d\n",
							gt_cmap.len));
		}

    }
	else
	{
		/*could not open the device*/
		DBG_PRINT_ERR(("Failed to open FBDEV device\n"));
	}

    /* close device if opened */
    if (TRUE == openStatus) {
        /* close FBDEV device */
        status = st_fbdev_closeAndreturn(&st_dev, devname);
        if (SUCCESS == status) {
            openStatus = FALSE; // device is closed
        }
    }

    /* print status of the test case */
    st_fbdev_display_test_status(status, test_id);

    return;
}


/****************************************************************************
 * Function             - st_fbdev_fbioPutCmap_ioctl_test
 * Functionality       - FBIOPUTCMAP  ioctl test
 * Input Params      - device name and testid
 * Return Value       - None.
 * Note                   - None
 ****************************************************************************/
void st_fbdev_fbioPutCmap_ioctl_test(char *devname, char *test_id)
{
    Int32 retVal = SUCCESS;
    Int32 status = SUCCESS;
    Int32 st_dev = -1;
	Bool endLoop = FALSE;
    struct st_fb_cmap_t current_cmap,gt_cmap;
	struct st_fb_cmap_t st_cmap;
    Uint16 test_red[4]={0xFF,0x00, 0x00, 0xFF}; 
    Uint16 test_green[4]={0x00, 0xFF, 0x00, 0xFF};
    Uint16 test_blue[4]={0x00, 0x00, 0xFF, 0x00};

		/*Initialize the color map with default values*/
		st_cmap.len = CMAP_LENGHT;
		st_cmap.red = (Uint16*)test_red;
		st_cmap.green= (Uint16*)test_green;
		st_cmap.blue=  (Uint16*)test_blue;
		st_cmap.transp=NULL;


    /* variables to track device state, mapping of buffers and state of FBDEV window */
    Bool openStatus = FALSE;


    /* get device number for a device string to avoid further string operations */
    st_dev = st_fbdev_set_device_number(devname);


    /* open device */
    status = st_fbdev_openAndreturn(&st_dev, devname);
	if(SUCCESS!= status) 
	{
        openStatus = FALSE;  // device is opened
        DBG_PRINT_TRC0(("FBDEV %s device could not be opened", devname));
		
	}
    else
    {
        openStatus = TRUE;  // device is opened
        DBG_PRINT_TRC0(("FBDEV %s device opened", devname));
		
		do {
				endLoop = TRUE;//we just have to run it once
				/*First get the color map*/
				
				/*Set the color map*/	
				st_cmap.start = current_cmap.start;
				
				retVal =
				   st_fbdev_putCmap_ioctl_interface(st_dev, &st_cmap);
				
				if (SUCCESS != retVal) {
					if (E_DEV_NOT_AVAILABLE == retVal) {
						DBG_PRINT_TRC(("Device is not available"));
						status = NOT_SUPPORTED;
					} else {
						DBG_PRINT_ERR(("FBIOPUTCMAP ioctl Failed"));
						status = FAILURE;
					}
					break;
				}

				DBG_PRINT_ERR(("FBIOPUTCMAP ioctl succeeded "));
				DBG_PRINT_ERR(("Verify the set Values "));
				
				retVal =
				   st_fbdev_getCmap_ioctl_interface(st_dev, &gt_cmap);
			
				if (SUCCESS != retVal) {
					if (E_DEV_NOT_AVAILABLE == retVal) {
						DBG_PRINT_TRC(("Device is not available"));
						status = NOT_SUPPORTED;
					} else {
						DBG_PRINT_ERR(("FBIOGETCMAP ioctl Failed"));
						status = FAILURE;
					}
					break;
				}
				
				DBG_PRINT_TRC0(("CMAP Start	: %d\n",
								gt_cmap.start));

				DBG_PRINT_TRC0(("CMAP Length	: %d\n",
								gt_cmap.len));

				DBG_PRINT_ERR(("Put back the Original values "));
				
				retVal =
				   st_fbdev_putCmap_ioctl_interface(st_dev, &current_cmap);
				
				if (SUCCESS != retVal) {
					if (E_DEV_NOT_AVAILABLE == retVal) {
						DBG_PRINT_TRC(("Device is not available"));
						status = NOT_SUPPORTED;
					} else {
						DBG_PRINT_ERR(("FBIOPUTCMAP ioctl Failed"));
						status = FAILURE;
					}
				}
			}while (FALSE == endLoop);
		}
	/* close device if opened */
	 if (TRUE == openStatus) {
		 /* close FBDEV device */
		  st_fbdev_closeAndreturn(&st_dev, devname);
			 openStatus = FALSE; // device is closed
	 }
	 
	 /* print status of the test case */
	 st_fbdev_display_test_status(status, test_id);
	 return;

}

/****************************************************************************
 * Function             - st_fbdev_fbioqueryplane_ioctl_test
 * Functionality       - Query the plane (gfx) and returns the omapfb_plane_info information
 * Input Params      - device name and testid
 * Return Value       - None.
 * Note                   - None 
 ****************************************************************************/
void st_fbdev_fbioqueryplane_ioctl_test(char *devname, char *test_id)
{
    Int32 retVal = SUCCESS;
    Int32 status = SUCCESS;
    Int32 st_dev = -1;
	struct st_omapfb_plane_info st_planeinfo;


    /* variables to track device state, mapping of buffers and state of FBDEV window */
    Bool openStatus = FALSE;


    /* get device number for a device string to avoid further string operations */
    st_dev = st_fbdev_set_device_number(devname);

    /* open device */
    status = st_fbdev_openAndreturn(&st_dev, devname);
    if (SUCCESS == status)      
    {
        openStatus = TRUE;
        DBG_PRINT_TRC0(("FBDEV %s device opened", devname));

        /* Query the device plane information */
        retVal = st_fbdev_fbioQueryPlaneInfo_ioctl_interface(st_dev, &st_planeinfo);
        status = st_fbdev_checkRetVal(retVal);

        if (status != SUCCESS) 
        { 
			DBG_PRINT_TRC(("OMAPFB_QUERY_PLANE ioctl Failed"));
            status = FAILURE;
        }
		else
        {
            DBG_PRINT_TRC(("OMAPFB_QUERY_PLANE ioctl successful"));
        }
    }
    else
    {
        DBG_PRINT_TRC0(("FBDEV %s device opened FAILED", devname));
    }

    /* close device if opened */
    if (TRUE == openStatus) {
        /* close FBDEV device */
         st_fbdev_closeAndreturn(&st_dev, devname);
            openStatus = FALSE; // device is closed
    }

    /* print status of the test case */
    st_fbdev_display_test_status(status, test_id);


    return;
}

/****************************************************************************
 * Function             - st_fbdev_fbioSetupMem_ioctl_test 
 * Functionality       - Allows user to setup the frame buffer momory
 * Input Params      - size and type.
 * Return Value       - None.
 * Note                   - NonE 
 ****************************************************************************/
void st_fbdev_fbioSetupMem_ioctl_test(char *devname, char *test_id)
{

    Int32 retVal = SUCCESS;
    Int32 status = SUCCESS;
    Int32 st_dev = -1;
    struct st_omapfb_mem_info st_getmemInfo;
    struct st_omapfb_mem_info st_putmemInfo;

	/* variables to track device state, mapping of buffers and state of FBDEV window */
    Bool openStatus = FALSE;


	/*mem zero the structures*/
	memset(&st_getmemInfo, 0, sizeof(st_getmemInfo));
	memset(&st_putmemInfo, 0, sizeof(st_putmemInfo));

    /* get device number for a device string to avoid further string operations */
    st_dev = st_fbdev_set_device_number(devname);

    /* open device */
    status = st_fbdev_openAndreturn(&st_dev, devname);
    if (SUCCESS == status)      // open is success
    {
        openStatus = TRUE;
        DBG_PRINT_TRC0(("FBDEV %s device opened", devname));

        /* get the frame buffer memory information */
        st_fbdev_QueryMemInfo_interface(st_dev, &st_getmemInfo);
		
        if (SUCCESS != retVal) {
            if (E_DEV_NOT_AVAILABLE == retVal) {
                DBG_PRINT_TRC(("Device is not available"));
                status = NOT_SUPPORTED;
            } else {
                DBG_PRINT_ERR(("OMAPFB_QUERY_MEM ioctl failed"));
                status = FAILURE;
            }
        }
		else
		{
			DBG_PRINT_TRC(("OMAPFB_QUERY_MEM ioctl succeeded"));

			//Now the query has succeeded we can set the FB mem information
			st_putmemInfo.size = st_getmemInfo.size; //put back the same size we dont want any confusion
			st_putmemInfo.type = OMAPFB_MEMTYPE_SDRAM;
			
			retVal = st_fbdev_SetMemInfo_interface(st_dev, &st_putmemInfo);
			
			if (SUCCESS != retVal) {
				if (E_DEV_NOT_AVAILABLE == retVal) {
					DBG_PRINT_TRC(("Device is not available"));
					status = NOT_SUPPORTED;
				} else {
					DBG_PRINT_ERR(("OMAPFB_SET_MEM ioctl failed"));
					status = FAILURE;
				}
			}
			else
			{
	            DBG_PRINT_TRC(("OMAPFB_SET_MEM ioctl succeeded"));
				/*Query and print the information*/
				memset(&st_putmemInfo, 0, sizeof(st_putmemInfo));
				
				/* get the frame buffer memory information */
				st_fbdev_QueryMemInfo_interface(st_dev, &st_putmemInfo);
				
				if (SUCCESS != retVal) {
					if (E_DEV_NOT_AVAILABLE == retVal) {
						DBG_PRINT_TRC(("Device is not available"));
						status = NOT_SUPPORTED;
					} else {
						DBG_PRINT_ERR(("OMAPFB_QUERY_MEM ioctl failed"));
						status = FAILURE;
					}
				}
				DBG_PRINT_TRC0(("Memory size set %lu ", st_putmemInfo.size));
				DBG_PRINT_TRC0(("Memory type set %d", st_putmemInfo.type));

				/*Now set back what ever was existing before*/
				retVal = st_fbdev_SetMemInfo_interface(st_dev, &st_getmemInfo);
				
				if (SUCCESS != retVal) {
					if (E_DEV_NOT_AVAILABLE == retVal) {
						DBG_PRINT_TRC(("Device is not available"));
						status = NOT_SUPPORTED;
					} else {
						DBG_PRINT_ERR(("OMAPFB_SET_MEM ioctl failed"));
						status = FAILURE;
					}
				}
			}
		}
		
	    /* close device if opened */
	    if (TRUE == openStatus) {
	        /* close FBDEV device */
	        status = st_fbdev_closeAndreturn(&st_dev, devname);
	        if (SUCCESS == status) {
	            openStatus = FALSE; // device is closed
	        }
	    }
    }
	else
	{
		DBG_PRINT_TRC0(("FBDEV %s device opened Failed", devname));
		status = FAILURE; 
	}
	

    /* print status of the test case */
    st_fbdev_display_test_status(status, test_id);

    return;
}
 
 /****************************************************************************
  * Function			 - st_fbdev_fbioqueryMem_ioctl_test 
  * Functionality		- Allows user to setup the frame buffer momory
  * Input Params	  - size and type.
  * Return Value	   - None.
  * Note				   - None 
  ****************************************************************************/
 void st_fbdev_fbioqueryMem_ioctl_test(char *devname, char *test_id)
 {
 
	 Int32 retVal = SUCCESS;
	 Int32 status = SUCCESS;
	 Int32 st_dev = -1;
	 struct st_omapfb_mem_info st_getmemInfo;
 
	 /* variables to track device state, mapping of buffers and state of FBDEV window */
	 Bool openStatus = FALSE;
 
 
	 /*mem zero the structures*/
	 memset(&st_getmemInfo, 0, sizeof(st_getmemInfo));
 
	 /* get device number for a device string to avoid further string operations */
	 st_dev = st_fbdev_set_device_number(devname);
 
	 /* open device */
	 status = st_fbdev_openAndreturn(&st_dev, devname);
	 if (SUCCESS == status) 	 // open is success
	 {
		 openStatus = TRUE;
		 DBG_PRINT_TRC0(("FBDEV %s device opened", devname));
 
		 /* get the frame buffer memory information */
		 st_fbdev_QueryMemInfo_interface(st_dev, &st_getmemInfo);
		 
		 if (SUCCESS != retVal) {
			 if (E_DEV_NOT_AVAILABLE == retVal) {
				 DBG_PRINT_TRC(("Device is not available"));
				 status = NOT_SUPPORTED;
			 } else {
				 DBG_PRINT_ERR(("OMAPFB_QUERY_MEM ioctl failed"));
				 status = FAILURE;
			 }
		 }
		 else
		 {
			 DBG_PRINT_TRC(("OMAPFB_QUERY_MEM ioctl succeeded"));
			 DBG_PRINT_TRC0(("Memory size set %lu ", st_getmemInfo.size));
			 DBG_PRINT_TRC0(("Memory type set %d", st_getmemInfo.type));
		 }
		 
		 /* close device if opened */
		 if (TRUE == openStatus) {
			 /* close FBDEV device */
			 status = st_fbdev_closeAndreturn(&st_dev, devname);
			 if (SUCCESS == status) {
				 openStatus = FALSE; // device is closed
			 }
		 }
	 }
	 else
	 {
		 DBG_PRINT_TRC0(("FBDEV %s device opened Failed", devname));
		 status = FAILURE; 
	 }
	 
 
	 /* print status of the test case */
	 st_fbdev_display_test_status(status, test_id);
 
	 return;
 }

/****************************************************************************
 * Function 		- st_fbdev_fbioGetUpdateMode_ioctl_test 
 * Functionality	- This returns the current update mode of DSS
 * Input Params 	- None.
 * Return Value 	- None.
 * Note 			- None 
 ****************************************************************************/
void st_fbdev_fbioGetUpdateMode_ioctl_test(char *devname, char *test_id)
{

	Int32 retVal = SUCCESS;
	Int32 status = SUCCESS;
	Int32 st_dev = -1;
	int st_mode;

	/* variables to track device state, mapping of buffers and state of FBDEV window */
	Bool openStatus = FALSE;
    

	/* get device number for a device string to avoid further string operations */
	st_dev = st_fbdev_set_device_number(devname);

	/* open device */
	status = st_fbdev_openAndreturn(&st_dev, devname);
	if (SUCCESS == status)		// open is success
	{
		openStatus = TRUE;
		DBG_PRINT_TRC0(("FBDEV %s device opened", devname));

		/* get the frame buffer memory information */
		retVal = st_fbdev_GetUpdatedMode_interface(st_dev, &st_mode);
		
		if (SUCCESS != retVal) {
			if (E_DEV_NOT_AVAILABLE == retVal) {
				DBG_PRINT_TRC(("Device is not available"));
				status = NOT_SUPPORTED;
			} else {
				DBG_PRINT_ERR(("OMAPFB_GET_UPDATE_MODE ioctl failed"));
				status = FAILURE;
			}
		}
		else
		{
			DBG_PRINT_TRC(("OMAPFB_GET_UPDATE_MODE ioctl succeeded"));
			DBG_PRINT_TRC0(("Mode -  %d ", st_mode));
		}
		
		/* close device if opened */
		if (TRUE == openStatus) {
			/* close FBDEV device */
			status = st_fbdev_closeAndreturn(&st_dev, devname);
			if (SUCCESS == status) {
				openStatus = FALSE; // device is closed
			}
		}
	}
	else
	{
		DBG_PRINT_TRC0(("FBDEV %s device opened Failed", devname));
		status = FAILURE; 
	}
	

	/* print status of the test case */
	st_fbdev_display_test_status(status, test_id);

	return ;
}




 
void st_fbdev_ioctl_test_parser(char *devname, char *test_id)
{
        int i;
        int retVal = SUCCESS;
        int status = SUCCESS;
        int st_mode = DSS_DISABLED;  
	switch(testoptions.ioctl_no) 
	{
		case 0:
			for(i=0; i< testoptions.loopcount; i++) 
			{
				st_fbdev_putVscreenInfo_ioctl_test(devname, test_id);
            }
			break;		
		case 1:
		{
			for(i=0; i< testoptions.loopcount; i++) 
			{
				 st_fbdev_getFscreenInfo_ioctl_test(devname, test_id);
			}
			break;
		}	
		case 2:
		{
			for(i=0; i< testoptions.loopcount; i++) 
			{
				st_fbdev_fbioqueryplane_ioctl_test(devname, test_id);
			}
				break;
		}
		case 3:
		{
			for(i=0; i< testoptions.loopcount; i++) 
			{
				st_fbdev_fbioqueryMem_ioctl_test(devname, test_id);
			}
			break;
		}
		case 4:
		{
			for(i=0; i< testoptions.loopcount; i++) 
			{
				st_fbdev_fbioGetUpdateMode_ioctl_test(devname, test_id);
			}
			break;
		}
		case 5:
                 {
			for(i=0; i< testoptions.loopcount; i++) 
			{
			         retVal = st_fbdev_SetUpdatedMode_interface((int)devname,st_mode);

   				 if (SUCCESS != retVal) {
        					 status = FAILURE;
      			        		 DBG_PRINT_ERR(("SET UPDATE MODE  Ioctl failed"));
					 break;
   				 }

			}
      			DBG_PRINT_TRC0(("SET UPDATE MODE  Ioctl passed"));
			break;
		}
	}

    /* end test case */
    DBG_PRINT_TST_END((test_id));
}

/* vim: set ts=4 sw=4 tw=80 et:*/
