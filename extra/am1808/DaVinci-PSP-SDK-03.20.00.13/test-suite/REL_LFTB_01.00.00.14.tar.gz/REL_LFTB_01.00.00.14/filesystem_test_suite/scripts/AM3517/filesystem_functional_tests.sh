DEVICE_NODE1=$1
FSTYPE1=$2
DEVICE_NODE2=$3
FSTYPE2=$4
MKFS_AVAIL=$5
FILE_SIZE=$6
NO_OF_FILES=$7
STABILITY_LOOP_COUNT=$8
DEVICE=$9
usage()
{
        echo "================================================================================================="
        echo "This program is to run functional tests on filesystem devices."
        echo ""
        echo "Before running the script partition the storage device into two partitions"
        echo "If mkfs is not available in the nfs please format the two partitions with the desired filesystems "
        echo "Syntax: filesystem_functional_tests.sh<device_node1><fstype_on_device_node1><device_node2>"
	echo "<fsytype_on_device_node2><mfks_available><max_file_size><no of files><stability_loop_count><device>"
        echo "options for type of device node: /dev/mtdblock3, /dev/mtdblock4, /dev/mmcblk0p1"
        echo "/dev/hda1, /dev/sda1 /dev/hda2, /dev/sda2 etc"
        echo "Please check the /dev/ directory for the device node"
        echo ""
        echo "options for type of filesystem: ext2, ext3, vfat, jffs2, yaffs2"
        echo ""
        echo "options for type of filesystem: ext2, ext3, vfat, jffs2, yaffs2"
        echo ""
        echo "options for mkfs_available : mkfs_avail, mkfs_unavail"
        echo ""
        echo "options for file size in MB: 100, 200, 300"
        echo "              check the capacity of the partition   "
        echo ""
        echo "options for no of files: 1, 2, 3"
        echo "              check the capacity of the partition   "
        echo "              The capacity of the partiton should accomodate no of files * file size"
        echo ""
        echo "options for  stability count: 100,1000 etc"
        echo ""
        echo "options for  device: USB,MMC,NAND,SPI etc"
        echo ""
        echo "Example: filesystem_functional_tests.sh  /dev/sda1 ext2 /dev/sda2 ext3 mkfs_avail 100 3 1000 USB for "
	echo "USB device with two partitions formatted with ext2 and ext3 and each partition can"
	echo "accomodate 300MB (3*100MB)"
        echo "===================================================================================================="

}
if [ -z "${DEVICE_NODE1}" ]
then
        echo "ERROR: No Device node1 specified."
        usage
        exit 1
fi
if [ -z "${FSTYPE1}" ]
then
        echo "ERROR: No Filesystem type1 specified."
        usage
        exit 1
fi
if [ -z "${DEVICE_NODE2}" ]
then
        echo "ERROR: No Device node2 specified."
        usage
        exit 1
fi
if [ -z "${FSTYPE2}" ]
then
        echo "ERROR: No Filesystem type2 specified."
        usage
        exit 1
fi
if [ -z "${MKFS_AVAIL}" ]
then
        echo "ERROR: No mkfs availabilty specified."
        usage
        exit 1
fi
if [ -z "${FILE_SIZE}" ]
then
        echo "ERROR: No File size specified."
        usage
        exit 1
fi
if [ -z "${NO_OF_FILES}" ]
then
        echo "ERROR: No number of files specified."
        usage
        exit 1
fi
if [ -z "${DEVICE}" ]
then
        echo "ERROR: No Device name specified."
        usage
        exit 1
fi
#Un mount the auto-mounted partitiions if any
umount /media/*
#
# Creating a variable for addressing Mount Point
MOUNT_POINT1=/mnt/partition1_$DEVICE
MOUNT_POINT2=/mnt/partition2_$DEVICE
# Create the Mount point
mkdir -p $MOUNT_POINT1
mkdir -p $MOUNT_POINT2
echo "Unmounting the mount points if already mounted"
umount $DEVICE_NODE1
umount $DEVICE_NODE2
umount $MOUNT_POINT1
umount $MOUNT_POINT2
echo " Check whether the devices are auto mounted"
mount
#Unmount if the device is auto mounted 
echo "Unmount all the auto mounted device on /media"
umount /media/*
echo " check whether the devices are unmounted"
mount
# format using "mkfs "
if [ "${MKFS_AVAIL}" == "mkfs_avail" ]
then
echo "Formatting the partitions"
mkfs.$FSTYPE1 $DEVICE_NODE1
mkfs.$FSTYPE2 $DEVICE_NODE2
fi
#Mount the Partition
echo "Mounting the partitions"
mount -t $FSTYPE1 $DEVICE_NODE1 $MOUNT_POINT1
mount -t $FSTYPE2 $DEVICE_NODE2 $MOUNT_POINT2
#listing the partitions
echo""
echo "###################################################################################"
echo "Executing the command 'mount'"
mount
echo "Executing the command 'df -ah'"
df -ah
echo "Executing the command 'fdisk -l'"
fdisk -l
echo""
echo "###################################################################################"
echo "Cleaning up the partitions"
rm -rf $MOUNT_POINT1/*
rm -rf $MOUNT_POINT2/*
echo " listing the partion1 Check whether the partition is empty or not"
ls -lart $MOUNT_POINT1
echo " listing the partion2 Check whether the partition is empty or not"
ls -lart $MOUNT_POINT2
echo " File creation and read/write tests on Mulitple partitions"
cd $MOUNT_POINT1
x=0
while [ $x -lt $NO_OF_FILES ]
do
dd if=/dev/zero of=file$x bs=1M count=$FILE_SIZE
x=$((x+1))
done
echo " created the files on partition 1"
echo " listing the files  on partition 1"
echo "Verify whether the file0 file1 file2 ... files are created or not"
ls -lart $MOUNT_POINT1
x=0
while [ $x -lt $NO_OF_FILES ]
do
cp file$x $MOUNT_POINT2
x=$((x+1))
done
echo " copied the files to partition 2"
echo " listing the files  on partition 2"
echo "Verify whether the file0 file1 file2 ... files are created or not"
ls -lart $MOUNT_POINT2
rm -rf $MOUNT_POINT2/file*
x=0
while [ $x -lt $NO_OF_FILES ]
do
mv file$x $MOUNT_POINT2
x=$((x+1))
done
echo " removed the files on partition 2 and copied from partition 1 to partition 2 "
echo " listing the files  on partition 2"
echo "Verify whether the file0 file1 file2 ... files are created or not"
ls -lart $MOUNT_POINT2
rm -rf $MOUNT_POINT2/file*
cd $MOUNT_POINT2
x=0
while [ $x -lt $NO_OF_FILES ]
do
dd if=/dev/zero of=file$x bs=1M count=$FILE_SIZE
x=$((x+1))
done
echo " created the files on partition 2"
echo " listing the files  on partition 2"
echo "Verify whether the file0 file1 file2 ... files are created or not"
ls -lart $MOUNT_POINT2
x=0
while [ $x -lt $NO_OF_FILES ]
do
cp file$x $MOUNT_POINT1
x=$((x+1))
done
echo " copied the files to partition 1"
echo " listing the files  on partition 1"
echo "Verify whether the file0 file1 file2 ... files are created or not"
ls -lart $MOUNT_POINT1
rm -rf $MOUNT_POINT1/file*
x=0
while [ $x -lt $NO_OF_FILES ]
do
mv file$x $MOUNT_POINT1
x=$((x+1))
done
echo " removed the files on partition 1 and copied from partition 2 to partition 1 "
echo " listing the files  on partition 1"
echo "Verify whether the file0 file1 file2 ... files are created or not"
ls -lart $MOUNT_POINT1
rm -rf $MOUNT_POINT1/file*
echo "Simultaneous read/write tests on multiple partiotions"
cd $MOUNT_POINT1
dd if=/dev/zero of=file_$FILE_SIZEmb_1 bs=1M count=$FILE_SIZE
cd $MOUNT_POINT2
dd if=/dev/zero of=file_$FILE_SIZEmb_2 bs=1M count=$FILE_SIZE
cp $MOUNT_POINT1/file_$FILE_SIZEmb_1 $MOUNT_POINT2&
cp $MOUNT_POINT2/file_$FILE_SIZEmb_2 $MOUNT_POINT1&
sleep 15
echo "Verify whether both the partitons has file_$FILE_SIZEmb_1 and file_$FILE_SIZEmb_2"
echo " listing the files on partition 1"
ls -lart $MOUNT_POINT1
echo " listing the files on partition 2"
ls -lart $MOUNT_POINT2
rm -rf $MOUNT_POINT1/*
rm -rf $MOUNT_POINT2/*
echo " stability tests started"
echo " PRESS CTRL-C TO EXIT"
cd $MOUNT_POINT1
x=0
while [ $x -lt $STABILITY_LOOP_COUNT ]
do
date
dd if=/dev/zero of=stability_file bs=1M count=$FILE_SIZE
mv stability_file $MOUNT_POINT2
x=$((x+1))
echo "check the size of the file"
echo "file size should match the $FILE_SIZE" 
du -h $MOUNT_POINT2/stability_file
rm -rf $MOUNT_POINT2/stability_file
done
sleep 20
umount $MOUNT_POINT1
umount $MOUNT_POINT2

