MODULE_NAME=$1
STABILITY_LOOP_COUNT=$2
DEVICE_NODE1=$3
FSTYPE1=$4
DEVICE_NODE2=$5
FSTYPE2=$6
FILE_SIZE=$7
NO_OF_FILES=$8
DEVICE=$9
MKFS_AVAIL=$10

usage()
{

	echo "================================================================================================="
        echo "This program is to runs the modular tests."
        echo ""
        echo "Syntax: filesystem_modular_tests.sh<module_name><stability_loop_count><device_node1><fstype_on_device_node1><device_node2>"
        echo "<fsytype_on_device_node2><max_file_size><no of files><device><mkfs_avail>"
        echo ""
        echo "options for module_name: musb_hdrc.ko, ohci-hcd.ko etc"
        echo ""
        echo "options for stability_loop_count: 10,20,100 etc"
        echo ""
        echo "options for type of device node: /dev/mtdblock3, /dev/mtdblock4, /dev/mmcblk0p1"
        echo "/dev/hda1, /dev/sda1 /dev/hda2, /dev/sda2 etc"
        echo "Please check the /dev/ directory for the device node"
        echo ""
        echo "options for type of filesystem: ext2, ext3, vfat, jffs2, yaffs2"
        echo ""
        echo "options for type of filesystem: ext2, ext3, vfat, jffs2, yaffs2"
        echo ""
        echo "options for file size in MB: 100, 200, 300"
        echo "              check the capacity of the partition   "
        echo ""
        echo "options for no of files: 1, 2, 3"
        echo "              check the capacity of the partition   "
        echo "              The capacity of the partiton should accomodate no of files * file size"
        echo ""
        echo ""
        echo "options for  device: USB,MMC,NAND,SPI etc"
        echo ""
        echo ""
        echo "options for mkfs_available : mkfs_avail, mkfs_unavail"
        echo ""
        echo "Example: filesystem_modular_tests.sh  musb_hdrc.ko 0 15 /dev/sda1 vfat /dev/sda2 ext2 100 3 USB mkfs_avail for "
        echo "USB device with two partitions and each partition can"
        echo "accomodate 300MB (3*100MB)"

        echo "===================================================================================================="

}
if [ -z "${MODULE_NAME}" ]
then
        echo "ERROR: No MODULE_NAME specified."
        usage
        exit 1
fi
if [ -z "${STABILITY_LOOP_COUNT}" ]
then
        echo "ERROR: No stability loop count specified."
        usage
        exit 1
fi
if [ -z "${DEVICE_NODE1}" ]
then
        echo "ERROR: No Device node1 specified."
        usage
        exit 1
fi
if [ -z "${FSTYPE1}" ]
then
        echo "ERROR: No Filesystem type1 specified."
        usage
        exit 1
fi
if [ -z "${DEVICE_NODE2}" ]
then
        echo "ERROR: No Device node2 specified."
        usage
        exit 1
fi
if [ -z "${FSTYPE2}" ]
then
        echo "ERROR: No Filesystem type2 specified."
        usage
        exit 1
fi
if [ -z "${FILE_SIZE}" ]
then
        echo "ERROR: No File size specified."
        usage
        exit 1
fi
if [ -z "${NO_OF_FILES}" ]
then
        echo "ERROR: No number of files specified."
        usage
        exit 1
fi
if [ -z "${DEVICE}" ]
then
        echo "ERROR: No Device name specified."
        usage
        exit 1
fi
if [ -z "${MKFS_AVAIL}" ]
then
        echo "ERROR: No mkfs availabilty specified."
        usage
        exit 1
fi

echo ""
echo "Executing modular tests without I/O"
echo ""
x=0
while [ $x -lt $STABILITY_LOOP_COUNT ]
do
x=$((x+1))
date
echo ""
echo "Inserting the module $MODULE_NAME"
echo ""
insmod $MODULE_NAME
echo ""
echo " listing the modules using lsmod. Check whether the $MODULE_NAME is listed or not"
echo ""
lsmod
#Un mount the auto-mounted partitiions if any
umount /media/*
rmmod $MODULE_NAME
done

echo ""
echo "Executing modular tests with I/O"
echo ""
x=0
while [ $x -lt $STABILITY_LOOP_COUNT ]
do
x=$((x+1))
date
insmod $MODULE_NAME
sleep 10

echo ""
echo " ######## lsmod ###############"
echo ""
lsmod

echo ""
echo " ####### cat /proc/modules #############"
echo ""
cat /proc/modules

echo ""
echo " ####### cat /proc/ioports #############"
echo ""
cat /proc/ioports

echo ""
echo " ####### cat /proc/iomem #############"
echo ""
cat /proc/iomem

echo ""
echo " ####### cat /proc/interrupts #############"
echo ""
cat /proc/interrupts
mount
df -ah
fdisk -l
#Un mount the auto-mounted partitiions if any
umount /media/*
#
# Creating a variable for addressing Mount Point
MOUNT_POINT1=/mnt/partition1_$DEVICE
MOUNT_POINT2=/mnt/partition2_$DEVICE
# Create the Mount point
mkdir -p $MOUNT_POINT1
mkdir -p $MOUNT_POINT2

echo ""
echo $MOUNT_POINT1
echo $MOUNT_POINT2
echo " Check whether the devices are auto mounted"
echo ""
mount
#Unmount if the device is auto mounted

echo ""
echo "Unmount all the auto mounted device on /medida"
echo ""
umount /media/*

echo ""
echo " check whether the devices are unmounted"
echo ""
mount
# format using "mkfs "
if [ "${MKFS_AVAIL}" == "mkfs_avail" ]
then

echo ""
echo "Formatting the partitions"
echo ""
mkfs.$FSTYPE1 $DEVICE_NODE1
mkfs.$FSTYPE2 $DEVICE_NODE2
fi
#Mount the Partition

echo ""
echo "Mounting the partitions"
echo ""
mount -t $FSTYPE1 $DEVICE_NODE1 $MOUNT_POINT1
mount -t $FSTYPE2 $DEVICE_NODE2 $MOUNT_POINT2
#listing the partitions

echo ""
echo "listing the partitions, Check whether the partitions are mounted or not"
echo ""
mount
echo ""
echo "Cleaning up the partitions"
echo ""
rm -rf $MOUNT_POINT1/*
rm -rf $MOUNT_POINT2/*

echo ""
echo " listing the partion1 Check whether the partition is empty or not"
echo ""
ls -lart $MOUNT_POINT1

echo ""
echo " listing the partion2 Check whether the partition is empty or not"
echo ""
ls -lart $MOUNT_POINT2

echo ""
echo " File creation and read/write tests on Mulitple partitions"
echo ""
cd $MOUNT_POINT1
x=0
while [ $x -lt $NO_OF_FILES ]
do
dd if=/dev/zero of=file$x bs=1M count=$FILE_SIZE
x=$((x+1))
done

echo ""
echo " created the files on partition 1"
echo " listing the files  on partition 1"
echo "Verify whether the file0 file1 file2 ... files are created or not"
echo ""
ls -lart $MOUNT_POINT1
x=0
while [ $x -lt $NO_OF_FILES ]
do
cp file$x $MOUNT_POINT2
x=$((x+1))
done

echo ""
echo " copied the files to partition 2"
echo " listing the files  on partition 2"
echo "Verify whether the file0 file1 file2 ... files are created or not"
echo ""
ls -lart $MOUNT_POINT2
rm -rf $MOUNT_POINT1/file*
rm -rf $MOUNT_POINT2/file*
cd -
umount $MOUNT_POINT1
umount $MOUNT_POINT2
rmmod $MODULE_NAME
echo ""
echo " ######## lsmod ###############"
echo ""
lsmod
echo ""
echo " ####### cat /proc/modules #############"
echo ""
cat /proc/modules
echo ""
echo " ####### cat /proc/ioports #############"
echo ""
cat /proc/ioports
echo ""
echo " ####### cat /proc/iomem #############"
echo ""
cat /proc/iomem
echo ""
echo " ####### cat /proc/interrupts #############"
echo ""
cat /proc/interrupts
mount
df -ah
fdisk -l
done

