#  filesystem_tests.sh
#
#   ============================================================================
#Options that can be exercised in the testsuite 
#
# -r	   --read            I/O direction mode is read
# -w       --write           I/O direction mode is write
# -f       --filename        Name of the file to read from or write to
# -b       --buffer_size     application buffer size in bytes
# -s	   --file_size       Total file size in MB
# -p	   --throughput      Enable the throughput measurement
# -l	   --cpuload	     Enable the cpuload measurement
# -T       --testcaseid      Test case id string for testers reference/logging purpose
# -?       --help            Displays the help/usage
# -v       --version         Version of Test suite
#
#
# Default values
# DEFAULT_BUFFER_SIZE 102400 bytes
# DEFAULT_FILE_SIZE 100MB
#
FSTYPE=$1
DEVICE_NODE=$2
SYNC_MODE=$3
MKFS_AVAIL=$4
FILE_SIZE=$5
usage()
{
        echo "=============================================================================================="
        echo "This program is to calculate the performance numbers for filesystem devices."
        echo ""
        echo "Syntax: filesystem_performance_tests.sh<type_of_filesystem><device_node><sync_mode><mfks_available><file_size>"
        echo ""
        echo "options for type of filesystem: ext2, ext3, vfat, jffs2, yaffs2"
        echo ""
        echo "options for type of device node: /dev/mtdblock3, /dev/mtdblock4, /dev/mmcblk0p1"
        echo "/dev/hda1, /dev/sda1 etc"
        echo "Please check the /dev/ directory for the device node"
        echo ""
        echo "options for sync mode : sync, async"
        echo ""
        echo "options for mkfs_available : mkfs_avail, mkfs_unavail"
        echo ""
        echo "options for file size : 10, 50, 100 etc"
        echo ""

        echo "Example: filesystem_perfromance_tests.sh jffs2 /dev/mtdblock4 async mkfs_unavail 100 for OMAP NAND JFFS2 ASYNC_MODE"
        echo "================================================================================================"

}
if [ -z "${FSTYPE}" ]
then
        echo "ERROR: No Filesystem type specified."
        usage
        exit 1
fi
if [ -z "${DEVICE_NODE}" ]
then
        echo "ERROR: No Device node specified."
        usage
        exit 1
fi
if [ -z "${SYNC_MODE}" ]
then
        echo "ERROR: No sync mode specified."
        usage
        exit 1
fi
if [ -z "${MKFS_AVAIL}" ]
then
        echo "ERROR: No mkfs availabilty specified."
        usage
        exit 1
fi
if [ -z "${FILE_SIZE}" ]
then
        echo "ERROR: No file size specified."
        usage
        exit 1
fi

#
#Unmount the auto mounted partitions if any
umount /media/*
# Creating a variable for addressing Mount Point
MOUNT_POINT=/mnt/filesystem
# Create the Mount point
mkdir -p $MOUNT_POINT
echo " Unmounting the mount point if already mounted"
umount $MOUNT_POINT
#
#Prints the usage/help
./filesystem_tests --help
#Prints the version
./filesystem_tests -v
#Runs the file system performance test -write/-read, -Filename, -buffer_size, -file_size are provided
# umount the mount directory if already mounted
umount $DEVICE_NODE
umount $MOUNT_POINT
# format using "mkfs "
if [ "${MKFS_AVAIL}" == "mkfs_avail" ]
then
mkfs.$FSTYPE $DEVICE_NODE
fi
#Mount the Partition
if [ "${SYNC_MODE}" == "async" ]
then
mount -t $FSTYPE $DEVICE_NODE $MOUNT_POINT
echo "Mounted with async mode"
elif [ "${SYNC_MODE}" == "sync" ]
then
mount -t $FSTYPE -o sync $DEVICE_NODE $MOUNT_POINT
echo "Mounted with sync mode"
fi
echo ""
echo "listing the mount partitions"
echo ""
echo "Command - mount"
echo ""
mount
echo ""
echo "Command - df-ah"
echo ""
df -ah
echo ""
echo 3 > /proc/sys/vm/drop_caches
./filesystem_tests -w -f $MOUNT_POINT/file_102400_100 -b 102400 -s $FILE_SIZE -p -l -T FILESYSTEM_WRITE_PERF_102400_100 
umount $MOUNT_POINT
mount -t $FSTYPE $DEVICE_NODE $MOUNT_POINT

echo 3 > /proc/sys/vm/drop_caches
./filesystem_tests -r -f $MOUNT_POINT/file_102400_100 -b 102400 -s $FILE_SIZE -p -l -T FILESYSTEM_READ_PERF_102400_100 
echo ""
echo " listing the files in the mount partition"
echo " Check whether the file size is 100MB or not"
echo ""
ls -lart $MOUNT_POINT/
echo ""

#
# umount the mount directory if already mounted
umount $MOUNT_POINT
# format using "mkfs "
if [ "${MKFS_AVAIL}" == "mkfs_avail" ]
then
mkfs.$FSTYPE $DEVICE_NODE
fi
#Mount the Partition
if [ "${SYNC_MODE}" == "async" ]
then
mount -t $FSTYPE $DEVICE_NODE $MOUNT_POINT
echo "Mounted with async mode"
elif [ "${SYNC_MODE}" == "sync" ]
then
mount -t $FSTYPE -o sync $DEVICE_NODE $MOUNT_POINT
echo "Mounted with sync mode"
fi
echo ""
echo "listing the mount partitions"
echo ""
echo "Command - mount"
echo ""
mount
echo ""
echo "Command - df-ah"
echo ""
df -ah
echo ""

echo 3 > /proc/sys/vm/drop_caches
./filesystem_tests -w -f $MOUNT_POINT/file_256000_100 -b 256000 -s $FILE_SIZE -p -l -T FILESYSTEM_WRITE_PERF_256000_100 
umount $MOUNT_POINT
mount -t $FSTYPE $DEVICE_NODE $MOUNT_POINT

echo 3 > /proc/sys/vm/drop_caches
./filesystem_tests -r -f $MOUNT_POINT/file_256000_100 -b 256000 -s $FILE_SIZE -p -l -T FILESYSTEM_READ_PERF_256000_100 
echo ""
echo " listing the files in the mount partition"
echo " Check whether the file size is 100MB or not"
echo ""
ls -lart $MOUNT_POINT/
echo ""

#
# umount the mount directory if already mounted
umount $MOUNT_POINT
# format using "mkfs "
if [ "${MKFS_AVAIL}" == "mkfs_avail" ]
then
mkfs.$FSTYPE $DEVICE_NODE
fi
#Mount the Partition
if [ "${SYNC_MODE}" == "async" ]
then
mount -t $FSTYPE $DEVICE_NODE $MOUNT_POINT
echo "Mounted with async mode"
elif [ "${SYNC_MODE}" == "sync" ]
then
mount -t $FSTYPE -o sync $DEVICE_NODE $MOUNT_POINT
echo "Mounted with sync mode"
fi
echo ""
echo "listing the mount partitions"
echo ""
echo "Command - mount"
echo ""
mount
echo ""
echo "Command - df-ah"
echo ""
df -ah
echo ""

echo 3 > /proc/sys/vm/drop_caches
./filesystem_tests -w -f $MOUNT_POINT/file_512000_100 -b 512000 -s $FILE_SIZE -p -l -T FILESYSTEM_WRITE_PERF_512000_100 
umount $MOUNT_POINT
mount -t $FSTYPE $DEVICE_NODE $MOUNT_POINT

echo 3 > /proc/sys/vm/drop_caches
./filesystem_tests -r -f $MOUNT_POINT/file_512000_100 -b 512000 -s $FILE_SIZE -p -l -T FILESYSTEM_READ_PERF_512000_100 
echo ""
echo " listing the files in the mount partition"
echo " Check whether the file size is 100MB or not"
echo ""
ls -lart $MOUNT_POINT/
echo ""

#
# umount the mount directory if already mounted
umount $MOUNT_POINT
# format using "mkfs "
if [ "${MKFS_AVAIL}" == "mkfs_avail" ]
then
mkfs.$FSTYPE $DEVICE_NODE
fi
#Mount the Partition
if [ "${SYNC_MODE}" == "async" ]
then
mount -t $FSTYPE $DEVICE_NODE $MOUNT_POINT
echo "Mounted with async mode"
elif [ "${SYNC_MODE}" == "sync" ]
then
mount -t $FSTYPE -o sync $DEVICE_NODE $MOUNT_POINT
echo "Mounted with sync mode"
fi
echo ""
echo "listing the mount partitions"
echo ""
echo "Command - mount"
echo ""
mount
echo ""
echo "Command - df-ah"
echo ""
df -ah
echo ""

echo 3 > /proc/sys/vm/drop_caches
./filesystem_tests -w -f $MOUNT_POINT/file_1048576_100 -b 1048576 -s $FILE_SIZE -p -l -T FILESYSTEM_WRITE_PERF_1048576_100 
umount $MOUNT_POINT
mount -t $FSTYPE $DEVICE_NODE $MOUNT_POINT

echo 3 > /proc/sys/vm/drop_caches
./filesystem_tests -r -f $MOUNT_POINT/file_1048576_100 -b 1048576 -s $FILE_SIZE -p -l -T FILESYSTEM_READ_PERF_1048576_100 
echo ""
echo " listing the files in the mount partition"
echo " Check whether the file size is 100MB or not"
echo ""
ls -lart $MOUNT_POINT/
echo ""
#
# umount the mount directory if already mounted
umount $MOUNT_POINT
# format using "mkfs "
if [ "${MKFS_AVAIL}" == "mkfs_avail" ]
then
mkfs.$FSTYPE $DEVICE_NODE
fi
#Mount the Partition
if [ "${SYNC_MODE}" == "async" ]
then
mount -t $FSTYPE $DEVICE_NODE $MOUNT_POINT
echo "Mounted with async mode"
elif [ "${SYNC_MODE}" == "sync" ]
then
mount -t $FSTYPE -o sync $DEVICE_NODE $MOUNT_POINT
echo "Mounted with sync mode"
fi
echo ""
echo "listing the mount partitions"
echo ""
echo "Command - mount"
echo ""
mount
echo ""
echo "Command - df-ah"
echo ""
df -ah
echo ""

echo 3 > /proc/sys/vm/drop_caches
./filesystem_tests -w -f $MOUNT_POINT/file_5242880_100 -b 5242880 -s $FILE_SIZE -p -l -T FILESYSTEM_WRITE_PERF_5242880_100 
umount $MOUNT_POINT
mount -t $FSTYPE $DEVICE_NODE $MOUNT_POINT

echo 3 > /proc/sys/vm/drop_caches
./filesystem_tests -r -f $MOUNT_POINT/file_5242880_100 -b 5242880 -s $FILE_SIZE -p -l -T FILESYSTEM_READ_PERF_5242880_100
echo ""
echo " listing the files in the mount partition"
echo " Check whether the file size is 100MB or not"
echo ""
ls -lart $MOUNT_POINT/
echo ""

ls -lart $MOUNT_POINT/
rm $MOUNT_POINT/file*
umount $MOUNT_POINT
