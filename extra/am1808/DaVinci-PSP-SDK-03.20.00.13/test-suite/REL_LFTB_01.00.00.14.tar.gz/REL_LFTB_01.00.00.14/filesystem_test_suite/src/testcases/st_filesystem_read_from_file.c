/*
 * st_filesystem_read_from_file.c
 *
 * This file contains fbdev parser and gives user selectable test cases
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/ 
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/

#include <sys/time.h>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

/* Include package headers here */
#include <stTimer.h>
#include <stBufferMgr.h>
#include <stLog.h>
#include <stCpuLoad.h>
#include "st_filesystem_common.h"

/****************************************************************************
 * Function             - st_filesystem_performance_read_test 
 * Functionality        - This function recieves the test params and read 
 *                        from the file
 * Input Params         -  info,test_id
 * Return Value         -  0: SUCCESS, -1: FAILURE
 * Note                 -  None
 ****************************************************************************/
int st_filesystem_performance_read_test(struct st_filesystem_testparams *info,
                           char *test_id)
{
    int fdes            = 0;
    int result          = 0;
    char *buff_ptr       = NULL; 
    char *file_ptr       = NULL; 
    int i               = 0;
    int read_ret         = 0;
    int bsize      = 0;
    int totalsize  = 0;
    int loopcount       = 0;
    int remainder       = 0; 
    int totbytread      = 0;    
    ST_TIMER_ID start_time;
    unsigned long elapsed_usecs = 0;
    ST_CPU_STATUS_ID cpu_status_id;
    float percentage_cpu_load = 0;
    do {

		file_ptr = info->filename;
		totalsize = info->file_size * 1024 * 1024;
		bsize = info->buffer_size;
 
        loopcount = totalsize/bsize;
        remainder = totalsize%bsize;
        /* Allocate memory for the buff_ptr, size = bsize */
        buff_ptr = (char * ) st_allocate_buffer(bsize * (sizeof(char)));
        if (NULL == buff_ptr)
        {
            st_perror("buff_ptr");
            break;
        }
		if (info->throughput_flag) {
    	    /* Start Timer */  
       		 startTimer(&start_time);
		}
		
		if (info->cpuload_flag) {
	       /* Start CPU Load calcaulation */ 
    	    startCpuLoadMeasurement (&cpu_status_id);
		}
		
        /* Perform the read operation */
		fdes = st_open((const char*)file_ptr, O_RDONLY);
        if(-1 == fdes)
        {
            DBG_PRINT_ERR(("file open failed "));
            break;
        }
        
        for(i = 0 ; i < loopcount; i++)
        {
            read_ret = st_read(fdes, buff_ptr, bsize) ;
            totbytread = totbytread + read_ret;
            if(bsize != read_ret)
            {
                DBG_PRINT_ERR(("file read failed "));
                break;
            }
        }

        if(remainder)
        {
            read_ret = st_read(fdes, buff_ptr, remainder) ;
            totbytread = totbytread + read_ret;
            if(remainder != read_ret)
            {
				DBG_PRINT_ERR(("file read failed "));
                break;
            }
        }
        result = st_close(fdes);
        if(-1 == result)
        {
           	DBG_PRINT_ERR(("file close failed "));
            break ;
        }

		if (info->throughput_flag) {
	        /* Stop the Timer and get the usecs elapsed */
    	    elapsed_usecs = stopTimer (&start_time);
        	DBG_PRINT_TRC0(("fileread | Durartion in usecs | %ld", elapsed_usecs));
        	DBG_PRINT_TRC0(("fileread | Mega Bytes/Sec | %lf", (float)(((float)totalsize/(float)elapsed_usecs))));
		}
		if (info->cpuload_flag) {
			
			  /* Get CPU Load figures */ 
        	percentage_cpu_load = stopCpuLoadMeasurement (&cpu_status_id);
        	if((percentage_cpu_load >= 0) && (percentage_cpu_load <= 100))
            	DBG_PRINT_TRC0(("fileread | percentage cpu load | %.2f%%", percentage_cpu_load));
		}
		DBG_PRINT_TST_RESULT_PASS((test_id));
		DBG_PRINT_TRC0(("Please check the size of the file"));

    }while (0);
    /* Free  memory for the buff_ptr */
    if (NULL != buff_ptr)
    {
        st_free_buffer(buff_ptr);
    }
	/* end test case */
   	DBG_PRINT_TST_END((test_id));
    return result;
}


/* vim: set ts=4 sw=4 tw=80 et:*/

