# i2c_tests_script.sh
#
#   ============================================================================
#Options that can be exercised in the testsuite
#        -?      --help
#        -v      --version		print current version of Test suite
#        -d      --device-node		device node interface
#        -a      --address		address of the device attached to i2c bus
#        -b      --buffer-size=# 	buffer size in bytes
#        -s      --total-size=#        	total size in bytes
#        -p      --page-size=#        	write buffer page size on the device
#        -r      --read    		I/O direction mode is read
#        -w      --write    		I/O direction mode is write
#        -t      --throughput      	Enable the throughput measurement
#        -l      --CPULoad         	Enable the CPULoad measurement
#        -T      --testcaseid      	Test case id string for testers reference/logging purpose
#
#
#
# Default values
#DEFAULT_DEVICE			eeprom
#DEFAULT_BUFFER_SIZE  		64
#DEFAULT_PAGE_SIZE  		64
#DEFAULT_TOTAL_SIZE  		1024
#DEFAULT_DEVICE_NODE		"/dev/i2c-0"
#DEFAULT_IO_MODE		read
PLATFORM=$1
usage()
{
        echo "=============================================================================================="
        echo "This program is to run functional and performance tests on i2c module."
        echo ""
        echo "Syntax: i2c_tests_script.sh<platform>"
        echo ""
        echo "options for platform: "DA8XX", "OMAPL137","DM644X", "DM6467", "
        echo ""
        echo "Example:  i2c_tests_script.sh DA8XX"
        echo "================================================================================================"

}
if [ -z "${PLATFORM}" ]
then
        echo "ERROR: No PLATFORM specified."
        usage
        exit 1
fi
if [ "${PLATFORM}" == "DA8XX" ]
then
DEVICE_NODE="/dev/i2c-0"
ADDRESS=0x50
#CAT24WC256 - 64 byte page write buffer
PAGE_SIZE=64
elif [ "${PLATFORM}" == "OMAPL137" ]
then
DEVICE_NODE="/dev/i2c-0"
ADDRESS=0x50
#CAT24WC256 - 64 byte page write buffer
PAGE_SIZE=64
elif [ "${PLATFORM}" == "DM644X" ]
then
DEVICE_NODE="/dev/i2c/0"
ADDRESS=0x50
#CAT24WC256 - 64 byte page write buffer
PAGE_SIZE=64
elif [ "${PLATFORM}" == "DM6467" ]
then
DEVICE_NODE="/dev/i2c/0"
ADDRESS=0x50
#CAT24C256 - 64 byte page write buffer
PAGE_SIZE=64
fi
#write
#On write buffer size should not be greater than page size since the address counter wraps
#around and previosly transmitted data will be overwritten
./i2c_tests -d $DEVICE_NODE -a $ADDRESS  -b 4 -s 1024 -w -p 64 -t -l -T I2C_WRITE_4_1024
./i2c_tests -d $DEVICE_NODE -a $ADDRESS  -b 8 -s 1024 -w -p 64 -t -l -T I2C_WRITE_8_1024
./i2c_tests -d $DEVICE_NODE -a $ADDRESS  -b 16 -s 1024 -w -p 64 -t -l -T I2C_WRITE_16_1024
./i2c_tests -d $DEVICE_NODE -a $ADDRESS  -b 32 -s 1024 -w -p 64 -t -l -T I2C_WRITE_32_1024
./i2c_tests -d $DEVICE_NODE -a $ADDRESS  -b 64 -s 1024 -w -p 64 -t -l -T I2C_WRITE_64_1024
sleep 3
#read
#On read there is no limitation of buffer size
./i2c_tests -d $DEVICE_NODE -a $ADDRESS  -b 4 -s 1024 -r -p 64 -t -l -T I2C_READ_4_1024
./i2c_tests -d $DEVICE_NODE -a $ADDRESS  -b 8 -s 1024 -r -p 64 -t -l -T I2C_READ_8_1024
./i2c_tests -d $DEVICE_NODE -a $ADDRESS  -b 16 -s 1024 -r -p 64 -t -l -T I2C_READ_16_1024
./i2c_tests -d $DEVICE_NODE -a $ADDRESS  -b 32 -s 1024 -r -p 64 -t -l -T I2C_READ_32_1024
./i2c_tests -d $DEVICE_NODE -a $ADDRESS  -b 64 -s 1024 -r -p 64 -t -l -T I2C_READ_64_1024
