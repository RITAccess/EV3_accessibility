/*
 * st_i2c_common.c
 *
 * This file contains the interface specific funtions
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/ 
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/

/* Generic header files */
#include <stDefines.h>

/*Testcode header file*/
#include "st_i2c_common.h"

/* Storage structures, enums, macros defined */
#define DEFAULT_IOMODE 'r'
#define DEFAULT_DEVICE_NODE "/dev/i2c-0"
#define DEFAULT_I2C_ADDRESS 0x50
#define DEFAULT_I2C_PAGE_SIZE 64
#define DEFAULT_DEVICE 0 /* eeprom */
#define DEFAULT_BUFFER_SIZE  64
#define DEFAULT_FILE_SIZE 1024

/* Global Variables */
struct st_i2c_testparams testoptions;



/****************************************************************************
 * Function			- st_init_i2c_test_params
 * Functionality        	- This function initilaizes the default values for
 * various test case options(which will be exposed as command line arguments)
 * Input Params         	-  None
 * Return Value         	-  None
 * Note                 		-  None
 ****************************************************************************/
void st_init_i2c_test_params(void)
{
    testoptions.iomode 		= DEFAULT_IOMODE;
	testoptions.device_node	= DEFAULT_DEVICE_NODE;
	testoptions.device		= DEFAULT_DEVICE;
	testoptions.address		= DEFAULT_I2C_ADDRESS;
	testoptions.page_size	= DEFAULT_I2C_PAGE_SIZE;
    testoptions.buffer_size = DEFAULT_BUFFER_SIZE;
    testoptions.file_size 	= DEFAULT_FILE_SIZE;
    
}


/****************************************************************************
 * Function             	- st_display_i2c_test_suite_help
 * Functionality        	- This function displays the help/usage
 * Input Params         	- None
 * Return Value         	- None
 * Note                 		- None
 ****************************************************************************/
void st_display_i2c_test_suite_help(void)
{
    printf("I2C TestSuite V %s\n", VERSION_STRING);
    printf("Usage:\n"
           "./i2c_tests <options>\n\n"
           "-d		--device-node		Device-node interface\n"
           "\t\t\t\tPossible values-/dev/i2c/0\n"
           "-a		--address			I2C address\n"
           "\t\t\t\tPossible values-0x50 etc, Check EVM schematic for the address\n"
           "\t\t\t\tPossible values-32, 64 etc, Check the eeprom datasheet for page size\n"
           "-b		--buffer_size  		application buffer size in bytes\n"
           "-p		--page_size  		hardware device page size in bytes\n"
           "-s 		--total_size    	Total size in bytes\n" 
           "-T    	--testcaseid   		Test case id string for testers reference/logging purpose\n"
           "\t\t\t\tPossible values- Any String without spaces\n"
           "-r     	--read         		I/O direction mode is read\n"
           "\t\t\t\tJust pass the option.No need to pass any value\n"
           "-w     	--write        		I/O direction mode is write\n"
		   "\t\t\t\tJust pass the option.No need to pass any value\n"
           "-t     	--throughput  		Throughput measurement enabled\n"
           "\t\t\t\tJust pass the option.No need to pass any value\n"
           "-l     	--cpuload	   		Cpuload measurment enabled\n"
           "\t\t\t\tJust pass the option.No need to pass any value\n"
           "-?     	--help         		Displays the help/usage\n"
           "-v     	--version      		Version of I2C Test suite\n");
    exit(0);
}


/****************************************************************************
 * Function             	- st_print_i2c_test_params
 * Functionality        	- This function prints the test option values
 * Input Params         	- Test params structure
 * Return Value         	- None
 * Note                 		- None
 ****************************************************************************/
void st_print_i2c_test_params(struct st_i2c_testparams
                                        *testoptions, char *test_id)
{
	/* Start test case */
	DBG_PRINT_TST_START((test_id));
	DBG_PRINT_TRC0(("The Test is going to start with following values "));
	if ( testoptions->iomode == 'w') {
		DBG_PRINT_TRC0(("I2C | WRITE"));
	} else {
		DBG_PRINT_TRC0(("I2C | READ"));
	}
    DBG_PRINT_TRC0(("Device Node | %s", testoptions->device_node));
	if ( testoptions->device == 0) {
		DBG_PRINT_TRC0(("I2C DEVICE | EEPROM "));
	} else if ( testoptions->device == 1) {
		DBG_PRINT_TRC0(("I2C DEVICE | AUDIO CODEC "));
	} else {
		DBG_PRINT_TRC0(("I2C DEVICE | VIDEO CODEC "));
	}
	DBG_PRINT_TRC0(("Device Address | 0x%x", testoptions->address));
	DBG_PRINT_TRC0(("Device Page size | %d", testoptions->page_size));
    DBG_PRINT_TRC0(("The application buffer size in bytes | %d", testoptions->buffer_size));
    DBG_PRINT_TRC0(("The total file size in bytes | %d", testoptions->file_size));
   
}


/* vi: set ts=4 sw=4 tw=80 et:*/

