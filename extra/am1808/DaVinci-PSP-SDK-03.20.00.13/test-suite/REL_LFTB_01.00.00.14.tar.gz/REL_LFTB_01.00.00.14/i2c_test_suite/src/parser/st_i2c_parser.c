/*
 * st_i2c_parser.c
 *
 * This file contains fbdev parser and gives user selectable test cases
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/ 
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/


/*Testcode related header files */
#include "st_i2c_common.h"

char *testcaseid = "i2c_tests";

/* Test case options structure */
extern struct st_i2c_testparams testoptions;

/*Function to display test suite version */
void st_display_i2c_testsuite_version();
/* Function to get the hex value from the str */
unsigned long st_get_unsigned(const char* str);




/****************************************************************************
 * Function             - st_process_i2c_test_options 
 * Functionality        - This function parses the command line options and values passed for the options
 * Input Params         -  argc,argv
 * Return Value         -  None
 * Note                 -  None
 ****************************************************************************/

static void st_process_i2c_test_options(int argc, char **argv)
{
    int error = FALSE;
    int version = FALSE;
    int help = FALSE;
    int read = FALSE;
    int write = FALSE;
    for (;;) {
        int option_index = 0;
        /** Options for getopt - New test case options added need to be
         * populated here*/
        static struct option long_options[] = {
            {"device-node", optional_argument, NULL, 'd'},
			{"address", optional_argument, NULL, 'a'},
            {"buffer_size", optional_argument, NULL, 'b'},
            {"page_size", optional_argument, NULL, 'p'},
            {"total_size", optional_argument, NULL, 's'},
            {"testcaseid", optional_argument, NULL, 'T'},
            {"read", no_argument, NULL, 'r'},
            {"write", no_argument, NULL, 'w'},
            {"throughput", no_argument, NULL, 't'},
			{"cpuload", no_argument, NULL, 'l'},
            {"version", no_argument, NULL, 'v'},
            {"help", no_argument, NULL, '?'},
            {NULL, 0, NULL, 0}
        };
        int c =
            getopt_long(argc, argv,
                        "d:a:e:b:p:s:T::rwtlv?",
                        long_options, &option_index);
        if (c == -1) {
            break;
        }

        switch (c) {
        case 'd':
            if (optarg != NULL) {
                testoptions.device_node = optarg;
            } else if (optind < argc && argv[optind]) {
                testoptions.device_node = argv[optind];
            }
            break;
		case 'a':
            if (optarg != NULL) {
                testoptions.address = st_get_unsigned(optarg);
            } else if (optind < argc && argv[optind]) {
                testoptions.address = st_get_unsigned(argv[optind]);
            }
            break;
        case 'b':
            if (optarg != NULL) {
                testoptions.buffer_size = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                testoptions.buffer_size = atoi(argv[optind]);
            }
            break;
		case 'p':
            if (optarg != NULL) {
                testoptions.page_size = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                testoptions.page_size = atoi(argv[optind]);
            }
            break;
        case 's':
            if (optarg != NULL) {
                testoptions.file_size = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                testoptions.file_size = atoi(argv[optind]);
            }
            break;

		
        case 'T':
            if (optarg != NULL) {
                testcaseid = optarg;
            } else if (optind < argc && argv[optind]) {
                testcaseid = argv[optind];
            }
            break;
		
        case 'r':
            read = TRUE;
            break;
			
		case 'w':
            write = TRUE;
            break;
			
		case 't':
			testoptions.throughput_flag = TRUE;
            break;

		case 'l':
			testoptions.cpuload_flag = TRUE;
            break;
			
        case 'v':
            st_display_i2c_testsuite_version();
            version = TRUE;
            break;
			
        case '?':
            help = TRUE;
            break;
		
        }
    }

    if (version != TRUE && help != TRUE) {
		if (read != TRUE && write != TRUE){
            error = TRUE;
			
        }
    }
    if (error == TRUE || help == TRUE) {
        st_display_i2c_test_suite_help();
    }
    if ((version != TRUE && help != TRUE) && (error != TRUE)) {

        st_print_i2c_test_params(&testoptions, testcaseid);
		

	if (read == TRUE) 
		st_i2c_eeprom_read_test(&testoptions, testcaseid);
	if (write == TRUE)
		st_i2c_eeprom_write_test(&testoptions, testcaseid);
    }
	  
}

/****************************************************************************
 * Function            	 	- st_get_unsigned
 * Functionality       	- Super-safe conversion of a string into an unsigned.
 * Input Params         	- str
 * Return Value         	- resultant value on succes, -1 on failure
 * Note                 		- None
 ****************************************************************************/

unsigned long st_get_unsigned(const char* str)
{
	char* end_ptr = NULL;

	unsigned long result = strtoul(str, &end_ptr, 0);

	if((str[0] != '\0') &&(*end_ptr == '\0'))
	{
		if(result == ULONG_MAX)
		{
			DBG_PRINT_ERR(("Too large integer: %s", str));
			return FAILURE;
		}

		return result;
	}

	DBG_PRINT_ERR(("Invalid value : %s", str));
	return FAILURE;
}


/****************************************************************************
 * Function            	 	- st_display_i2c_testsuite_version
 * Functionality       	- This function displays the test suite version
 * Input Params         	- None 
 * Return Value         	- None
 * Note                 		- None
 ****************************************************************************/

void st_display_i2c_testsuite_version()
{
    printf("I2C TestSuite V %s\n", VERSION_STRING);
}

/****************************************************************************
 * Function             	- Main function
 * Functionality       	- This is where the execution begins
 * Input Params      	- argc,argv
 * Return Value         	- None
 * Note                 		- None
 ****************************************************************************/

int main(int argc, char *argv[])
{
    /* Initialize options with default vales */
    st_init_i2c_test_params();

	/* Initialize Timer module */
    initTimerModule();

    /* Invoke the parser function to process the command line options */
    st_process_i2c_test_options(argc, argv);
    return 0;
}
/* vi: set ts=4 sw=4 tw=80 et:*/

