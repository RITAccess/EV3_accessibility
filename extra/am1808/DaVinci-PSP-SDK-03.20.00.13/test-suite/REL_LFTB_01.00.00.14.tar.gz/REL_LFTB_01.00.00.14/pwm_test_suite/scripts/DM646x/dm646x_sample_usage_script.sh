#  dm646x_pwm_tests_sample_script


#Prints the usage/help
./DM646x_pwm_tests --help

#Prints the version
./DM646x_pwm_tests -v

#Runs the default PWM test
./DM646x_pwm_tests 

#Run the PWM test on pwm instance 1 with 200 as period and 100 as pulse width duration,rptval as 50,phase and inact states as 0
./DM646x_pwm_tests -d /dev/davinci_pwm1 -I 200 -i 100 -p 0 -s 0 -r 50

#Run the API test- Runs all APIs supported. -T stands for special tests like api,stability. Currently only api,stability can be passed for -T. Wheraes the smsmall letter -t stands for test name(will be logged) and helpful for testers reference. User can pass any string to small -t option but string shouldn't have any spaces.
./DM646x_pwm_tests -T api -t apitests

#Run the stability Test
./DM646x_pwm_tests -T stability

#Run the stability test for 10 times on PWM instance 0.By changing n to high value, it can run over night and detect for any memory leak/crash.
# -d stands for device node and can be passed as command line
./DM646x_pwm_tests -d /dev/davinci_pwm0 -T stability -n 10


