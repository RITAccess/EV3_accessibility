/*
 * st_pwm_common.c 
 *
 * This file implements common functions among platforms and test cases
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/ 
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/


#include <st_pwm_common.h>

/* Globals */
extern int fd_dev; 
struct pwm_testparams testoptions;

/****************************************************************************
 * Function             - st_pwm_close_interface
 * Functionality        - This function closes the pwm device instance
 * Input Params         - pwm instance device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_pwm_close_interface()
{
    int retVal = SUCCESS;

    retVal  = close(fd_dev);

    if (0 > retVal)
        return FAILURE;

    return SUCCESS;
}

/****************************************************************************
 * Function             - st_pwm_set_mode_interface
 * Functionality        - This function sets the PWM operating mode
 * Input Params         - pwm instance device number,mode
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_pwm_set_mode_interface(int mode)
{
    int retVal = SUCCESS;
    int opmode = mode;
    retVal = ioctl(fd_dev,PWMIOC_SET_MODE, &opmode);
    if (SUCCESS != retVal)
    {
        return FAILURE;
    }
    return SUCCESS;
}

/****************************************************************************
 * Function             - st_pwm_set_period_interface
 * Functionality        - This function sets the PWM period
 * Input Params         - pwm instance device number,timer period
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_pwm_set_period_interface(int period)
{
    int retVal = SUCCESS;
    int val = period;
    retVal = ioctl(fd_dev,PWMIOC_SET_PERIOD, &val);
    if (SUCCESS != retVal)
    {
        return FAILURE;
    }
    return SUCCESS;
}

/****************************************************************************
 * Function             - st_pwm_set_duration_interface
 * Functionality        - This function sets the pulse width duration
 * Input Params         - pwm instance device number,pulse width duration
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_pwm_set_duration_interface(int duration)
{
    int retVal = SUCCESS;
    int val = duration;
    retVal = ioctl(fd_dev,PWMIOC_SET_DURATION, &val);
    if (SUCCESS != retVal)
    {
        return FAILURE;
    }
    return SUCCESS;
}

/****************************************************************************
 * Function             - st_pwm_set_rpt_interface
 * Functionality        - This function sets the rpt value
 * Input Params         - pwm instance device number,rpt value
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_pwm_set_rpt_interface(int rptval)
{
    int retVal = SUCCESS;
    int val = rptval;
    retVal = ioctl(fd_dev,PWMIOC_SET_RPT_VAL, &val);
    if (SUCCESS != retVal)
    {
        return FAILURE;
    }
    return SUCCESS;
}

/****************************************************************************
 * Function             - st_pwm_set_phase_state_interface
 * Functionality        - This function sets the phase state
 * Input Params         - pwm instance device number,phase state value
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_pwm_set_phase_state_interface(int phasestate)
{
    int retVal = SUCCESS;
    int val = phasestate;
    retVal = ioctl(fd_dev,PWMIOC_SET_FIRST_PHASE_STATE, &val);
    if (SUCCESS != retVal)
    {
        return FAILURE;
    }
    return SUCCESS;
}

/****************************************************************************
 * Function             - st_pwm_set_inact_out_state_interface
 * Functionality        - This function sets the inact out state
 * Input Params         - pwm instance device number,inact out value
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_pwm_set_inact_out_state_interface(int inactstate)
{
    int retVal = SUCCESS;
    int val = inactstate;
    retVal = ioctl(fd_dev,PWMIOC_SET_INACT_OUT_STATE, &val);
    if (SUCCESS != retVal)
    {
        return FAILURE;
    }
    return SUCCESS;
}

/****************************************************************************
 * Function             - st_pwm_start_interface
 * Functionality        - This function  starts the PWM instance
 * Input Params         - pwm instance device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_pwm_start_interface()
{
    int retVal = SUCCESS;
    int val = 0;
    retVal = ioctl(fd_dev,PWMIOC_START, &val);
    if (SUCCESS != retVal)
    {
        return FAILURE;
    }
    sleep(10);  
    return SUCCESS;
}

/****************************************************************************
 * Function             - st_pwm_stop_interface
 * Functionality        - This function stops the PWM instance
 * Input Params         - pwm instance device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_pwm_stop_interface()
{
    int retVal = SUCCESS;
    int val = 0;
    retVal = ioctl(fd_dev,PWMIOC_STOP, &val);
    if (SUCCESS != retVal)
    {
        return FAILURE;
    }
    return SUCCESS;
}

/****************************************************************************
 * Function             - init_pwm_test_params
 * Functionality        - This function initilaizes the default values for
 * various test case options(which will be exposed as command line arguments)
 * Input Params         -  None
 * Return Value         -  None
 * Note                 -  None
 ****************************************************************************/
void init_pwm_test_params()
{
    testoptions.devnode = DEFAULT_NODE;
    testoptions.mode = DEFAULT_MODE;
    testoptions.period = DEFAULT_PERIOD;
    testoptions.duration = DEFAULT_DURATION;
    testoptions.rptval= DEFAULT_RPT_VAL;
    testoptions.phstate = DEFAULT_PH_STATE;
    testoptions.inactstate = DEFAULT_INACT_OUT_STATE;
}

/****************************************************************************
 * Function             - st_pwm_set_device_number
 * Functionality        - Function sets device number for a device string
 * Input Params         - device name and numberNone
 * Note                 - None
 ****************************************************************************/
void st_pwm_set_device_number(char* devname, int* st_dev)
{
    if (!strcmp(devname, PWM_INSTANCE0))
    {
        *st_dev = INSTANCE0;
    }
    else if (!strcmp(devname, PWM_INSTANCE1))
    {
        *st_dev = INSTANCE1;
    }
    else if (!strcmp(devname, PWM_INSTANCE2))
    {
        *st_dev = INSTANCE2;
    }
    else if (!strcmp(devname, PWM_INSTANCE3))
    {
        *st_dev = INSTANCE3;
    }

}

/****************************************************************************
 * Function             - print_pwm_test_params
 * Functionality        - This function prints the test option values
 * Input Params         - Test params structure
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/
void print_pwm_test_params(struct pwm_testparams *testoptions,char *testcaseid)
{
    DBG_PRINT_TST_START((testcaseid));
    DBG_PRINT_TRC0(("The Test is going to start with following values "));
    DBG_PRINT_TRC0(("The device node | %s",testoptions->devnode));
    DBG_PRINT_TRC0(("The mode is | %d",testoptions->mode));
    DBG_PRINT_TRC0(("The period is | %d msec",testoptions->period));
    DBG_PRINT_TRC0(("The duration is | %d msec",testoptions->duration));
}

/****************************************************************************
 * Function             - display_help
 * Functionality        - This function displays the help/usage
 * Input Params         - None
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/
void display_pwm_test_suite_help(void)
{
    printf("PWM Test suite V %1.2f\n", VERSION_STRING);
    printf("Usage:\n"
            "./pwm_tests <options>\n\n"
            "-d       --devicenode     Device node on which test is to be run\n"
            "\t\t\t\tPossible value-/dev/davinci_pwm0 etc based on platform\n"
            "-T       --testname        Name of the special test\n"
            "\t\t\t\tPossible values-stability,api\n"
            "-m       --mode            Operating mode of PWM \n"
            "\t\t\t\tPossible values-0 for one shot mode, 1 for continous mode\n"
            "-I       --period          Period in milliseconds\n"
            "-i       --duration        Pulse width duration in milliseconds\n"
            "-n       --stabilitycount  Number of times to run stability test-any integer value\n"
            "-t       --testcaseid      Test case id string for testers reference/logging purpose\n"
            "\t\t\t\tPossible values- Any String without spaces\n"
            "-r       --rptval          Repeat value\n"
            "-s       --inactstate      Inact out state\n"
            "\t\t\t\tPossible values-0 or 1\n"
            "-p       --phasestate      Phase state\n"
            "\t\t\t\tPossible values-0 or 1\n"
            "-?       --help            Displays the help/usage\n"
            "-v       --version         Version of Display Test suite\n");
    exit(0);
}
/* vim: set ts=4 sw=4 tw=80 et:*/
