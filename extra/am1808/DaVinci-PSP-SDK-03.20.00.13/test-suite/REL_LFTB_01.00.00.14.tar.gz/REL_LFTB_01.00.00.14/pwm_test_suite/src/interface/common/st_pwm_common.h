/*
 * st_v4l2_pwm_common.h 
 *
 * This file contains the common function definitions
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/ 
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/


#ifndef _ST_COMMON_H_
#define _ST_COMMON_H_

/* Standard Linux header files */
/* Generic header files */
#include <stdio.h>
#include <string.h>
#include <getopt.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <asm/types.h>      
#include <time.h>
#include <pthread.h>
#include <signal.h>
#include <sched.h>
#include <linux/unistd.h>
#include <sys/prctl.h>
#include <sys/stat.h>
#include <sys/sysinfo.h>


/*Testcode related Header files*/
#include <stDefines.h>
#include <stLog.h>

/* Driver specfic header file */
#include "davinci_pwm.h"

/*Structure for holding the test options */
struct pwm_testparams
{
    /* Device node name */
    char *devnode;
    /* Device Mode*/
    int mode;
    /* Period */
    int period;
    /* Pulse width duration */
    int duration;
    /* Rpt calue */
    int rptval;
    /* Phase state */
    int phstate;
    /* Inact out state */
    int inactstate; 
};

/* Function declarations */
/* Function to print testcase options(print member values of
 * pwm_testparams structure) */
void print_pwm_test_params();

/*Device node for Instance 0*/
#define PWM_INSTANCE0   "/dev/davinci_pwm0"
/*Device node for Instance 1*/
#define PWM_INSTANCE1   "/dev/davinci_pwm1"
/*Device node for Instance 2*/
#define PWM_INSTANCE2   "/dev/davinci_pwm2"
/*Device node for Instance 3*/
#define PWM_INSTANCE3   "/dev/davinci_pwm3"

/* Device instance number mappings */
#define INSTANCE0 0
#define INSTANCE1 1
#define INSTANCE2 2
#define INSTANCE3 3

/* PWM modes */
#define ST_PWM_CONTINUOUS_MODE PWM_CONTINUOUS_MODE
#define ST_PWM_ONESHOT_MODE PWM_ONESHOT_MODE

/*Default settings */
#define DEFAULT_NODE PWM_INSTANCE0
#define DEFAULT_MODE ST_PWM_CONTINUOUS_MODE
#define DEFAULT_PERIOD 100
#define DEFAULT_DURATION 50
#define DEFAULT_RPT_VAL 10
#define DEFAULT_PH_STATE 0
#define DEFAULT_INACT_OUT_STATE 0

/* Return values */
#define SUCCESS 0
#define FAILURE -1
#define DEVICE_NOT_SUPPORTED -2

/* Status codes */
#define TRUE 1
#define FALSE 0

#endif /* _ST_COMMON_H_ */

/* vim: set ts=4 sw=4 tw=80 et:*/

