/*
 * st_pwm_parser.c 
 *
 * This file contains code to parse the command line options and invoke test
 *  cases appropriately
 *
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/ 
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/

/*  File Name :   

 
    (C) Copyright 2008, Texas Instruments, Inc

    @author     Prathap.M.S 
    @version    0.1 - Created

 */ 

/* Generic header files */

#define __USE_GNU

/* Test case common header file */
#include "st_pwm_common.h"

#define DEFAULT_STABILITY_COUNT 1000

/* Default values related to test */
char *testcaseid = "PWMTests";
char *testname = "Functionality";

/* Test case options structure */
extern struct pwm_testparams testoptions;

/* This is to indicate if its a special test */
int othertests=0;

/*Function to display test suite version */
void display_pwm_testsuite_version();


/****************************************************************************
 * Function             - process_pwm_test_options 
 * Functionality        - This function parses the command line options and vallues passed for the options
 * Input Params         -  argc,argv
 * Return Value         -  None
 * Note                 -  None
 ****************************************************************************/
static void process_pwm_test_options(int argc, char *argv[])
{
    int error=FALSE;
    int version=FALSE;
    int help = FALSE;
    int othertests = FALSE;
    int stabilitycount = DEFAULT_STABILITY_COUNT;
    for (;;) {
        int option_index = 0;
        /** Options for getopt - New test case options added need to be
         * populated here*/
        static struct option long_options[] = {
            {"devicenode", optional_argument, NULL, 'd'},
            {"mode", optional_argument, NULL, 'm'},
            {"period", optional_argument, NULL, 'I'},
            {"duration", optional_argument, NULL, 'i'},
            {"rptval", optional_argument, NULL, 'r'},
            {"inactstate", optional_argument, NULL, 's'},
            {"phasestate", optional_argument, NULL, 'p'},
            {"stabilitycount", optional_argument, NULL, 'n'},
            {"testcaseid", optional_argument, NULL, 't'},
            {"testname", optional_argument, NULL, 'T'},
            {"version", no_argument, NULL, 'v'},
            {"help", no_argument, NULL, '?'},
            {NULL, 0, NULL, 0}
        };
        int c = getopt_long (argc, argv, "d:m:I:i:r:s:p:n:t:T::v?",
                long_options, &option_index);
        if (c == -1)
        {
            break;
        }
        switch (c) {
            case 'd':  
                if(optarg != NULL)
                {
                    testoptions.devnode = optarg;
                }
                else if(optind<argc && argv[optind])
                {
                    testoptions.devnode = argv[optind];
                }
                break;
            case 'm':  
                if(optarg != NULL)
                {
                    testoptions.mode = atoi(optarg);
                }
                else if(optind<argc && argv[optind])
                {
                    testoptions.mode = atoi(argv[optind]);
                }
                break;
            case 'I':  
                if(optarg != NULL)
                {
                    testoptions.period = atoi(optarg);
                }
                else if(optind<argc && argv[optind])
                {
                    testoptions.period = atoi(argv[optind]);
                }
                break;
            case 'i':  
                if(optarg != NULL)
                {
                    testoptions.duration = atoi(optarg);
                }
                else if(optind<argc && argv[optind])
                {
                    testoptions.duration = atoi(argv[optind]);
                }
                break;
            case 'r':  
                if(optarg != NULL)
                {
                    testoptions.rptval = atoi(optarg);
                }
                else if(optind<argc && argv[optind])
                {
                    testoptions.rptval = atoi(argv[optind]);
                }
                break;
            case 's' : 
                if(optarg != NULL)
                {
                    testoptions.inactstate = atoi(optarg);
                }
                else if(optind<argc && argv[optind])
                {
                    testoptions.inactstate  = atoi(argv[optind]);
                }
                break;
            case 'p' : 
                if(optarg != NULL)
                {
                    testoptions.phstate = atoi(optarg);
                }
                else if(optind<argc && argv[optind])
                {
                    testoptions.phstate  = atoi(argv[optind]);
                }
                break;
            case 'n' : 
                if(optarg != NULL)
                {
                    stabilitycount = atoi(optarg);
                }
                else if(optind<argc && argv[optind])
                {
                    stabilitycount  = atoi(argv[optind]);
                }
                break;
            case 't' : 
                if(optarg != NULL)
                { 
                    testcaseid=optarg;
                }
                else if(optind<argc && argv[optind])
                {
                    testcaseid = argv[optind];
                }
                break;
            case 'T' : 
                if(optarg != NULL)
                { 
                    testname=optarg;
                }
                else if(optind<argc && argv[optind])
                {
                    testname = argv[optind];
                }
                othertests = TRUE;
                break;
            case 'v' : 
                display_pwm_testsuite_version();
                version= TRUE;
                break;
            case '?': 
                help = TRUE; break;

        }
    }
    /* If any error in usage, values provided for options, display help to user*/ 
    if (help == TRUE)
    {
        display_pwm_test_suite_help();
    }

    if(version != TRUE && help !=TRUE)
    {       
        print_pwm_test_params(&testoptions,testcaseid);
        if(othertests == TRUE)
        {
            if(strcmp(testname,"stability") == SUCCESS)
            {
                st_pwm_stability_test(&testoptions,testcaseid,stabilitycount);
            }
            else if(strcmp(testname,"api") == SUCCESS)
            {
                st_pwm_api_test(&testoptions,testcaseid);
            }
            else
            {
                printf("Test not supported\n");
            } 

        }
        else 
        {
            st_pwm_test(&testoptions,testcaseid);            
        }  

    }
}

/****************************************************************************
 * Function             - display_pwm_testsuite_version
 * Functionality        - This function displays the test suite version
 * Input Params         - None 
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/
void display_pwm_testsuite_version()
{
    printf("pwmDisplayTestSuite V %s\n", VERSION_STRING);
}

/****************************************************************************
 * Function             - Main function
 * Functionality        - This is where the execution begins
 * Input Params         - argc,argv
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/
int main(int argc, char **argv)
{
    /* Initialize options with default vales */	
    init_pwm_test_params();
    /* Invoke the parser function to process the command line options */
    process_pwm_test_options(argc, argv);
    return 0;
}
/* vi: set ts=4 sw=4 tw=80 et:*/

