/*
 * st_pwm_api_test.c 
 *
 * This file contains code to test APIs, ioctls supported by PWM driver
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/ 
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/


/* function prototypes for interface functions are defined here*/
#include "st_pwm_common.h"

/****************************************************************************
 * Function             - st_pwm_api_test
 * Functionality        - Function to test PWM driver supported APIs,ioctls
 * Input Params         - pwm_testparams structure,  test case id.
 * Return Value         - None.
 * Note                 - None
 ****************************************************************************/
void st_pwm_api_test(struct pwm_testparams *testoptions,  char* test_id)
{

    int retVal = SUCCESS;
    int status = SUCCESS;
    int i = 0,st_dev =0;

    /* Retrieving test case options values */
    int mode = testoptions->mode;
    int period = testoptions->period;
    int duration = testoptions->duration;
    int rptval = testoptions->rptval; 
    int phstate = testoptions->phstate;
    int inactstate = testoptions->inactstate;

    /* variables to track device open/close state */ 
    Bool openStatus = FALSE;


    /* Get device number for a device string to avoid further string operations */
    st_pwm_set_device_number(testoptions->devnode, &st_dev);

    do
    {  
        /* open PWM device */
        retVal = st_pwm_open_interface(st_dev);
        if (SUCCESS != retVal)
        {
            if(DEVICE_NOT_SUPPORTED == retVal)
            {
                DBG_PRINT_ERR(("This device node/instance is not supported on this platform"));
                status = FAILURE;
                break;
            }
            else
            {
                DBG_PRINT_ERR(("Failed to open PWM device instance %d ",st_dev));
                status = FAILURE;  
                break;
            }
        }

        openStatus = TRUE; // device is opened
        DBG_PRINT_TRC0(("PWM device instance %d  opened ", st_dev));

        /* Set mode */
        retVal = st_pwm_set_mode_interface(mode);
        if (SUCCESS != retVal)
        {
            DBG_PRINT_ERR(("Set mode Ioctl Failed "));
            status = FAILURE;
            break;
        }
        DBG_PRINT_TRC0(("Set mode Ioctl Passed ")); 

        /* Set period */ 
        retVal = st_pwm_set_period_interface(period); 
        if (SUCCESS != retVal)
        {
            DBG_PRINT_ERR(("Set Period Ioctl Failed "));
            status = FAILURE;
            break;
        }
        DBG_PRINT_TRC0(("Set Period Ioctl Passed "));

        /*Set pulse width duration */ 
        retVal = st_pwm_set_duration_interface(duration); 
        if (SUCCESS != retVal)
        {
            DBG_PRINT_ERR(("Set Duration Ioctl failed "));
            status = FAILURE;
            break;
        }
        DBG_PRINT_TRC0(("Set Duration Ioctl Passed "));

        /* Set phase state */ 
        retVal = st_pwm_set_phase_state_interface(phstate); 
        if (SUCCESS != retVal)
        {
            DBG_PRINT_ERR(("Set phase state Ioctl Failed "));
            status = FAILURE;
            break;
        }
        DBG_PRINT_TRC0(("Set phase state Ioctl Passed "));

        /* Set inact out state */ 
        retVal = st_pwm_set_inact_out_state_interface(inactstate); 
        if (SUCCESS != retVal)
        {
            DBG_PRINT_ERR(("Set inact out state Ioctl Failed "));
            status = FAILURE;
            break;
        }
        DBG_PRINT_TRC0(("Set inact out state Ioctl Passed "));
        /*Start PWM */ 
        retVal = st_pwm_start_interface(); 
        if (SUCCESS != retVal)
        {
            DBG_PRINT_ERR(("Start Ioctl failed "));
            status = FAILURE;
            break;
        }
        DBG_PRINT_TRC0(("Start Ioctl Passed "));

        /*Stop PWM */ 
        retVal = st_pwm_stop_interface(); 
        if (SUCCESS != retVal)
        {
            DBG_PRINT_ERR(("Stop Ioctl failed "));
            status = FAILURE;
            break;
        }
        DBG_PRINT_TRC0(("Stop Ioctl Passed "));

        /* close device if opened */
        if (TRUE == openStatus)
        {
            /* close PWM device */
            retVal = st_pwm_close_interface();
            if (SUCCESS != retVal)
            {
                DBG_PRINT_ERR(("PWM device instance %d could not be closed ",st_dev));
                status = FAILURE;
                break;
            } 

            openStatus = FALSE; // device is closed

            DBG_PRINT_TRC0(("PWM device instance %d closed sucessfully ",st_dev));
            DBG_PRINT_TRC0(("PWM Test complete "));
        }
        break;

    }while(SUCCESS != retVal);

    /* print status/result of the test case */
    if (FAILURE == status)
    {
        DBG_PRINT_TST_RESULT_FAIL((test_id));
    }
    else
    {
        DBG_PRINT_TST_RESULT_PASS((test_id));
    }
    /* end test case */
    DBG_PRINT_TST_END((test_id));	

    return;

}

/* vim: set ts=4 sw=4 tw=80 et:*/


