# omap35x_resizer_sample_usage_script


#Prints the usage/help
./OMAP35x_resizer_tests --help

#Prints the version
./OMAP35x_resizer_tests -v

#Runs the default resize (from in.yuv with w=640, h=480 to out.yuv with W=320, H=240)
./OMAP35x_resizer_tests 

#Run the resizer upscaling test to upscale in.yuv to W = 1280, H = 720
./OMAP35x_resizer_tests -W 1280 -H 720

#Run the resizer downscaling test on in.yuv and let the output file be called OUTPUT.yuv 
./OMAP35x_resizer_tests -i in.yuv -w 640 -h 480 -o OUTPUT.yuv -W 300 -H 200

# -d stands for device node. Can be passed as command line option as shown below.
./OMAP35x_resizer_tests -d /dev/omap-resizer

