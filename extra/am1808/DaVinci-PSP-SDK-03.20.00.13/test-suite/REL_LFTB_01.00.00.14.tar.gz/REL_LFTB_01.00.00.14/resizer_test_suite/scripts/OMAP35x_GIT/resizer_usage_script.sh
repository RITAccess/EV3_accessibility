#   ============================================================================
#   @file   omap35x_git_resizer_sample_usage_script
#
#   @desc   This script contains some sample usage of resizer test suite on omap35x_git platform
#
#   ============================================================================


#Prints the usage/help
./resizer_tests --help

#Prints the version
./resizer_tests -v

#Runs the default resize (from in.yuv with w=640, h=480 to out.yuv with W=320, H=240)
echo "Running resizer tests. All tests are file based. Require a YUV422 file as input and then resize it and write to output file"
echo "Tests to downscale input file(assumes default filename as in.yuv and that should be present in the current working directory)"
./resizer_tests -t Resizer_downscale_0.5x_test

#Run the resizer upscaling test to upscale in.yuv to W = 1280, H = 960
./resizer_tests -W 1280 -H 960 -t Resizer_upscale_2x_test

#Run the resizer downscaling test on in.yuv and let the output file be called OUTPUT.yuv 
./resizer_tests -i in.yuv -o OUTPUT.yuv -t Resizer_tests_downscale_file_command_line

#Run the resizer downscaling test on in.yuv and let the output file be calLed OUTPUT.yuv
echo "Running Resizer tests with different scaling ratios"
./resizer_tests  -W 1280 -H 720 -o OUTPUT_1_1280x720.yuv -t Resizer_tests_upscale 
./resizer_tests  -W 320 -H 240 -o OUTPUT_320x240.yuv -t Resizer_tests_downscale
./resizer_tests  -W 160 -H 120 -o OUTPUT_160x120.yuv -t Resizer_tests_downscale_0.25x
./resizer_tests  -i OUTPUT_160x120.yuv  -W 640 -H 480 -o OUTPUT_VGA.yuv -t Resizer_tests_upscale_4x
./resizer_tests  -W 640 -H 480 -o OUTPUT_VGA.yuv -t Resizer_tests_upscale_1x
./resizer_tests  -W 640 -H 240 -o OUTPUT_640x240.yuv -t Resizer_tests_downscale_vertical_only
./resizer_tests  -W 320 -H 480 -o OUTPUT_320x480.yuv -t Resizer_tests_downscale_horizontal_only
./resizer_tests  -W 1280 -H 480 -o OUTPUT_1280x480.yuv -t Resizer_tests_upscale_horizontal_only
./resizer_tests  -W 640 -H 960 -o OUTPUT_640x960.yuv -t Resizer_tests_upscale_vertical_only

#Run the Performance test
echo "Running Performance tests. The resize time and cpu load are printed"
./resizer_tests -i OUTPUT_160x120.yuv  -W 640 -H 480 -o OUTPUT_VGA.yuv -p -l -t Resizer_Throughput_cpu_load_tests_upscale_4x
./resizer_tests  -W 160 -H 120 -o OUTPUT_160x120.yuv -p -l -t Resizer_Throughput_cpu_load_tests_downscale_0.25x

# -d stands for device node. to test the ioctl tests.
./resizer_tests -d /dev/omap-resizer -T ioctl -t Resizer_ioctl_tests

# -d stands for device node. to test the ioctl tests.
./resizer_tests -d /dev/omap-resizer -c 10 -t Resizer_tests_n_times

#For user pointer technique
./resizer_tests -u
