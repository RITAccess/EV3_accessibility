/*
 * st_resizer_interface.c
 *
 * This file calls Resizer driver functions and takes parameters given from testcase functions.
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/

 /* Resizer structs, enums, macros defined */
#include "st_resizer_common.h"

struct st_rsz_reqbufs reqbufs, reqoutbufs;
struct st_rsz_buffer buf;
struct st_rsz_resize rsz;
char *in_buf = 0;
char *out_buf = 0;
struct st_rsz_params params;
int readexp;
/****************************************************************************
 * Function             - st_resizer_output_file_write_interface
 * Functionality        - This function copies the output image to output file
 * Input Params         - Output image dimensions
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/
void st_resizer_output_file_write_interface(int out_w, int out_h) {
	int ret_val;

	ret_val = fwrite(out_buf, ONE, out_w * out_h*TWO, out_data);

}



/****************************************************************************
 * Function             - st_resizer_resize_interface
 * Functionality        - This function resizes the input image
 * Input Params         - None
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/
int st_resizer_resize_interface(void) {
	rsz.in_buf.index = -1;
	rsz.out_buf.index = -1;
	rsz.in_buf.size = test_options.in_height * test_options.in_width*TWO;
	rsz.out_buf.size = test_options.out_height * test_options.out_width*TWO;

	if (ioctl(fd_rsz, RSZ_RESIZE, &rsz) == FAILURE) {
		return FAILURE;
	}

	return SUCCESS;
}

/****************************************************************************
 * Function             - st_resizer_queue_buf_interface
 * Functionality        - This function queues the buffers
 * Input Params         - None
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/
int st_resizer_queue_buf_interface(void) {
	return MODE_NOT_SUPPORTED;
}

/****************************************************************************
 * Function             - st_resizer_input_file_read_interface
 * Functionality        - This function copies the input file to input buffer
 * Input Params         - None
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/
int st_resizer_input_file_read_interface(void) {
	int sizeimage, ret_val;

	sizeimage = params.in_hsize*params.in_vsize*TWO;

	ret_val = fread(in_buf, ONE, sizeimage, in_data);
	if (ret_val != sizeimage)
		return FAILURE;
	return SUCCESS;
}


/****************************************************************************
 * Function             - st_resizer_query_mmap_interface
 * Functionality        - This function queries and memory maps the buffers
 * Input Params         - None
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/
int st_resizer_query_mmap_interface(void) {
	/* getting physical address for mmap */
	buf.buf_type = ST_RSZ_BUF_IN;
	buf.index = ZERO;
	if (ioctl(fd_rsz, RSZ_QUERYBUF, &buf) == FAILURE) {
		return FAILURE;
	}

	rsz.in_buf.offset = buf.offset;

	in_buf = (char *)mmap(0,
		test_options.in_height * test_options.in_width*TWO, PROT_READ | PROT_WRITE,
		MAP_SHARED, fd_rsz, buf.offset);

	if (in_buf == MAP_FAILED) {
		return FAILURE;
	}

	/* map the output buffers to user space */
	buf.buf_type = ST_RSZ_BUF_OUT;
	buf.index = ZERO;
	if (ioctl(fd_rsz, RSZ_QUERYBUF, &buf) == FAILURE) {
		return FAILURE;
	}
	rsz.out_buf.offset = buf.offset;


	out_buf = (char *)mmap(0,
		test_options.out_height * test_options.out_width*TWO, PROT_READ | PROT_WRITE,
		MAP_SHARED, fd_rsz, buf.offset);
	if (out_buf == MAP_FAILED) {
		return FAILURE;
	}

	return SUCCESS;
}

/****************************************************************************
 * Function             - st_resizer_request_buf_interface
 * Functionality        - This function requests for buffers
 * Input Params         - None
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/
int st_resizer_request_buf_interface(void) {
	/* allocating the memory to input buffer */
	reqbufs.buf_type = ST_RSZ_BUF_IN;
	reqbufs.size = test_options.in_height * test_options.in_width*TWO;

	reqbufs.count = ONE;

	if (ioctl(fd_rsz, RSZ_REQBUF, &reqbufs) == FAILURE)
		return FAILURE;

	/* allocating the memory to output buffer */
	reqoutbufs.buf_type = ST_RSZ_BUF_OUT;
	reqoutbufs.size = test_options.out_height * test_options.out_width*TWO;
	reqoutbufs.count = ONE;

	if (ioctl(fd_rsz, RSZ_REQBUF, &reqoutbufs) == FAILURE)
		return FAILURE;

	return SUCCESS;
}

/****************************************************************************
 * Function             - st_resizer_set_expand_register_interface
 * Functionality        - This function sets the read cycle expand register
 * Input Params         - None
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/
int st_resizer_set_expand_register_interface(void) {
	return MODE_NOT_SUPPORTED;
}

/****************************************************************************
 * Function             - st_resizer_set_params_interface
 * Functionality        - This function sets the resizer parameters
 * Input Params         - Input file dimensions and output file dimensions
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/
int st_resizer_set_params_interface(int in_w, int in_h, int out_w, int out_h, int in_pitch, int out_pitch) 
{

    int i;

	test_options.in_height = in_h;
	test_options.in_width = in_w;
	test_options.out_height = out_h;
	test_options.out_width = out_w;

	params.in_hsize = in_w;
	params.in_vsize = in_h;	/* only 1 filed of NTSC image */
	params.in_pitch = in_w*TWO;
	params.cbilin = ZERO;	/* filter with luma for low pass */
	params.pix_fmt = FMT_UYVY;
	params.out_hsize = out_w;
	params.out_vsize = out_h;
	params.out_pitch = out_w*TWO;
	params.vert_starting_pixel = ZERO;
	params.horz_starting_pixel = ZERO;
	params.inptyp = ST_RSZ_INTYPE_YCBCR422_16BIT;
	params.hstph = ZERO;
	params.vstph = ZERO;
	params.yenh_params.type = ZERO;
	params.yenh_params.gain = ZERO;
	params.yenh_params.slop = ZERO;
	params.yenh_params.core = ZERO;

	for (i = ZERO; i < RDRV_RESZ_SPEC__MAX_FILTER_COEFF; i++)
		params.hfilt_coeffs[i] = gRDRV_resz_filter_4tap_high_quality[i];

	for (i = ZERO; i < RDRV_RESZ_SPEC__MAX_FILTER_COEFF; i++)
		params.vfilt_coeffs[i] = gRDRV_resz_filter_4tap_high_quality[i];

	if (ioctl(fd_rsz, RSZ_S_PARAM, &params) == FAILURE) {
		return FAILURE;
	}
	return SUCCESS;
}

/****************************************************************************
 * Function             - st_resizer_test_suite_help
 * Functionality        - This function displays the help/usage
 * Input Params         - None
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/
void st_resizer_test_suite_help(void) {
	printf("resizerTestSuite V %s\n", VERSION_STRING);
	printf("Usage:\n"
           "./DM644x_resizer_tests <options>\n\n"
           "-d	--devicenode		Resizer device node\n"
           "\t\t\t\tPossible values-/dev/omap-resizer\n"
           "-i	--inputfile		Name of input file ('in.yuv' by default)\n"
           "-w	--inputwidth		Width of input file (640 by default)\n"
           "-h	--inputheight		Height of input file (480 by default)\n"
           "-o	--outputfile		Name of output file ('out.yuv' by default)\n"
           "-W	--outputwidth		Width of output file (320 by default)\n"
           "-H	--outputheight	Height of output file (240 by default)\n"
           "-?	--help			Displays the help/usage\n"
           "-v	--version		Version of Resizer Test suite\n\n"
           "Please make sure to check the resize ratio to be between 1/4x to 4x,\n"
           "where x = output dimension/input dimension\n\n");
	exit(0);
}

/****************************************************************************
 * Function             - st_resizer_set_cycle_interface
 * Functionality        -
 * Input Params         - None
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/
int st_resizer_set_cycle_interface(void) {
	return SUCCESS;
}

/****************************************************************************
 * Function             - st_resizer_get_status_interface
 * Functionality        -
 * Input Params         - struct rsz_status
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/
int st_resizer_get_status_interface() {
	return SUCCESS;
}
/****************************************************************************
 * Function             - st_resizer_get_param_interface
 * Functionality        - struct rsz_params
 * Input Params         - None
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/
int st_resizer_get_param_interface(struct rsz_params *g_params) {
	return SUCCESS;
}
/****************************************************************************
 * Function             - st_resizer_query_mmap_userptr_interface
 * Functionality        - This function queries and memory maps the buffers
 * Input Params         - None
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/
int st_resizer_query_mmap_userptr_interface(void) {


        return SUCCESS;
}



/****************************************************************************
 * Function             - st_resizer_request_buf_userptr_interface
 * Functionality        - This function requests for buffers
 * Input Params         - None
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/
int st_resizer_request_buf_userptr_interface(void) {

        return SUCCESS;
}

/* vi: set ts=4 sw=4 tw=80 et:*/
