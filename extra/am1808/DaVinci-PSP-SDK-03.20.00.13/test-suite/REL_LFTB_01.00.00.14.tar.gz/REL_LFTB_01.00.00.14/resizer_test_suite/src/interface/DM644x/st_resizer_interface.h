/*
 * st_resizer_interface.h
 *
 * This file abstracts resizer driver structures, macros and enums
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/ 
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/

#ifndef _ST_RESIZER_INTERFACE_H_
#define _ST_RESIZER_INTERFACE_H_

/* Generic header files */
#include <stdio.h>
#include <getopt.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <asm/types.h>
#include <sys/stat.h>

/* Resizer specific header files */
#include <asm-arm/arch-davinci/davinci_resizer.h>

#define RSZ_DRIVER	"/dev/davinci_resizer"
#define ST_RSZ_BUF_IN RSZ_BUF_IN
#define ST_RSZ_BUF_OUT RSZ_BUF_OUT

/*Wrapper for driver structure rsz_reqbufs*/ 
struct st_rsz_reqbufs {
	int buf_type;		/* type of frame buffer */
	int size;		/* size of the frame bufferto be allocated */
	int count;		/* number of frame buffer to be allocated */
};

/*Wrapper for driver structure rsz_buffer*/ 
struct st_rsz_buffer {
	int index;		/* buffer index number, 0 -> N-1 */
	int buf_type;		/* buffer type, input or output */
	int offset;		/* physical     address of the buffer,
				   used in the mmap() system call */
	int size;
};

/*Wrapper for driver structure rsz_resize*/ 
struct st_rsz_resize {
	struct st_rsz_buffer in_buf;
	struct st_rsz_buffer out_buf;
};

/*Wrapper for driver structure rsz_params*/
struct st_rsz_params {
	int in_hsize;		/* input frame horizontal size */
	int in_vsize;		/* input frame vertical size */
	int in_pitch;		/* offset between two rows of input frame */
	int inptyp;		/* for determining 16 bit or 8 bit data */
	int vert_starting_pixel;	/* for specifying vertical
					   starting pixel in input */
	int horz_starting_pixel;	/* for specyfing horizontal
					   starting pixel in input */
	int cbilin;		/* # defined, filter with luma or bi-linear
				   interpolation */
	int pix_fmt;		/* # defined, UYVY or YUYV */
	int out_hsize;		/* output frame horizontal size */
	int out_vsize;		/* output frame vertical size */
	int out_pitch;		/* offset between two rows of output frame */
	int hstph;		/* for specifying horizontal starting phase */
	int vstph;		/* for specifying vertical starting phase */
	short hfilt_coeffs[32];	/* horizontal filter coefficients */
	short vfilt_coeffs[32];	/* vertical filter coefficients */
	rsz_yenh_t yenh_params;	
};

#endif 	/* _ST_V4L2_CAPTURE_INTERFACE_H_ */



/* vi: set ts=4 sw=4 tw=80 et:*/
