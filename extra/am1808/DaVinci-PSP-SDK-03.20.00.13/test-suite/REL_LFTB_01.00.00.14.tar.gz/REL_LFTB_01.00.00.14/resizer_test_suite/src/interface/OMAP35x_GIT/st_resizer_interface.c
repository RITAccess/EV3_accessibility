/*
 * st_resizer_interface.c
 *
 * This file calls Resizer driver functions and takes parameters given from testcase functions.
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/

 /* Resizer structs, enums, macros defined */
#include "st_resizer_common.h"
#include <linux/fb.h>
struct st_rsz_params params;
struct st_v4l2_requestbuffers reqbuf;
struct st_v4l2_buffer buffer;
int readexp;
/****************************************************************************
 * Function             - st_resizer_output_file_write_interface
 * Functionality        - This function copies the output image to output file
 * Input Params         - Output image dimensions
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/
void st_resizer_output_file_write_interface(int out_w, int out_h) {
	int ret_val;
    ret_val = fwrite(out_start, ONE, out_w * out_h * TWO,   out_data);
}

/****************************************************************************
 * Function             - st_resizer_resize_interface
 * Functionality        - This function resizes the input image
 * Input Params         - None
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/
int st_resizer_resize_interface(void) {
	int ret_val;

	ret_val = ioctl(fd_rsz, RSZ_RESIZE, NULL);
	if (ret_val)
		return FAILURE;

	return SUCCESS;
}

/****************************************************************************
 * Function             - st_resizer_set_cycle_interface
 * Functionality        -
 * Input Params         - None
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/
int st_resizer_set_cycle_interface(void) {
	int ret_val;
    int read_exp = readexp;

	ret_val = ioctl(fd_rsz, RSZ_S_EXP,&read_exp);
	if (ret_val)
	{
		perror("RSZ_S_EXP");
		return FAILURE;
	}

	return SUCCESS;
}

/****************************************************************************
 * Function             - st_resizer_get_status_interface
 * Functionality        -
 * Input Params         - struct rsz_status
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/
int st_resizer_get_status_interface() {
	int ret_val;
    struct rsz_status gstatus;

	ret_val = ioctl(fd_rsz, RSZ_G_STATUS,&gstatus);
	if (ret_val)
	{
		perror("RSZ_G_STATUS");
		return FAILURE;
	}

    DBG_PRINT_TRC0(("Channel status - %d",gstatus.chan_busy)) ;
    DBG_PRINT_TRC0(("Busy status - %d", gstatus.hw_busy)) ;
    DBG_PRINT_TRC0(("Src - %d",  gstatus.src));

	return SUCCESS;
}
/****************************************************************************
 * Function             - st_resizer_get_param_interface
 * Functionality        - struct rsz_params
 * Input Params         - None
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/
int st_resizer_get_param_interface(struct rsz_params *g_params) {
	int ret_val = SUCCESS;
        // int i;
    struct st_rsz_params params;

	ret_val = ioctl(fd_rsz,RSZ_G_PARAM,&params);
    DBG_PRINT_TRC0(("Return value - %d",ret_val));
	if (ret_val)
	{
		perror("RSZ_G_PARAM");
		return FAILURE;
	}
    DBG_PRINT_TRC0(("Input height - %d",params.in_hsize)) ;
    DBG_PRINT_TRC0(("Input width - %d",params.in_vsize)) ;
    DBG_PRINT_TRC0(("Output height - %d",params.out_hsize)) ;
    DBG_PRINT_TRC0(("Output width - %d",params.out_vsize)) ;
    DBG_PRINT_TRC0(("Input pitch - %d",params.in_pitch)) ;
    DBG_PRINT_TRC0(("Output pitch - %d",params.out_pitch)) ;

    return SUCCESS;
}
/****************************************************************************
 * Function             - st_resizer_queue_buf_interface
 * Functionality        - This function queues the buffers
 * Input Params         - None
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/
int st_resizer_queue_buf_interface(void) {
	buffer.type = reqbuf.type;
	buffer.memory = reqbuf.memory;
	buffer.index = ZERO;
	buffer.m.userptr = (unsigned int)in_start;

	if (ioctl(fd_rsz, RSZ_QUEUEBUF, &buffer) < SUCCESS)
	{
		perror("RSZ_QUEUEBUF");
		return FAILURE;
	}

	buffer.index = ONE;
	buffer.m.userptr = (unsigned int)out_start;

	if (ioctl(fd_rsz, RSZ_QUEUEBUF, &buffer) < SUCCESS)
	{
		perror("RSZ_QUEUEBUF");
		return FAILURE;
	}

	return SUCCESS;
}

/****************************************************************************
 * Function             - st_resizer_input_file_read_interface
 * Functionality        - This function copies the input file to input buffer
 * Input Params         - None
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/
int st_resizer_input_file_read_interface(void) {
	int sizeimage;
    //int ret_val;

	sizeimage = params.in_hsize*params.in_vsize*TWO;
//	ret_val = fread(in_start, ONE, sizeimage, in_data);
    colorbar_generate(in_start, params.in_hsize, params.in_vsize, 0);
    return SUCCESS;
}

/****************************************************************************
 * Function             - st_resizer_query_mmap_interface
 * Functionality        - This function queries and memory maps the buffers
 * Input Params         - None
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/
int st_resizer_query_mmap_interface(void) {
	int ret_val;
	buffer.type = reqbuf.type;
	buffer.memory = reqbuf.memory;
	buffer.index = ZERO;
        ret_val = ioctl (fd_rsz, RSZ_QUERYBUF, &buffer);
	if (ret_val < SUCCESS)
	{
		perror("RSZ_QUERYBUF");
		return FAILURE;
	}

	in_start = mmap(NULL, buffer.length, PROT_READ |PROT_WRITE, MAP_SHARED,
		fd_rsz, buffer.m.offset);
	if (MAP_FAILED == in_start)
		return FAILURE;

	buffer.index = ONE;
	ret_val = ioctl (fd_rsz, RSZ_QUERYBUF, &buffer);
	if (ret_val)
	{
		perror("RSZ_QUERYBUF");
		return FAILURE;
	}

	out_start = mmap(NULL, buffer.length, PROT_READ | PROT_WRITE, MAP_SHARED,
		fd_rsz, buffer.m.offset);
	if (MAP_FAILED == out_start)
		return FAILURE;

	return SUCCESS;
}

/****************************************************************************
 * Function             - st_resizer_query_mmap_userptr_interface
 * Functionality        - This function queries and memory maps the buffers
 * Input Params         - None
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/
int st_resizer_query_mmap_userptr_interface(void) {
        int ret_val;
        buffer.type = reqbuf.type;
        buffer.memory = reqbuf.memory;
        buffer.index = ZERO;

        ret_val = ioctl (fd_rsz, RSZ_QUERYBUF, &buffer);
        if (ret_val < SUCCESS)
		{
			perror("RSZ_QUERYBUF");
			return FAILURE;
		}



        in_start = (char *)(buffer_addr);

        buffer.index = ONE;
        ret_val = ioctl (fd_rsz, RSZ_QUERYBUF, &buffer);
        if (ret_val)
		{
			perror("RSZ_QUERYBUF");
			return FAILURE;
		}

        out_start = (char *)(buffer_addr + in_imgsize);

        return SUCCESS;
}

/****************************************************************************
 * Function             - st_resizer_request_buf_interface
 * Functionality        - This function requests for buffers
 * Input Params         - None
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/
int st_resizer_request_buf_interface(void) {
	int ret_val;

	reqbuf.type = ST_V4L2_BUF_TYPE_VIDEO_CAPTURE;
	reqbuf.memory = ST_V4L2_MEMORY_MMAP;
	reqbuf.count = TWO;

	ret_val = ioctl (fd_rsz, RSZ_REQBUF, &reqbuf);
	if (ret_val < SUCCESS)
		{
			perror("RSZ_REQBUF");
			return FAILURE;
		}
	return SUCCESS;
}

/****************************************************************************
 * Function             - st_resizer_request_buf_userptr_interface
 * Functionality        - This function requests for buffers
 * Input Params         - None
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/
int st_resizer_request_buf_userptr_interface(void) {
        int ret_val;

        DBG_PRINT_TRC0(("in_imgsize = %lu",in_imgsize));
        DBG_PRINT_TRC0(("out_imgsize = %ld",out_imgsize));
        buffer_addr = (unsigned long)mmap((void *)0, (in_imgsize + out_imgsize), (PROT_READ |PROT_WRITE), MAP_SHARED, fb_fd, 0);
        if ((unsigned long)MAP_FAILED == buffer_addr)
                return FAILURE;

        memset((void *)buffer_addr, 0, (in_imgsize + out_imgsize));

        reqbuf.type = ST_V4L2_BUF_TYPE_VIDEO_CAPTURE;
        reqbuf.memory = ST_V4L2_MEMORY_USERPTR;
        reqbuf.count = TWO;

        ret_val = ioctl (fd_rsz, RSZ_REQBUF, &reqbuf);
        if (ret_val < SUCCESS)
        {
			perror("RSZ_REQBUF");
			return FAILURE;
		}
        return SUCCESS;
}

/****************************************************************************
 * Function             - st_resizer_set_expand_register_interface
 * Functionality        - This function sets the read cycle expand register
 * Input Params         - None
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/
int st_resizer_set_expand_register_interface(void) {
	return MODE_NOT_SUPPORTED;
}

/****************************************************************************
 * Function             - st_resizer_set_params_interface
 * Functionality        - This function sets the resizer parameters
 * Input Params         - Input file dimensions and output file dimensions
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/
int st_resizer_set_params_interface(int in_w, int in_h, int out_w, int out_h,
        int in_pitch, int out_pitch) {
	int i, ret_val;

        struct fb_fix_screeninfo fixinfo;
        struct fb_var_screeninfo varinfo;

        fb_fd = open(FBDEV, O_RDWR);
        if(fb_fd <= 0)
                return FAILURE;
	ret_val = ioctl(fb_fd, FBIOGET_FSCREENINFO, &fixinfo);
	if (ret_val < 0)
    {
		perror("FBIOGET_FSCREENINFO");
		return FAILURE;
	}
	ret_val = ioctl(fb_fd, FBIOGET_VSCREENINFO, &varinfo);
	if (ret_val < 0)
    {
		perror("FBIOGET_VSCREENINFO");
		return FAILURE;
	}

	params.in_hsize = in_w;
	params.in_vsize = in_h;
//	params.in_pitch = params.in_hsize * TWO;
    params.in_pitch = in_pitch;
    params.inptyp = ST_RSZ_INTYPE_YCBCR422_16BIT;
	params.vert_starting_pixel = ZERO;
	params.horz_starting_pixel = ZERO;
	params.cbilin = ZERO;
	params.pix_fmt = FMT;
	params.out_hsize = out_w;
	params.out_vsize = out_h;
//	params.out_pitch = params.out_hsize * TWO;
    params.out_pitch = out_pitch;
    params.hstph = ZERO;
	params.vstph = ZERO;

	for (i = ZERO; i < RDRV_RESZ_SPEC__MAX_FILTER_COEFF; i++)
		params.tap4filt_coeffs[i] = gRDRV_resz_filter_4tap_high_quality[i];

	for (i = ZERO; i < RDRV_RESZ_SPEC__MAX_FILTER_COEFF; i++)
		params.tap7filt_coeffs[i] = gRDRV_resz_filter_7tap_high_quality[i];

	params.yenh_params.type = ZERO;
	params.yenh_params.gain = ZERO;
	params.yenh_params.slop = ZERO;
	params.yenh_params.core = ZERO;

        in_imgsize = params.in_pitch * params.in_vsize;
        out_imgsize =  params.out_pitch * params.out_vsize;

	ret_val = ioctl(fd_rsz, RSZ_S_PARAM, &params);
	if (ret_val)
    {
		perror("RSZ_S_PARAM");
		return FAILURE;
	}
	return SUCCESS;
}

/****************************************************************************
 * Function             - st_resizer_test_suite_help
 * Functionality        - This function displays the help/usage
 * Input Params         - None
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/
void st_resizer_test_suite_help(void) {
	printf("resizerTestSuite V %s\n", VERSION_STRING);
	printf("Usage:\n"
           "./OMAP35x_GIT_resizer_tests <options>\n\n"
           "-d	--devicenode		Resizer device node\n"
           "\t\t\t\tPossible values-/dev/omap-resizer\n"
           "-i	--inputfile	     	Name of input file ('in.yuv' by default)\n"
           "-w	--inputwidth		Width of input file (640 by default)\n"
           "-h	--inputheight		Height of input file (480 by default)\n"
           "-p  --in_pitch          Input Pitch (default 640*480*2)\n"
           "-o	--outputfile		Name of output file ('out.yuv' by default)\n"
           "-W	--outputwidth		Width of output file (320 by default)\n"
           "-H	--outputheight		Height of output file (240 by default)\n"
           "-P  --out_pitch         Out Pitch (default 320*240*2)\n"
           "-r	--throughput		Displays the throughput info\n"
           "-u	--userpointer	    For userpointer technique\n"
           "-l 	--cpuload           Displays the cpuload info\n"
           "-T 	--test_name         Test for functions, currently supports value: ioctl(for IOCTL test, needs L and I values with it)\n"
           "-I  --ioctl_no       	Give IOCTL number for IOCTL test\n"
           "\t\t\t\t			    Possible values-0:RSZ_S_EXP, 1:RSZ_S_PARAM and RSZ_G_PARAM, 2:RSZ_G_STATUS\n"
           "-L  --loopcount  	    Loopcount for IOCTL test\n"
		   "-c  --readcycle  	    readcycle\n"
		   "-t  --testcaseid  	    testcaseid\n"
           "-?	--help			    Displays the help/usage\n"
           "-v	--version		    Version of Resizer Test suite\n\n"
           "Please make sure to check the resize ratio to be between 1/4x to 4x,\n"
           "where x = output dimension/input dimension\n\n");
	exit(0);
}

/* vi: set ts=4 sw=4 tw=80 et:*/
