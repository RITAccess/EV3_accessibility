/*
 * st_resizer_common.c
 *
 * This file contains the common functions definitions
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/

/* generic headers */

 /* Resizer structs, enums, macros defined */
#include "st_resizer_common.h"

/* Default values related to test */
char *testcase_id = "ResizerTests";
char *test_name = "Functionality";

/* This is to indicate if its a special test */
int other_tests = 0;

int status = SUCCESS;
int open_file = FALSE;
int open_device = FALSE;
static short ycbcr[8] = {
        (0x1F << 11) | (0x3F << 5) | (0x1F),
        (0x00 << 11) | (0x00 << 5) | (0x00),
        (0x1F << 11) | (0x00 << 5) | (0x00),
        (0x00 << 11) | (0x3F << 5) | (0x00),
        (0x00 << 11) | (0x00 << 5) | (0x1F),
        (0x1F << 11) | (0x3F << 5) | (0x00),
        (0x1F << 11) | (0x00 << 5) | (0x1F),
        (0x00 << 11) | (0x3F << 5) | (0x1F),
};

/* Test case options structure */
struct st_resizer_testparams test_options;

short gRDRV_resz_filter_4tap_high_quality[RDRV_RESZ_SPEC__MAX_FILTER_COEFF]= {
	0, 256, 0, 0, -6, 246, 16, 0, -7, 219, 44, 0, -5, 179, 83, -1, -3,
	130, 132, -3, -1, 83, 179, -5, 0, 44, 219, -7, 0, 16, 246, -6
};
short gRDRV_resz_filter_7tap_high_quality[RDRV_RESZ_SPEC__MAX_FILTER_COEFF] = {
	-1, 19, 108, 112, 19, -1, 0, 0, 0, 6, 88, 126, 37, -1, 0, 0,
	0, 0, 61, 134, 61, 0, 0, 0, 0, -1, 37, 126, 88, 6, 0, 0
};

FILE *in_data, *out_data;
int fd_rsz=0;
void *in_start, *out_start;

/****************************************************************************
 * Function             - st_resizer_close_interface
 * Functionality        - This function closes the resizer device
 * Input Params         - None
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/
void st_resizer_close_interface(void) {
	close(fd_rsz);
}

/****************************************************************************
 * Function             - st_resizer_close_file_interface
 * Functionality        - This function closes the input and output files
 * Input Params         - None
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/
void st_resizer_close_file_interface(void) {
//	fclose(in_data);
	fclose(out_data);
}

/****************************************************************************
 * Function             - st_resizer_open_interface
 * Functionality        - This function opens the resizer device
 * Input Params         - Input file and output file
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/
int st_resizer_open_interface(char *dev) {
	int mode = O_RDWR;

	fd_rsz = open(dev, mode);
	if (FAILURE == fd_rsz)
		return FAILURE;
	return SUCCESS;
}

/****************************************************************************
 * Function             - st_resizer_open_file_interface
 * Functionality        - This function opens the input and output files
 * Input Params         - Input file and output file
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/
int st_resizer_open_file_interface(char *in_f, char *out_f) {
//	in_data = fopen(in_f, "rb");
//	if (NULL == in_data )
//		return FAILURE;
	out_data = fopen(out_f, "wb");
	if (NULL == out_data)
		return FAILURE;
	return SUCCESS;
}

/****************************************************************************
 * Function             - st_resizer_print_test_params
 * Functionality        - This function prints the test option values
 * Input Params         - Test params structure
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/
void st_resizer_print_test_params(struct st_resizer_testparams *test_options,char *testcaseid) {
    DBG_PRINT_TST_START((testcaseid));
	DBG_PRINT_TRC0(("The Test is going to start with following values "));
    DBG_PRINT_TRC0(("The device node | %s", test_options->device));
    DBG_PRINT_TRC0(("Generating YUV Color Bar with"));
	DBG_PRINT_TRC0(("The input width | %d", test_options->in_width));
	DBG_PRINT_TRC0(("The input height | %d", test_options->in_height));
	DBG_PRINT_TRC0(("The output file | %s", test_options->out_file));
	DBG_PRINT_TRC0(("The output file width | %d", test_options->out_width));
	DBG_PRINT_TRC0(("The output file height | %d", test_options->out_height));
	DBG_PRINT_TRC0(("The read cycle value | %d", test_options->read_cycle));
}

/****************************************************************************
 * Function             - st_resizer_chk_rsz_ratio
 * Functionality        - This function checks the resize ratio
 * Input Params         - None
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/
int st_resizer_chk_rsz_ratio(void) {
	float ht_ratio, wd_ratio;

	ht_ratio = (float)(test_options.out_height) / (float)(test_options.in_height);
	wd_ratio = (float)(test_options.out_width) / (float)(test_options.in_width);

	if(MIN_RSZ_RATIO <= ht_ratio && MAX_RSZ_RATIO >= ht_ratio && MIN_RSZ_RATIO
		<= wd_ratio && MAX_RSZ_RATIO >= wd_ratio)
		return SUCCESS;
	else
		return FAILURE;
}

 /****************************************************************************
 * Function             - st_resizer_init_test_params
 * Functionality        - This function initilaizes the default values for
 * various test case options(which will be exposed as command line arguments)
 * Input Params         -  None
 * Return Value         -  None
 * Note                 -  None
 ****************************************************************************/
void st_resizer_init_test_params(void) {
	test_options.device = DEFAULT_DEVICE;
    	test_options.in_file = DEFAULT_IN_FILE;
    	test_options.out_file = DEFAULT_OUT_FILE;
    	test_options.in_height = DEFAULT_IN_HEIGHT;
    	test_options.in_width = DEFAULT_IN_WIDTH;
    	test_options.out_height = DEFAULT_OUT_HEIGHT;
        test_options.in_pitch = (DEFAULT_IN_WIDTH * 2);
        test_options.out_pitch = (DEFAULT_OUT_WIDTH * 2);
        test_options.out_width = DEFAULT_OUT_WIDTH;
    	test_options.read_cycle = DEFAULT_READ_CYCLE;
        test_options.throughput = FALSE;
        test_options.cpuload = FALSE;
        test_options.userpointer = FALSE;
}
/****************************************************************************
   * Function             - colorbar_generate
    * Functionality        - This function generates the color bars
     * Input Params         - device number
      * Return Value         - 0: SUCCESS, -1: FAILURE
       * Note                 - None
        ****************************************************************************/
void colorbar_generate(unsigned char *addr, int width, int height, int order)
{
        unsigned short *ptr = ((unsigned short *)addr) + order*width;
        int i, j, k;

            for(i = 0 ; i < 8 ; i ++) {
                for(j = 0 ; j < height / 8 ; j ++) {
                    for(k = 0 ; k < width / 2 ; k ++, ptr++)
                        *ptr = ycbcr[i];
                    if((unsigned int)ptr >= (unsigned int)addr
                                                        + width*height)
                        ptr = (unsigned short*)addr;
                }
            }
}
void fill_lines(int width)
{
        unsigned char CVal[4][2] = {{0x5A, 0xF0},{0x36, 0x22},
                    {0xF0, 0x6E},{0x10, 0x92}};
        int i, j ,k;
        unsigned char lines[4][2][1920];
    /* Copy Y data for all 4 colors in the array */
            memset(lines[0][0], 0x51, width);
            memset(lines[1][0], 0x91, width);
            memset(lines[2][0], 0x29, width);
            memset(lines[3][0], 0xD2, width);
            /* Copy C data for all 4 Colors in the array */
            for(i = 0 ; i < 4 ; i ++) {
                for(j = 0 ; j < 2 ; j ++){
                    for(k = 0 + j ; k < width ; k+=2)
                        lines[i][1][k] = CVal[i][j];
                }
            }
}
/* vi: set ts=4 sw=4 tw=80 et:*/
