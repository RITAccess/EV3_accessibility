/*
 * st_resizer_common.h
 *
 * This file contains the common function declaration
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/

#ifndef _ST_RESIZER_COMMON_H_
#define _ST_RESIZER_COMMON_H_

/* Standard Linux header files */
#include <st_resizer_interface.h>
#include <stdio.h>
#include <string.h>

/*Testcode related Header files*/
#include <stDefines.h>
#include <stLog.h>
#include <stTimer.h>
#include <stBufferMgr.h>
#include <stCpuLoad.h>

#define __USE_GNU
#define DEFAULT_IN_FILE "in.yuv"
#define DEFAULT_OUT_FILE "out.yuv"
#define DEFAULT_IN_HEIGHT 480
#define DEFAULT_IN_WIDTH 640
#define MIN_RSZ_RATIO 0.25
#define MAX_RSZ_RATIO 4
#define MODE_NOT_SUPPORTED 	-12
#define QMUL  (0x100)
#define RDRV_RESZ_SPEC__MAX_FILTER_COEFF 32
#define COEF(nr, dr)   ((short)(((nr)*(int)QMUL)/(dr)))
#define DEFAULT_DEVICE RSZ_DRIVER
#define DEFAULT_OUT_HEIGHT 240
#define DEFAULT_OUT_WIDTH 320
#define DEFAULT_READ_CYCLE 0x0
#define FMT 		RSZ_PIX_FMT_YUYV;
#define FMT_UYVY RSZ_PIX_FMT_UYVY
#define ST_RSZ_INTYPE_YCBCR422_16BIT RSZ_INTYPE_YCBCR422_16BIT
#define TWO 2
#define ONE 1
#define ZERO 0
#define FIVE 5
#define FBDEV	"/dev/fb0"

/* Test case options structure */
extern struct st_resizer_testparams test_options;

/* Default values related to test */
extern char *testcase_id;
extern char *test_name;
extern int status;
extern int open_file;
extern int open_device;
extern int readexp;
unsigned long in_imgsize;
unsigned long out_imgsize;
unsigned long buffer_addr;
int fb_fd;

/* This is to indicate if its a special test */
extern int other_tests;
extern short gRDRV_resz_filter_4tap_high_quality[RDRV_RESZ_SPEC__MAX_FILTER_COEFF];
extern short gRDRV_resz_filter_7tap_high_quality[RDRV_RESZ_SPEC__MAX_FILTER_COEFF];
extern FILE *in_data, *out_data;
extern int fd_rsz;
extern void *in_start, *out_start;
/* Test case options structure */
extern struct st_resizer_testparams test_options;

/*Structure for holding the test options */
struct st_resizer_testparams
{
/* Device node name */
    char *device;
/*Input yuv file*/
    char *in_file;
/*Output yuv file*/
    char *out_file;
/* Input file height*/
    int in_height;
/* Input file height*/
    int read_cycle;
/* Input file width */
    int in_width;
/* Output file height*/
    int out_height;
/* Output file width */
    int out_width;
/* throughput info */
    Bool throughput;
/* cpu load info */
    Bool cpuload;
/**/
    Bool userpointer;
/* option for ioctl tests */
    int loopcount;
    int ioctl_no;
/*Pitch*/
    int in_pitch;
    int out_pitch;
};


/*Function Declarations */
void resizer_testsuite_version(void);
void st_resizer_test(struct st_resizer_testparams *, char *);
void st_resizer_ioctl_test(struct st_resizer_testparams *);
void st_resizer_test_suite_help(void);
int st_resizer_chk_rsz_ratio(void);
int st_resizer_open_file_interface(char *, char *);
int st_resizer_open_interface(char *);
void st_error_handler(int, int, int);
void st_resizer_close_file_interface(void);
void st_resizer_close_interface(void);
int st_resizer_set_params_interface(int, int, int, int, int, int);
int st_resizer_set_expand_register_interface(void);
int st_resizer_request_buf_interface(void);
int st_resizer_query_mmap_interface(void);
int st_resizer_request_buf_userptr_interface(void);
int st_resizer_query_mmap_userptr_interface(void);
int st_resizer_input_file_read_interface(void);
int st_resizer_queue_buf_interface(void);
int st_resizer_resize_interface(void);
void st_resizer_output_file_write_interface(int, int);
int st_resizer_set_cycle_interface(void);
int st_resizer_get_param_interface();
int st_resizer_get_status_interface();
void colorbar_generate(unsigned char *addr, int width, int height, int order);
void fill_lines(int width);
#endif /* _ST_V4L2_CAPTURE_COMMON_H_ */

/* vi: set ts=4 sw=4 tw=80 et:*/
