/*
 * st_resizer_parser.c
 *
 * This file contains the parser code to parse the resizer test options
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/


 /* Test case common header file */
#include "st_resizer_common.h"

/*************************Function Declarations********************************/
/* Function to initialize options with default values */
void st_resizer_init_test_params(void);
/* Function to print options with which the test will run */
void st_resizer_print_test_params(struct st_resizer_testparams *,char *);
static void process_resizer_test_options(int argc, char *argv[]);


/****************************************************************************
 * Function             - resizer_testsuite_version
 * Functionality        - This function displays the test suite version
 * Input Params         - None
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/
void resizer_testsuite_version()
{
    printf("resizerTestSuite V %s\n", VERSION_STRING);
}


 /****************************************************************************
 * Function             - process_resizer_test_options
 * Functionality        - This function parses the command line options and values passed for the options
 * Input Params         -  argc,argv
 * Return Value         -  None
 * Note                 -  None
 ****************************************************************************/
static void process_resizer_test_options(int argc, char *argv[])
{
    int error = FALSE;
    int ver = FALSE;
    int help = FALSE;

    for (;;) {
        int opt_index = 0;
        /** Options for getopt - New test case options added need to be
         * populated here*/
        static struct option long_options[] = {
            {"devicenode", optional_argument, NULL, 'd'},
            {"loopcount", optional_argument, NULL, 'L'},
            {"ioctl_no", optional_argument, NULL, 'I'},
            {"inputfile", optional_argument, NULL, 'i'},
            {"inputwidth", optional_argument, NULL, 'w'},
            {"inputheight", optional_argument, NULL, 'h'},
            {"in_pitch", optional_argument, NULL, 'p'},
            {"outputfile", optional_argument, NULL, 'o'},
            {"outputwidth", optional_argument, NULL, 'W'},
            {"outputheight", optional_argument, NULL, 'H'},
            {"out_pitch", optional_argument, NULL, 'P'},
            {"readcycle", optional_argument, NULL, 'c'},
            {"testcaseid", optional_argument, NULL, 't'},
            {"testname", optional_argument, NULL, 'T'},
            {"throughput", no_argument, NULL, 'r'},
            {"cpuload", no_argument, NULL, 'l'},
            {"userpointer", no_argument, NULL, 'u'},
            {"version", no_argument, NULL, 'v'},
            {"help", no_argument, NULL, '?'},
            {NULL, 0, NULL, 0}
        };
        int c = getopt_long(argc, argv,
                            "d:L:I:i:w:h:p:o:W:H:P:c:t:T::rluv?",
                            long_options, &opt_index);
        if (c == -1) {
            break;
        }
        switch (c) {
        case 'd':
            if (optarg != NULL) {
                test_options.device = optarg;
            } else if (optind < argc && argv[optind]) {
                test_options.device = argv[optind];
            }
            break;
        case 'L':
            if (optarg != NULL) {
                test_options.loopcount = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                test_options.loopcount = atoi(argv[optind]);
            }
            break;
        case 'I':
            if (optarg != NULL) {
                test_options.ioctl_no = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                test_options.ioctl_no = atoi(argv[optind]);
            }
            break;
        case 'i':
            if (optarg != NULL) {
                test_options.in_file = optarg;
            } else if (optind < argc && argv[optind]) {
                test_options.in_file = argv[optind];
            }
            break;
        case 'w':
            if (optarg != NULL) {
                test_options.in_width = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                test_options.in_width = atoi(argv[optind]);
            }
            break;
        case 'h':
            if (optarg != NULL) {
                test_options.in_height = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                test_options.in_height = atoi(argv[optind]);
            }
            break;
        case 'c':
            if (optarg != NULL) {
                test_options.read_cycle = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                test_options.read_cycle = atoi(argv[optind]);
            }
            break;
        case 'o':
            if (optarg != NULL) {
                test_options.out_file = optarg;
            } else if (optind < argc && argv[optind]) {
                test_options.out_file = argv[optind];
            }
            break;
        case 'W':
            if (optarg != NULL) {
                test_options.out_width = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                test_options.out_width = atoi(argv[optind]);
            }
            break;
        case 'H':
            if (optarg != NULL) {
                test_options.out_height = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                test_options.out_height = atoi(argv[optind]);
            }
            break;
        case 'P':
           if (optarg != NULL) {
               test_options.out_pitch = atoi(optarg);
           } else if (optind < argc && argv[optind]){
               test_options.out_pitch = atoi(argv[optind]);
           }
           break;
        case 'p':
          if (optarg != NULL) {
              test_options.in_pitch = atoi(optarg);
          } else if (optind < argc && argv[optind]){
              test_options.in_pitch = atoi(argv[optind]);
          }
          break;

        case 't':
            if (optarg != NULL) {
                testcase_id = optarg;
            } else if (optind < argc && argv[optind]) {
                testcase_id = argv[optind];
            }
            break;
        case 'T':
            if (optarg != NULL) {
                test_name = optarg;
            } else if (optind < argc && argv[optind]) {
                test_name = argv[optind];
            }
            other_tests = TRUE;
            break;
        case 'r':
            test_options.throughput = TRUE;
            break;
        case 'l':
            test_options.cpuload = TRUE;
            break;
        case 'u':
            test_options.userpointer = TRUE;
            break;
        case 'v':
            resizer_testsuite_version();
            ver = TRUE;
            break;
        case '?':
            help = TRUE;
            break;

        }
    }
    /* If any error in usage, values provided for options, display the help to user */
    if (TRUE != help && TRUE != ver) {
        if (FAILURE == st_resizer_chk_rsz_ratio()){
			error = TRUE;
        }
    }
    if (TRUE == error || TRUE == help) {
        st_resizer_test_suite_help();
    }

    if ((TRUE != ver && TRUE != help) && (TRUE != error)) {
        st_resizer_print_test_params(&test_options,testcase_id);
        if(TRUE != other_tests) {
            st_resizer_test(&test_options, testcase_id);
		}
        else if (strcmp(test_name, "ioctl") == SUCCESS) {
            st_resizer_ioctl_test(&test_options);
        }
        else {
            printf("Test not supported\n");
        }
    }
}

/****************************************************************************
 * Function             - Main function
 * Functionality        - This is where the execution begins
 * Input Params         - argc,argv
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/
int main(int argc, char **argv)
{
    /* Initialize options with default values */
    st_resizer_init_test_params();
    /* Invoke the parser function to process the command line options */
    process_resizer_test_options(argc, argv);
    return 0;
}

/* vi: set ts=4 sw=4 tw=80 et:*/
