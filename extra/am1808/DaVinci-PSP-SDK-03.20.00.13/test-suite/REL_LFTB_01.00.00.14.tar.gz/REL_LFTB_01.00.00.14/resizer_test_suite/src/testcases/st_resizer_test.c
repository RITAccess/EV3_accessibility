/*
 * st_resizer_test.c
 *
 * This file contains code to test the Resizer driver
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

/*generic header files */
#include "st_resizer_common.h"

/****************************************************************************
 * Function             - st_resizer_test
 * Functionality        - Function to resize an image of given width and height
 * Input Params         - test_options structure with input parameters, testcaseid
 * Return Value         - None.
 * Note                 - None
 ****************************************************************************/
void st_resizer_test(struct st_resizer_testparams *test_options, char *test_id) {
    int ret = SUCCESS;
    ST_TIMER_ID startTime;
    unsigned long elapsedUsecs = 0;
    ST_CPU_STATUS_ID cpuStatusId;
    float percentageCpuLoad = 0;

    do {
        /*Open input and output files */
        ret = st_resizer_open_file_interface(test_options->in_file, test_options->out_file);
        if(FAILURE == ret) {
            DBG_PRINT_ERR(("Files cannot be opened"));
            st_error_handler(open_device, open_file, status);
            break;
        }
        else {
            DBG_PRINT_TRC0(("Files opened successfully"));
            open_file = TRUE;
        }

        if(test_options->cpuload == TRUE)
        {
            startCpuLoadMeasurement (&cpuStatusId);
        }
        /*Open resizer device */
        ret = st_resizer_open_interface(test_options->device);
        if(FAILURE == ret) {
            DBG_PRINT_ERR(("Resizer device could not be opened"));
            st_error_handler(open_device, open_file, status);
            break;
        }
        else {
            DBG_PRINT_TRC0(("Resizer device opened successfully"));
            open_device = TRUE;
        }


        /*Set resizer parameters */
        ret = st_resizer_set_params_interface(test_options->in_width,
                test_options->in_height, test_options->out_width,
                test_options->out_height, test_options->in_pitch,
                test_options->out_pitch);
        if(FAILURE == ret) {
            DBG_PRINT_ERR(("Unable to set parameters for the Resizer"));
            st_error_handler(open_device, open_file, status);
            break;
        }
        else
            DBG_PRINT_TRC0(("Resizer parameters set successfully"));

        /*Set read cycle expand register*/
        ret = st_resizer_set_cycle_interface();
        if(FAILURE == ret) {
            DBG_PRINT_ERR(("Unable to set read cycle expand register"));
            st_error_handler(open_device, open_file, status);
            break;
        }
        else if(SUCCESS == ret) {
            DBG_PRINT_TRC0(("Read cycle expand register set successfully"));
        }

      if(test_options->userpointer != TRUE)
      {
       /*Request for buffers*/
        ret = st_resizer_request_buf_interface();
        if(FAILURE == ret) {
            DBG_PRINT_ERR(("Unable to request for buffers"));
            st_error_handler(open_device, open_file, status);
            break;
        }
        else
            DBG_PRINT_TRC0(("Buffers requested successfully"));


        DBG_PRINT_TRC0(("CHECK IF THIS IS CALLED.. "));
        /*Query and mmap the buffers*/
        ret = st_resizer_query_mmap_interface();
        if(FAILURE == ret) {
            DBG_PRINT_ERR(("Unable to query and mmap the buffers"));
            st_error_handler(open_device, open_file, status);
            break;
        }
        else
            DBG_PRINT_TRC0(("Buffers QUERY'ed and mmaped successfully"));
      }

      if(test_options->userpointer == TRUE)
      {
        DBG_PRINT_TRC0(("Using User Pointer"));
       /*Request for buffers*/
        ret = st_resizer_request_buf_userptr_interface();
        if(FAILURE == ret) {
            DBG_PRINT_ERR(("Unable to request for buffers"));
            st_error_handler(open_device, open_file, status);
            break;
        }
        else
            DBG_PRINT_TRC0(("Buffers requested successfully"));


        DBG_PRINT_TRC0(("CHECK IF THIS IS CALLED.. "));
        /*Query and mmap the buffers*/
        ret = st_resizer_query_mmap_userptr_interface();
        if(FAILURE == ret) {
            DBG_PRINT_ERR(("Unable to query and mmap the buffers"));
            st_error_handler(open_device, open_file, status);
            break;
        }
        else
            DBG_PRINT_TRC0(("Buffers QUERY'ed and mmaped successfully"));
      }

        /*Copy input file to input buffer*/
        ret = st_resizer_input_file_read_interface();
        if(FAILURE == ret) {
            DBG_PRINT_ERR(("Unable to copy input file to input buffer"));
            st_error_handler(open_device, open_file, status);
            break;
        }
        else
            DBG_PRINT_TRC0(("Input file copied to input buffer successfully"));


        /*Queue buffers*/
        ret = st_resizer_queue_buf_interface();
        if(FAILURE == ret) {
            DBG_PRINT_ERR(("Unable to queue buffers"));
            st_error_handler(open_device, open_file, status);
            break;
        }
        else  if(SUCCESS == ret) {
            DBG_PRINT_TRC0(("Buffers queued successfully"));
        }

        if(test_options->throughput == TRUE)
        {
            startTimer(&startTime);
        }
        /*Resize the input image*/
        ret = st_resizer_resize_interface();

        /* Stop the Timer and get the usecs elapsed */
        if(test_options->throughput == TRUE)
        {
            elapsedUsecs = stopTimer (&startTime);
            DBG_PRINT_TRC0(("The time consumed for resize operation in microseconds = %ld",elapsedUsecs));
        }
        if(FAILURE == ret) {
            DBG_PRINT_ERR(("Unable to resize image"));
            st_error_handler(open_device, open_file, status);
            break;
        }
        else
            DBG_PRINT_TRC0(("Resized image successfully"));

        /*Copy the resized image to output file*/
        st_resizer_output_file_write_interface(test_options->out_width, test_options->out_height);

        /* Close the input and output files*/
        st_resizer_close_file_interface();

        /*Close the device */
        st_resizer_close_interface();

        if(test_options->cpuload == TRUE)
        {
            /* Get CPU Load figures */
            percentageCpuLoad = stopCpuLoadMeasurement (&cpuStatusId);
            DBG_PRINT_TRC0(("Percentage CPU Load for resize operation:%.2f%%",percentageCpuLoad));
        }
    }while (SUCCESS != ret);

    /* print status/result of the test case */
    if (FAILURE == status) {
        DBG_PRINT_TST_RESULT_FAIL((test_id));
    }
    else {
        DBG_PRINT_TST_RESULT_PASS((test_id));
    }

    /* end test case */
    DBG_PRINT_TST_END((test_id));
}

/****************************************************************************
 * Function             - st_resizer_ioctl_test
 * Functionality        - Function to test the newly added ioctls
 * Input Params         - None.
 * Return Value         - None.
 * Note                 - None
 * ioctls.
 ****************************************************************************/
void  st_resizer_ioctl_test(struct st_resizer_testparams *test_options)
{
    int ret = SUCCESS;
    int i;
    DBG_PRINT_TRC0(("Testing the IOCTLs"));

    do
    {
			/*Open input and output files */
			ret = st_resizer_open_file_interface(test_options->in_file,
					test_options->out_file);
			if(FAILURE == ret) {
				DBG_PRINT_ERR(("Files cannot be opened"));
				st_error_handler(open_device, open_file, status);
				break;
			}
			else {
				DBG_PRINT_TRC0(("Files opened successfully"));
				open_file = TRUE;
			}


			/*Open resizer device */
			ret = st_resizer_open_interface(test_options->device);
			if(FAILURE == ret) {
				DBG_PRINT_ERR(("Resizer device could not be opened"));
				st_error_handler(open_device, open_file, status);
				break;
			}
			else {
				DBG_PRINT_TRC0(("Resizer device opened successfully"));
				open_device = TRUE;
			}
		switch(test_options->ioctl_no)
		{
				/*RSZ_S_EXP IOCTL*/
			case 0:
				for(i=0; i< test_options->loopcount; i++)
				{
					/* Configure the Read cycle required for Resizer module */
					DBG_PRINT_TRC0(("Configure the Read cycle required for Resizer module"));
					/* get format */
					readexp = test_options->read_cycle;
					ret = st_resizer_set_cycle_interface();
					if (SUCCESS != ret)
					{
						DBG_PRINT_ERR(("RSZ_S_EXP Ioctl Failed"));
						status = FAILURE;
						break;
					}

				 }
					DBG_PRINT_TRC0(("RSZ_S_EXP Ioctl Passed"));
				break;

			case 1:
			{
					for(i=0; i< test_options->loopcount; i++)
				{
					/*Set resizer parameters */
					ret = st_resizer_set_params_interface(test_options->in_width,
							test_options->in_height, test_options->out_width,
							test_options->out_height, test_options->in_pitch,
                            test_options->out_pitch);
					if(FAILURE == ret) {
						DBG_PRINT_ERR(("Unable to set parameters for the Resizer"));
						st_error_handler(open_device, open_file, status);
						break;
						}

					/* Get the Resizer parameters that are previously being set */
					DBG_PRINT_TRC0(("Get the Resizer parameters that are being set"));

					ret = st_resizer_get_param_interface();
					if (SUCCESS != ret){
						DBG_PRINT_ERR(("RSZ_G_PARAM Ioctl Failed"));
						status = FAILURE;
						break;
						}
				}

					DBG_PRINT_TRC0(("RSZ_S_PARAM and RSZ_G_PARAM Ioctls Passed"));
					break;
			}
			case 2:
			{
				for(i=0; i< test_options->loopcount; i++)
				{
					/* Get the Resizer channel status */
					DBG_PRINT_TRC0(("Get the Resizer channel status"));
					/* get format */
					ret = st_resizer_get_status_interface();
					if (SUCCESS != ret)
					{
						DBG_PRINT_ERR(("RSZ_G_STATUS Ioctl Failed"));
						status = FAILURE;
						break;
					}
				}
				DBG_PRINT_TRC0(("RSZ_G_STATUS Ioctl Passed"));
			}
		}
	}while(SUCCESS != ret);

    DBG_PRINT_TRC0(("Close the files and device"));

    /* Close the input and output files*/
    st_resizer_close_file_interface();

    /*Close the device */
    st_resizer_close_interface();
}



void st_error_handler(open_device, open_file, status) {
    status = FAILURE;

    if(TRUE == open_file) {
        st_resizer_close_file_interface();
        open_file = FALSE;
    }

    if(TRUE == open_device) {
        st_resizer_close_interface();
        open_device = FALSE;
    }
}

/* vim: set ts=4 sw=4 tw=80 et:*/
