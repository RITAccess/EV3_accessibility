/*
 * stBufferMgr.c 
 * 
 * This file defines the buffer management functions.
 * 
 * 
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/ 
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/
  
/* Generic header files */
#include <stBufferMgr.h>


/*************************************************************************************
 * Function             : st_alloc_mem
 * Functionality        : To allocate memory
 * Input Params         : size    - Memory size to be allocated
 *                      : mem_ptr - variable which will hold the address allocated
 * Return Value         : 0 if success and -1 incase of error
 **************************************************************************************/

Int32 st_alloc_mem (IN Uint32 size, INOUT void ** mem_ptr)
{
  Int32 status =0;

 *mem_ptr = (void *)malloc(size);
 if(NULL != *mem_ptr)
 {
  status = 0;
 }else{
  status = -1;
 }

 return status;
}

 

/*************************************************************************************
 * Function             : st_free_mem
 * Functionality        : To free the allocate memory
 * Input Params         : mem_ptr - variable which will hold the address allocated
 * Return Value         : Zero
 **************************************************************************************/

Int32 st_free_mem (IN void * mem_ptr)
{
    free(mem_ptr);
    return 0;
}
 


/*************************************************************************************
 * Function             : st_alloc_aligned_mem
 * Functionality        : To allocate memory and align it
 * Input Params         : size       - Memory size to be allocated
 *                      : alignment  - Value for which memory is to be aligned
 *                      : mem_ptr    - variable which will hold the address allocated
 *                      : MEM_Handle - Variable which will hold aligned address
 * Return Value         : 0 if successful and -1 incase of failure
 **************************************************************************************/

Int32 st_alloc_aligned_mem (IN Uint32 size, IN Uint32 alignment, INOUT void ** mem_ptr, INOUT void ** MEM_Handle)
{
 Int32 status;
 
 *mem_ptr = malloc(size);
 if(NULL != *mem_ptr)
 {
  status = 0;
 }else{
  status = -1;
 }
 
 *MEM_Handle = (Ptr)(((Uint32)((*mem_ptr + ((Uint32)alignment)) - 1u)) & (~(((Uint32)alignment) - 1u)));
 if(NULL != *MEM_Handle)
 {
  status = 0;
 }else{
  status = -2;
 }

  return status;
}



/*************************************************************************************
 * Function             : st_free_aligned_mem
 * Functionality        : To free the aligned memory
 * Input Params         : MEM_Handle - variable which will hold the alignes address 
 * Return Value         : Zero
 **************************************************************************************/

Int32 st_free_aligned_mem (IN void * MEM_Handle)
{
 free(MEM_Handle);
 return 0;
}

/*************************************************************************************
 * Function             : st_allocate_buffer
 * Functionality        : To allocate memory
 * Input Params         : size    - Memory size to be allocated
 * Return Value         : Memory handle
 **************************************************************************************/
void * st_allocate_buffer(IN size_t size)
{
    return malloc(size);
}

/*************************************************************************************
 * Function             : st_free_buffer
 * Functionality        : To free memory
 * Input Params         : buffer - variable which will hold the buffer address 
 * Return Value         : Zero
 **************************************************************************************/

int st_free_buffer(void * buffer)
{
    free(buffer);
    return 0;
}




/* vim: set ts=4 sw=4 tw=80 et:*/
