/*
 * stLog.h 
 * 
 * This file implements  the logging macros
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/ 
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/

#ifndef _ST_LOG_H_
#define _ST_LOG_H_

#include <stDefines.h>

#define PERFLOG(...) printf("%s:%s:%d:", __FILE__, __FUNCTION__, __LINE__); \
                     printf(__VA_ARGS__)


/* to enable START, END, TEST RESULT, WARNING and ERROR MACROS */
#define ST_ENABLE_PRINT

/* this is not enabled by default - uncomment this to enable TRC0 */

#define ST_ENABLE_TRC0


/*----------------------------------------------------------------------------
  Define Macros
  ----------------------------------------------------------------------------*/

/* This is mandatory and is always enabled */
#define DBG_PRINT_TRC(x) printf x ;\
	                     printf ("\n"); 
	                    
/****************** DBG Prints enabled by default ************/
#ifdef ST_ENABLE_PRINT

/* Used to represent the beginning of the test case. The parameter to this
 * function call will be a macro representing the testcase description.
 * For eg: DBG_PRINT_TST_START((LINUXI2C0250)) ; 
 * The test case id LINUXI2C0250 is a macro which can be defined as follows:
 * #define LINUXI2C0250 |LINUXI2C0250|" 
 * Since the id is defined as a macro, in future we can also create a way to
 * generate meaningful description corresponding to the id automatically from
 * the test matrix
 * eg:  #define LINUXI2C0250 "LINUXI2C0250|Configure for  TV out display|"
 * */


#define DBG_PRINT_TST_START(x) printf ("\n\n|TEST START| "); \
	                        printf x; \
	                        printf ("|"); \
	                        printf ("\n");

/* Enable the warning logs */
#define DBG_PRINT_WRG(x) printf ("\n\n|WARNING| "); \
                         printf("Warning Line: %d, File: %s - ", \
                                __LINE__, __FILE__); \
                         printf x ; \
	                     printf ("|"); \
	                     printf ("\n");                          

/* Enable the error logs */	                        
#define DBG_PRINT_ERR(x) printf ("\n\n|ERROR| "); \
                         printf("*ERROR* Line: %d, File: %s - ", \
	                            __LINE__, __FILE__); \
	                     printf x ; \
	                     printf ("|"); \
	                     printf ("\n");

/* Used to represent the PASS result of the test case. The parameter to this
 * function call will be a macro representing the testcase description and test
 * result.  The use of separate macros to represent pass and fail criteria
 * improves the readability and eliminates the requirement of passing the result
 * a parameter.
 * For eg: DBG_PRINT_TST_RESULT_PASS((LINUXI2C0250)) ; 
 * The test case id LINUXI2C0250 is a macro.
 * */	                     
#define DBG_PRINT_TST_RESULT_PASS(x) printf ("|TEST RESULT|PASS| "); \
                                     printf x ; \
	                                 printf ("|"); \
	                        		 printf ("\n");


/* Used to represent the FAIL result of the test case. The parameter to this
 * function call will be a macro representing the testcase description and test
 * result. The use of separate macros to represent pass and fail criteria
 * improves the readability and eliminates the requirement of passing the result
 * a parameter.
 * For eg: DBG_PRINT_TST_RESULT_FAIL((LINUXI2C0250)) ; 
 * The test case id LINUXI2C0250 is a macro.
 * */
#define DBG_PRINT_TST_RESULT_FAIL(x) printf ("|TEST RESULT|FAIL| "); \
                                     printf x ; \
	                                 printf ("|"); \
	                        		 printf ("\n");


/* Used to represent the end of the test case. The parameter to this
 * function call will be a macro representing the testcase description.
 * For eg: DBG_PRINT_TST_END((LINUXI2C0250)) ; 
 * The test case id LINUXI2C0250 is a macro which can be defined as follows:
 * #define LINUXI2C0250 "LINUXI2C0250|" 
 * Since the id is defined as a macro, in future we can also create a way to
 * generate meaningful description corresponding to the id automatically from
 * the test matrix
 * eg:  #define LINUXI2C0250 "LINUXI2C0250|Configure display driver for TV Out|"
 * */                                                                                     
#define DBG_PRINT_TST_END(x) printf ("|TEST END| "); \
	                        printf x; \
	                        printf ("|"); \
	                        printf ("\n");                                     	                       


/* Trace without additional prints */
#define DBG_PRINT_TRC_NEOL(x) printf x;
#endif /*ST_ENABLE_PRINT*/        


#ifdef ST_ENABLE_TRC0
#define DBG_PRINT_TRC0(x) printf ("| TRACE LOG| "); \
                         printf x ;\
	                     printf ("|"); \
	                     printf ("\n"); 
#else
#define DBG_PRINT_TRC0(x) 
#endif /*ST_ENABLE_TRC0*/


#endif /* _ST_LOG_H_ */

/* vim: set ts=4 sw=4 tw=80 et:*/

