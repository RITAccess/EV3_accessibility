/*
 *  stTimer.c
 *
 * This file implements the timer wrappers
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/ 
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/



#include <stDefines.h>
#include <stLog.h>
#include <stTimer.h>

/* Use this define to calibrate the delta value */
#define BASE_NUM_TRIALS 10

/* Delta in microseconds to be adjusted */
static int deltaTime = 0;

/* Return the difference between 2 timeval structs 
 * in microseconds
 */ 
static long diffTime(IN ST_TIMER_ID * pTimeStart, IN ST_TIMER_ID * pTimeEnd);

/* Return the time elapsed between 2 timeval structs 
 * in microseconds
 */ 
static long elapsedTime(IN ST_TIMER_ID * pTimeStart, IN ST_TIMER_ID * pTimeEnd);

/* Initialize Timer module */
void initTimerModule(void)
{
    ST_TIMER_ID startTime;
    ST_TIMER_ID endTime;
    int i = 0;

    /* Already calibrated */
    if(0 != deltaTime) return; 
    
    /* We need to average deltaTime out */
    for(i = 0; i < BASE_NUM_TRIALS; i++)
    {
        startTimer(&startTime);
        startTimer(&endTime);  

        deltaTime += diffTime(&startTime, &endTime);
    }

    deltaTime = deltaTime / BASE_NUM_TRIALS;
    
//    PERFLOG("Delta : %ld\n", deltaTime);
}

/* Get the current time, update the pTimerHandle */
void getTime(INOUT ST_TIMER_ID * pTimerHandle)
{
    startTimer(pTimerHandle);
}

/* Start the timer and update the pTimerHandle */
void startTimer(INOUT ST_TIMER_ID * pTimerHandle)
{
    ST_TIMER_ID * pStartTimeVal = pTimerHandle;
	
    gettimeofday(pStartTimeVal, NULL);

    #if LOG_TIME
    PERFLOG("timeVal.sec %ld\n", pStartTimeVal->tv_sec);
    PERFLOG("timeVal.usec %ld\n", pStartTimeVal->tv_usec);
    #endif
}

/* Stop the Timer and return the elapsed usecs  */
unsigned long stopTimer(IN ST_TIMER_ID * pTimerHandle)
{
    ST_TIMER_ID * pStartTimeVal = pTimerHandle;
    ST_TIMER_ID stopTimeVal;
    gettimeofday(&stopTimeVal, NULL);

    #if LOG_TIME
    PERFLOG("timeVal.sec %ld\n", stopTimeVal.tv_sec);
    PERFLOG("timeVal.usec %ld\n", stopTimeVal.tv_usec);
    #endif
    return((unsigned long)elapsedTime(pStartTimeVal, &stopTimeVal));
}

/* Return the difference between 2 timeval structs 
 * in microseconds
 */ 
static long diffTime(IN ST_TIMER_ID * pTimeStart, IN ST_TIMER_ID * pTimeEnd)
{
    return ((pTimeEnd->tv_sec - pTimeStart->tv_sec) * 1000000u 
            + pTimeEnd->tv_usec - pTimeStart->tv_usec);
}

/* Return the time elapsed between 2 timeval structs 
 * in microseconds
 */ 
static long elapsedTime(IN ST_TIMER_ID * pTimeStart, IN ST_TIMER_ID * pTimeEnd)
{
    return (diffTime(pTimeStart, pTimeEnd) - deltaTime);
}


/* vim: set ts=4 sw=4 tw=80 et:*/

