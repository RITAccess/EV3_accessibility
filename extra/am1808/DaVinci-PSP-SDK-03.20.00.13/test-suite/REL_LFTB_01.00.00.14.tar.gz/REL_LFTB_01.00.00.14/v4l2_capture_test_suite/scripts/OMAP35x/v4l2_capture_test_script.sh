# v4l2_capture_sample_usage_script


#Prints the usage/help
./v4l2_capture_tests --help

#Prints the version
./v4l2_capture_tests -v

#Runs the default loopback - No options provided
./v4l2_capture_tests 

#Run the capture test- number of buffers queued is (-c) 3 and number of iterations (-n) 1000
./v4l2_capture_tests -c 3 -n 1000

#Run the stability Test with stability count as 100
./v4l2_capture_tests -T stability -P 100

#runs the default loopback with PAL standard
./v4l2_capture_tests -s PAL

#Stress Test- Run the loopback test overnight with no of buffers queued is 4 
./v4l2_capture_tests -c 4 -T stress

# -d stands for device node. -p stands for pixelformat Can be passed as command line option as shown below.
./v4l2_capture_tests -d /dev/video0 -p UYVY

#Runs the capture and write test (-D 0). Writes the 200th frame (-W 200) to file capture.yuv (-f capture.yuv). This YUV file can be viewed with a YUV Player.
./v4l2_capture_tests -D 0 -f capture.yuv -W 200
