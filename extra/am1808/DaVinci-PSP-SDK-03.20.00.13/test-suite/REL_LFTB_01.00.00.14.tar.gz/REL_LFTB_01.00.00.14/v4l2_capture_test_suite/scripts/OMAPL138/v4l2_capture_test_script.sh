#v4l2_capture_test_script

#Prints the usage/help
./v4l2_capture_tests --help

#Prints the version
./v4l2_capture_tests -v

echo "Running capture and display tests on LCD"

#Runs the default loopback - No options provided
./v4l2_capture_tests -n 300 -t V4L2_capture_lcd_display_loopback_tests 

echo "Tests to obtain frame rate and CPU load with different inputs - composite and S-Video"
./v4l2_capture_tests -i COMPOSITE -F -l -t V4L2_capture_frame_rate_cpuload_tests
./v4l2_capture_tests -i SVIDEO -F -l -t V4L2_capture_frame_rate_cpuload_tests

#Run the capture test- number of buffers queued is (-c) 3 and number of iterations (-n) 300
echo "Test to vary number of buffers and frames"
./v4l2_capture_tests -c 3 -n 300 -t V4L2_capture_lcd_display_loopback_tests_with_3_buffers_300_frames

#Run the stability Test with stability count
./v4l2_capture_tests -n 300 -T stability -P 5 -t V4L2_capture_stability_tests 

#runs the default loopback with PAL standard
#./v4l2_capture_tests -s PAL
#./v4l2_capture_tests -s NTSC 


#Input switching tests
echo "Running tests with different inputs - composite and S-Video"
./v4l2_capture_tests -n 300 -i COMPOSITE -t V4L2_composite_capture_lcd_display_loopback_tests
./v4l2_capture_tests -n 300 -i SVIDEO -t V4L2_SVideo_capture_lcd_display_loopback_tests


# -d stands for device node. -p stands for pixelformat Can be passed as command line option as shown below.
./v4l2_capture_tests -n 300 -d /dev/video0 -p UYVY
#Uncomment this on a YUYV input
#./v4l2_capture_tests -d /dev/video0 -p YUYV 

echo "Tests to vary number of buffers,frame count"
#Run the capture test- number of buffers queued is (-c) 3 and number of iterations (-n) 300
./v4l2_capture_tests -c 3 -n 300 -t V4L2_capture_display_loopback_tests_with_3_buffers_300_frames

#Input switching tests
./v4l2_capture_tests -n 300 -i COMPOSITE -t V4L2_capture_display_loopback_tests
./v4l2_capture_tests -n 300 -i SVIDEO -t V4L2_capture_display_loopback_tests

echo "Frame rate and CPU load tests"
echo "Frame rate and cpu load test with composite interface"
./v4l2_capture_tests -i COMPOSITE -F -l -t V4L2_composite_capture_frame_rate_cpu_load_tests
echo "Frame rate and cpu load test with SVIDEO interface"
./v4l2_capture_tests -i SVIDEO -F -l -t V4L2_SVideo_capture_frame_rate_cpu_load_tests
