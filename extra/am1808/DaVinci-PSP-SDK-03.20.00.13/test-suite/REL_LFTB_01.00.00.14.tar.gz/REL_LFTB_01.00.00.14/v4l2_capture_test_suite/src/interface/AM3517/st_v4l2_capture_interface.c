/* * st_v4l2_capture_interface.c
 *
 * This file calls V4L2 Capture driver functions and takes parameters given
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/


#include "st_v4l2_capture_common.h"




#define WIDTH_NTSC 720

#define HEIGHT_NTSC 480

#define WIDTH_PAL 720

#define HEIGHT_PAL 576

 /* Device nodes supported */
#define VID0_DEVICE "/dev/video0"

#define VID1_DEVICE "/dev/video1"

#define VID2_DEVICE "/dev/video2"

#define V4L2_DEV0 0


#define MAX_BUFFER 10


/* Interfaces supported */
#define INTERFACE_COMPOSITE "COMPOSITE"
#define INTERFACE_SVIDEO "SVIDEO"
#define INTERFACE_LCD "LCD"

#define COMPOSITE_IFC 0
#define SVIDEO_IFC 1

/*Buffer Exchange Mechanisms*/
#define BUFFER_XCHG_MMAP 1
#define BUFFER_XCHG_USERPTR 0

/*Display/Write Options*/
#define OPT_DISPLAY 1
#define OPT_WRITE 0

#define PIX_FMT_UYVY "UYVY"

 /* Macros- Default settings/values for capture */
#define DEFAULT_NUM_BUFFERS 2 

#define DEFAULT_NUM_FRAMES  1000

#define DEFAULT_DEVICE VID0_DEVICE

#define DEFAULT_STD STD_NTSC

#define DEFAULT_INTERFACE INTERFACE_COMPOSITE

#define DEFAULT_INTERFACE_DISP INTERFACE_LCD

#define DEFAULT_OPEN_MODE BLOCKING_OPEN_MODE

#define DEFAULT_WIDTH WIDTH_NTSC

#define DEFAULT_HEIGHT HEIGHT_NTSC

#define DEFAULT_PIX_FMT PIX_FMT_UYVY

#define DEFAULT_BUFFER_XCHG_MECHANISM BUFFER_XCHG_MMAP

#define DEFAULT_BRIGHTNESS 128

#define DEFAULT_CONTRAST 128

#define DEFAULT_SATURATION 128

#define DEFAULT_HUE 0

#define DEFAULT_AUTO_GAIN 1

#define DEFAULT_OPT_DISPLAY OPT_DISPLAY

#define DEFAULT_FILENAME "v4l2_capture_out.yuv"

#define DEFAULT_FRAME_WRITE 100

#define OUTPUTPATH      "/sys/class/display_control/omap_disp_control/video1"
#define OUTPUTPATH_1      "/sys/class/display_control/omap_disp_control/ch0_output"

 /* Test case options structure */
struct st_v4l2_capture_testparams test_options;
struct st_v4l2_input st_ip;
v4l2_std_id st_std_id;
struct st_v4l2_standard st_standard;
struct st_v4l2_capability st_capability;
int cap_support;
unsigned int common_int, numbufs, d_numbufs;
char common_char[32];
unsigned int common_pix;
struct st_v4l2_format st_format, st_display_format;
struct st_v4l2_requestbuffers st_reqbufs;
struct v4l2_buffer st_buf, display_buf, capture_buf;
static struct st_buf_info st_capture_buff_info[MAX_BUFFER];
static struct st_buf_info st_display_buff_info[MAX_BUFFER];
static struct st_buf_info st_display2_buff_info[MAX_BUFFER];
int pixelfmt;

extern int std_flag;
char *cap_ptr, *dis_ptr;

/* v4l2_capture window file descriptors */
static int fd_dev0 = 0;

/* v4l2_capture window file descriptors */
static int fd_dev1 = 0;
static int fd_dev2 = 0;

/****************************************************************************
 * Function             - st_v4l2_capture_write_image_interface
 * Functionality        - This function writesa frame of the image
 * Input Params         - Capture File name, Frame to write, frame being displayed
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_write_image_interface(char *fname, int frame,
                                          int cur_frame)
{
    FILE *fp;
    int h, size;


    size = st_format.fmt.pix.width * 2;
    cap_ptr = st_capture_buff_info[capture_buf.index].start;

    if (cur_frame == (frame - 1)) {
        fp = fopen(fname, "wb");
        if (fp == NULL)
            return FAILURE;
        for (h = 0; h < st_format.fmt.pix.height; h++) {
            fwrite(cap_ptr, size, 1, fp);
            cap_ptr += size;
        }
        fclose(fp);
    }

    cap_ptr = st_capture_buff_info[capture_buf.index].start;
    dis_ptr = st_display_buff_info[display_buf.index].start;

    for (h = 0; h < st_display_format.fmt.pix.height; h++) {
        memcpy(dis_ptr, cap_ptr, st_display_format.fmt.pix.width * 2);
        cap_ptr += st_format.fmt.pix.width * 2;
        dis_ptr += st_display_format.fmt.pix.width * 2;
    }
    return SUCCESS;

}

/****************************************************************************
 * Function             - st_v4l2_capture_unmap_close_display_interface
 * Functionality        - This function unmaps display buffers and closes the device
 * Input Params         - None
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/
void st_v4l2_capture_unmap_close_display_interface(void)
{
    int j;
    for (j = 0; j < d_numbufs; j++) {
        munmap(st_display_buff_info[j].start,
               st_display_buff_info[j].length);
        st_display_buff_info[j].start = NULL;
    }
    close(fd_dev1);
}

/****************************************************************************
 * Function             - st_v4l2_capture_streamoff_interface
 * Functionality        - This function streams off capture
 * Input Params         - Capture device
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_streamoff_interface(int dev)
{
    int a, ret = SUCCESS;

    a = BUF_TYPE_VIDEO_CAPTURE;
    if (V4L2_DEV0 == dev) {
        ret = ioctl(fd_dev0, VIDIOC_STREAMOFF, &a);
    }
    if (SUCCESS != ret) {
	    perror("VIDIOC_STREAMOFF");
        return FAILURE;
    }

    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_capture_streamoff_display_interface
 * Functionality        - This function streams off display
 * Input Params         - None
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_streamoff_display_interface(void)
{
    int a, ret = SUCCESS;

    a = BUF_TYPE_VIDEO_OUTPUT;
    ret = ioctl(fd_dev1, VIDIOC_STREAMOFF, &a);
    if (ret < 0) {
        st_v4l2_capture_unmap_close_display_interface();
        return FAILURE;
    }

    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_capture_queue_display_interface
 * Functionality        - This function queues the capture buffer
 * Input Params         - Capture device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_queue_display_interface(void)
{
    int ret = SUCCESS;
    ret = ioctl(fd_dev1, VIDIOC_QBUF, &display_buf);

    if (ret < 0) {
		perror("VIDIOC_QBUF");
        st_v4l2_capture_unmap_close_display_interface();
        return FAILURE;
    }

    return SUCCESS;

}

/****************************************************************************
 * Function             - st_v4l2_capture_queue_interface
 * Functionality        - This function queues the capture buffer
 * Input Params         - Capture device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_queue_interface(int dev)
{
    int ret = SUCCESS;
    if (V4L2_DEV0 == dev) {
        ret = ioctl(fd_dev0, VIDIOC_QBUF, &capture_buf);
    }
    if (SUCCESS != ret) {
	    perror("VIDIOC_QBUF");
        return FAILURE;
    }

    return SUCCESS;

}

/****************************************************************************
 * Function             - st_v4l2_capture_process_image_interface
 * Functionality        - This function processes the image for displaying
 * Input Params         - None
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/
void st_v4l2_capture_process_image_interface(void)
{
   int h;

    cap_ptr = st_capture_buff_info[capture_buf.index].start;
    dis_ptr = st_display_buff_info[display_buf.index].start;

    for (h = 0; h < st_display_format.fmt.pix.height; h++) {
        memcpy(dis_ptr, cap_ptr, st_display_format.fmt.pix.width * 2);
        cap_ptr += st_format.fmt.pix.width * 2;
        dis_ptr += st_display_format.fmt.pix.width * 2;
    }

}

/****************************************************************************
 * Function             - st_v4l2_capture_dequeue_interface
 * Functionality        - This function dequeues the capture buffer
 * Input Params         - Capture device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_dequeue_interface(int dev)
{
    int ret = SUCCESS;
    if (V4L2_DEV0 == dev) {
        ret = ioctl(fd_dev0, VIDIOC_DQBUF, &capture_buf);
    }
    if (SUCCESS != ret) {
		perror("VIDIOC_DQBUF");
        return FAILURE;
    }

    return SUCCESS;

}

/****************************************************************************
 * Function             - st_v4l2_capture_dequeue_display_interface
 * Functionality        - This function dequeues the display buffer
 * Input Params         - None
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_dequeue_display_interface(void)
{
    int ret = SUCCESS;
    ret = ioctl(fd_dev1, VIDIOC_DQBUF, &display_buf);
    if (ret < 0) {
		perror("VIDIOC_DQBUF");
        st_v4l2_capture_unmap_close_display_interface();
        return FAILURE;
    }

    return SUCCESS;

}

/****************************************************************************
 * Function             - st_v4l2_capture_set_interface
 * Functionality        - This function sets the capture for queueing and dequeueing
 * Input Params         - None
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/
void st_v4l2_capture_set_interface(void)
{
    capture_buf.type = BUF_TYPE_VIDEO_CAPTURE;
    capture_buf.index = 0;
    capture_buf.memory = MEMORY_MMAP;

}

/****************************************************************************
 * Function             - st_v4l2_capture_set_display_interface
 * Functionality        - This function sets the display for queueing and dequeueing
 * Input Params         - None
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/
void st_v4l2_capture_set_display_interface(void)
{
    display_buf.type = BUF_TYPE_VIDEO_OUTPUT;
    display_buf.index = 0;
    display_buf.memory = MEMORY_MMAP;

}

/****************************************************************************
 * Function             - st_v4l2_capture_streamon_interface
 * Functionality        - This function streams on capture
 * Input Params         - Capture device
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_streamon_interface(int dev)
{
    int a, ret = SUCCESS;

    a = BUF_TYPE_VIDEO_CAPTURE;
    if (V4L2_DEV0 == dev) {
        ret = ioctl(fd_dev0, VIDIOC_STREAMON, &a);
    }
    if (SUCCESS != ret) {
		perror("VIDIOC_STREAMON");
        return FAILURE;
    }

    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_capture_streamon_display_interface
 * Functionality        - This function streams on display
 * Input Params         - None
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_streamon_display_interface(void)
{
    int a, ret = SUCCESS;

    a = BUF_TYPE_VIDEO_OUTPUT;
    ret = ioctl(fd_dev1, VIDIOC_STREAMON, &a);
    if (ret < 0) {
		perror("VIDIOC_STREAMON");
        st_v4l2_capture_unmap_close_display_interface();
        return FAILURE;
    }

    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_capture_init_display_interface
 * Functionality        - This function initialises the display parameters
 * Input Params         - No. of buffers
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_init_display_interface(int n_bufs)
{
    int i, ret = SUCCESS;
    struct st_v4l2_requestbuffers reqbuf;
    struct v4l2_buffer buf;

    /* Open the video display device */
    fd_dev1 = open((const char *) VID1_DEVICE, O_RDWR);
    if (fd_dev1 <= 0) {
        return DISPLAY_OPEN_FAILED;
    }

    /* Get the format */
    st_display_format.type = BUF_TYPE_VIDEO_OUTPUT;
    ret = ioctl(fd_dev1, VIDIOC_G_FMT, &st_display_format);
    if (ret < 0) {
		perror("VIDIOC_G_FMT");
        close(fd_dev1);
        return FAILURE;
    }

    if (std_flag == NTSC_STD) {
        st_display_format.fmt.pix.width = WIDTH_NTSC;
        st_display_format.fmt.pix.height = HEIGHT_NTSC;
    } else if (std_flag == PAL_STD) {
        st_display_format.fmt.pix.width = WIDTH_PAL;
        st_display_format.fmt.pix.height = HEIGHT_PAL;
    }

    st_display_format.fmt.pix.pixelformat = pixelfmt;

    ret = ioctl(fd_dev1, VIDIOC_S_FMT, &st_display_format);
    if (ret < 0) {
		perror("VIDIOC_S_FMT");
        close(fd_dev1);
        return FAILURE;
    }

    ret = ioctl(fd_dev1, VIDIOC_G_FMT, &st_display_format);
    if (ret < 0) {
	perror("VIDIOC_G_FMT");
	close(fd_dev1);
        return FAILURE;
    }

    if (st_display_format.fmt.pix.pixelformat != pixelfmt) {
        close(fd_dev1);
        return FAILURE;
    }

    /* Buffer allocation */
    reqbuf.count = n_bufs;
//    reqbuf.type = BUF_TYPE_VIDEO_OUTPUT;
 //   reqbuf.memory = MEMORY_MMAP;
    reqbuf.type = V4L2_BUF_TYPE_VIDEO_OUTPUT;
    reqbuf.memory = V4L2_MEMORY_MMAP;
    ret = ioctl(fd_dev1, VIDIOC_REQBUFS, &reqbuf);
    if (ret < 0) {
		perror("VIDIOC_REQBUFS");
        close(fd_dev1);
        return FAILURE;
    }

    /* Store the numbfer of buffers allocated */
    d_numbufs = reqbuf.count;

    memset(&buf, 0, sizeof(buf));

    /* Mmap the buffers */
    for (i = 0; i < d_numbufs; i++) {
        /* Query physical address of the buffers */
        buf.type = reqbuf.type;
        buf.index = i;
        buf.memory = reqbuf.memory;
        ret = ioctl(fd_dev1, VIDIOC_QUERYBUF, &buf);
        if (ret < 0) {
		perror("VIDIOC_QUERYBUF");
            close(fd_dev1);
            return FAILURE;
        }

        /* Mmap the buffers in application space */
        st_display_buff_info[i].length = buf.length;
        st_display_buff_info[i].index = i;
        st_display_buff_info[i].start =
            mmap(NULL, buf.length, PROT_READ | PROT_WRITE, MAP_SHARED,
                 fd_dev1, buf.m.offset);

        if (st_display_buff_info[i].start == MAP_FAILED) {
            st_v4l2_capture_unmap_close_display_interface();
            return FAILURE;
        }
        memset((void *) st_display_buff_info[i].start, 0x80,
               st_display_buff_info[i].length);

        /* Enqueue buffers */
        ret = ioctl(fd_dev1, VIDIOC_QBUF, &buf);
        if (ret < 0) {
		perror("VIDIOC_QBUF");
            st_v4l2_capture_unmap_close_display_interface();
            return FAILURE;
        }
    }

    if (ret != SUCCESS) {
        return FAILURE;
    }
    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_capture_close_interface
 * Functionality        - This function closes the device instance
 * Input Params         - Capture device
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
void st_v4l2_capture_close_interface(int dev)
{
    if (V4L2_DEV0 == dev) {
        close(fd_dev0);
    }
}

/****************************************************************************
 * Function             - st_v4l2_capture_unmap_buffers_interface
 * Functionality        - This function unmaps buffers
 * Input Params         - None
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/
void st_v4l2_capture_unmap_buffers_interface(void)
{
    int i;

    for (i = 0; i < numbufs; i++) {
        munmap(st_capture_buff_info[i].start,
               st_capture_buff_info[i].length);
        st_capture_buff_info[i].start = NULL;
    }

}

/****************************************************************************
 * Function             - st_v4l2_capture_query_mmap_que_buffers_interface
 * Functionality        - This function requests queries the physical address of buffers, maps
                                 them in user space and enqueues them
 * Input Params         - Capture device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_query_mmap_que_buffers_interface(int dev)
{
    int i, ret = SUCCESS;

    if (V4L2_DEV0 == dev) {
        for (i = 0; i < numbufs; i++) {

            st_buf.type = st_reqbufs.type;
            st_buf.index = i;
            st_buf.memory = st_reqbufs.memory;


            ret = ioctl(fd_dev0, VIDIOC_QUERYBUF, &st_buf);

            if (SUCCESS != ret) {
				perror("VIDIOC_QUERYBUF");
                return QUERYBUF_FAILED;
            }

            st_capture_buff_info[i].length = st_buf.length;
            st_capture_buff_info[i].index = i;
            st_capture_buff_info[i].start =
                mmap(NULL, st_buf.length, PROT_READ | PROT_WRITE,
                     MAP_SHARED, fd_dev0, st_buf.m.offset);

            if (st_capture_buff_info[i].start == MAP_FAILED) {
                return MMAP_FAILED;
            }

            memset((void *) st_capture_buff_info[i].start, 0x80,
                   st_capture_buff_info[i].length);

            ret = ioctl(fd_dev0, VIDIOC_QBUF, &st_buf);

        }
    }

    if (ret != SUCCESS) {
		perror("VIDIOC_QBUF");
        return FAILURE;
    }
    return SUCCESS;
}
/****************************************************************************
 * Function             - st_v4l2_capture_query_mmap_que_buffers_userptr_interface
 * Functionality        - This function requests queries the physical address of buffers, maps
                                 them in user space and enqueues them
 * Input Params         - Capture device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_query_mmap_que_buffers_userptr_interface(int dev)
{
    int i, ret = SUCCESS;

    if (V4L2_DEV0 == dev) {
        for (i = 0; i < numbufs; i++) {

            st_capture_buff_info[i].length = st_buf.length;
            st_capture_buff_info[i].index = i;
            st_capture_buff_info[i].start = st_display2_buff_info[i].start;

            if (st_capture_buff_info[i].start == MAP_FAILED) {
                return MMAP_FAILED;
            }

            memset((void *) st_capture_buff_info[i].start, 0x80,
                   st_capture_buff_info[i].length);

            st_buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
            st_buf.index = i;
            st_buf.memory = st_reqbufs.memory;
            st_buf.m.userptr = (unsigned int)st_capture_buff_info[i].start;

            ret = ioctl(fd_dev0, VIDIOC_QUERYBUF, &st_buf);

            if (SUCCESS != ret) {
			perror("VIDIOC_QUERYBUF");
                return QUERYBUF_FAILED;
            }

            ret = ioctl(fd_dev0, VIDIOC_QBUF, &st_buf);

        }
    }

    if (ret != SUCCESS) {
		perror("VIDIOC_QBUF");
        return FAILURE;
    }
    return SUCCESS;
}
/****************************************************************************
 * Function             - st_v4l2_capture_clear_buffers_interface
 * Functionality        - This function clears buffers
 * Input Params         - None
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/
void st_v4l2_capture_clear_buffers_interface(void)
{
    int i;

    memset(&st_buf, 0, sizeof(st_buf));

    for (i = 0; i < MAX_BUFFER; i++) {
        st_capture_buff_info[i].start = NULL;
    }

    for (i = 0; i < MAX_BUFFER; i++) {
        st_display_buff_info[i].start = NULL;
    }
}


/****************************************************************************
 * Function             - st_v4l2_capture_request_buffers_interface
 * Functionality        - This function requests for buffers
 * Input Params         - Capture device number, number of buffers, exchange mechanism
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_request_buffers_interface(int dev, int n_buffers,
                                              int buf_xchg)
{
    int ret = SUCCESS;

    st_reqbufs.count = n_buffers;
    st_reqbufs.type = BUF_TYPE_VIDEO_CAPTURE;

    if (buf_xchg == BUFFER_XCHG_MMAP) {
        st_reqbufs.memory = MEMORY_MMAP;
    } else {
        return XCHG_NOT_SUPPORTED;
    }

    if (V4L2_DEV0 == dev) {
        ret = ioctl(fd_dev0, VIDIOC_REQBUFS, &st_reqbufs);
    }

    numbufs = st_reqbufs.count;

    if (ret < 0) {
	    perror("VIDIOC_REQBUFS");
        return FAILURE;
    }
    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_capture_request_buffers_userptr_interface
 * Functionality        - This function requests for buffers
 * Input Params         - Capture device number, number of buffers, exchange mechanism
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_request_buffers_userptr_interface(int dev, int n_buffers,
                                              int buf_xchg)
{
    int ret = SUCCESS;

    st_reqbufs.count = n_buffers;
    st_reqbufs.type = BUF_TYPE_VIDEO_CAPTURE;
    st_reqbufs.memory = V4L2_MEMORY_USERPTR;

    if (V4L2_DEV0 == dev) {
        ret = ioctl(fd_dev0, VIDIOC_REQBUFS, &st_reqbufs);
    }

    numbufs = st_reqbufs.count;

    if (ret < 0) {
	perror("VIDIOC_REQBUFS");
        return FAILURE;
    }
    memset(&st_buf, 0, sizeof(st_buf));
    return SUCCESS;
}


/****************************************************************************
 * Function             - st_v4l2_capture_get_format_interface
 * Functionality        - This function gets the format
 * Input Params         - Capture device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_get_format_interface(int dev)
{
    int ret = SUCCESS;
    st_format.type = BUF_TYPE_VIDEO_CAPTURE;

    if (V4L2_DEV0 == dev) {
        ret = ioctl(fd_dev0, VIDIOC_G_FMT, &st_format);
    }

    common_pix = st_format.fmt.pix.pixelformat;

    if (st_format.fmt.pix.pixelformat != pixelfmt) {
        return FORMAT_NOT_SUPPORTED;
    }

    if (SUCCESS != ret) {
		perror("VIDIOC_G_FMT");
        return FAILURE;
    }

    return SUCCESS;
}


/****************************************************************************
 * Function             - st_v4l2_capture_set_format_interface
 * Functionality        - This function sets the format
 * Input Params         - Capture device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_set_format_interface(int dev)
{
    int ret = SUCCESS;

    st_format.type = BUF_TYPE_VIDEO_CAPTURE;
    if (V4L2_DEV0 == dev) {
        ret = ioctl(fd_dev0, VIDIOC_G_FMT, &st_format);
    }
    st_format.fmt.pix.pixelformat = pixelfmt;
    if (V4L2_DEV0 == dev) {
        ret = ioctl(fd_dev0, VIDIOC_S_FMT, &st_format);
    }

    if (SUCCESS != ret) {
	perror("VIDIOC_S_FMT");
        return FAILURE;
    }
    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_capture_chk_capability_interface
 * Functionality        - This function checks if the capture device is capable of streaming
 * Input Params         - Capture device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_chk_capability_interface(int dev)
{
    int ret = SUCCESS;


    if (V4L2_DEV0 == dev) {
        ret = ioctl(fd_dev0, VIDIOC_QUERYCAP, &st_capability);
    }

    if (st_capability.capabilities & V4L2_CAP_STREAMING)
        cap_support = TRUE;
    else
        cap_support = FALSE;

    if (SUCCESS != ret) {
		perror("VIDIOC_QUERYCAP");
        return FAILURE;
    }
    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_capture_enum_std_interface
 * Functionality        - This function enumerates the std
 * Input Params         - Capture device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_enum_std_interface(int dev)
{
    int ret = SUCCESS;
    st_standard.index = 0;

    while (1) {

        if (V4L2_DEV0 == dev) {
            ret = ioctl(fd_dev0, VIDIOC_ENUMSTD, &st_standard);
        }
        if (st_standard.id & st_std_id)
            break;
        st_standard.index++;

    }

    if (SUCCESS != ret) {
		perror("VIDIOC_ENUMSTD");
        return FAILURE;
    }
    strcpy(common_char, st_standard.name);
    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_capture_get_std_interface
 * Functionality        - This function gets the current std in the decoder
 * Input Params         - Capture device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_get_std_interface(int dev)
{
    int ret = SUCCESS;

    if (V4L2_DEV0 == dev) {
        ret = ioctl(fd_dev0, VIDIOC_G_STD, &st_std_id);
    }

    if (SUCCESS != ret) {
		perror("VIDIOC_G_STD");
        return FAILURE;
    }
    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_capture_querystd_interface
 * Functionality        - This function detects current video std
 * Input Params         - Capture device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_querystd_interface(int dev)
{
    int ret = SUCCESS;

    if (V4L2_DEV0 == dev) {
        ret = ioctl(fd_dev0, VIDIOC_QUERYSTD, &st_std_id);
    }

    if (SUCCESS != ret) {
		perror("VIDIOC_QUERYSTD");
        return FAILURE;
    }
    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_capture_set_standard_number
 * Functionality        - Function sets standard number for a standard string
 * Input Params         - standard name
 * Note                 - None
 ****************************************************************************/
void st_v4l2_capture_set_standard_number(char *std_name, int *st_std)
{
    if (!strcmp(std_name, STD_NTSC)) {
        *st_std = NTSC_STD;
    }
    if (!strcmp(std_name, STD_PAL)) {
        *st_std = PAL_STD;
    }
}


/****************************************************************************
 * Function             - st_v4l2_capture_enum_input_interface
 * Functionality        - This function enumerates V4L2 Capture interface
 * Input Params         - Capture device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_enum_input_interface(int dev)
{
    int ret = SUCCESS;

    if (V4L2_DEV0 == dev) {
        ret = ioctl(fd_dev0, VIDIOC_ENUMINPUT, &st_ip);
    }

    if (SUCCESS != ret) {
		perror("VIDIOC_ENUMINPUT");
        return FAILURE;
    }
    strcpy(common_char, st_ip.name);
    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_capture_get_input_interface
 * Functionality        - This function gets V4L2 Capture interface
 * Input Params         - Capture device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_get_input_interface(int dev)
{
    int ret = SUCCESS;
    int index;

    if (V4L2_DEV0 == dev) {
        ret = ioctl(fd_dev0, VIDIOC_G_INPUT, &index);
    }

    if (SUCCESS != ret) {
		perror("VIDIOC_G_INPUT");
        return FAILURE;
    }
    st_ip.index = index;
    common_int = index;
    return SUCCESS;
}


/****************************************************************************
 * Function             - st_v4l2_capture_set_input_interface
 * Functionality        - This function gets V4L2 Capture interface
 * Input Params         - Capture device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_set_input_interface(int dev)
{
    int ret = SUCCESS;
int index = inter;

    if (V4L2_DEV0 == dev) {
        ret = ioctl(fd_dev0, VIDIOC_S_INPUT, &index);
    }

    if (SUCCESS != ret) {
		perror("VIDIOC_S_INPUT");
        return FAILURE;
    }
    st_ip.index = index;
    common_int = index;
    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_capture_enum_format_interface
 * Functionality        - This function gets V4L2 format
 * Input Params         - Capture device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - NonE
 ****************************************************************************/
int st_v4l2_capture_enum_format_interface(int dev,struct st_v4l2_fmtdesc *st_fmt)
{

    int ret = SUCCESS;
  //struct st_v4l2_fmtdesc fmt;

  //  st_fmt.index=0;

    if (V4L2_DEV0 == dev) {

        ret = ioctl(fd_dev0, VIDIOC_ENUM_FMT, st_fmt);
    }

    if (SUCCESS != ret) {
		perror("VIDIOC_ENUM_FMT");
        return FAILURE;
    }

    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_validate_format_interface
 * Functionality        - This function Validates  the format parameterst
 * Input Params         - Capture device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_validate_format_interface(int dev)
{

    int ret = SUCCESS;
	struct v4l2_format validate_fmt;



	/*Fill in some default values for the structure that is passed*/
	validate_fmt.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
	validate_fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_UYVY;
	validate_fmt.fmt.pix.sizeimage = DEFAULT_IMAGE_SIZE;
	validate_fmt.fmt.pix.bytesperline = DEFAULT_BYTES_PER_LINE;
	validate_fmt.fmt.pix.field = V4L2_FIELD_INTERLACED;

    if (V4L2_DEV0 == dev) {

        ret = ioctl(fd_dev0, VIDIOC_TRY_FMT, &validate_fmt);
    }

    if (SUCCESS != ret) {
		perror("VIDIOC_ENUM_FMT");
        return FAILURE;
    }

    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_query_contrast_interface
 * Functionality        - This function queries the controls information
 * Input Params         - Capture device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_query_contrast_interface(int dev,struct st_v4l2_queryctrl *st_ctrl)
{

    int ret = SUCCESS;
	struct st_v4l2_queryctrl qctrl;
	/*Fill in some default values for the structure that is passed*/
	qctrl.id=V4L2_CID_CONTRAST;


    if (V4L2_DEV0 == dev) {

        ret = ioctl(fd_dev0, VIDIOC_QUERYCTRL, &qctrl);
    }

    if (SUCCESS != ret) {
		perror("VIDIOC_QUERYCTRL");
        return FAILURE;
    }
	else
	{
		strcpy((char *)(st_ctrl->name),(char *)(qctrl.name));
		st_ctrl->minimum = qctrl.minimum;
		st_ctrl->maximum = qctrl.maximum;
		st_ctrl->default_value = qctrl.default_value;
	}

    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_query_brightness_interface
 * Functionality        - This function queries the controls information
 * Input Params         - Capture device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_query_brightness_interface(int dev,struct st_v4l2_queryctrl *st_ctrl)
{

    int ret = SUCCESS;
	struct st_v4l2_queryctrl qctrl;
	/*Fill in some default values for the structure that is passed*/
	qctrl.id=V4L2_CID_BRIGHTNESS;


    if (V4L2_DEV0 == dev) {

        ret = ioctl(fd_dev0, VIDIOC_QUERYCTRL, &qctrl);
    }

    if (SUCCESS != ret) {
		perror("VIDIOC_QUERYCTRL");
        return FAILURE;
    }
	else
	{
         	strcpy((char *)(st_ctrl->name),(char *)(qctrl.name));
		st_ctrl->minimum = qctrl.minimum;
		st_ctrl->maximum = qctrl.maximum;
		st_ctrl->default_value = qctrl.default_value;
	}

    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_query_HUE_interface
 * Functionality        - This function queries the controls information
 * Input Params         - Capture device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_query_hue_interface(int dev,struct st_v4l2_queryctrl *st_ctrl)
{

    int ret = SUCCESS;
	struct st_v4l2_queryctrl qctrl;
	/*Fill in some default values for the structure that is passed*/
	qctrl.id=V4L2_CID_HUE;


    if (V4L2_DEV0 == dev) {

        ret = ioctl(fd_dev0, VIDIOC_QUERYCTRL, &qctrl);
    }

    if (SUCCESS != ret) {
		perror("VIDIOC_QUERYCTRL");
        return FAILURE;
    }
	else
	{
         	strcpy((char *)(st_ctrl->name),(char *)(qctrl.name));
		st_ctrl->minimum = qctrl.minimum;
		st_ctrl->maximum = qctrl.maximum;
		st_ctrl->default_value = qctrl.default_value;
	}

    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_query_saturation_interface
 * Functionality        - This function queries the controls information
 * Input Params         - Capture device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_query_saturation_interface(int dev,struct st_v4l2_queryctrl *st_ctrl)
{

    int ret = SUCCESS;
	struct st_v4l2_queryctrl qctrl;
	/*Fill in some default values for the structure that is passed*/
	qctrl.id=V4L2_CID_SATURATION;


    if (V4L2_DEV0 == dev) {

        ret = ioctl(fd_dev0, VIDIOC_QUERYCTRL, &qctrl);
    }

    if (SUCCESS != ret) {
		perror("VIDIOC_QUERYCTRL");
        return FAILURE;
    }
	else
	{
        	strcpy((char *)(st_ctrl->name),(char *)(qctrl.name));
		st_ctrl->minimum = qctrl.minimum;
		st_ctrl->maximum = qctrl.maximum;
		st_ctrl->default_value = qctrl.default_value;
	}

    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_query_autogain_interface
 * Functionality        - This function queries the controls information
 * Input Params         - Capture device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_query_autogain_interface(int dev,struct st_v4l2_queryctrl *st_ctrl)
{

    int ret = SUCCESS;
	struct st_v4l2_queryctrl qctrl;
	/*Fill in some default values for the structure that is passed*/
	qctrl.id=V4L2_CID_AUTOGAIN;


    if (V4L2_DEV0 == dev) {

        ret = ioctl(fd_dev0, VIDIOC_QUERYCTRL, &qctrl);
    }

    if (SUCCESS != ret) {
		perror("VIDIOC_QUERYCTRL");
        return FAILURE;
    }
	else
	{
        	strcpy((char *)(st_ctrl->name),(char *)(qctrl.name));
		st_ctrl->minimum = qctrl.minimum;
		st_ctrl->maximum = qctrl.maximum;
		st_ctrl->default_value = qctrl.default_value;
	}

    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_set_contrast_interface
 * Functionality        - This IOCTL is used to set the value for a particular
 * control in current decoder.
 * Input Params         - Capture device number,control structure
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_set_contrast_interface(int dev,struct st_v4l2_control st_ctrl)
{
    int ret = SUCCESS;
	st_ctrl.id=V4L2_CID_CONTRAST;

    if (V4L2_DEV0 == dev) {
        ret = ioctl(fd_dev0, VIDIOC_S_CTRL, &st_ctrl);
    }

    if (SUCCESS != ret) {
		perror("VIDIOC_S_CTRL");
        return FAILURE;
    }
    return SUCCESS;
}
/****************************************************************************
 * Function             - st_v4l2_set_brightness_interface
 * Functionality        - This IOCTL is used to set the value for a particular
 * control in current decoder.
 * Input Params         - Capture device number,control structure
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_set_brightness_interface(int dev,struct st_v4l2_control st_ctrl)
{
    int ret = SUCCESS;
	st_ctrl.id=V4L2_CID_BRIGHTNESS;

    if (V4L2_DEV0 == dev) {
        ret = ioctl(fd_dev0, VIDIOC_S_CTRL, &st_ctrl);
    }

    if (SUCCESS != ret) {
		perror("VIDIOC_S_CTRL");
        return FAILURE;
    }
    return SUCCESS;
}
/****************************************************************************
 * Function             - st_v4l2_set_hue_interface
 * Functionality        - This IOCTL is used to set the value for a particular
 * control in current decoder.
 * Input Params         - Capture device number,control structure
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_set_hue_interface(int dev,struct st_v4l2_control st_ctrl)
{
    int ret = SUCCESS;
	st_ctrl.id=V4L2_CID_HUE;

    if (V4L2_DEV0 == dev) {
        ret = ioctl(fd_dev0, VIDIOC_S_CTRL, &st_ctrl);
    }

    if (SUCCESS != ret) {
		perror("VIDIOC_S_CTRL");
        return FAILURE;
    }
    return SUCCESS;
}
/****************************************************************************
 * Function             - st_v4l2_set_saturation_interface
 * Functionality        - This IOCTL is used to set the value for a particular
 * control in current decoder.
 * Input Params         - Capture device number,control structure
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_set_saturation_interface(int dev,struct st_v4l2_control st_ctrl)
{
    int ret = SUCCESS;
	st_ctrl.id=V4L2_CID_SATURATION;

    if (V4L2_DEV0 == dev) {
        ret = ioctl(fd_dev0, VIDIOC_S_CTRL, &st_ctrl);
    }

    if (SUCCESS != ret) {
		perror("VIDIOC_S_CTRL");
        return FAILURE;
    }
    return SUCCESS;
}
/****************************************************************************
 * Function             - st_v4l2_set_autogain_interface
 * Functionality        - This IOCTL is used to set the value for a particular
 * control in current decoder.
 * Input Params         - Capture device number,control structure
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_set_autogain_interface(int dev,struct st_v4l2_control st_ctrl)
{
    int ret = SUCCESS;
	st_ctrl.id=V4L2_CID_AUTOGAIN;

    if (V4L2_DEV0 == dev) {
        ret = ioctl(fd_dev0, VIDIOC_S_CTRL, &st_ctrl);
    }

    if (SUCCESS != ret) {
		perror("VIDIOC_S_CTRL");
        return FAILURE;
    }
    return SUCCESS;
}
/****************************************************************************
 * Function             - st_v4l2_get_contrast_interface
 * Functionality        - This IOCTL is used to get the value for a particular
 * control in current decoder.
 * Input Params         - Capture device number,control structure
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_get_contrast_interface(int dev,struct st_v4l2_control *g_ctrl)
{
    int ret = SUCCESS;
    struct st_v4l2_control ctrl;

	ctrl.id=V4L2_CID_CONTRAST;
    if (V4L2_DEV0 == dev) {
        ret = ioctl(fd_dev0, VIDIOC_G_CTRL, &ctrl);
    }

    if (SUCCESS != ret) {
		perror("VIDIOC_G_CTRL");
        return FAILURE;
    }
    g_ctrl->value = ctrl.value;

    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_get_brightness_interface
 * Functionality        - This IOCTL is used to get the value for a particular
 * control in current decoder.
 * Input Params         - Capture device number,control structure
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/

int st_v4l2_get_brightness_interface(int dev,struct st_v4l2_control *g_ctrl)
{
    int ret = SUCCESS;
    struct st_v4l2_control ctrl;

	ctrl.id=V4L2_CID_BRIGHTNESS;
    if (V4L2_DEV0 == dev) {
        ret = ioctl(fd_dev0, VIDIOC_G_CTRL, &ctrl);
    }

    if (SUCCESS != ret) {
		perror("VIDIOC_G_CTRL");
        return FAILURE;
    }
    g_ctrl->value = ctrl.value;

    return SUCCESS;

}

/****************************************************************************
 * Function             - st_v4l2_get_hue_interface
 * Functionality        - This IOCTL is used to get the value for a particular
 * control in current decoder.
 * Input Params         - Capture device number,control structure
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/

int st_v4l2_get_hue_interface(int dev,struct st_v4l2_control *g_ctrl)
{
    int ret = SUCCESS;
    struct st_v4l2_control ctrl;

	ctrl.id=V4L2_CID_HUE;
    if (V4L2_DEV0 == dev) {
        ret = ioctl(fd_dev0, VIDIOC_G_CTRL, &ctrl);
    }

    if (SUCCESS != ret) {
		perror("VIDIOC_G_CTRL");
        return FAILURE;
    }
    g_ctrl->value = ctrl.value;

    return SUCCESS;

}

/****************************************************************************
 * Function             - st_v4l2_get_saturation_interface
 * Functionality        - This IOCTL is used to get the value for a particular
 * control in current decoder.
 * Input Params         - Capture device number,control structure
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/

int st_v4l2_get_saturation_interface(int dev,struct st_v4l2_control *g_ctrl)
{
    int ret = SUCCESS;
    struct st_v4l2_control ctrl;

	ctrl.id=V4L2_CID_SATURATION;
    if (V4L2_DEV0 == dev) {
        ret = ioctl(fd_dev0, VIDIOC_G_CTRL, &ctrl);
    }

    if (SUCCESS != ret) {
		perror("VIDIOC_G_CTRL");
        return FAILURE;
    }
    g_ctrl->value = ctrl.value;

    return SUCCESS;

}

/****************************************************************************
 * Function             - st_v4l2_get_AUTOGAIN_interface
 * Functionality        - This IOCTL is used to get the value for a particular
 * control in current decoder.
 * Input Params         - Capture device number,control structure
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/

int st_v4l2_get_autogain_interface(int dev,struct st_v4l2_control *g_ctrl)
{
    int ret = SUCCESS;
    struct st_v4l2_control ctrl;

	ctrl.id=V4L2_CID_AUTOGAIN;
    if (V4L2_DEV0 == dev) {
        ret = ioctl(fd_dev0, VIDIOC_G_CTRL, &ctrl);
    }

    if (SUCCESS != ret) {
		perror("VIDIOC_G_CTRL");
        return FAILURE;
    }
    g_ctrl->value = ctrl.value;

    return SUCCESS;

}

/****************************************************************************
 * Function             - st_v4l2_capture_set_interface_number
 * Functionality        - Function sets interface number for a interface string
 * Input Params         - interface name
 * Note                 - None
 ****************************************************************************/
void st_v4l2_capture_set_interface_number(char *ifc_name, int *st_ifc)
{
    if (!strcmp(ifc_name, INTERFACE_COMPOSITE)) {
        *st_ifc = COMPOSITE_IFC;
    }
    else if (!strcmp(ifc_name, INTERFACE_SVIDEO)) {
        *st_ifc = SVIDEO_IFC;
    }
    else {
        *st_ifc = COMPOSITE_IFC;
    }

inter = *st_ifc;
}

/****************************************************************************
 * Function             - st_v4l2_capture_open_nonblock_interface
 * Functionality        - This function opens V4L2 capture window in non
 *                        blocking mode(not supported on OMAP35x)
 * Input Params         - V4L2 Capture device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_open_nonblock_interface(int dev)
{
    return MODE_NOT_SUPPORTED;
}

/****************************************************************************
 * Function             - st_v4l2_capture_open_interface
 * Functionality        - This function opens V4L2 Capture device
 * Input Params         - V4L2 Capture device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_open_interface(int dev)
{
    int ret = SUCCESS;

    if (V4L2_DEV0 == dev) {
        fd_dev0 = open(VID0_DEVICE, O_RDWR);
        ret = fd_dev0;
    } else
        return DEV_NONEXISTENT;

    if (0 >= ret)
        return FAILURE;

    return SUCCESS;
}


/****************************************************************************
 * Function             - st_v4l2_capture_set_device_number
 * Functionality        - Function sets device number for a device string
 * Input Params         - device name
 * Note                 - None
 ****************************************************************************/
void st_v4l2_capture_set_device_number(char *dev_name, int *st_dev)
{
    if (!strcmp(dev_name, VID0_DEVICE)) {
        *st_dev = V4L2_DEV0;
    } else
        *st_dev = FAILURE;
}


/****************************************************************************
 * Function             - st_v4l2_capture_print_test_params
 * Functionality        - This function prints the test option values
 * Input Params         - Test params structure
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/
void st_v4l2_capture_print_test_params(struct st_v4l2_capture_testparams
                                       *test_options,char *testcaseid)
{
    DBG_PRINT_TST_START((testcaseid));
    DBG_PRINT_TRC0(("The Test is going to start with following values"));
    DBG_PRINT_TRC0(("The device node | %s", test_options->device));
    DBG_PRINT_TRC0(("The number of buffers | %d",
                    test_options->n_buffers));
    DBG_PRINT_TRC0(("The number of frames | %d", test_options->n_frames));
    DBG_PRINT_TRC0(("The standard | %s", test_options->std));
    DBG_PRINT_TRC0(("The capture interface | %s",
                    test_options->c_interfac));
    DBG_PRINT_TRC0(("The display interface | %s",
                    test_options->d_interfac));
    DBG_PRINT_TRC0(("The pixel format | %s", test_options->pix_fmt));
    if (test_options->display == TRUE) {
        DBG_PRINT_TRC0(("The write option is disabled"));
    } else {
        DBG_PRINT_TRC0(("The write option is enabled"));
        DBG_PRINT_TRC0(("The writefilename | %s", test_options->f_name));
        DBG_PRINT_TRC0(("The frame to be written | %d",
                        test_options->f_write));
    }
}

/****************************************************************************
 * Function             - st_v4l2_capture_test_suite_help
 * Functionality        - This function displays the help/usage
 * Input Params         - None
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/
void st_v4l2_capture_test_suite_help(void)
{
    printf("v4l2CaptureTestSuite V %s\n", VERSION_STRING);
        printf("Usage:\n"
           "./am3517_V4l2_capture_tests <options>\n\n"
           "-d       --devicenode       Device node on which capture test is to be run\n"
           "\t\t\t\tPossible values-/dev/video0\n"
           "-c       --countofbuffers   Number of buffers to queue\n"
           "-n       --noofframes       Number of frames to be captured\n"
           "-s       --standard         Name of the standard\n"
           "\t\t\t\tPossible values-NTSC, PAL\n"
           "-i       --captureinterface Name of the capture interface\n"
           "\t\t\t\tPossible values-COMPOSITE, SVIDEO\n"
           "-p       --pixelformat      Pixel formats\n"
           "\t\t\t\tPossible values-YUYV,UYVY\n"
           "-B       --brightness      Brightness control value\n"
           "\t\t\t\tPossible values-0 to 255\n"
           "-C       --contrast        Contrast control value\n"
           "\t\t\t\tPossible values-0 to 255\n"
           "-S       --saturation      Saturation control value\n"
           "\t\t\t\tPossible values-0 to 255\n"
           "-H       --hue             Hue control value\n"
           "\t\t\t\tPossible values-(-180 to 180)\n"
           "-G       --autogain        Autogain control value\n"
           "\t\t\t\tPossible values-0 or 1\n"
           "-P       --stabilitycount  Stability count\n"
           "-D       --displayorwrite  Display/write option\n"
           "\t\t\t\tPossible values-0 (write) or 1(display)\n"
           "-f       --filename        Name of the image file to write to\n"
           "\t\t\t\t Make sure the -D option is set to 0\n"
           "-W       --writeframe      Particular frame number to capture and write\n"
           "\t\t\t\t Make sure it is less than -n (noofframes)\n"
           "-T       --testname        Name of the special test\n"
           "\t\t\t\tPossible values-stability, stress, ioctl\n"
           "-t       --testcaseid      Test case id string for testers reference/logging purpose\n"
           "\t\t\t\tPossible values- Any String without spaces\n"
           "-F       --framerate       Displays the Frame rate in fps(frames per second)\n"
           "-l       --cpuload         Displays the cpu load in percentage\n"
           "-I       --ioctl_no        Give IOCTL number for IOCTL test\n"
           "\t\t\t\tPossible values-0:G_INPUT/ENUM_INPUT, 1:G_INPUT/ENUM_INPUT/S_INPUT, 2:G_STD/ENUM_STD/QUERYSTD, 3:G_FMT/S_FMT, 4:ENUM_FMT, 5: CNTRL(need -j option to pass)\n"
           "-j       --case_no        Give IOCTL number 5 for CNTRL IOCTL test\n"
           "\t\t\t\tPossible values-0:Contrast, 1:Brightness, 2:Hue, 3:Saturation, 4:Autogain (Please specify values accordingly with C,B,H,S,G option stated above)\n"
           "-L       --loopcount       Loopcount for IOCTL test\n"
           "-?       --help            Displays the help/usage\n"
           "-v       --version         Version of Capture Test suite\n");
    exit(0);
}


/****************************************************************************
 * Function             - st_v4l2_capture_chk_ifc
 * Functionality        - This function checks the user input
 * Input Params         - None
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_chk_ifc()
{
    int flag = FALSE;

    if ((strcmp(test_options.c_interfac, "COMPOSITE") != 0)
        && (strcmp(test_options.c_interfac, "SVIDEO") != 0)) {
        DBG_PRINT_ERR(("Wrong capture interface entered- Please enter either COMPOSITE or SVIDEO\n"));
        flag = TRUE;
    }

    if (TRUE == flag)
        return FAILURE;
    else
        return SUCCESS;

}


/****************************************************************************
 * Function             - st_v4l2_capture_chk_std
 * Functionality        - This function checks the user input
 * Input Params         - None
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_chk_std()
{

    if ((strcmp(test_options.std, "NTSC") != 0)
        && (strcmp(test_options.std, "PAL") != 0)
        && (strcmp(test_options.std, "VGA") != 0)
        && (strcmp(test_options.std, "720P") != 0)
        && (strcmp(test_options.std, "480P") != 0)) {
        DBG_PRINT_ERR(("Wrong standard entered- Please enter either NTSC, PAL, VGA, 720P or 480P\n"));
        return FAILURE;
    }
    return SUCCESS;

}


/****************************************************************************
 * Function             - st_v4l2_capture_chk_pix_fmt
 * Functionality        - This function checks the user input
 * Input Params         - None
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_chk_pix_fmt()
{

    if (strcmp(test_options.pix_fmt, "RGB565") == 0) {
        pixelfmt = ST_PIX_FMT_RGB565;
    }

    else if (strcmp(test_options.pix_fmt, "YUYV") == 0) {
        pixelfmt = ST_PIX_FMT_YUYV;
    }

    else if (strcmp(test_options.pix_fmt, "UYVY") == 0) {
        pixelfmt = ST_PIX_FMT_UYVY;
    }

    else if (strcmp(test_options.pix_fmt, "RGB888") == 0) {
        pixelfmt = ST_PIX_FMT_RGB888;
    }

    else {
        DBG_PRINT_ERR(("Wrong format entered- Please enter either RGB565, YUYV, UYVY or RGB888\n"));
        return FAILURE;
    }
    return SUCCESS;
}

 /****************************************************************************
 * Function             - init_v4l2_capture_test_params
 * Functionality        - This function initilaizes the default values for
 * various test case options(which will be exposed as command line arguments)
 * Input Params         -  None
 * Return Value         -  None
 * Note                 -  None
 ****************************************************************************/
void st_v4l2_capture_init_test_params()
{
    test_options.device = DEFAULT_DEVICE;
    test_options.n_buffers = DEFAULT_NUM_BUFFERS;
    test_options.n_frames = DEFAULT_NUM_FRAMES;
    test_options.std = DEFAULT_STD;
    test_options.c_interfac = DEFAULT_INTERFACE;
    test_options.d_interfac = DEFAULT_INTERFACE_DISP;
    test_options.open_mode = DEFAULT_OPEN_MODE;
    test_options.width = DEFAULT_WIDTH;
    test_options.height = DEFAULT_HEIGHT;
    test_options.pix_fmt = DEFAULT_PIX_FMT;
    test_options.buf_xchange = DEFAULT_BUFFER_XCHG_MECHANISM;
    test_options.brightness = DEFAULT_BRIGHTNESS;
    test_options.contrast = DEFAULT_CONTRAST;
    test_options.saturation = DEFAULT_SATURATION;
    test_options.hue = DEFAULT_HUE;
    test_options.a_gain = DEFAULT_AUTO_GAIN;
    test_options.display = DEFAULT_OPT_DISPLAY;
    test_options.f_name = DEFAULT_FILENAME;
    test_options.f_write = DEFAULT_FRAME_WRITE;
    test_options.framerate = FALSE;
    test_options.cpuload = FALSE;
    test_options.userpointer = FALSE;
}
/****************************************************************************
 * Function             - st_v4l2_capture_init_display_video2_interface
 * Functionality        - This function initialises the display parameters for video 2 plane
 * Input Params         - No. of buffers
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_init_display_video2_interface(int n_bufs)
{
    int i, ret = SUCCESS;
    struct st_v4l2_requestbuffers reqbuf;
    struct v4l2_buffer buf;

    /* Open the video display device */
    fd_dev2 = open((const char *) VID2_DEVICE, O_RDWR);
    if (fd_dev2 <= 0) {
        return DISPLAY_OPEN_FAILED;
    }

    /* Get the format */
    st_display_format.type = BUF_TYPE_VIDEO_OUTPUT;
    ret = ioctl(fd_dev2, VIDIOC_G_FMT, &st_display_format);
    if (ret < 0) {
		perror("VIDIOC_G_FMT");
        close(fd_dev2);
        return FAILURE;
    }

    if (std_flag == NTSC_STD) {
        st_display_format.fmt.pix.width = WIDTH_NTSC;
        st_display_format.fmt.pix.height = HEIGHT_NTSC;
    } else if (std_flag == PAL_STD) {
        st_display_format.fmt.pix.width = WIDTH_PAL;
        st_display_format.fmt.pix.height = HEIGHT_PAL;
    }

    st_display_format.fmt.pix.pixelformat = pixelfmt;

    ret = ioctl(fd_dev2, VIDIOC_S_FMT, &st_display_format);
    if (ret < 0) {
		perror("VIDIOC_S_FMT");
        close(fd_dev2);
        return FAILURE;
    }

    ret = ioctl(fd_dev2, VIDIOC_G_FMT, &st_display_format);
    if (ret < 0) {
		perror("VIDIOC_G_FMT");
        close(fd_dev2);
        return FAILURE;
    }

    if (st_display_format.fmt.pix.pixelformat != pixelfmt) {
        close(fd_dev2);
        return FAILURE;
    }

    /* Buffer allocation */
    reqbuf.count = n_bufs;
    reqbuf.type = V4L2_BUF_TYPE_VIDEO_OUTPUT;
    reqbuf.memory = V4L2_MEMORY_MMAP;
    ret = ioctl(fd_dev2, VIDIOC_REQBUFS, &reqbuf);
    if (ret < 0) {
	    perror("VIDIOC_REQBUFS");
        close(fd_dev2);
        return FAILURE;
    }

    /* Store the numbfer of buffers allocated */
    d_numbufs = reqbuf.count;

    memset(&buf, 0, sizeof(buf));

    for (i = 0; i < MAX_BUFFER; i++) {
        st_display2_buff_info[i].start = NULL;
    }

    /* Mmap the buffers */
    for (i = 0; i < d_numbufs; i++) {

        /* Query physical address of the buffers */
        buf.type = reqbuf.type;
        buf.index = i;
        buf.memory = reqbuf.memory;
        ret = ioctl(fd_dev2, VIDIOC_QUERYBUF, &buf);
        if (ret < 0) {
	    perror("VIDIOC_QUERYBUF");
            close(fd_dev2);
            return FAILURE;
        }

        /* Mmap the buffers in application space */
        st_display2_buff_info[i].length = buf.length;
        st_display2_buff_info[i].index = i;
        st_display2_buff_info[i].start =
            mmap(NULL, buf.length, PROT_READ | PROT_WRITE, MAP_SHARED,
                 fd_dev2, buf.m.offset);

        if (st_display2_buff_info[i].start == MAP_FAILED) {
            st_v4l2_capture_unmap_close_display_interface();
            return FAILURE;
        }
        memset((void *) st_display2_buff_info[i].start, 0x80,
               st_display_buff_info[i].length);

    }

    if (ret != SUCCESS) {
        return FAILURE;
    }
    return SUCCESS;
}


/* vi: set ts=4 sw=4 tw=80 et:*/
