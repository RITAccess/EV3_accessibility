/*
 * st_v4l2_capture_interface.c
 *
 * This file calls V4L2 Capture driver functions and takes parameters given 
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/ 
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/


 /* V4L2 Capture structs, enums, macros defined */
#include "st_v4l2_capture_common.h"

#define WIDTH_NTSC 720
#define HEIGHT_NTSC 480
#define WIDTH_PAL 720
#define HEIGHT_PAL 576

 /* Device nodes supported */
#define VID0_DEVICE "/dev/video0"
#define VID1_DEVICE "/dev/video1"
#define VID2_DEVICE "/dev/video2"
#define VID3_DEVICE "/dev/video3"
#define V4L2_DEV0 0
#define V4L2_DEV1 1
#define V4L2_DEV2 2
#define V4L2_DEV3 3


#define OSD0_DEVICE "/dev/fb/0"
#define OSD1_DEVICE "/dev/fb/2"

#define PREV_DEVICE "/dev/davinci_previewer"

/* Interfaces supported */
#define INTERFACE_COMPOSITE "COMPOSITE"
#define INTERFACE_SVIDEO "SVIDEO"
#define INTERFACE_COMPONENT "COMPONENT"

#define COMPOSITE_IFC 0
#define SVIDEO_IFC 2
#define COMPONENT_IFC 1

/*Buffer Exchange Mechanisms*/
#define BUFFER_XCHG_MMAP 1
#define BUFFER_XCHG_USERPTR 0

/*Display/Write Options*/
#define OPT_DISPLAY 1
#define OPT_WRITE 0

#define PIX_FMT_UYVY "UYVY"

 /* Macros- Default settings/values for capture */
#define DEFAULT_NUM_BUFFERS 3
#define DEFAULT_NUM_FRAMES  1000
#define DEFAULT_DEVICE VID0_DEVICE
#define DEFAULT_STD STD_NTSC
#define DEFAULT_INTERFACE INTERFACE_COMPOSITE
#define DEFAULT_INTERFACE_DISP INTERFACE_COMPOSITE
#define DEFAULT_OPEN_MODE BLOCKING_OPEN_MODE
#define DEFAULT_WIDTH WIDTH_NTSC
#define DEFAULT_HEIGHT HEIGHT_NTSC
#define DEFAULT_PIX_FMT PIX_FMT_UYVY
#define DEFAULT_BUFFER_XCHG_MECHANISM BUFFER_XCHG_MMAP
#define DEFAULT_BRIGHTNESS 128
#define DEFAULT_CONTRAST 128
#define DEFAULT_SATURATION 128
#define DEFAULT_HUE 0
#define DEFAULT_AUTO_GAIN 1
#define DEFAULT_OPT_DISPLAY OPT_DISPLAY
#define DEFAULT_FILENAME "v4l2_capture_out.yuv"
#define DEFAULT_FRAME_WRITE 100
#define STDPATH         "/sys/class/davinci_display/ch0/mode"

/*******************************************************************************
 *  STRUCTURE DEFINITIONS
 */
struct buff
{
    void *start;
    size_t length;
};


 /* Test case options structure */
struct st_v4l2_capture_testparams test_options;
struct st_v4l2_input st_ip;
v4l2_std_id st_std_id;
struct st_v4l2_standard st_standard;
struct st_v4l2_capability st_capability;
int cap_support;
unsigned int common_pix;
unsigned int common_int, numbufs, d_numbufs;
unsigned char common_char[32];
struct st_v4l2_format st_format, st_display_format;
struct st_v4l2_requestbuffers st_reqbufs;
struct v4l2_buffer st_buf, display_buf, capture_buf;
static struct st_buf_info st_capture_buff_info[MAX_BUFFER2];
static struct st_buf_info st_display_buff_info[MAX_BUFFER2];
int st_display_chroma_offset, st_capture_chroma_offset;
int st_capture_size;
int pixelfmt;
static struct v4l2_cropcap cropcap;
static struct buff *buffers, *d_buffers, vid1Buf[MAX_BUFFER2];;
static int disppitch, dispheight, dispwidth;
static int nWidthFinal, nHeightFinal;
struct st_v4l2_requestbuffers reqbuf;


extern int std_flag;
static unsigned char *cap_ptr, *dis_ptr, *displaybuffer, *capturebuffer;
char outputname[15], stdname[15];

/* v4l2_capture window file descriptors */
static int fd_dev0 = 0;

/* v4l2_capture window file descriptors */
static int fd_dev1 = 0;

/* v4l2_display window file descriptors */
static int fd_dev2 = 0;
static int fd_dev3 = 0;

static int fd_osd0, fd_osd1, fd;
extern int errno;

/* The control functions need to be implemented */
/****************************************************************************
 * Function             - st_v4l2_capture_set_autogain_interface
 * Functionality        - This function sets the autogain parameters
 * Input Params         - Capture device, control structure
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_set_autogain_interface(int dev,struct st_v4l2_control st_ctrl)
{
    return SUCCESS;
}


/****************************************************************************
 * Function             - st_v4l2_capture_get_autogain_interface
 * Functionality        - This function queries for the auto gain parameters
 * Input Params         - Capture device, control structure
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_get_autogain_interface(int dev,struct st_v4l2_control *st_ctrl)
{
    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_capture_set_hue_interface
 * Functionality        - This function sets the hue parameters
 * Input Params         - Capture device, control strucure
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_set_hue_interface(int dev,struct st_v4l2_control st_ctrl)
{

    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_capture_get_hue_interface
 * Functionality        - This function queries for the hue parameters
 * Input Params         - Capture device
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_get_hue_interface(int dev,struct st_v4l2_control *st_ctrl)
{
    return SUCCESS;
}
/****************************************************************************
 * Function             - st_v4l2_capture_set_saturation_interface
 * Functionality        - This function sets the saturation parameters
 * Input Params         - Capture device,control structure
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_set_saturation_interface(int dev,struct st_v4l2_control st_ctrl)
{
    return SUCCESS;
}


/****************************************************************************
 * Function             - st_v4l2_capture_get_saturation_interface
 * Functionality        - This function queries for the saturation parameters
 * Input Params         - Capture device, control structure
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_get_saturation_interface(int dev,struct st_v4l2_control *st_ctrl)
{
    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_capture_set_contrast_interface
 * Functionality        - This function sets the contrast parameters
 * Input Params         - Capture device, control structure
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_set_contrast_interface(int dev,struct st_v4l2_control st_ctrl)
{
    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_capture_get_contrast_interface
 * Functionality        - This function queries for the contrast parameters
 * Input Params         - Capture device,ctrl strucuure
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_get_contrast_interface(int dev,struct st_v4l2_control *st_ctrl)
{
    return SUCCESS;
}


/****************************************************************************
 * Function             - st_v4l2_capture_set_brightness_interface
 * Functionality        - This function sets the brightness parameters
 * Input Params         - Capture device,control structure
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_set_brightness_interface(int dev,struct st_v4l2_control st_ctrl)
{
    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_capture_get_brightness_interface
 * Functionality        - This function sets the brightness parameters
 * Input Params         - Capture device, control structure
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/

int st_v4l2_get_brightness_interface(int dev,struct st_v4l2_control *st_ctrl)
{
    return SUCCESS;
}
/****************************************************************************
 * Function             - st_v4l2_capture_query_saturation_interface
 * Functionality        - This function queries for the brightness parameters
 * Input Params         - Capture device,query control structure
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_query_saturation_interface(int dev,struct st_v4l2_queryctrl *qctrl)
{
    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_capture_query_hue_interface
 * Functionality        - This function queries for the hue parameters
 * Input Params         - Capture device,query control structure
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_query_hue_interface(int dev,struct st_v4l2_queryctrl *qctrl)
{
    return SUCCESS;
}
/****************************************************************************
 * Function             - st_v4l2_capture_query_contrast_interface
 * Functionality        - This function queries for the hue parameters
 * Input Params         - Capture device,query control structure
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_query_contrast_interface(int dev,struct st_v4l2_queryctrl *qctrl)
{
    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_capture_query_brightness_interface
 * Functionality        - This function queries for the hue parameters
 * Input Params         - Capture device,query control structure
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_query_brightness_interface(int dev,struct st_v4l2_queryctrl *qctrl)
{
    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_capture_query_autogain_interface
 * Functionality        - This function queries for the hue parameters
 * Input Params         - Capture device,query control structure
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_query_autogain_interface(int dev,struct st_v4l2_queryctrl *qctrl)
{
    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_capture_get_input_interface
 * Functionality        - This function queries for the hue parameters
 * Input Params         - Capture device
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_get_input_interface(int dev)
{
    return SUCCESS;
}



/****************************************************************************
 * Function             - st_v4l2_capture_write_image_interface
 * Functionality        - This function writesa frame of the image
 * Input Params         - Capture File name, Frame to write, frame being displayed
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_write_image_interface(char *fname, int frame,
                                          int cur_frame)
{
    FILE *fp;
    int i;

    cap_ptr = buffers[capture_buf.index].start;
    capturebuffer = cap_ptr;

    if (cur_frame == (frame - 1)) {
        fp = fopen(fname, "wb");
        if (fp == NULL)
            return FAILURE;
        for (i = 0; i < dispheight; i++) {
            fwrite(cap_ptr, disppitch, 1, fp);
            cap_ptr += disppitch;
        }
        fclose(fp);
    }

    cap_ptr = capturebuffer;
    dis_ptr = d_buffers[display_buf.index].start;
    displaybuffer = dis_ptr;

    /* Display image onto requested video window */
    for (i = 0; i < dispheight; i++) {
        memcpy(dis_ptr, cap_ptr, disppitch);
        cap_ptr += disppitch;
        dis_ptr += disppitch;
    }


    return SUCCESS;
}


/****************************************************************************
 * Function             - st_v4l2_capture_unmap_close_display_interface
 * Functionality        - This function unmaps display buffers and closes the device
 * Input Params         - None
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/
void st_v4l2_capture_unmap_close_display_interface(void)
{
    int j;
    for (j = 0; j < reqbuf.count; j++) {
        munmap(d_buffers[j].start, d_buffers[j].length);
        d_buffers[j].start = NULL;
    }
    close(fd_dev3);
    close(fd_osd0);
    close(fd_osd1);
    fd_dev3 = 0;
    fd_osd0 = 0;
    fd_osd1 = 0;
}

/****************************************************************************
 * Function             - st_v4l2_capture_streamoff_interface
 * Functionality        - This function streams off capture
 * Input Params         - Capture device
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_streamoff_interface(int dev)
{
    int ret = SUCCESS;
    enum v4l2_buf_type type;

    type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    if (V4L2_DEV0 == dev) {
        ret = ioctl(fd_dev0, VIDIOC_STREAMOFF, &type);
    }

    if (SUCCESS > ret) {
        return FAILURE;
    }
    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_capture_streamoff_display_interface
 * Functionality        - This function streams off display
 * Input Params         - None
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_streamoff_display_interface(void)
{
    int ret = SUCCESS;
    enum v4l2_buf_type type;

    type = V4L2_BUF_TYPE_VIDEO_OUTPUT;

    ret = ioctl(fd_dev3, VIDIOC_STREAMOFF, &type);
    if (ret < 0) {
        st_v4l2_capture_unmap_close_display_interface();
        return FAILURE;
    }
    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_capture_queue_display_interface
 * Functionality        - This function queues the capture buffer
 * Input Params         - Capture device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_queue_display_interface(void)
{
    int ret = SUCCESS, index = 0, i;
    struct v4l2_buffer d_buf;

    if (displaybuffer == NULL)

        return FAILURE;




    memset(&(d_buf), 0, sizeof(d_buf));

    /* Find index of the buffer whose address is passed as the argument */
    for (i = 0; i < DEFAULT_NUM_BUFFERS; i++) {

        if (displaybuffer == d_buffers[i].start) {

            index = i;
            break;
        }
    }



    d_buf.m.offset = (unsigned long) displaybuffer;
    d_buf.type = V4L2_BUF_TYPE_VIDEO_OUTPUT;
    d_buf.memory = V4L2_MEMORY_MMAP;
    d_buf.index = index;

    ret = ioctl(fd_dev3, VIDIOC_QBUF, &d_buf);
    if (ret < SUCCESS) {
        return FAILURE;
    }

    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_capture_queue_interface
 * Functionality        - This function queues the capture buffer
 * Input Params         - Capture device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_queue_interface(int dev)
{

    int ret = SUCCESS;


    if (V4L2_DEV0 == dev) {
        ret = ioctl(fd_dev0, VIDIOC_QBUF, &capture_buf);
    }

    if (ret < SUCCESS)

        return FAILURE;


    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_capture_process_image_interface
 * Functionality        - This function processes the image for displaying
 * Input Params         - None
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/
void st_v4l2_capture_process_image_interface(void)
{
    int i;


    cap_ptr = buffers[capture_buf.index].start;

    dis_ptr = d_buffers[display_buf.index].start;
    displaybuffer = dis_ptr;


    /* Display image onto requested video window */
    for (i = 0; i < dispheight; i++) {
        memcpy(dis_ptr, cap_ptr, disppitch);
        cap_ptr += disppitch;
        dis_ptr += disppitch;
    }



}

/****************************************************************************
 * Function             - st_v4l2_capture_dequeue_interface
 * Functionality        - This function dequeues the capture buffer
 * Input Params         - Capture device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_dequeue_interface(int dev)
{
    memset(&(capture_buf), 0, sizeof(capture_buf));
    capture_buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    capture_buf.memory = V4L2_MEMORY_MMAP;


    if (FAILURE == ioctl(fd_dev0, VIDIOC_DQBUF, &capture_buf)) {
        return FAILURE;
    }

    return SUCCESS;

}

/****************************************************************************
 * Function             - st_v4l2_capture_dequeue_display_interface
 * Functionality        - This function dequeues the display buffer
 * Input Params         - None
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_dequeue_display_interface(void)
{
    int ret = SUCCESS;



    memset(&(display_buf), 0, sizeof(display_buf));



    display_buf.type = V4L2_BUF_TYPE_VIDEO_OUTPUT;


    ret = ioctl(fd_dev3, VIDIOC_DQBUF, &display_buf);
    if (ret < SUCCESS) {
        st_v4l2_capture_unmap_close_display_interface();
        return FAILURE;
    }

    return SUCCESS;

}


/****************************************************************************
 * Function             - st_v4l2_capture_set_interface
 * Functionality        - This function sets the capture for queueing and dequeueing
 * Input Params         - None
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/
void st_v4l2_capture_set_interface(void)
{

}

/****************************************************************************
 * Function             - st_v4l2_capture_set_display_interface
 * Functionality        - This function sets the display for queueing and dequeueing
 * Input Params         - None
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/
void st_v4l2_capture_set_display_interface(void)
{

}

/****************************************************************************
 * Function             - st_v4l2_capture_streamon_interface
 * Functionality        - This function streams on capture
 * Input Params         - Capture device
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_streamon_interface(int dev)
{
    enum v4l2_buf_type type;
    type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    if (FAILURE == ioctl(fd_dev0, VIDIOC_STREAMON, &type))
        return FAILURE;
    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_capture_streamon_display_interface
 * Functionality        - This function streams on display
 * Input Params         - None
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_streamon_display_interface(void)
{

    int ret = SUCCESS;
    enum v4l2_buf_type type;

    type = V4L2_BUF_TYPE_VIDEO_OUTPUT;
    ret = ioctl(fd_dev3, VIDIOC_STREAMON, &type);
    if (ret < SUCCESS) {
        return FAILURE;
    }


    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_capture_init_display_interface
 * Functionality        - This function initialises the display parameters
 * Input Params         - No. of buffers
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_init_display_interface(int n_bufs)
{
    int i = 0, ret = SUCCESS;

    struct v4l2_buffer buf;
    char str[200];
    struct v4l2_fmtdesc format;
    struct v4l2_format setfmt;
    struct v4l2_capability capability;

    /* Set mode which is same as the one detected in the capture */
    strcpy(str, "echo ");
    if (st_std_id == V4L2_STD_NTSC)
        strcat(str, STD_NTSC);
    else
        strcat(str, STD_PAL);
    strcat(str, " > ");
    strcat(str, STDPATH);
    if (system(str)) {
        return SET_MODE_FAILED;
    }

    /* open osd0, osd1 devices and disable */
    fd_osd0 = open(OSD0_DEVICE, O_RDWR);
    ioctl(fd_osd0, FBIOBLANK, 1);

    fd_osd1 = open(OSD1_DEVICE, O_RDWR);
    ioctl(fd_osd1, FBIOBLANK, 1);

    /* Open the video display device */
    fd_dev3 = open(VID3_DEVICE, O_RDWR);
    if (fd_dev3 == FAILURE) {
        return DISPLAY_OPEN_FAILED;
    }

    ret = ioctl(fd_dev3, VIDIOC_QUERYCAP, &capability);
    if (ret < SUCCESS) {
        return FAILURE;
    }

    while (1) {
        format.index = i;
        format.type = V4L2_BUF_TYPE_VIDEO_OUTPUT;
        ret = ioctl(fd_dev3, VIDIOC_ENUM_FMT, &format);
        if (ret < SUCCESS)
            break;
        i++;
    }


    /* Buffer allocation */
    reqbuf.count = n_bufs;
    reqbuf.type = V4L2_BUF_TYPE_VIDEO_OUTPUT;
    reqbuf.memory = V4L2_MEMORY_MMAP;
    ret = ioctl(fd_dev3, VIDIOC_REQBUFS, &reqbuf);
    if (ret < SUCCESS) {
        close(fd_dev3);
        return FAILURE;
    }

    memset(&(st_display_format), 0, sizeof(st_display_format));

    setfmt.type = V4L2_BUF_TYPE_VIDEO_OUTPUT;
    setfmt.fmt.pix.pixelformat = V4L2_PIX_FMT_UYVY;
    setfmt.fmt.pix.field = V4L2_FIELD_INTERLACED;
    if (st_std_id == V4L2_STD_NTSC) {
        setfmt.fmt.pix.width = WIDTH_NTSC;
        setfmt.fmt.pix.height = HEIGHT_NTSC;
    } else {
        setfmt.fmt.pix.width = WIDTH_PAL;
        setfmt.fmt.pix.height = HEIGHT_PAL;
    }
    ret = ioctl(fd_dev3, VIDIOC_S_FMT, &setfmt);
    if (ret < SUCCESS) {

        close(fd_dev3);
        return FAILURE;
    }

    st_display_format.type = V4L2_BUF_TYPE_VIDEO_OUTPUT;
    ret = ioctl(fd_dev3, VIDIOC_G_FMT, &st_display_format);
    if (ret < SUCCESS) {

        return FAILURE;
    }
    dispheight = st_display_format.fmt.pix.height;
    disppitch = st_display_format.fmt.pix.bytesperline;
    dispwidth = st_display_format.fmt.pix.width;

    /* Store the numbfer of buffers allocated */
    d_numbufs = reqbuf.count;

    d_buffers = (struct buff *) calloc(reqbuf.count, sizeof(struct buff));
    if (!d_buffers) {
        return FAILURE;
    }

    bzero(&buf, sizeof(buf));

    for (i = 0; i < reqbuf.count; i++) {

        buf.index = i;
        buf.type = V4L2_BUF_TYPE_VIDEO_OUTPUT;
        buf.memory = V4L2_MEMORY_MMAP;
        ret = ioctl(fd_dev3, VIDIOC_QUERYBUF, &buf);
        if (ret < SUCCESS) {

            close(fd_dev3);
            return FAILURE;
        }

        d_buffers[i].length = buf.length;
        d_buffers[i].start =
            mmap(NULL, buf.length, PROT_READ | PROT_WRITE, MAP_SHARED,
                 fd_dev3, buf.m.offset);



        if (MAP_FAILED == d_buffers[i].start) {

            return FAILURE;
        }

        memset(d_buffers[i].start, 0x80, buf.length);

        buf.type = V4L2_BUF_TYPE_VIDEO_OUTPUT;
        buf.memory = V4L2_MEMORY_MMAP;
        buf.index = i;
        ret = ioctl(fd_dev3, VIDIOC_QBUF, &buf);
        if (ret < SUCCESS) {
            return FAILURE;
        }
    }

    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_capture_close_interface
 * Functionality        - This function closes the device instance
 * Input Params         - Capture device
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
void st_v4l2_capture_close_interface(int dev)
{
    if (V4L2_DEV0 == dev) {
        close(fd_dev0);
        fd_dev0 = 0;
    }

}

/****************************************************************************
 * Function             - st_v4l2_capture_unmap_buffers_interface
 * Functionality        - This function unmaps buffers
 * Input Params         - None
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/
void st_v4l2_capture_unmap_buffers_interface(void)
{
    int i;

    for (i = 0; i < DEFAULT_NUM_BUFFERS; i++) {
        munmap(buffers[i].start, buffers[i].length);
        buffers[i].start = NULL;
    }

}


/****************************************************************************
 * Function             - st_v4l2_capture_query_mmap_que_buffers_interface
 * Functionality        - This function requests queries the physical address of buffers, maps
                                 them in user space and enqueues them
 * Input Params         - Capture device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_query_mmap_que_buffers_interface(int dev)
{
    int i;


    buffers =
        (struct buff *) calloc(st_reqbufs.count, sizeof(struct buff));

    if (!buffers) {
        return FAILURE;
    }

    if (V4L2_DEV0 == dev) {

        for (i = 0; i < st_reqbufs.count; ++i) {
            memset(&(st_buf), 0, sizeof(st_buf));
            st_buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;

            st_buf.memory = V4L2_MEMORY_MMAP;
            st_buf.index = i;


            if (FAILURE == ioctl(fd_dev0, VIDIOC_QUERYBUF, &st_buf))
                return QUERYBUF_FAILED;


            buffers[i].length = st_buf.length;
            buffers[i].start =
                mmap(NULL, st_buf.length, PROT_READ | PROT_WRITE,
                     MAP_SHARED, fd_dev0, st_buf.m.offset);

            if (MAP_FAILED == buffers[i].start) {
                return MMAP_FAILED;
            }

            memset(&(st_buf), 0, sizeof(st_buf));

            st_buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
            st_buf.memory = V4L2_MEMORY_MMAP;
            st_buf.index = i;

            if (FAILURE == ioctl(fd_dev0, VIDIOC_QBUF, &st_buf))
                return FAILURE;

        }



    }

    return SUCCESS;

}

/****************************************************************************
 * Function             - st_v4l2_capture_clear_buffers_interface
 * Functionality        - This function clears buffers
 * Input Params         - None
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/
void st_v4l2_capture_clear_buffers_interface(void)
{
}

/****************************************************************************
 * Function             - st_v4l2_capture_request_buffers_interface
 * Functionality        - This function requests for buffers
 * Input Params         - Capture device number, number of buffers, exchange mechanism
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_request_buffers_interface(int dev, int n_buffers,
                                              int buf_xchg)
{
    memset(&(st_reqbufs), 0, sizeof(st_reqbufs));

    st_reqbufs.count = n_buffers;
    st_reqbufs.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;

    st_reqbufs.memory = V4L2_MEMORY_MMAP;


    if (V4L2_DEV0 == dev) {
        if (FAILURE == ioctl(fd_dev0, VIDIOC_REQBUFS, &st_reqbufs))
            return FAILURE;
    }



    if (st_reqbufs.count < n_buffers) {
        return FAILURE;
    }

    numbufs = st_reqbufs.count;

    return SUCCESS;

}


/****************************************************************************
 * Function             - st_v4l2_capture_get_format_interface
 * Functionality        - This function gets the format
 * Input Params         - Capture device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_get_format_interface(int dev)
{
    unsigned int min;
    if (V4L2_DEV0 == dev) {
        if (FAILURE == ioctl(fd_dev0, VIDIOC_G_FMT, &st_format))
            return FAILURE;
    }

    nWidthFinal = st_format.fmt.pix.width;
    nHeightFinal = st_format.fmt.pix.height;

    /* checking what is finally negotiated */
    min = st_format.fmt.pix.width * 2;
    if (st_format.fmt.pix.bytesperline < min) {
        /*correct it */
        st_format.fmt.pix.bytesperline = min;
    }

    min = st_format.fmt.pix.bytesperline * st_format.fmt.pix.height;
    if (st_format.fmt.pix.sizeimage < min) {

        /*correct it */
        st_format.fmt.pix.sizeimage = min;
    }

    return SUCCESS;



}

/****************************************************************************
 * Function             - st_v4l2_capture_set_format_interface
 * Functionality        - This function sets the format
 * Input Params         - Capture device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_set_format_interface(int dev)
{
    memset(&(st_format), 0, sizeof(st_format));

    if (st_std_id == V4L2_STD_NTSC) {

        st_format.fmt.pix.width = WIDTH_NTSC;
        st_format.fmt.pix.height = HEIGHT_NTSC;
    } else {

        st_format.fmt.pix.width = WIDTH_PAL;
        st_format.fmt.pix.height = HEIGHT_PAL;
    }

    st_format.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    st_format.fmt.pix.pixelformat = V4L2_PIX_FMT_UYVY;
    st_format.fmt.pix.field = V4L2_FIELD_INTERLACED;

    if (V4L2_DEV0 == dev) {
        if (FAILURE == ioctl(fd_dev0, VIDIOC_S_FMT, &st_format))
            return FAILURE;
    }

    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_capture_chk_capability_interface
 * Functionality        - This function checks if the capture device is capable of streaming
 * Input Params         - Capture device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_chk_capability_interface(int dev)
{
    struct v4l2_capability cap;

    if (V4L2_DEV0 == dev) {     /* is capture supported? */
        if (FAILURE == ioctl(fd_dev0, VIDIOC_QUERYCAP, &cap)) {
            return FAILURE;
        }

        if (!(cap.capabilities & V4L2_CAP_VIDEO_CAPTURE)) {
            return FAILURE;
        }


        /* is MMAP-IO supported? */
        if (!(cap.capabilities & V4L2_CAP_STREAMING))

            return FAILURE;



        /* select cropping as deault rectangle */
        cropcap.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;

        if (FAILURE == ioctl(fd_dev0, VIDIOC_CROPCAP, &cropcap)) {
            /* ignore error */
        }

    }
    cap_support = TRUE;
    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_capture_enum_std_interface
 * Functionality        - This function enumerates the std
 * Input Params         - Capture device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_enum_std_interface(int dev)
{
    /*Not applicable */
    return STEP_NOT_REQUIRED;
}

/****************************************************************************
 * Function             - st_v4l2_capture_get_std_interface
 * Functionality        - This function gets the current std in the decoder
 * Input Params         - Capture device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_get_std_interface(int dev)
{
    /*Not applicable */
    return STEP_NOT_REQUIRED;
}

/****************************************************************************
 * Function             - st_v4l2_capture_querystd_interface
 * Functionality        - This function detects current video std
 * Input Params         - Capture device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_querystd_interface(int dev)
{
    st_std_id = VPFE_STD_AUTO;

    if (FAILURE == ioctl(fd_dev0, VIDIOC_S_STD, &st_std_id))
        return FAILURE;

    sleep(1);                   /* wait until decoder is fully locked */

    if (FAILURE == ioctl(fd_dev0, VIDIOC_QUERYSTD, &st_std_id))
        return FAILURE;

    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_capture_set_standard_number
 * Functionality        - Function sets standard number for a standard string
 * Input Params         - standard name 
 * Note                 - None
 ****************************************************************************/
void st_v4l2_capture_set_standard_number(char *std_name, int *st_std)
{
    if (!strcmp(std_name, STD_NTSC)) {
        *st_std = NTSC_STD;
    }
    if (!strcmp(std_name, STD_PAL)) {
        *st_std = PAL_STD;
    }
}


/****************************************************************************
 * Function             - st_v4l2_capture_enum_input_interface
 * Functionality        - This function enumerates V4L2 Capture interface
 * Input Params         - Capture device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_enum_input_interface(int dev)
{   if (FAILURE == ioctl(fd_dev0, VIDIOC_ENUMINPUT, &st_ip))
        return FAILURE;

    strcpy(common_char, st_ip.name);

    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_capture_set_input_interface
 * Functionality        - This function sets V4L2 Capture interface
 * Input Params         - Capture device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_set_input_interface(int dev) {
   int index = inter;
 
    if (FAILURE == ioctl(fd_dev0, VIDIOC_S_INPUT, &index))
        return FAILURE;

    common_int = index;
    st_ip.index = index;
    return SUCCESS;    
}

/****************************************************************************
 * Function             - st_v4l2_capture_set_interface_number
 * Functionality        - Function sets interface number for a interface string
 * Input Params         - interface name 
 * Note                 - None
 ****************************************************************************/
void st_v4l2_capture_set_interface_number(char *ifc_name, int *st_ifc)
{
    if (!strcmp(ifc_name, INTERFACE_COMPOSITE)) {
        *st_ifc = COMPOSITE_IFC;
    }
    if (!strcmp(ifc_name, INTERFACE_SVIDEO)) {
        *st_ifc = SVIDEO_IFC;
    }
    inter = *st_ifc;
}

/****************************************************************************
 * Function             - st_v4l2_capture_open_nonblock_interface
 * Functionality        - This function opens V4L2 capture window in non
 *                        blocking mode(not supported on OMAP35x)
 * Input Params         - V4L2 Capture device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_open_nonblock_interface(int dev)
{
    if (V4L2_DEV0 == dev) {
        if ((fd_dev0 =
             open(VID0_DEVICE, O_RDWR | O_NONBLOCK, 0)) <= FAILURE)
            return FAILURE;

    } else
        return DEV_NONEXISTENT;

    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_capture_open_interface
 * Functionality        - This function opens V4L2 Capture device
 * Input Params         - V4L2 Capture device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_open_interface(int dev)
{
    if (V4L2_DEV0 == dev) {
        if ((fd_dev0 = open(VID0_DEVICE, O_RDWR, 0)) <= FAILURE)
            return FAILURE;
    } else if (V4L2_DEV1 == dev) {
        if ((fd_dev1 = open(VID1_DEVICE, O_RDWR, 0)) <= FAILURE)
            return FAILURE;
    } else
        return DEV_NONEXISTENT;

    return SUCCESS;
}


/****************************************************************************
 * Function             - st_v4l2_capture_set_device_number
 * Functionality        - Function sets device number for a device string
 * Input Params         - device name 
 * Note                 - None
 ****************************************************************************/
void st_v4l2_capture_set_device_number(char *dev_name, int *st_dev)
{
    if (!strcmp(dev_name, VID0_DEVICE)) {
        *st_dev = V4L2_DEV0;

    } else if (!strcmp(dev_name, VID1_DEVICE)) {
        *st_dev = V4L2_DEV1;

    } else
        *st_dev = FAILURE;



}


/****************************************************************************
 * Function             - st_v4l2_capture_print_test_params
 * Functionality        - This function prints the test option values
 * Input Params         - Test params structure
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/
void st_v4l2_capture_print_test_params(struct st_v4l2_capture_testparams
                                       *test_options,char *testcaseid)
{
    DBG_PRINT_TST_START((testcaseid));
    DBG_PRINT_TRC0(("The Test is going to start with following values"));
    DBG_PRINT_TRC0(("The device node | %s", test_options->device));
    DBG_PRINT_TRC0(("The number of buffers | %d",
                    test_options->n_buffers));
    DBG_PRINT_TRC0(("The number of frames | %d", test_options->n_frames));
    DBG_PRINT_TRC0(("The standard | %s", test_options->std));
    DBG_PRINT_TRC0(("The capture interface | %s",
                    test_options->c_interfac));
    DBG_PRINT_TRC0(("The pixel format | %s", test_options->pix_fmt));
    if (test_options->display == TRUE) {
        DBG_PRINT_TRC0(("The write option is disabled"));
    } else {
        DBG_PRINT_TRC0(("The write option is enabled"));
        DBG_PRINT_TRC0(("The writefilename | %s", test_options->f_name));
        DBG_PRINT_TRC0(("The frame to be written | %d",
                        test_options->f_write));
    }
}

/****************************************************************************
 * Function             - st_v4l2_capture_test_suite_help
 * Functionality        - This function displays the help/usage
 * Input Params         - None
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/
void st_v4l2_capture_test_suite_help(void)
{
    printf("v4l2CaptureTestSuite V %s\n", VERSION_STRING);
    printf("Usage:\n"
           "./dm644xV4l2CaptureTests <options>\n\n"
           "-d       --devicenode     	Device node on which capture test is to be run\n"
           "\t\t\t\tPossible values-/dev/video0 \n"
           "-c       --countofbuffers  	Number of buffers to queue (change bootargs)\n"
           "-n       --noofframes      	Number of frames to be captured\n"
           "-s       --standard        	Name of the standard (change switch setting)\n"
           "\t\t\t\tPossible values-NTSC, PAL\n"
           "-i       --captureinterface	Name of the capture interface\n"
           "\t\t\t\tPossible values-COMPOSITE, SVIDEO\n"
           "-b       --openmode          	Mode to open the driver in\n"
           "\t\t\t\tPossible values-0(non-blocking) or 1(blocking)\n"
           "-B       --brightness      	Brightness control value\n"
           "\t\t\t\tPossible values-0 to 255 (default 128)\n"
           "-C       --contrast      	Contrast control value\n"
           "\t\t\t\tPossible values-0 to 255 (default 128)\n"
           "-S       --saturation      	Saturation control value\n"
           "\t\t\t\tPossible values-0 to 255 (default 128)\n"
           "-H       --hue      		Hue control value\n"
           "\t\t\t\tPossible values- -128 to 127 (default: 0)\n"
           "-G       --autogain		Autogain control value\n"
           "\t\t\t\tPossible values-0 or 1(default)\n" 
           "-P       --stabilitycount       Stability count\n"
           "-D       --displayorwrite    	Display/write option\n"
           "\t\t\t\tPossible values-0 (write) or 1(display)\n"
           "-f       --filename        	Name of the image file to write to\n"
           "\t\t\t\tMake sure the -D option is set to 0\n"
           "-W       --writeframe      	Particular frame number to capture and write\n"
           "\t\t\t\tMake sure it is less than -n (noofframes)\n"
           "-T       --testname        	Name of the special test\n"
           "\t\t\t\tPossible values-stability, stress\n"
           /*"-t       --testcaseid      Test case id string for testers reference/logging purpose\n"
              "\t\t\t\tPossible values- Any String without spaces\n" */
           "-?       --help            	Displays the help/usage\n"
           "-v       --version         	Version of Capture Test suite\n");
    exit(0);
}


/****************************************************************************
 * Function             - st_v4l2_capture_chk_ifc
 * Functionality        - This function checks the user input
 * Input Params         - None
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_chk_ifc(void)
{
    int flag = FALSE;

    if ((strcmp(test_options.c_interfac, "COMPOSITE") != 0)
        && (strcmp(test_options.c_interfac, "SVIDEO") != 0)) {
        DBG_PRINT_ERR(("Wrong capture interface entered- Please enter either COMPOSITE or SVIDEO\n"));
        flag = TRUE;
    }

    if (TRUE == flag)
        return FAILURE;
    else
        return SUCCESS;

}


/****************************************************************************
 * Function             - st_v4l2_capture_chk_std
 * Functionality        - This function checks the user input
 * Input Params         - None
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_chk_std()
{

    if ((strcmp(test_options.std, "NTSC") != 0)
        && (strcmp(test_options.std, "PAL") != 0)) {
        DBG_PRINT_ERR(("Wrong standard entered- Please enter either NTSC or PAL\n"));
        return FAILURE;
    }
    return SUCCESS;

}


/****************************************************************************
 * Function             - st_v4l2_capture_chk_pix_fmt
 * Functionality        - This function checks the user input
 * Input Params         - None
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_chk_pix_fmt()
{
    /*not applicable */
    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_capture_enum_format_interface
 * Functionality        - This function gets V4L2 format 
 * Input Params         - Capture device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - NonE 
 ****************************************************************************/
int st_v4l2_capture_enum_format_interface(int dev,struct st_v4l2_fmtdesc *st_fmt) 
{
    return SUCCESS;
}

 /****************************************************************************
 * Function             - init_v4l2_capture_test_params
 * Functionality        - This function initilaizes the default values for
 * various test case options(which will be exposed as command line arguments)
 * Input Params         -  None
 * Return Value         -  None
 * Note                 -  None
 ****************************************************************************/
void st_v4l2_capture_init_test_params()
{
    test_options.device = DEFAULT_DEVICE;
    test_options.n_buffers = DEFAULT_NUM_BUFFERS;
    test_options.n_frames = DEFAULT_NUM_FRAMES;
    test_options.std = DEFAULT_STD;
    test_options.c_interfac = DEFAULT_INTERFACE;
    test_options.d_interfac = DEFAULT_INTERFACE_DISP;
    test_options.open_mode = DEFAULT_OPEN_MODE;
    test_options.width = DEFAULT_WIDTH;
    test_options.height = DEFAULT_HEIGHT;
    test_options.pix_fmt = DEFAULT_PIX_FMT;
    test_options.buf_xchange = DEFAULT_BUFFER_XCHG_MECHANISM;
    test_options.brightness = DEFAULT_BRIGHTNESS;
    test_options.contrast = DEFAULT_CONTRAST;
    test_options.saturation = DEFAULT_SATURATION;
    test_options.hue = DEFAULT_HUE;
    test_options.a_gain = DEFAULT_AUTO_GAIN;
    test_options.display = DEFAULT_OPT_DISPLAY;
    test_options.f_name = DEFAULT_FILENAME;
    test_options.f_write = DEFAULT_FRAME_WRITE;
}
/****************************************************************************
 * Function             - st_v4l2_capture_query_mmap_que_buffers_userptr_interface
 * Functionality        - This function requests queries the physical address of buffers, maps
                                 them in user space and enqueues them
 * Input Params         - Capture device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_query_mmap_que_buffers_userptr_interface(int dev)
{
    int ret = SUCCESS;
    return SUCCESS;
}
/****************************************************************************
 * Function             - st_v4l2_capture_request_buffers_userptr_interface
 * Functionality        - This function requests for buffers
 * Input Params         - Capture device number, number of buffers, exchange mechanism
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_request_buffers_userptr_interface(int dev, int n_buffers,
                                              int buf_xchg)
{
    int ret = SUCCESS;
    return SUCCESS;
}

/****************************************************************************
 * Function             - st_v4l2_capture_init_display_video2_interface
 * Functionality        - This function initialises the display parameters for video 2 plane
 * Input Params         - No. of buffers
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
int st_v4l2_capture_init_display_video2_interface(int n_bufs)
{
    int ret = SUCCESS;
    return SUCCESS;
}
/* vi: set ts=4 sw=4 tw=80 et:*/
