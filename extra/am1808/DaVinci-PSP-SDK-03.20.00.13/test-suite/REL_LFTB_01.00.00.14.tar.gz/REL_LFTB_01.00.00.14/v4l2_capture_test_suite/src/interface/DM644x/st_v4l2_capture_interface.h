/*
 * st_v4l2_capture_interface.h
 *
 * This file abstracts V4L2 Capture driver structures, macros and enums
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/ 
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/

#ifndef _ST_V4L2_CAPTURE_INTERFACE_H_
#define _ST_V4L2_CAPTURE_INTERFACE_H_

/* Generic header files */
#define __USE_GNU
#include <stdio.h>
#include <string.h>
#include <getopt.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <linux/fb.h>
#include <asm/types.h>
#include <time.h>
#include <sys/stat.h>
#include <sys/prctl.h>
#include <linux/unistd.h>
#include <sched.h>
#include <pthread.h>
#include <signal.h>

/* V4L2 specific header files */
#include <media/davinci/davinci_vpfe.h>
#include <video/davincifb_ioctl.h>
#include <linux/videodev.h>
#include <linux/videodev2.h>
#include <media/davinci/davinci_display.h>
#include <asm/arch/davinci_previewer.h>

#define COMPOSITE_IFC 0
#define SVIDEO_IFC 1

#define DEFAULT_INTERFACE_DISP INTERFACE_COMPOSITE
#define DEFAULT_PIX_FMT PIX_FMT_UYVY

#define STDPATH         "/sys/class/davinci_display/ch0/mode"

#endif /* _ST_V4L2_CAPTURE_INTERFACE_H_ */

/* vi: set ts=4 sw=4 tw=80 et:*/
