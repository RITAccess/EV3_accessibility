/*
 * st_v4l2_capture_common.c
 *
 * This file contains the common functions definitions
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/ 
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/

/* generic headers */
#include "st_v4l2_capture_common.h"

/* Default values related to test */
char *testcase_id = "CaptureTests";
char *test_name = "Functionality";
int captureandwrite = FALSE;

/* This is to indicate if its a special test */
int other_tests = 0;

/* Test case options structure */
struct st_v4l2_capture_testparams test_options;

int std_flag;
unsigned int common_int, common_pix;
char common_char[32];
int cap_support;
unsigned int numbufs;
struct st_v4l2_input st_ip;
v4l2_std_id st_std_id;
struct st_v4l2_standard st_standard;
struct st_v4l2_capability st_capability;
int cap_support;
unsigned int common_int, numbufs, d_numbufs;
char common_char[32];
struct st_v4l2_format st_format, st_display_format;
struct st_v4l2_requestbuffers st_reqbufs, reqbuf;
struct v4l2_buffer st_buf, display_buf, capture_buf;
struct st_buf_info st_capture_buff_info[100];
struct st_buf_info st_display_buff_info[100];
struct st_buf_info st_display2_buff_info[100];
unsigned long buffer_addr[MAX_BUFFER1];
int buffersize;
int pixelfmt;
char *cap_ptr, *dis_ptr;

/* v4l2_capture window file descriptors */
int fd_dev0 = 0;

/* v4l2_capture window file descriptors */
int fd_dev1 = 0;

int fd_fbdev0 = 0;

int inter;
int st_display_chroma_offset, st_capture_chroma_offset;
int st_capture_size;
char outputname[15], stdname[15];
int fd_dev2 = 0;
struct v4l2_cropcap cropcap;
struct buff *buffers, *d_buffers;
int disppitch, dispheight, dispwidth;
int nWidthFinal, nHeightFinal;
char *displaybuffer, *capturebuffer;
int fd_dev3 = 0;
int fd_osd0, fd_osd1;
struct st_v4l2_queryctrl queryctrl;
struct st_v4l2_control control;

 /****************************************************************************
 * Function             - init_v4l2_capture_test_params
 * Functionality        - This function initilaizes the default values for
 * various test case options(which will be exposed as command line arguments)
 * Input Params         -  None
 * Return Value         -  None
 * Note                 -  None
 ****************************************************************************/
void st_v4l2_capture_init_test_params()
{
    test_options.device = DEFAULT_DEVICE;
    test_options.n_buffers = DEFAULT_NUM_BUFFERS;
    test_options.n_frames = DEFAULT_NUM_FRAMES;
    test_options.std = DEFAULT_STD;
    test_options.c_interfac = DEFAULT_INTERFACE;
    test_options.d_interfac = DEFAULT_INTERFACE_DISP;
    test_options.open_mode = DEFAULT_OPEN_MODE;
    test_options.pix_fmt = DEFAULT_PIX_FMT;
    test_options.buf_xchange = DEFAULT_BUFFER_XCHG_MECHANISM;
    test_options.brightness = DEFAULT_BRIGHTNESS;
    test_options.contrast = DEFAULT_CONTRAST;
    test_options.saturation = DEFAULT_SATURATION;
    test_options.hue = DEFAULT_HUE;
    test_options.a_gain = DEFAULT_AUTO_GAIN;
    test_options.display = DEFAULT_OPT_DISPLAY;
    test_options.f_name = DEFAULT_FILENAME;
    test_options.f_write = DEFAULT_FRAME_WRITE;
}

/* vi: set ts=4 sw=4 tw=80 et:*/
