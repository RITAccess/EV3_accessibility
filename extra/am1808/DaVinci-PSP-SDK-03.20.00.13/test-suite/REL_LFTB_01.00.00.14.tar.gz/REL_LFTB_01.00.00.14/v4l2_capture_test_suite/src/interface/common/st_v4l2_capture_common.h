/*
 * st_v4l2_capture_common.h
 *
 * This file contains the common functions
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/


#include <stdio.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <getopt.h>
#include <sys/mman.h>
#include <sys/time.h>
#include <linux/videodev.h>
#include <linux/videodev2.h>




#ifndef _ST_V4L2_CAPTURE_COMMON_H_
#define _ST_V4L2_CAPTURE_COMMON_H_

/* Standard Linux header files */
#include <st_v4l2_capture_interface.h>

/*Testcode related Header files*/
#include <stDefines.h>
#include <stLog.h>
#include <stTimer.h>
#include <stBufferMgr.h>
#include <stCpuLoad.h>
#define MAXLOOPCOUNT    10000



int inter;
/*Structure for holding the test options */
struct st_v4l2_capture_testparams
{
/* Device node name */
    char *device;
/* Number of buffers to request/enqueue */
    int n_buffers;
/*Number of frames to capture */
    int n_frames;
/*Capture standard : NTSC / PAL, etc */
    char *std;
/*Capture interface : COMPOSITE / SVIDEO, etc*/
    char *c_interfac;
/*Display interface : COMPOSITE / SVIDEO, etc*/
    char *d_interfac;
/* Open mode- Blocking/non blocking */
    int open_mode;
/* Width of the input image to be captured */
    int width;
/* Height of the input image to be captured */
    int height;
/* Pixel format of the image to be captured */
    char *pix_fmt;
/* Buffer exchange mechanism: Mmap or Userptr */
    int buf_xchange;
/* Brightness control parameter */
    int brightness;
/* Contrast Control parameter */
    int contrast;
/* Saturation control parameter*/
    int saturation;
/* Hue control parameter */
    int hue;
/* Auto Gain control parameter */
    int a_gain;
/* Option to display captured data or to write to a file*/
    int display;
/* File to write the captured image to*/
    char *f_name;
/* Particular frame to write*/
    int f_write;
/* option to enable frame rates calculation*/
    int framerate;
/* option to enable cpuload calculation*/
    int cpuload;
/* Global variable to control the use of user pointer or mmap*/
    Bool userpointer;
/* option for ioctl tests */
    int loopcount;
    int ioctl_no;
    int case_no;
};

/*control values*/
#define ST_CONTRAST 1
#define ST_BRIGHTNESS 2
#define ST_HUE 3
#define ST_SATURATION 4
#define ST_AUTOGAIN 5

/*Function Declarations */
void v4l2_capture_testsuite_version(void);
void st_v4l2_capture_test(struct st_v4l2_capture_testparams *, char *);
void st_v4l2_capture_write_test(struct st_v4l2_capture_testparams *,
                                char *);
void st_v4l2_capture_stress_test(struct st_v4l2_capture_testparams *,
                                 char *);
void st_v4l2_capture_stability_test(struct st_v4l2_capture_testparams *,
                                    char *, int);
void st_v4l2_capture_ioctl_test(struct st_v4l2_capture_testparams *,
                                 char *);  


/* The Declarations of implementation defined in the interface.c */
/* Standards supported */
#define STD_NTSC "NTSC"
#define STD_PAL "PAL"
#define STD_480P "480P-60"
#define STD_576P "576P-50"
#define STD_720P_50FPS "720P-50"
#define STD_720P_60FPS "720P-60"
#define STD_1080I_25FPS "1080I-25"
#define STD_1080I_30FPS "1080I-30"

 /* pixel Formats */
#define ST_PIX_FMT_UYVY V4L2_PIX_FMT_UYVY
#define ST_PIX_FMT_YUYV V4L2_PIX_FMT_YUYV
#define ST_PIX_FMT_RGB565 V4L2_PIX_FMT_RGB565
#define ST_PIX_FMT_RGB888 V4L2_PIX_FMT_RGB24

/* Open() call modes */
#define BLOCKING_OPEN_MODE 1
#define NON_BLOCKING_OPEN_MODE 0

#define NTSC_STD 0
#define PAL_STD 1
#define P480_STD 2
#define P576_STD 3
#define P720_50_STD 4
#define P720_60_STD 5
#define I1080_25_STD 6
#define I1080_30_STD 7

/* ERROR CODES - Helpful to differentiate between failures from non supported features*/
#define MODE_NOT_SUPPORTED 	-12
#define FORMAT_NOT_SUPPORTED 	-15
#define XCHG_NOT_SUPPORTED -16
#define QUERYBUF_FAILED -17
#define MMAP_FAILED -18
#define SET_VIDEOPIPELINE_FAILED -19
#define SET_OUTPUT_FAILED -20
#define DISPLAY_OPEN_FAILED -21
#define DISPLAY_QUERYCAP_FAILED -22
#define STEP_NOT_REQUIRED -23
#define SET_MODE_FAILED -24
#define DEV_NONEXISTENT -25

#define BUF_TYPE_VIDEO_CAPTURE V4L2_BUF_TYPE_VIDEO_CAPTURE
#define BUF_TYPE_VIDEO_OUTPUT V4L2_BUF_TYPE_VIDEO_OUTPUT
#define MEMORY_MMAP V4L2_MEMORY_MMAP
#define MEMORY_USERPTR V4L2_MEMORY_USERPTR


#define MAX_BUFFER1 4
#define MAX_BUFFER2 10

#define DEFAULT_IMAGE_SIZE 200*200
#define DEFAULT_BYTES_PER_LINE 8*200
/* Wrapper structure for v4l2_input */

struct st_v4l2_input
{
    unsigned int index;         /*  Which input */
    char name[32];     /*  Label */
    unsigned int type;          /*  Type of input */
    v4l2_std_id std;
    unsigned int status;
};

/*Wrapper structure for v4l2_standard*/
struct st_v4l2_standard
{
    unsigned int index;
    v4l2_std_id id;
    char name[32];
    unsigned int framelines;
    unsigned int reserved[4];
};

/*Wrapper structure for v4l2_capability*/
struct st_v4l2_capability
{
    unsigned char driver[16];   /* i.e. "bttv" */
    unsigned char card[32];     /* i.e. "Hauppauge WinTV" */
    unsigned char bus_info[32]; /* "PCI:" + pci_name(pci_dev) */
    unsigned int version;       /* should use KERNEL_VERSION() */
    unsigned int capabilities;  /* Device capabilities */
};

/*Wrapper structure for v4l2_format*/
struct st_v4l2_format
{
    enum v4l2_buf_type type;
    union
    {
        struct v4l2_pix_format pix;     // V4L2_BUF_TYPE_VIDEO_CAPTURE
        struct v4l2_window win; // V4L2_BUF_TYPE_VIDEO_OVERLAY
        struct v4l2_vbi_format vbi;     // V4L2_BUF_TYPE_VBI_CAPTURE
        struct v4l2_sliced_vbi_format sliced;   // V4L2_BUF_TYPE_SLICED_VBI_CAPTURE
        unsigned char raw_data[200];    // user-defined
    } fmt;
};

/*Wrapper structure for v4l2_requestbuffers*/
struct st_v4l2_requestbuffers
{
    unsigned int count;
    enum v4l2_buf_type type;
    enum v4l2_memory memory;
    unsigned int reserved[2];
};

/* structure used to store information of the buffers */
struct st_buf_info
{
    int index;
    unsigned int length;
    char *start;
};

struct st_v4l2_queryctrl
{
    Uint32                  id;
    enum v4l2_ctrl_type     type;
    Uint8                   name[32];  /* Whatever */
    Int32                   minimum;   /* Note signedness */
    Int32                   maximum;
    Int32                   step;
    Int32                   default_value;
    Uint32                  flags;
    Uint32                  reserved[2];
};

struct st_v4l2_control
{
    Uint32          id;
    Int32           value;
};

struct st_v4l2_fmtdesc
{
    Uint32              index;             /* Format number      */
    enum v4l2_buf_type  type;              /* buffer type        */
    Uint32              flags;
    Uint8               description[32];   /* Description string */
    Uint32              pixelformat;       /* Format fourcc      */
    Uint32              reserved[4];
};


/* Function declarations*/
/* Function to unmap and close the display*/
void st_v4l2_capture_unmap_close_display_interface(void);
/* Function to stop streaming on the capture device*/
int st_v4l2_capture_streamoff_interface(int);
/* Function to stop streaming on the display device*/
int st_v4l2_capture_streamoff_display_interface(void);
/* Function to perform QBUF on the display device*/
int st_v4l2_capture_queue_display_interface(void);
/* Function to perform QBUF on the capture device*/
int st_v4l2_capture_queue_interface(int);
/* Function to perform process the image within the loop*/
void st_v4l2_capture_process_image_interface(void);
/* Function to perform DQBUF on the capture device*/
int st_v4l2_capture_dequeue_interface(int);
/* Function to perform DQBUF on the display device*/
int st_v4l2_capture_dequeue_display_interface(void);
/* Function to prepare the capture buffers*/
void st_v4l2_capture_set_interface(void);
/* Function to prepare the display buffers*/
void st_v4l2_capture_set_display_interface(void);
/* Function to start streaming on the capture device*/
int st_v4l2_capture_streamon_interface(int);
/* Function to start streaming on the display device*/
int st_v4l2_capture_streamon_display_interface(void);
/* Function to initialise the display device*/
int st_v4l2_capture_init_display_interface(int);
int st_v4l2_capture_init_display_video2_interface(int);
/* Function to close the capture device*/
void st_v4l2_capture_close_interface(int);
/* Function to unmap the capture buffers*/
void st_v4l2_capture_unmap_buffers_interface(void);
/* Function to perform QUERYBUF, mmap and QBUF on the capture buffers*/
int st_v4l2_capture_query_mmap_que_buffers_interface(int);
/* Function to perform QUERYBUF, mmap and QBUF on the capture buffers*/
int st_v4l2_capture_query_mmap_que_buffers_userptr_interface(int);
/* Function to clear the capture buffers*/
void st_v4l2_capture_clear_buffers_interface(void);
/* Function to perform REQBUFS on the capture device*/
int st_v4l2_capture_request_buffers_interface(int, int, int);
/* Function to perform REQBUFS on the capture device*/
int st_v4l2_capture_request_buffers_userptr_interface(int, int, int);
/* Function to perform G_FMT on the capture device*/
int st_v4l2_capture_get_format_interface(int);
/* Function to perform S_FMT on the capture device*/
int st_v4l2_capture_set_format_interface(int);             //
/* Function to perform QUERYCAP on the capture device*/
int st_v4l2_capture_chk_capability_interface(int);
/* Function to perform ENUMSTD on the capture device*/
int st_v4l2_capture_enum_std_interface(int);
/* Function to perform G_STD on the capture device*/
int st_v4l2_capture_get_std_interface(int);
/* Function to perform QUERYSTD on the capture device*/
int st_v4l2_capture_querystd_interface(int);
/* Function to map the standard to an integer*/
void st_v4l2_capture_set_standard_number(char *, int *);
/* Function to perform ENUMINPUT on the capture device*/
int st_v4l2_capture_enum_input_interface(int);
/* Function to perform G_INPUT on the capture device*/
int st_v4l2_capture_get_input_interface(int);
/* Function to map the interface to an integer*/
void st_v4l2_capture_set_interface_number(char *, int *);
/* Function to open the capture device in nonblocking mode*/
int st_v4l2_capture_open_nonblock_interface(int);
/* Function to open the capture device in blocking mode*/
int st_v4l2_capture_open_interface(int);
/* Function to map the device to an integer*/
void st_v4l2_capture_set_device_number(char *, int *);
/* Function to print the help*/
void st_v4l2_capture_test_suite_help(void);
/* Function to check if the interface is entered correctly*/
int st_v4l2_capture_chk_ifc(void);
/* Function to check if the standard is entered correctly*/
int st_v4l2_capture_chk_std(void);
/* Function to check if the pixel format is entered correctly*/
int st_v4l2_capture_chk_pix_fmt(void);
/**/
int st_v4l2_capture_set_input_interface(int);
/**/
int st_v4l2_capture_write_image_interface(char *fname, int frame, int cur_frame);
/*support for new ioctls*/
/*Function to enum the format*/
int st_v4l2_capture_enum_format_interface(int dev,struct st_v4l2_fmtdesc *st_fmt);

/*Function to validate the format*/
int st_v4l2_validate_format_interface(int dev);

/*Functions to query set and get the contrast*/
int st_v4l2_query_contrast_interface(int dev,struct st_v4l2_queryctrl *qctrl);
int st_v4l2_set_contrast_interface(int dev,struct st_v4l2_control st_ctrl);
int st_v4l2_get_contrast_interface(int dev,struct st_v4l2_control *st_ctrl);

/*Functions to query set and get the brightness*/
int st_v4l2_query_brightness_interface(int dev,struct st_v4l2_queryctrl *qctrl);
int st_v4l2_set_brightness_interface(int dev,struct st_v4l2_control st_ctrl);
int st_v4l2_get_brightness_interface(int dev,struct st_v4l2_control *st_ctrl);

/*Functions to query set and get the hue*/
int st_v4l2_query_hue_interface(int dev,struct st_v4l2_queryctrl *qctrl);
int st_v4l2_set_hue_interface(int dev,struct st_v4l2_control st_ctrl);
int st_v4l2_get_hue_interface(int dev,struct st_v4l2_control *st_ctrl);

/*Functions to query set and get the saturation*/
int st_v4l2_query_saturation_interface(int dev,struct st_v4l2_queryctrl *qctrl);
int st_v4l2_set_saturation_interface(int dev,struct st_v4l2_control st_ctrl);
int st_v4l2_get_saturation_interface(int dev,struct st_v4l2_control *st_ctrl);

/*Functions to query set and get the autogain*/
int st_v4l2_query_autogain_interface(int dev,struct st_v4l2_queryctrl *qctrl);
int st_v4l2_set_autogain_interface(int dev,struct st_v4l2_control st_ctrl);
int st_v4l2_get_autogain_interface(int dev,struct st_v4l2_control *st_ctrl);

/*Wrapper Functions to query set and get control informations*/
int st_v4l2_get_control_val(int st_dev,int ctrl);
int st_v4l2_query_control_val(int st_dev,int ctrl);
int st_v4l2_set_control_val(int st_dev,int ctrl,int val);

#endif /* _ST_V4L2_CAPTURE_COMMON_H_ */

/* vi: set ts=4 sw=4 tw=80 et:*/
