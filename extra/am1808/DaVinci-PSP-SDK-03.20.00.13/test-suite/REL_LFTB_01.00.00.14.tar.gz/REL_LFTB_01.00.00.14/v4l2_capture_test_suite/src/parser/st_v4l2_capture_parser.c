/*
 * st_v4l2_capture_parser.c
 *
 * This file contains code to test various features supported by V4L2 capture driver
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/


 /* Generic header files */
#define __USE_GNU

/* Test case common header file */
#include "st_v4l2_capture_common.h"

#define DEFAULT_STABILITY_COUNT 1000


 /* Default values related to test */
char *testcase_id = "CaptureTests";
char *test_name = "Functionality";
 int captureandwrite = FALSE;

/* This is to indicate if its a special test */
int other_tests = 0;

/* Test case options structure */
extern struct st_v4l2_capture_testparams test_options;

/*************************Function Declarations********************************/
/* Function to initialize options with default values */
void st_v4l2_capture_init_test_params(void);
/* Function to print options with which the test will run */
void st_v4l2_capture_print_test_params(struct st_v4l2_capture_testparams
                                       *,char *);


/****************************************************************************
 * Function             - v4l2_capture_testsuite_version
 * Functionality        - This function displays the test suite version
 * Input Params         - None
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/
void v4l2_capture_testsuite_version()
{
    printf("v4l2CaptureTestSuite V %s\n", VERSION_STRING);
}


 /****************************************************************************
 * Function             - process_v4l2_capture_test_options
 * Functionality        - This function parses the command line options and vallues passed for the options
 * Input Params         -  argc,argv
 * Return Value         -  None
 * Note                 -  None
 ****************************************************************************/
static void process_v4l2_capture_test_options(int argc, char *argv[])
{
    int error = FALSE;
    int ver = FALSE;
    int help = FALSE;
    //int othertests = FALSE;

    int stabilitycount = DEFAULT_STABILITY_COUNT;
    for (;;) {
        int opt_index = 0;
        /** Options for getopt - New test case options added need to be
         * populated here*/
        static struct option long_options[] = {
            {"loopcount", optional_argument, NULL, 'L'},
            {"ioctl_no", optional_argument, NULL, 'I'},
            {"devicenode", optional_argument, NULL, 'd'},
            {"countofbuffers", optional_argument, NULL, 'c'},
            {"noofframes", optional_argument, NULL, 'n'},
            {"standard", optional_argument, NULL, 's'},
            {"captureinterface", optional_argument, NULL, 'i'},
            {"openmode", optional_argument, NULL, 'b'},
            {"width", optional_argument, NULL, 'w'},
            {"height", optional_argument, NULL, 'h'},
            {"pixelformat", optional_argument, NULL, 'p'},
            {"bufferaccess", optional_argument, NULL, 'm'},
            {"case_no", optional_argument, NULL, 'j'},
            {"brightness", optional_argument, NULL, 'B'},
            {"contrast", optional_argument, NULL, 'C'},
            {"saturation", optional_argument, NULL, 'S'},
            {"hue", optional_argument, NULL, 'H'},
            {"autogain", optional_argument, NULL, 'G'},
            {"stabilitycount", optional_argument, NULL, 'P'},
            {"displayorwrite", optional_argument, NULL, 'D'},
            {"filename", optional_argument, NULL, 'f'},
            {"writeframe", optional_argument, NULL, 'W'},
            {"testcaseid", optional_argument, NULL, 't'},
            {"testname", optional_argument, NULL, 'T'},
            {"framerate", no_argument, NULL, 'F'},
            {"userpointer", no_argument, NULL, 'u'},
            {"cpuload", no_argument, NULL, 'l'},
            {"version", no_argument, NULL, 'v'},
            {"help", no_argument, NULL, '?'},
            {NULL, 0, NULL, 0}
        };
        int c = getopt_long(argc, argv,
                            "L:I:d:c:n:s:i:b:w:h:p:m:j:B:C:S:H:G:P:D:f:N:W:t:T::Fulv?",
                            long_options, &opt_index);
        if (c == -1) {
            break;
        }
        switch (c) {
        case 'L':
            if (optarg != NULL) {
                test_options.loopcount = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                test_options.loopcount = atoi(argv[optind]);
            }
            break;
        case 'I':
            if (optarg != NULL) {
                test_options.ioctl_no = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                test_options.ioctl_no = atoi(argv[optind]);
            }
            break;
        case 'd':
            if (optarg != NULL) {
                test_options.device = optarg;
            } else if (optind < argc && argv[optind]) {
                test_options.device = argv[optind];
            }
            break;
        case 'c':
            if (optarg != NULL) {
                test_options.n_buffers = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                test_options.n_buffers = atoi(argv[optind]);
            }
            break;
        case 'n':
            if (optarg != NULL) {
                test_options.n_frames = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                test_options.n_frames = atoi(argv[optind]);
            }
            break;
        case 's':
            if (optarg != NULL) {
                test_options.std = optarg;
            } else if (optind < argc && argv[optind]) {
                test_options.std = argv[optind];
            }
            break;
        case 'i':
            if (optarg != NULL) {
                test_options.c_interfac = optarg;
            } else if (optind < argc && argv[optind]) {
                test_options.c_interfac = argv[optind];
            }
            break;
        case 'b':
            if (optarg != NULL) {
                test_options.open_mode = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                test_options.open_mode = atoi(argv[optind]);
            }
            break;
        case 'w':
            if (optarg != NULL) {
                test_options.width = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                test_options.width = atoi(argv[optind]);
            }
            break;
        case 'h':
            if (optarg != NULL) {
                test_options.height = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                test_options.height = atoi(argv[optind]);
            }
            break;
        case 'P':
            if (optarg != NULL) {
                stabilitycount = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                stabilitycount = atoi(argv[optind]);
            }
            break;
        case 'p':
            if (optarg != NULL) {
                test_options.pix_fmt = optarg;
            } else if (optind < argc && argv[optind]) {
                test_options.pix_fmt = argv[optind];
            }
            break;
        case 'm':
            if (optarg != NULL) {
                test_options.buf_xchange = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                test_options.buf_xchange = atoi(argv[optind]);
            }
            break;
        case 'B':
            if (optarg != NULL) {
                test_options.brightness = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                test_options.brightness = atoi(argv[optind]);
            }
            break;
        case 'j':
            if (optarg != NULL) {
                test_options.case_no = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                test_options.case_no = atoi(argv[optind]);
            }
            break;
        case 'C':
            if (optarg != NULL) {
                test_options.contrast = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                test_options.contrast = atoi(argv[optind]);
            }
            break;
        case 'S':
            if (optarg != NULL) {
                test_options.saturation = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                test_options.saturation = atoi(argv[optind]);
            }
            break;
        case 'H':
            if (optarg != NULL) {
                test_options.hue = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                test_options.hue = atoi(argv[optind]);
            }
            break;
        case 'G':
            if (optarg != NULL) {
                test_options.a_gain = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                test_options.a_gain = atoi(argv[optind]);
            }
            break;
        case 'D':
            if (optarg != NULL) {
                test_options.display = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                test_options.display = atoi(argv[optind]);
            }
            if (test_options.display == SUCCESS) {
                captureandwrite = TRUE;
            }
            break;
        case 'f':
            if (optarg != NULL) {
                test_options.f_name = optarg;
            } else if (optind < argc && argv[optind]) {
                test_options.f_name = argv[optind];
            }
            break;
        case 'W':
            if (optarg != NULL) {
                test_options.f_write = atoi(optarg);
            } else if (optind < argc && argv[optind]) {
                test_options.f_write = atoi(argv[optind]);
            }
            break;
        case 't':
            if (optarg != NULL) {
                testcase_id = optarg;
            } else if (optind < argc && argv[optind]) {
                testcase_id = argv[optind];
            }
            break;
        case 'T':
            if (optarg != NULL) {
                test_name = optarg;
            } else if (optind < argc && argv[optind]) {
                test_name = argv[optind];
            }
            other_tests = TRUE;
            break;
        case 'F':
            test_options.framerate = TRUE;
            break;
        case 'u':
            test_options.userpointer = TRUE;
            break;
        case 'l':
            test_options.cpuload = TRUE;
            break;
        case 'v':
            v4l2_capture_testsuite_version();
            ver = TRUE;
            break;
        case '?':
            help = TRUE;
            break;

        }
    }
    /* If any error in usage, values provided for options, display the help to user */
    if (TRUE != help && TRUE != ver) {
        if (FAILURE == st_v4l2_capture_chk_pix_fmt()
            || FAILURE == st_v4l2_capture_chk_std()
            || FAILURE == st_v4l2_capture_chk_ifc()) {
            error = TRUE;
        }
    }
    if (TRUE == error || TRUE == help) {
        st_v4l2_capture_test_suite_help();
    }

    if ((TRUE != ver && TRUE != help) && (TRUE != error)) {
        st_v4l2_capture_print_test_params(&test_options,testcase_id);
        if (TRUE != other_tests) {

			if(TRUE == test_options.buf_xchange) {

			st_v4l2_capture_test(&test_options, testcase_id);
				}


        } else if (strcmp(test_name, "stability") == SUCCESS) {
            st_v4l2_capture_stability_test(&test_options, testcase_id,
                                           stabilitycount);
        } else if (strcmp(test_name, "stress") == SUCCESS) {
            st_v4l2_capture_stress_test(&test_options, testcase_id);
        }
	    else if (strcmp(test_name, "ioctl") == SUCCESS) {
            st_v4l2_capture_ioctl_test(&test_options, testcase_id);
        }
        else {
            printf("Test not supported\n");
        }
    }
}

/****************************************************************************
 * Function             - Main function
 * Functionality        - This is where the execution begins
 * Input Params         - argc,argv
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/
int main(int argc, char **argv)
{
    /* Initialize options with default values */
    st_v4l2_capture_init_test_params();
    /* Invoke the parser function to process the command line options */
    process_v4l2_capture_test_options(argc, argv);
    return 0;
}

/* vi: set ts=4 sw=4 tw=80 et:*/
