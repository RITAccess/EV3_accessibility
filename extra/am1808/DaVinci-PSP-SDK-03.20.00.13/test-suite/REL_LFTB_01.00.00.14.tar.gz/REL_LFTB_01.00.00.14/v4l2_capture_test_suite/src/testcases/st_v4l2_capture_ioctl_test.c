/*
 * st_v4l2_capture_ioctl_test.c
 *
 * This file contains code to tests the stability of the V4L2 capture driver
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/


 /*generic header files */

#include "st_v4l2_capture_common.h"
extern unsigned char common_char[32];
extern unsigned int common_int;
extern unsigned int common_pix;

 /****************************************************************************
 * Function             - st_v4l2_capture_ioctl_test
 * Functionality        - Function to test ioctl's in V4L2 capture driver
 * Input Params         - test_options structure with input parameters, testcaseid
 * Return Value         - None.
 * Note                 - None
 ****************************************************************************/

void st_v4l2_capture_ioctl_test(struct st_v4l2_capture_testparams
                                 *test_options, char *test_id)
{
    int ret = SUCCESS;
    int stat = SUCCESS;

    int st_dev;
    int st_ifc;
    int i = 0;

    /* variables to track device state, mapping of buffers and state of V4L2 window */
    Bool open_stat = FALSE;

	 /* get device number for a device string to avoid further string operations */
st_v4l2_capture_set_device_number(test_options->device, &st_dev);
   do
   {
	if (test_options->open_mode == BLOCKING_OPEN_MODE)
            {
	   /* open V4L2 capture device */
            ret = st_v4l2_capture_open_interface(st_dev);
            	if (SUCCESS != ret)
            	{
		         if (DEV_NONEXISTENT == ret)
			{
	         		DBG_PRINT_ERR(("Capture Device %s does not exist",
                                	test_options->device));
                		}
			else
			{
		                 DBG_PRINT_ERR(("Failed to open V4L2 capture device /dev/video%d", st_dev));
                		}
		        stat = FAILURE;
               	}
	    }
	 else
         {							  /* open V4L2 display device in non blocking mode */
		ret = st_v4l2_capture_open_nonblock_interface(st_dev);
         	if (SUCCESS != ret)
		{
                		if (MODE_NOT_SUPPORTED == ret)
			{
	                    	DBG_PRINT_ERR(("This open mode is not supported"));
	        	                 stat = FAILURE;
                          }
			else if (DEV_NONEXISTENT == ret)
			{
	         	         DBG_PRINT_ERR(("Capture Device %s does not exist",
         	                 test_options->device));
		                  stat = FAILURE;
                          }
		        else
                         {
		                    DBG_PRINT_ERR(("Failed to open V4L2 capture device /dev/video%d", st_dev));
                 			   stat = FAILURE;

                		}
            	}

	 }
	        open_stat = TRUE;       // device is opened

        	        DBG_PRINT_TRC0(("V4L2 capture device node /dev/video%d opened",
                    st_dev));

switch(test_options->ioctl_no)
{
		/*G_INPUT IOCTL*/
		case 0:
		for(i=0; i< test_options->loopcount; i++)
		{
				/*get input */
			        ret = st_v4l2_capture_get_input_interface(st_dev);

			if (FAILURE == ret)
			{
				DBG_PRINT_ERR(("G_INPUT Ioctl Failed"));
			      	stat = FAILURE;
				st_v4l2_capture_close_interface(st_dev);
			        	break;
			}
			else if (SUCCESS == ret)
			{
	          		DBG_PRINT_TRC0(("G_INPUT Ioctl Passed"));
	 		}
			 /*enum input */
			        ret = st_v4l2_capture_enum_input_interface(st_dev);
			if (FAILURE == ret)
			{
			        DBG_PRINT_ERR(("ENUMINPUT Ioctl Failed"));
			        stat = FAILURE;
			        st_v4l2_capture_close_interface(st_dev);
			        break;
		        }
		        else if (SUCCESS == ret)
		        {
			       DBG_PRINT_TRC0(("ENUMINPUT Ioctl Passed"));
			       DBG_PRINT_TRC0(("Input is %s", common_char));
        			}

		}
			       DBG_PRINT_TRC0(("Testing of G_INPUT IOCTL done successfully"));
		break;

	case 1:
	{

		for(i=0; i< test_options->loopcount; i++)
		{
		        /*get input */
	        		ret = st_v4l2_capture_get_input_interface(st_dev);

			if (FAILURE == ret)
			{
				DBG_PRINT_ERR(("G_INPUT Ioctl Failed"));
		      		stat = FAILURE;
				st_v4l2_capture_close_interface(st_dev);
			        	break;
			}
			else if (SUCCESS == ret)
			{
          			DBG_PRINT_TRC0(("G_INPUT Ioctl Passed"));
				DBG_PRINT_TRC0(("1: index - %d", common_int));
	 		}

		 /*enum input */
	        ret = st_v4l2_capture_enum_input_interface(st_dev);
			if (FAILURE == ret)
			{
			        DBG_PRINT_ERR(("ENUMINPUT Ioctl Failed"));
			        stat = FAILURE;
			        st_v4l2_capture_close_interface(st_dev);
			        break;
		        }
		        else if (SUCCESS == ret)
		        {
			       DBG_PRINT_TRC0(("ENUMINPUT Ioctl Passed"));
			       DBG_PRINT_TRC0(("Input is %s", common_char));
        			}

			/* get interface number for the interface string */
        	                 st_v4l2_capture_set_interface_number(test_options->c_interfac, &st_ifc);

			ret = st_v4l2_capture_set_input_interface(st_dev);

			if (FAILURE == ret)
			{
				DBG_PRINT_ERR(("S_INPUT Ioctl Failed"));
			      	stat = FAILURE;
				st_v4l2_capture_close_interface(st_dev);
			        	break;
			}
			else if (SUCCESS == ret)
			{
	          		DBG_PRINT_TRC0(("S_INPUT Ioctl Passed"));
				DBG_PRINT_TRC0(("1: index - %d", common_int));
	 		}
			 /*enum input */
			        ret = st_v4l2_capture_enum_input_interface(st_dev);
			if (FAILURE == ret)
			{
			        DBG_PRINT_ERR(("ENUMINPUT Ioctl Failed"));
			        stat = FAILURE;
			        st_v4l2_capture_close_interface(st_dev);
			        break;
		        }
		        else if (SUCCESS == ret)
		        {
			       DBG_PRINT_TRC0(("ENUMINPUT Ioctl Passed"));
			       DBG_PRINT_TRC0(("Input is changed to %s", common_char));
        			}

  			}
	         	       DBG_PRINT_TRC0(("Testing of S_INPUT IOCTL done successfully"));
		}
		break;

	case 2:
	{

		for(i=0; i< test_options->loopcount; i++)
		{
		        /*get input */
	        		ret = st_v4l2_capture_get_input_interface(st_dev);

			if (FAILURE == ret)
			{
				DBG_PRINT_ERR(("G_INPUT Ioctl Failed"));
		      		stat = FAILURE;
				st_v4l2_capture_close_interface(st_dev);
			        	break;
			}
			else if (SUCCESS == ret)
			{
          			DBG_PRINT_TRC0(("G_INPUT Ioctl Passed"));
				DBG_PRINT_TRC0(("1: index - %d", common_int));
	 		}

			/*enum input */
	     		ret = st_v4l2_capture_enum_input_interface(st_dev);
			if (FAILURE == ret)
			{
			        DBG_PRINT_ERR(("ENUMINPUT Ioctl Failed"));
			        stat = FAILURE;
			        st_v4l2_capture_close_interface(st_dev);
			        break;
		        }
		        else if (SUCCESS == ret)
		        {
			       DBG_PRINT_TRC0(("ENUMINPUT Ioctl Passed"));
			       DBG_PRINT_TRC0(("Input is %s", common_char));
        			}

			/* get interface number for the interface string */
        	                 st_v4l2_capture_set_interface_number(test_options->c_interfac, &st_ifc);

			ret = st_v4l2_capture_set_input_interface(st_dev);

			if (FAILURE == ret)
			{
				DBG_PRINT_ERR(("S_INPUT Ioctl Failed"));
			      	stat = FAILURE;
				st_v4l2_capture_close_interface(st_dev);
			        	break;
			}
			else if (SUCCESS == ret)
			{
	          		DBG_PRINT_TRC0(("S_INPUT Ioctl Passed"));
				DBG_PRINT_TRC0(("1: index - %d", common_int));
	 		}

			/*query standard */
		         ret = st_v4l2_capture_querystd_interface(st_dev);
		         if (SUCCESS != ret)
		         {
			          DBG_PRINT_ERR(("QUERYSTD Ioctl Failed"));
			          stat = FAILURE;
			          st_v4l2_capture_close_interface(st_dev);
			          break;
        		         }
			          DBG_PRINT_TRC0(("QUERYSTD Ioctl Passed"));

        		         /*get the standard */
		         ret = st_v4l2_capture_get_std_interface(st_dev);
		         if (FAILURE == ret)
		         {
			          DBG_PRINT_ERR(("G_STD Ioctl Failed"));
			          stat = FAILURE;
			          st_v4l2_capture_close_interface(st_dev);
			          break;
		         }
		         else if (SUCCESS == ret)
		         {
			          DBG_PRINT_TRC0(("G_STD Ioctl Passed"));
        		         }

		         /*enum standard */
		         ret = st_v4l2_capture_enum_std_interface(st_dev);
		         if (FAILURE == ret)
		         {
			          DBG_PRINT_ERR(("ENUMSTD Ioctl Failed"));
		                  stat = FAILURE;
		                  st_v4l2_capture_close_interface(st_dev);
		                  break;
		         }
		         else if (SUCCESS == ret)
		         {
			         DBG_PRINT_TRC0(("ENUMSTD Ioctl Passed"));
		      	         DBG_PRINT_TRC0(("Current standard is %s", common_char));
		         }


		 }
		   	         DBG_PRINT_TRC0(("Testing of QUERYSTD IOCTL done successfully"));
	}
	break;

	case 3:
	{
		for(i=0; i< test_options->loopcount; i++)
		{


			ret = st_v4l2_capture_get_format_interface(st_dev);
			if (FAILURE == ret)
		        {
			            DBG_PRINT_ERR(("G_FMT Ioctl Failed"));
			            stat = FAILURE;
			            st_v4l2_capture_close_interface(st_dev);
			            break;
		        }
		        else
			{
			            DBG_PRINT_TRC0(("G_FMT Ioctl Passed"));
		   	            DBG_PRINT_TRC0(("Current pixel format is - %s", (common_pix == V4L2_PIX_FMT_UYVY)? "V4L2_PIX_FMT_UYVY" : "V4L2_PIX_FMT_YUYV"));
        			}

        			/*set the format */
		        DBG_PRINT_TRC0(("Set the input interface pixel format to - %s", test_options->pix_fmt));
		        ret = st_v4l2_capture_chk_pix_fmt();
		        if (FAILURE == ret)
		        {
			            stat = FAILURE;
			            st_v4l2_capture_close_interface(st_dev);
			            break;
        			}

		        ret = st_v4l2_capture_set_format_interface(st_dev);
		        if (FAILURE == ret)
		        {
			            DBG_PRINT_ERR(("S_FMT Ioctl Failed"));
			            stat = FAILURE;
			            st_v4l2_capture_close_interface(st_dev);
			            break;
		        }
		        else if (SUCCESS == ret)
			{
			            DBG_PRINT_TRC0(("S_FMT Ioctl Passed"));
        			}

			ret = st_v4l2_capture_get_format_interface(st_dev);
			if (FAILURE == ret)
		        {
			            DBG_PRINT_ERR(("G_FMT Ioctl Failed"));
			            stat = FAILURE;
			            st_v4l2_capture_close_interface(st_dev);
			            break;
		        }
		        else if (SUCCESS == ret)
			{
			            DBG_PRINT_TRC0(("G_FMT Ioctl Passed"));
		   	            DBG_PRINT_TRC0(("New pixel format is - %s", (common_pix == V4L2_PIX_FMT_UYVY)? "V4L2_PIX_FMT_UYVY" : "V4L2_PIX_FMT_YUYV"));
        			}
		}
				   DBG_PRINT_TRC0(("Testing of G_FMT/S_FMT IOCTL done successfully"));

	}
	break;

	case 4:
	{

		struct st_v4l2_fmtdesc st_fmt;
		for(i=0; i< test_options->loopcount; i++)
		{
			st_fmt.index = i;
			st_fmt.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;

		        ret = st_v4l2_capture_enum_format_interface(st_dev, &st_fmt);
		        if (FAILURE == ret)
		        {
			            DBG_PRINT_ERR(("VIDIOC_ENUM_FMT Ioctl Failed"));
			            stat = FAILURE;
			            st_v4l2_capture_close_interface(st_dev);
			            break;
		        }
		        else if (SUCCESS == ret)
			{
			        	    DBG_PRINT_TRC0(("VIDIOC_ENUM_FMT Ioctl Passed"));
     				    DBG_PRINT_TRC0(("index=%lu, type=%u, flags=%ld, " "pixelformat=%c%c%c%c, description='%s'", st_fmt.index, st_fmt.type, st_fmt.flags, (char)(st_fmt.pixelformat & 0xff), (char)((st_fmt.pixelformat >>  8) & 0xff), (char)((st_fmt.pixelformat >> 16) & 0xff), (char)((st_fmt.pixelformat >> 24) & 0xff), st_fmt.description));
		   	}


		}
				    DBG_PRINT_TRC0(("Testing of ENUM_FMT IOCTL done successfully"));
	}
	break;

	case 5:
	{
                for(i=0; i< test_options->loopcount; i++)
                {
	    		int ret = SUCCESS;
		        struct st_v4l2_control st_ctrl, g_ctrl;
	   		memset(&st_ctrl,0, sizeof(st_ctrl));
		        memset(&g_ctrl,0, sizeof(g_ctrl));

			switch (test_options->case_no)
			{
			case 0:
			          DBG_PRINT_TRC0(("Set the contrast"));
				  if((test_options->contrast > 255) ||
						  (test_options->contrast < 0))
				  {
					  DBG_PRINT_ERR(("Wrong	value passed - range:0-255"));
					  ret = FAILURE;
					  break;
			          }
                                  st_ctrl.value = test_options->contrast;
				  ret =	st_v4l2_set_contrast_interface(st_dev,st_ctrl);
				  if (SUCCESS != ret)
			    	  {
				          DBG_PRINT_ERR(("S_CTRL contrast Ioctl Failed"));
					  ret = FAILURE;
					  st_v4l2_capture_close_interface(st_dev);
				  }
				  else
				  {
					  DBG_PRINT_TRC0(("S_CTRL contrast Ioctl Passed"));   										                       }
  		                  ret = st_v4l2_get_contrast_interface(st_dev,&g_ctrl);
   		                  if (SUCCESS != ret)
				  {
					  DBG_PRINT_ERR(("G_CTRLI Ioctl Failed"));
					  ret =	FAILURE;
					  st_v4l2_capture_close_interface(st_dev);
				  }
				  else
				  {
					  DBG_PRINT_TRC0(("The Contrast Value %ld", g_ctrl.value));
					  DBG_PRINT_TRC0(("G_CTRL ioctl Passed"));
				  }
		           break;

			   case 1:
 				     DBG_PRINT_TRC0(("Set the brightness"));
			             if((test_options->brightness > 255) ||
						     (test_options->brightness < 0))
		                     {

					  DBG_PRINT_ERR(("Wrong value passed - range:0-255"));
					  ret =	FAILURE;
					  break;
				     }
				     st_ctrl.value = test_options->brightness;
				     ret = st_v4l2_set_brightness_interface(st_dev,st_ctrl);

			            if (SUCCESS != ret)
				    {
					    DBG_PRINT_ERR(("S_CTRL britness Ioctl Failed"));
					    ret = FAILURE;
					    st_v4l2_capture_close_interface(st_dev);
				    }
				    else
				    {
					    DBG_PRINT_TRC0(("S_CTRL britness Ioctl Passed"));
				    }
				    ret =  st_v4l2_get_brightness_interface(st_dev,&g_ctrl);
				    if (SUCCESS != ret)
				    {
					    DBG_PRINT_ERR(("G_CTRL Ioctl Failed"));
					    ret	= FAILURE;
					    st_v4l2_capture_close_interface(st_dev);
				    }
				    else
				    {
					    DBG_PRINT_TRC0(("The Brightness Value %ld", g_ctrl.value));
					    DBG_PRINT_TRC0(("G_CTRL Ioctl Passed"));
				    }
				    break;

		            case 2:
                		     DBG_PRINT_TRC0(("Set the Hue"));
				     if((test_options->hue > 180) || (test_options->hue < -180))
				     {
					    DBG_PRINT_ERR(("Wrongi value passed - range:-180-180"));
					    ret = FAILURE;
					    break;
				     }
				     ret = st_v4l2_set_hue_interface(st_dev,st_ctrl);
				     if(SUCCESS != ret)
				     {
					     DBG_PRINT_ERR(("S_CTRL hue Ioctl Failed"));
					     ret = FAILURE;
					     st_v4l2_capture_close_interface(st_dev);
				     }
				     else
				     {
					     DBG_PRINT_TRC0(("S_CTRL hue Ioctl Passed"));
				     }
				     st_ctrl.value = test_options->hue;
				     ret = st_v4l2_get_hue_interface(st_dev,&g_ctrl);
				     if(SUCCESS != ret)
				     {
					     DBG_PRINT_ERR(("G_CTRL Ioctl Failed"));
					     ret = FAILURE;
					     st_v4l2_capture_close_interface(st_dev);
				     }
				     else
				     {
					     DBG_PRINT_TRC0(("The Hue Value %ld", g_ctrl.value));
					     DBG_PRINT_TRC0(("G_CTRL Ioctl Passed"));
				     }
				     break;

			     case 3:
				     DBG_PRINT_TRC0(("Set the  Saturation"));
				     if((test_options->saturation > 255) || (test_options->saturation < 0))
				     {
					     DBG_PRINT_ERR(("Wrong value passed - range:0-255"));
					     ret = FAILURE;
					     break;
				     }
				     st_ctrl.value = test_options->saturation;
				     ret = st_v4l2_set_saturation_interface(st_dev,st_ctrl);
				     if(SUCCESS != ret)
				     {
					     DBG_PRINT_ERR(("S_CTRL saturation Ioctl Failed"));
					     ret = FAILURE;
					     st_v4l2_capture_close_interface(st_dev);
				     }
				     else
				     {
					     DBG_PRINT_TRC0(("S_CTRL saturation Ioctl Passed"));
				     }
				     ret = st_v4l2_get_saturation_interface(st_dev,&g_ctrl);
				     if(SUCCESS != ret)
				     {
					     DBG_PRINT_ERR(("G_CTRL Ioctl Failed"));
					     ret = FAILURE;
					     st_v4l2_capture_close_interface(st_dev);
				     }
				     else
				     {
					     DBG_PRINT_TRC0(("The Saturation Value %ld", g_ctrl.value));
					     DBG_PRINT_TRC0(("G_CTRL Ioctl Passed"));
				     }
				     break;
			     case 4:
				     DBG_PRINT_TRC0(("Set the Autogain"));
				     if((test_options->a_gain > 255) ||
						     (test_options->a_gain < 0))
				     {
					     DBG_PRINT_ERR(("Wrong value passed - range:0-1"));
					     ret = FAILURE;
					     break;
				     }
				     st_ctrl.value = test_options->a_gain;
				     ret = st_v4l2_set_autogain_interface(st_dev,st_ctrl);
				     if(SUCCESS != ret)
				     {
					     DBG_PRINT_ERR(("S_CTRL autogain Ioctl Failed"));
					     ret = FAILURE;
					     st_v4l2_capture_close_interface(st_dev);
				     }
				     else
				     {
					     DBG_PRINT_TRC0(("S_CTRL autogain Ioctl Passed"));
				     }

				     ret = st_v4l2_get_autogain_interface(st_dev,&g_ctrl);
				     if(SUCCESS != ret)
				     {
					     DBG_PRINT_ERR(("G_CTRL Ioctl Failed"));
					     ret = FAILURE;
					     st_v4l2_capture_close_interface(st_dev);
				     }
				     else
				     {
					     DBG_PRINT_TRC0(("The autogain Value %ld", g_ctrl.value));
					     DBG_PRINT_TRC0(("G_CTRL Ioctl Passed"));
				     }
				     break;

			     default:
				     ret = FAILURE;
				     DBG_PRINT_TRC0(("Unknown parameter"));
			}
		}

        }
        break;	
	default:
	st_v4l2_capture_test_suite_help();
	break;


}
	st_v4l2_capture_close_interface(st_dev);
	DBG_PRINT_TST_RESULT_PASS((test_id));
	DBG_PRINT_TST_END((test_id));

   } while (SUCCESS != ret);
return;
}
