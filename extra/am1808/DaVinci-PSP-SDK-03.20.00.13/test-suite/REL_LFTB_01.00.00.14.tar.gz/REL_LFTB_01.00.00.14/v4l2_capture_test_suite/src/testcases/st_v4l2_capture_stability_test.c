/*
 * st_v4l2_capture_stability_tests.c
 *
 * This file contains code to tests the stability of the V4L2 capture driver
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/ 
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/


 /*generic header files */
#include "st_v4l2_capture_common.h"

extern unsigned int common_int;
extern char common_char[32];
extern int cap_support;
extern unsigned int numbufs;

int std_flag;

 /****************************************************************************
 * Function             - st_v4l2_capture_test
 * Functionality        - Function to capture image of given width*height 
 * Input Params         - test_options structure with input parameters, testcaseid
 * Return Value         - None.
 * Note                 - None
 ****************************************************************************/
void st_v4l2_capture_stability_test(struct st_v4l2_capture_testparams
                                    *test_options, char *test_id,
                                    int stability)
{

    int ret = SUCCESS;
    int stat = SUCCESS;

    int st_dev;
    int st_ifc;
    int st_std, st_st;


    int j, i = 0;

    /* variables to track device state, mapping of buffers and state of V4L2 window */
    Bool open_stat = FALSE;



    /* get device number for a device string to avoid further string operations */
    st_v4l2_capture_set_device_number(test_options->device, &st_dev);

    do {
        for (j = 0; j < stability; j++) {

            if (test_options->open_mode == BLOCKING_OPEN_MODE) {        /* open V4L2 capture device */
                ret = st_v4l2_capture_open_interface(st_dev);
                if (SUCCESS != ret) {
                    if (DEV_NONEXISTENT == ret) {
                        DBG_PRINT_ERR(("Capture Device %s does not exist",
                                       test_options->device));
                    } else {
                        DBG_PRINT_ERR(("Failed to open V4L2 capture device /dev/video%d", st_dev));
                    }
                    stat = FAILURE;
                    break;
                }
            } else {            /* open V4L2 display device in non blocking mode */
                ret = st_v4l2_capture_open_nonblock_interface(st_dev);
                if (SUCCESS != ret) {
                    if (MODE_NOT_SUPPORTED == ret) {
                        DBG_PRINT_ERR(("This open mode is not supported"));
                        stat = FAILURE;
                        break;
                    } else if (DEV_NONEXISTENT == ret) {
                        DBG_PRINT_ERR(("Capture Device %s does not exist",
                                       test_options->device));
                        stat = FAILURE;
                        break;
                    } else {
                        DBG_PRINT_ERR(("Failed to open V4L2 capture device /dev/video%d", st_dev));
                        stat = FAILURE;
                        break;
                    }
                }
            }

            open_stat = TRUE;   // device is opened

            DBG_PRINT_TRC0(("V4L2 capture device node /dev/video%d opened", st_dev));

            /* get interface number for the interface string */
            st_v4l2_capture_set_interface_number(test_options->c_interfac,
                                                 &st_ifc);

            /*get input */
            ret = st_v4l2_capture_get_input_interface(st_dev);
            if (FAILURE == ret) {
                DBG_PRINT_ERR(("G_INPUT Ioctl Failed"));
                stat = FAILURE;
                st_v4l2_capture_close_interface(st_dev);
                break;
            } else if (SUCCESS == ret) {
                DBG_PRINT_TRC0(("G_INPUT Ioctl Passed"));

                if (st_ifc != common_int) {
                    DBG_PRINT_ERR(("Detected input interface is different from the one you are trying to set"));
                    stat = FAILURE;
                    st_v4l2_capture_close_interface(st_dev);
                    break;
                }
            }

            /*enum input */
            ret = st_v4l2_capture_enum_input_interface(st_dev);
            if (FAILURE == ret) {
                DBG_PRINT_ERR(("ENUMINPUT Ioctl Failed"));
                stat = FAILURE;
                st_v4l2_capture_close_interface(st_dev);
                break;
            } else if (SUCCESS == ret) {
                DBG_PRINT_TRC0(("ENUMINPUT Ioctl Passed"));
                DBG_PRINT_TRC0(("Input detected is %s", common_char));
            }

            /* get standard number for the standard string */
            st_v4l2_capture_set_standard_number(test_options->std,
                                                &st_std);

            /*query standard */
            ret = st_v4l2_capture_querystd_interface(st_dev);
            if (SUCCESS != ret) {
                DBG_PRINT_ERR(("QUERYSTD Ioctl Failed"));
                stat = FAILURE;
                st_v4l2_capture_close_interface(st_dev);
                break;
            }
            DBG_PRINT_TRC0(("QUERYSTD Ioctl Passed"));

            /*get the standard */
            ret = st_v4l2_capture_get_std_interface(st_dev);
            if (FAILURE == ret) {
                DBG_PRINT_ERR(("G_STD Ioctl Failed"));
                stat = FAILURE;
                st_v4l2_capture_close_interface(st_dev);
                break;
            } else if (SUCCESS == ret) {
                DBG_PRINT_TRC0(("G_STD Ioctl Passed"));
            }

            /*enum standard */
            ret = st_v4l2_capture_enum_std_interface(st_dev);
            if (FAILURE == ret) {
                DBG_PRINT_ERR(("ENUMSTD Ioctl Failed"));
                stat = FAILURE;
                st_v4l2_capture_close_interface(st_dev);
                break;
            } else if (SUCCESS == ret) {
                DBG_PRINT_TRC0(("ENUMSTD Ioctl Passed"));
                DBG_PRINT_TRC0(("Current standard is %s", common_char));

                if (strcmp(common_char, STD_NTSC)) {
                    std_flag = NTSC_STD;
                } else if (strcmp(common_char, STD_PAL)) {
                    std_flag = PAL_STD;
                } else if (strcmp(common_char, STD_480P)) {
                    std_flag = P480_STD;
                } else if (strcmp(common_char, STD_576P)) {
                    std_flag = P576_STD;
                } else if (strcmp(common_char, STD_720P_50FPS)) {
                    std_flag = P720_50_STD;
                } else if (strcmp(common_char, STD_720P_60FPS)) {
                    std_flag = P720_60_STD;
                } else if (strcmp(common_char, STD_1080I_25FPS)) {
                    std_flag = I1080_25_STD;
                } else if (strcmp(common_char, STD_1080I_30FPS)) {
                    std_flag = I1080_30_STD;
                }

                /* get standard number for the standard derived */
                st_v4l2_capture_set_standard_number(common_char, &st_st);

                if (st_std != st_st) {
                    DBG_PRINT_ERR(("Detected input standard is different from the one you are trying to set"));
                    stat = FAILURE;
                    st_v4l2_capture_close_interface(st_dev);
                    break;
                }
            }

            /*check if the device is capable of streaming */
            ret = st_v4l2_capture_chk_capability_interface(st_dev);
            if (FAILURE == ret) {
                DBG_PRINT_ERR(("QUERYCAP Ioctl Failed"));
                stat = FAILURE;
                st_v4l2_capture_close_interface(st_dev);
                break;
            } else if (SUCCESS == ret) {
                DBG_PRINT_TRC0(("QUERYCAP Ioctl Passed"));

                if (TRUE == cap_support) {
                    DBG_PRINT_TRC0(("Capture device is capable of streaming"));
                } else {
                    DBG_PRINT_ERR(("Capture device is not capable of streaming"));
                    stat = FAILURE;
                    st_v4l2_capture_close_interface(st_dev);
                    break;
                }
            }

            /*set the format */
            ret = st_v4l2_capture_set_format_interface(st_dev);
            if (FAILURE == ret) {
                DBG_PRINT_ERR(("S_FMT Ioctl Failed"));
                stat = FAILURE;
                st_v4l2_capture_close_interface(st_dev);
                break;
            } else if (SUCCESS == ret) {
                DBG_PRINT_TRC0(("S_FMT Ioctl Passed"));
            }

            /*chk the format */
            ret = st_v4l2_capture_get_format_interface(st_dev);
            if (SUCCESS != ret) {
                if (FORMAT_NOT_SUPPORTED == ret) {
                    DBG_PRINT_ERR(("Detected format is not the same as the one you tried to set"));
                } else {
                    DBG_PRINT_ERR(("G_FMT Ioctl Failed"));
                }
                stat = FAILURE;
                st_v4l2_capture_close_interface(st_dev);
                break;
            }
            DBG_PRINT_TRC0(("G_FMT Ioctl Passed"));

            /*request for buffers */
            ret =
                st_v4l2_capture_request_buffers_interface(st_dev,
                                                          test_options->
                                                          n_buffers,
                                                          test_options->
                                                          buf_xchange);
            if (SUCCESS != ret) {
                
                    DBG_PRINT_ERR(("REQBUFS Ioctl Failed"));
               

                stat = FAILURE;
                st_v4l2_capture_close_interface(st_dev);
                break;
            }
            DBG_PRINT_TRC0(("REQBUFS Ioctl Passed"));
            DBG_PRINT_TRC0(("No. of Buffers allocated is %d", numbufs));

            /*clear buffers */
            st_v4l2_capture_clear_buffers_interface();

            /*query, mmap and enqueue buffers */
            ret = st_v4l2_capture_query_mmap_que_buffers_interface(st_dev);
            if (SUCCESS != ret) {
                if (QUERYBUF_FAILED == ret) {
                    DBG_PRINT_ERR(("QUERYBUF Ioctl Failed"));
                } else if (MMAP_FAILED == ret) {
                    DBG_PRINT_ERR(("Could not mmap the buffers"));
                } else {
                    DBG_PRINT_ERR(("QBUF Ioctl Failed"));
                }

                stat = FAILURE;
                st_v4l2_capture_unmap_buffers_interface();
                st_v4l2_capture_close_interface(st_dev);
                break;
            }
            DBG_PRINT_TRC0(("QUERYBUF, mmap, QBUF Passed"));
            DBG_PRINT_TRC0(("Capture Initialised"));

            /*initialise display */
            ret =
                st_v4l2_capture_init_display_interface(test_options->
                                                       n_buffers);
            if (SUCCESS != ret) {
                if (SET_VIDEOPIPELINE_FAILED == ret) {
                    DBG_PRINT_ERR(("Cannot set video1 pipeline to LCD"));
                } else if (SET_OUTPUT_FAILED == ret) {
                    DBG_PRINT_ERR(("Cannot set output"));
                } else if (SET_MODE_FAILED == ret) {
                    DBG_PRINT_ERR(("Could not set mode"));
                } else if (DISPLAY_OPEN_FAILED == ret) {
                    DBG_PRINT_ERR(("Could not open display device"));
                } else {
                    DBG_PRINT_ERR(("Could not initialise display"));
                }
                stat = FAILURE;
                st_v4l2_capture_unmap_buffers_interface();
                st_v4l2_capture_close_interface(st_dev);
                break;
            }
            DBG_PRINT_TRC0(("Display Initialised"));
            /*stream on display */
            ret = st_v4l2_capture_streamon_display_interface();
            if (SUCCESS != ret) {
                DBG_PRINT_ERR(("Could not stream on display"));
                st_v4l2_capture_unmap_buffers_interface();
                st_v4l2_capture_close_interface(st_dev);
                stat = FAILURE;
                break;
            }
            DBG_PRINT_TRC0(("Display Stream on Passed"));

            /*stream on capture */
            ret = st_v4l2_capture_streamon_interface(st_dev);
            if (SUCCESS != ret) {
                DBG_PRINT_ERR(("Could not stream on capture"));
                st_v4l2_capture_unmap_buffers_interface();
                st_v4l2_capture_close_interface(st_dev);
                stat = FAILURE;
                break;
            }
            DBG_PRINT_TRC0(("Capture Stream on Passed"));

            /* Set the display buffers for queuing and dqueueing operation */
            st_v4l2_capture_set_display_interface();

            /* Set the capture buffers for queuing and dqueueing operation */
            st_v4l2_capture_set_interface();

            DBG_PRINT_TRC0(("Capturing and displaying now"));

            for (i = 0; i < test_options->n_frames; i++) {
                /* Dequeue display buffer */
                ret = st_v4l2_capture_dequeue_display_interface();
                if (SUCCESS != ret) {
                    DBG_PRINT_ERR(("Could not dequeue display buffer"));
                    st_v4l2_capture_unmap_buffers_interface();
                    st_v4l2_capture_close_interface(st_dev);
                    stat = FAILURE;
                    break;
                }


                /* Dequeue capture buffer */
                ret = st_v4l2_capture_dequeue_interface(st_dev);
                if (SUCCESS != ret) {
                    DBG_PRINT_ERR(("Could not dequeue capture buffer"));
                    st_v4l2_capture_unmap_buffers_interface();
                    st_v4l2_capture_close_interface(st_dev);
                    stat = FAILURE;
                    break;
                }


                /* Process image */
                st_v4l2_capture_process_image_interface();

                /* queue capture buffer */
                ret = st_v4l2_capture_queue_interface(st_dev);
                if (SUCCESS != ret) {
                    DBG_PRINT_ERR(("Could not queue capture buffer"));
                    st_v4l2_capture_unmap_buffers_interface();
                    st_v4l2_capture_close_interface(st_dev);
                    stat = FAILURE;
                    break;
                }


                /* queue display buffer */
                ret = st_v4l2_capture_queue_display_interface();
                if (SUCCESS != ret) {
                    DBG_PRINT_ERR(("Could not queue display buffer"));
                    st_v4l2_capture_unmap_buffers_interface();
                    st_v4l2_capture_close_interface(st_dev);
                    stat = FAILURE;
                    break;
                }


            }

            /*stream off display */
            ret = st_v4l2_capture_streamoff_display_interface();
            if (SUCCESS != ret) {
                DBG_PRINT_ERR(("Could not stream off display"));
                st_v4l2_capture_unmap_buffers_interface();
                st_v4l2_capture_close_interface(st_dev);
                stat = FAILURE;
                break;
            }
            DBG_PRINT_TRC0(("Display Stream off Passed"));

            /*stream off capture */
            ret = st_v4l2_capture_streamoff_interface(st_dev);
            if (SUCCESS != ret) {
                DBG_PRINT_ERR(("Could not stream off capture"));
                st_v4l2_capture_unmap_buffers_interface();
                st_v4l2_capture_close_interface(st_dev);
                stat = FAILURE;
                break;
            }
            DBG_PRINT_TRC0(("Capture Stream off Passed"));

            /*unmap and close display */
            st_v4l2_capture_unmap_close_display_interface();

            st_v4l2_capture_unmap_buffers_interface();
            st_v4l2_capture_close_interface(st_dev);

            open_stat = FALSE;  // device is closed
        }
    } while (SUCCESS != ret);
    if (FAILURE == stat) {
        DBG_PRINT_TST_RESULT_FAIL((test_id));
    } else {
        DBG_PRINT_TST_RESULT_PASS((test_id));
    }
    /* end test case */
    DBG_PRINT_TST_END((test_id));

}


/* vim: set ts=4 sw=4 tw=80 et:*/
