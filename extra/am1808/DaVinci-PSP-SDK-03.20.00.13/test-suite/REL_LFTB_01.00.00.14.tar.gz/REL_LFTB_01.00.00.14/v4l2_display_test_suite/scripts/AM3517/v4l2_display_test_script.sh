#  AM3517_v4l2_display_test_sample_script

#Prints the usage/help
./v4l2_display_tests --help

#Prints the version
./v4l2_display_tests -v

echo "Running tests on OMAP35x GIT Release"
echo "Testing on LCD with video1 device"

#Runs the default color bar display-No options provided
./v4l2_display_tests -n 200 -t V4L2_DEFAULT_COLOR_BAR_DISPLAY_TEST  

echo "RUN_THE_V4L2_TEST_WITH_THROUGHPUT_LCD_DISPLAY"   
./v4l2_display_tests -F  -t V4L2_DISPLAY_TEST_WITH_THROUGHTPUT_INFORMATION

echo "RUN_THE_V4L2_TEST_WITH_CPULOAD_LCD_DISPLAY"   
./v4l2_display_tests -l  -t V4L2_DISPLAY_TEST_WITH_CPULOAD_INFORMATION

echo "RUN_THE_V4L2_TEST_WITH_THROUGHPUT_CPULOAD_LCD_DISPLAY"   
./v4l2_display_tests -F -l  -t V4L2_DISPLAY_TEST_WITH_THROUGHTPUT_CPULOAD_INFORMATION

echo "Run the v4l2 tests for different standard resolutions"
#Run the display test- Displays default color bar with width (-w) 720, height (-h) 480, number of buffers queued is (-c) 3 and number of iterations (-n) 500 
./v4l2_display_tests -n 200 -w 640 -h 480 -c 3 -t V4L2_VGA_DISPLAY_TEST
./v4l2_display_tests -n 200 -w 320 -h 240 -c 3 -t V4L2_QVGA_DISPLAY_TEST
./v4l2_display_tests -n 200 -w 160 -h 120 -c 3 -t V4L2_QQVGA_DISPLAY_TEST

echo "Run the v4l2 tests for different pixel format"

./v4l2_display_tests -n 200 -p RGB565 -t V4L2_TEST_PIXEL_FORMAT_RGB565
./v4l2_display_tests -n 200 -p UYVY   -t V4L2_TEST_PIXEL_FORMAT_UYVY
./v4l2_display_tests -n 200 -p YUYV   -t V4L2_TEST_PIXEL_FORMAT_YUYV
./v4l2_display_tests -n 200 -p RGB888 -t V4L2_TEST_PIXEL_FORMAT_RGB888

#Run the api test case for some crop factor   
echo "Run the v4l2 tests for different crop factor with different resolution"
./v4l2_display_tests -n 200 -r 0 -w 640 -h 480 -c 3 -t  V4L2_CROPPING_VGA_DISPLAY_CROP_FACTOR_0_TEST
./v4l2_display_tests -n 200 -r 2 -w 640 -h 480 -c 3 -t  V4L2_CROPPING_VGA_DISPLAY_CROP_FACTOR_2_TEST
./v4l2_display_tests -n 200 -r 4 -w 640 -h 480 -c 3 -t  V4L2_CROPPING_VGA_DISPLAY_CROP_FACTOR_4_TEST
./v4l2_display_tests -n 200 -r 8 -w 640 -h 480 -c 3 -t  V4L2_CROPPING_VGA_DISPLAY_CROP_FACTOR_8_TEST

./v4l2_display_tests -n 200 -r 0 -w 320 -h 240 -c 3 -t  V4L2_CROPPING_QVGA_DISPLAY_CROP_FACTOR_0_TEST
./v4l2_display_tests -n 200 -r 2 -w 320 -h 240 -c 3 -t  V4L2_CROPPING_QVGA_DISPLAY_CROP_FACTOR_2_TEST
./v4l2_display_tests -n 200 -r 4 -w 320 -h 240 -c 3 -t  V4L2_CROPPING_QVGA_DISPLAY_CROP_FACTOR_4_TEST
./v4l2_display_tests -n 200 -r 8 -w 320 -h 240 -c 3 -t  V4L2_CROPPING_QVGA_DISPLAY_CROP_FACTOR_8_TEST

./v4l2_display_tests -n 200 -r 0 -w 160 -h 120 -c 3 -t  V4L2_CROPPING_QQVGA_DISPLAY_CROP_FACTOR_0_TEST
./v4l2_display_tests -n 200 -r 2 -w 160 -h 120 -c 3 -t  V4L2_CROPPING_QQVGA_DISPLAY_CROP_FACTOR_2_TEST
./v4l2_display_tests -n 200 -r 4 -w 160 -h 120 -c 3 -t  V4L2_CROPPING_QQVGA_DISPLAY_CROP_FACTOR_4_TEST
./v4l2_display_tests -n 200 -r 8 -w 160 -h 120 -c 3 -t  V4L2_CROPPING_QQVGA_DISPLAY_CROP_FACTOR_8_TEST

echo "Run the v4l2 tests for different crop factor with different pixel formats"
./v4l2_display_tests -n 200 -r 0 -p RGB565 -t V4L2_CROPPING_TEST_CROP_FACTOR_0_PIXEL_FORMAT_RGB565
./v4l2_display_tests -n 200 -r 2 -p RGB565 -t V4L2_CROPPING_TEST_CROP_FACTOR_2_PIXEL_FORMAT_RGB565
./v4l2_display_tests -n 200 -r 4 -p RGB565 -t V4L2_CROPPING_TEST_CROP_FACTOR_4_PIXEL_FORMAT_RGB565
./v4l2_display_tests -n 200 -r 8 -p RGB565 -t V4L2_CROPPING_TEST_CROP_FACTOR_8_PIXEL_FORMAT_RGB565

./v4l2_display_tests -n 200 -r 0 -p UYVY -t V4L2_CROPPING_TEST_CROP_FACTOR_0_PIXEL_FORMAT_UYVY
./v4l2_display_tests -n 200 -r 2 -p UYVY -t V4L2_CROPPING_TEST_CROP_FACTOR_2_PIXEL_FORMAT_UYVY
./v4l2_display_tests -n 200 -r 4 -p UYVY -t V4L2_CROPPING_TEST_CROP_FACTOR_4_PIXEL_FORMAT_UYVY
./v4l2_display_tests -n 200 -r 8 -p UYVY -t V4L2_CROPPING_TEST_CROP_FACTOR_8_PIXEL_FORMAT_UYVY

./v4l2_display_tests -n 200 -r 0 -p YUYV -t V4L2_CROPPING_TEST_CROP_FACTOR_0_PIXEL_FORMAT_YUYV
./v4l2_display_tests -n 200 -r 2 -p YUYV -t V4L2_CROPPING_TEST_CROP_FACTOR_2_PIXEL_FORMAT_YUYV
./v4l2_display_tests -n 200 -r 4 -p YUYV -t V4L2_CROPPING_TEST_CROP_FACTOR_4_PIXEL_FORMAT_YUYV
./v4l2_display_tests -n 200 -r 8 -p YUYV -t V4L2_CROPPING_TEST_CROP_FACTOR_8_PIXEL_FORMAT_YUYV

./v4l2_display_tests -n 200 -r 0 -p RGB888 -t V4L2_CROPPING_TEST_CROP_FACTOR_0_PIXEL_FORMAT_RGB888
./v4l2_display_tests -n 200 -r 2 -p RGB888 -t V4L2_CROPPING_TEST_CROP_FACTOR_2_PIXEL_FORMAT_RGB888
./v4l2_display_tests -n 200 -r 4 -p RGB888 -t V4L2_CROPPING_TEST_CROP_FACTOR_4_PIXEL_FORMAT_RGB888
./v4l2_display_tests -n 200 -r 8 -p RGB888 -t V4L2_CROPPING_TEST_CROP_FACTOR_8_PIXEL_FORMAT_RGB888

echo "Running Rotation tests with different resolutions"
#runs the default color bar test with mmap option and various other rotation options

./v4l2_display_tests -n 200 -R 0   -w 640 -h 480 -c 3 -t V4L2_ROTATION_0_DEGREE_VGA_DISPLAY_TEST
./v4l2_display_tests -n 200 -R 90  -w 640 -h 480 -c 3 -t V4L2_ROTATION_90_DEGREE_VGA_DISPLAY_TEST
./v4l2_display_tests -n 200 -R 180 -w 640 -h 480 -c 3 -t V4L2_ROTATION_180_DEGREE_VGA_DISPLAY_TEST
./v4l2_display_tests -n 200 -R 270 -w 640 -h 480 -c 3 -t V4L2_ROTATION_270_DEGREE_VGA_DISPLAY_TEST

./v4l2_display_tests -n 200 -R 0   -w 320 -h 240 -c 3 -t V4L2_ROTATION_0_DEGREE_QVGA_DISPLAY_TEST
./v4l2_display_tests -n 200 -R 90  -w 320 -h 240 -c 3 -t V4L2_ROTATION_90_DEGREE_QVGA_DISPLAY_TEST
./v4l2_display_tests -n 200 -R 180 -w 320 -h 240 -c 3 -t V4L2_ROTATION_180_DEGREE_QVGA_DISPLAY_TEST
./v4l2_display_tests -n 200 -R 270 -w 320 -h 240 -c 3 -t V4L2_ROTATION_270_DEGREE_QVGA_DISPLAY_TEST

./v4l2_display_tests -n 200 -R 0   -w 160 -h 120 -c 3 -t V4L2_ROTATION_0_DEGREE_QQVGA_DISPLAY_TEST
./v4l2_display_tests -n 200 -R 90  -w 160 -h 120 -c 3 -t V4L2_ROTATION_90_DEGREE_QQVGA_DISPLAY_TEST
./v4l2_display_tests -n 200 -R 180 -w 160 -h 120 -c 3 -t V4L2_ROTATION_180_DEGREE_QQVGA_DISPLAY_TEST
./v4l2_display_tests -n 200 -R 270 -w 160 -h 120 -c 3 -t V4L2_ROTATION_270_DEGREE_QQVGA_DISPLAY_TEST

echo "Running Rotation tests with different pixel formats"

./v4l2_display_tests -n 200 -R 0   -p RGB565 -t V4L2_ROTATION_0_DEGREE_TEST_PIXEL_FORMAT_RGB565
./v4l2_display_tests -n 200 -R 90  -p RGB565 -t V4L2_ROTATION_90_DEGREE_TEST_PIXEL_FORMAT_RGB565
./v4l2_display_tests -n 200 -R 180 -p RGB565 -t V4L2_ROTATION_180_DEGREE_TEST_PIXEL_FORMAT_RGB565
./v4l2_display_tests -n 200 -R 270 -p RGB565 -t V4L2_ROTATION_270_DEGREE_TEST_PIXEL_FORMAT_RGB565

./v4l2_display_tests -n 200 -R 0   -p UYVY -t V4L2_ROTATION_0_DEGREE_TEST_PIXEL_FORMAT_UYVY
./v4l2_display_tests -n 200 -R 90  -p UYVY -t V4L2_ROTATION_90_DEGREE_TEST_PIXEL_FORMAT_UYVY
./v4l2_display_tests -n 200 -R 180 -p UYVY -t V4L2_ROTATION_180_DEGREE_TEST_PIXEL_FORMAT_UYVY
./v4l2_display_tests -n 200 -R 270 -p UYVY -t V4L2_ROTATION_270_DEGREE_TEST_PIXEL_FORMAT_UYVY

./v4l2_display_tests -n 200 -R 0   -p YUYV -t V4L2_ROTATION_0_DEGREE_TEST_PIXEL_FORMAT_YUYV
./v4l2_display_tests -n 200 -R 90  -p YUYV -t V4L2_ROTATION_90_DEGREE_TEST_PIXEL_FORMAT_YUYV
./v4l2_display_tests -n 200 -R 180 -p YUYV -t V4L2_ROTATION_180_DEGREE_TEST_PIXEL_FORMAT_YUYV
./v4l2_display_tests -n 200 -R 270 -p YUYV -t V4L2_ROTATION_270_DEGREE_TEST_PIXEL_FORMAT_YUYV

#Run the API test- Runs all APIs supported. -T stands for special tests like api,stability. Currently only api,stability can be passed for -T. Wheraes the smsmall letter -t stands for test name(will be logged) and helpful for testers reference. User can pass any string to small -t option but string shouldn't have any spaces.
echo "Run the v4l2 api test cases "
./v4l2_display_tests -T api -t V4L2_API_TESTS

#Run the stability Test
echo "RUN_THE_V4L2_STABILITY_TEST"   
./v4l2_display_tests -n 200 -T stability -C 3 -t V4L2_DISPLAY_STABILITY_TEST

#runs the default color bar test with user pointer option and various other options
echo "RUN_THE_V4L2_TEST_WITH_USER_POINTER"   
./v4l2_display_tests -n 200 -u 1 -t V4L2_DISPLAY_TEST_WITH_USER_POINTER

echo "Testing on Video1 with LCD complete"

echo "Starting Tests on LCD with video2 device"

#Runs the default color bar display-No options provided
./v4l2_display_tests -d /dev/video2 -n 200 -t V4L2_DEFAULT_COLOR_BAR_DISPLAY_TEST  

echo "RUN_THE_V4L2_TEST_WITH_THROUGHPUT_LCD_DISPLAY"   
./v4l2_display_tests -d /dev/video2 -F  -t V4L2_DISPLAY_TEST_WITH_THROUGHTPUT_INFORMATION

echo "RUN_THE_V4L2_TEST_WITH_CPULOAD_LCD_DISPLAY"   
./v4l2_display_tests -d /dev/video2 -l  -t V4L2_DISPLAY_TEST_WITH_CPULOAD_INFORMATION

echo "RUN_THE_V4L2_TEST_WITH_THROUGHPUT_CPULOAD_LCD_DISPLAY"   
./v4l2_display_tests -d /dev/video2 -F -l  -t V4L2_DISPLAY_TEST_WITH_THROUGHTPUT_CPULOAD_INFORMATION

echo "Run the v4l2 tests -d /dev/video2 -d /dev/video2 for different standard resolutions"
#Run the display test- Displays default color bar with width (-w) 720, height (-h) 480, number of buffers queued is (-c) 3 and number of iterations (-n) 500 
./v4l2_display_tests -d /dev/video2 -n 200 -w 640 -h 480 -c 3 -t V4L2_VGA_DISPLAY_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -w 320 -h 240 -c 3 -t V4L2_QVGA_DISPLAY_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -w 160 -h 120 -c 3 -t V4L2_QQVGA_DISPLAY_TEST

echo "Run the v4l2 tests for different pixel format"

./v4l2_display_tests -d /dev/video2 -n 200 -p RGB565 -t V4L2_TEST_PIXEL_FORMAT_RGB565
./v4l2_display_tests -d /dev/video2 -n 200 -p UYVY   -t V4L2_TEST_PIXEL_FORMAT_UYVY
./v4l2_display_tests -d /dev/video2 -n 200 -p YUYV   -t V4L2_TEST_PIXEL_FORMAT_YUYV
./v4l2_display_tests -d /dev/video2 -n 200 -p RGB888 -t V4L2_TEST_PIXEL_FORMAT_RGB888

#Run the api test case for some crop factor   
echo "Run the v4l2 tests for different crop factor with different resolution"
./v4l2_display_tests -d /dev/video2 -n 200 -r 0 -w 640 -h 480 -c 3 -t  V4L2_CROPPING_VGA_DISPLAY_CROP_FACTOR_0_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -r 2 -w 640 -h 480 -c 3 -t  V4L2_CROPPING_VGA_DISPLAY_CROP_FACTOR_2_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -r 4 -w 640 -h 480 -c 3 -t  V4L2_CROPPING_VGA_DISPLAY_CROP_FACTOR_4_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -r 8 -w 640 -h 480 -c 3 -t  V4L2_CROPPING_VGA_DISPLAY_CROP_FACTOR_8_TEST

./v4l2_display_tests -d /dev/video2 -n 200 -r 0 -w 320 -h 240 -c 3 -t  V4L2_CROPPING_QVGA_DISPLAY_CROP_FACTOR_0_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -r 2 -w 320 -h 240 -c 3 -t  V4L2_CROPPING_QVGA_DISPLAY_CROP_FACTOR_2_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -r 4 -w 320 -h 240 -c 3 -t  V4L2_CROPPING_QVGA_DISPLAY_CROP_FACTOR_4_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -r 8 -w 320 -h 240 -c 3 -t  V4L2_CROPPING_QVGA_DISPLAY_CROP_FACTOR_8_TEST

./v4l2_display_tests -d /dev/video2 -n 200 -r 0 -w 160 -h 120 -c 3 -t  V4L2_CROPPING_QQVGA_DISPLAY_CROP_FACTOR_0_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -r 2 -w 160 -h 120 -c 3 -t  V4L2_CROPPING_QQVGA_DISPLAY_CROP_FACTOR_2_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -r 4 -w 160 -h 120 -c 3 -t  V4L2_CROPPING_QQVGA_DISPLAY_CROP_FACTOR_4_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -r 8 -w 160 -h 120 -c 3 -t  V4L2_CROPPING_QQVGA_DISPLAY_CROP_FACTOR_8_TEST

echo "Run the v4l2 tests for different crop factor with different pixel formats"
./v4l2_display_tests -d /dev/video2 -n 200 -r 0 -p RGB565 -t V4L2_CROPPING_TEST_CROP_FACTOR_0_PIXEL_FORMAT_RGB565
./v4l2_display_tests -d /dev/video2 -n 200 -r 2 -p RGB565 -t V4L2_CROPPING_TEST_CROP_FACTOR_2_PIXEL_FORMAT_RGB565
./v4l2_display_tests -d /dev/video2 -n 200 -r 4 -p RGB565 -t V4L2_CROPPING_TEST_CROP_FACTOR_4_PIXEL_FORMAT_RGB565
./v4l2_display_tests -d /dev/video2 -n 200 -r 8 -p RGB565 -t V4L2_CROPPING_TEST_CROP_FACTOR_8_PIXEL_FORMAT_RGB565

./v4l2_display_tests -d /dev/video2 -n 200 -r 0 -p UYVY -t V4L2_CROPPING_TEST_CROP_FACTOR_0_PIXEL_FORMAT_UYVY
./v4l2_display_tests -d /dev/video2 -n 200 -r 2 -p UYVY -t V4L2_CROPPING_TEST_CROP_FACTOR_2_PIXEL_FORMAT_UYVY
./v4l2_display_tests -d /dev/video2 -n 200 -r 4 -p UYVY -t V4L2_CROPPING_TEST_CROP_FACTOR_4_PIXEL_FORMAT_UYVY
./v4l2_display_tests -d /dev/video2 -n 200 -r 8 -p UYVY -t V4L2_CROPPING_TEST_CROP_FACTOR_8_PIXEL_FORMAT_UYVY

./v4l2_display_tests -d /dev/video2 -n 200 -r 0 -p YUYV -t V4L2_CROPPING_TEST_CROP_FACTOR_0_PIXEL_FORMAT_YUYV
./v4l2_display_tests -d /dev/video2 -n 200 -r 2 -p YUYV -t V4L2_CROPPING_TEST_CROP_FACTOR_2_PIXEL_FORMAT_YUYV
./v4l2_display_tests -d /dev/video2 -n 200 -r 4 -p YUYV -t V4L2_CROPPING_TEST_CROP_FACTOR_4_PIXEL_FORMAT_YUYV
./v4l2_display_tests -d /dev/video2 -n 200 -r 8 -p YUYV -t V4L2_CROPPING_TEST_CROP_FACTOR_8_PIXEL_FORMAT_YUYV

./v4l2_display_tests -d /dev/video2 -n 200 -r 0 -p RGB888 -t V4L2_CROPPING_TEST_CROP_FACTOR_0_PIXEL_FORMAT_RGB888
./v4l2_display_tests -d /dev/video2 -n 200 -r 2 -p RGB888 -t V4L2_CROPPING_TEST_CROP_FACTOR_2_PIXEL_FORMAT_RGB888
./v4l2_display_tests -d /dev/video2 -n 200 -r 4 -p RGB888 -t V4L2_CROPPING_TEST_CROP_FACTOR_4_PIXEL_FORMAT_RGB888
./v4l2_display_tests -d /dev/video2 -n 200 -r 8 -p RGB888 -t V4L2_CROPPING_TEST_CROP_FACTOR_8_PIXEL_FORMAT_RGB888

echo "Running Rotation tests with different resolutions"
#runs the default color bar test with mmap option and various other rotation options

./v4l2_display_tests -d /dev/video2 -n 200 -R 0   -w 640 -h 480 -c 3 -t V4L2_ROTATION_0_DEGREE_VGA_DISPLAY_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -R 90  -w 640 -h 480 -c 3 -t V4L2_ROTATION_90_DEGREE_VGA_DISPLAY_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -R 180 -w 640 -h 480 -c 3 -t V4L2_ROTATION_180_DEGREE_VGA_DISPLAY_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -R 270 -w 640 -h 480 -c 3 -t V4L2_ROTATION_270_DEGREE_VGA_DISPLAY_TEST

./v4l2_display_tests -d /dev/video2 -n 200 -R 0   -w 320 -h 240 -c 3 -t V4L2_ROTATION_0_DEGREE_QVGA_DISPLAY_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -R 90  -w 320 -h 240 -c 3 -t V4L2_ROTATION_90_DEGREE_QVGA_DISPLAY_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -R 180 -w 320 -h 240 -c 3 -t V4L2_ROTATION_180_DEGREE_QVGA_DISPLAY_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -R 270 -w 320 -h 240 -c 3 -t V4L2_ROTATION_270_DEGREE_QVGA_DISPLAY_TEST

./v4l2_display_tests -d /dev/video2 -n 200 -R 0   -w 160 -h 120 -c 3 -t V4L2_ROTATION_0_DEGREE_QQVGA_DISPLAY_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -R 90  -w 160 -h 120 -c 3 -t V4L2_ROTATION_90_DEGREE_QQVGA_DISPLAY_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -R 180 -w 160 -h 120 -c 3 -t V4L2_ROTATION_180_DEGREE_QQVGA_DISPLAY_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -R 270 -w 160 -h 120 -c 3 -t V4L2_ROTATION_270_DEGREE_QQVGA_DISPLAY_TEST

echo "Running Rotation tests with different pixel formats"

./v4l2_display_tests -d /dev/video2 -n 200 -R 0   -p RGB565 -t V4L2_ROTATION_0_DEGREE_TEST_PIXEL_FORMAT_RGB565
./v4l2_display_tests -d /dev/video2 -n 200 -R 90  -p RGB565 -t V4L2_ROTATION_90_DEGREE_TEST_PIXEL_FORMAT_RGB565
./v4l2_display_tests -d /dev/video2 -n 200 -R 180 -p RGB565 -t V4L2_ROTATION_180_DEGREE_TEST_PIXEL_FORMAT_RGB565
./v4l2_display_tests -d /dev/video2 -n 200 -R 270 -p RGB565 -t V4L2_ROTATION_270_DEGREE_TEST_PIXEL_FORMAT_RGB565

./v4l2_display_tests -d /dev/video2 -n 200 -R 0   -p UYVY -t V4L2_ROTATION_0_DEGREE_TEST_PIXEL_FORMAT_UYVY
./v4l2_display_tests -d /dev/video2 -n 200 -R 90  -p UYVY -t V4L2_ROTATION_90_DEGREE_TEST_PIXEL_FORMAT_UYVY
./v4l2_display_tests -d /dev/video2 -n 200 -R 180 -p UYVY -t V4L2_ROTATION_180_DEGREE_TEST_PIXEL_FORMAT_UYVY
./v4l2_display_tests -d /dev/video2 -n 200 -R 270 -p UYVY -t V4L2_ROTATION_270_DEGREE_TEST_PIXEL_FORMAT_UYVY

./v4l2_display_tests -d /dev/video2 -n 200 -R 0   -p YUYV -t V4L2_ROTATION_0_DEGREE_TEST_PIXEL_FORMAT_YUYV
./v4l2_display_tests -d /dev/video2 -n 200 -R 90  -p YUYV -t V4L2_ROTATION_90_DEGREE_TEST_PIXEL_FORMAT_YUYV
./v4l2_display_tests -d /dev/video2 -n 200 -R 180 -p YUYV -t V4L2_ROTATION_180_DEGREE_TEST_PIXEL_FORMAT_YUYV
./v4l2_display_tests -d /dev/video2 -n 200 -R 270 -p YUYV -t V4L2_ROTATION_270_DEGREE_TEST_PIXEL_FORMAT_YUYV

#Run the API test- Runs all APIs supported. -T stands for special tests -d /dev/video2 like api,stability. Currently only api,stability can be passed for -T. Wheraes the smsmall letter -t stands for test name(will be logged) and helpful for testers reference. User can pass any string to small -t option but string shouldn't have any spaces.
echo "Run the v4l2 api test cases "
./v4l2_display_tests -d /dev/video2 -T api -t V4L2_API_TESTS

#Run the stability Test
echo "RUN_THE_V4L2_STABILITY_TEST"   
./v4l2_display_tests -d /dev/video2 -n 200 -T stability -C 3 -t V4L2_DISPLAY_STABILITY_TEST

#runs the default color bar test with user pointer option and various other options
echo "RUN_THE_V4L2_TEST_WITH_USER_POINTER"   
./v4l2_display_tests -d /dev/video2 -n 200 -u 1 -t V4L2_DISPLAY_TEST_WITH_USER_POINTER

./v4l2_display_tests -T alpha 

echo "Testing on video2 with LCD complete"

sleep 1000

echo "Switching to TV"
echo "Switching video1 to TV"

echo 0 > /sys/devices/platform/omapdss/overlay0/enabled
echo "" > /sys/devices/platform/omapdss/overlay0/manager
echo 0 > /sys/devices/platform/omapdss/display0/enabled
#fbset -fb /dev/fb0 -xres $w -yres $h -vxres $w -vyres $h
echo "tv" > /sys/devices/platform/omapdss/overlay0/manager
echo 1 > /sys/devices/platform/omapdss/display1/enabled
echo 1 > /sys/devices/platform/omapdss/overlay0/enabled

#Runs the default color bar display-No options provided
./v4l2_display_tests -n 200 -t V4L2_DEFAULT_COLOR_BAR_DISPLAY_TEST

#Run the performance tests
echo "RUN_THE_V4L2_TEST_WITH_THROUGHPUT_TV_DISPLAY_NTSC"   
./v4l2_display_tests -w 720 -h 480 -F -t V4L2_DISPLAY_TEST_WITH_THROUGHTPUT_INFORMATION_NTSC

echo "RUN_THE_V4L2_TEST_WITH_CPULOAD_TV_DISPLAY_NTSC"   
./v4l2_display_tests -w 720 -h 480 -l -t V4L2_DISPLAY_TEST_WITH_CPULOAD_INFORMATION_NTSC

echo "RUN_THE_V4L2_TEST_WITH_THROUGHPUT_AND_CPULOAD_TV_DISPLAY_NTSC"   
./v4l2_display_tests -w 720 -h 480 -F -l -t V4L2_DISPLAY_TEST_WITH_THROUGHPUT_CPULOAD_INFORMATION_NTSC

echo "RUN_THE_V4L2_TEST_WITH_THROUGHPUT_TV_DISPLAY_PAL"   
./v4l2_display_tests -w 720 -h 576 -F -t V4L2_DISPLAY_TEST_WITH_THROUGHTPUT_INFORMATION_PAL

echo "RUN_THE_V4L2_TEST_WITH_CPULOAD_TV_DISPLAY_PAL"   
./v4l2_display_tests -w 720 -h 576 -l -t V4L2_DISPLAY_TEST_WITH_CPULOAD_INFORMATION_PAL

echo "RUN_THE_V4L2_TEST_WITH_THROUGHPUT_AND_CPULOAD_TV_DISPLAY_PAL"   
./v4l2_display_tests -w 720 -h 576 -F -l -t V4L2_DISPLAY_TEST_WITH_THROUGHPUT_CPULOAD_INFORMATION_PAL

echo "Run the v4l2 tests for different standard resolutions"
#Run the display test- Displays default color bar with width (-w) 720, height (-h) 480, number of buffers queued is (-c) 3 and number of iterations (-n) 500 
./v4l2_display_tests -n 200 -w 640 -h 480 -c 3 -t V4L2_VGA_DISPLAY_TEST
./v4l2_display_tests -n 200 -w 320 -h 240 -c 3 -t V4L2_QVGA_DISPLAY_TEST
./v4l2_display_tests -n 200 -w 160 -h 120 -c 3 -t V4L2_QQVGA_DISPLAY_TEST

echo "Run the v4l2 tests for different pixel format"

./v4l2_display_tests -n 200 -p RGB565 -t V4L2_TEST_PIXEL_FORMAT_RGB565
./v4l2_display_tests -n 200 -p UYVY   -t V4L2_TEST_PIXEL_FORMAT_UYVY
./v4l2_display_tests -n 200 -p YUYV   -t V4L2_TEST_PIXEL_FORMAT_YUYV
./v4l2_display_tests -n 200 -p RGB888 -t V4L2_TEST_PIXEL_FORMAT_RGB888

echo "Run the v4l2 tests for different crop factor with different resolution"
./v4l2_display_tests -n 200 -r 0 -w 640 -h 480 -c 3 -t  V4L2_CROPPING_VGA_DISPLAY_CROP_FACTOR_0_TEST
./v4l2_display_tests -n 200 -r 2 -w 640 -h 480 -c 3 -t  V4L2_CROPPING_VGA_DISPLAY_CROP_FACTOR_2_TEST
./v4l2_display_tests -n 200 -r 4 -w 640 -h 480 -c 3 -t  V4L2_CROPPING_VGA_DISPLAY_CROP_FACTOR_4_TEST
./v4l2_display_tests -n 200 -r 8 -w 640 -h 480 -c 3 -t  V4L2_CROPPING_VGA_DISPLAY_CROP_FACTOR_8_TEST

./v4l2_display_tests -n 200 -r 0 -w 320 -h 240 -c 3 -t  V4L2_CROPPING_QVGA_DISPLAY_CROP_FACTOR_0_TEST
./v4l2_display_tests -n 200 -r 2 -w 320 -h 240 -c 3 -t  V4L2_CROPPING_QVGA_DISPLAY_CROP_FACTOR_2_TEST
./v4l2_display_tests -n 200 -r 4 -w 320 -h 240 -c 3 -t  V4L2_CROPPING_QVGA_DISPLAY_CROP_FACTOR_4_TEST
./v4l2_display_tests -n 200 -r 8 -w 320 -h 240 -c 3 -t  V4L2_CROPPING_QVGA_DISPLAY_CROP_FACTOR_8_TEST

./v4l2_display_tests -n 200 -r 0 -w 160 -h 120 -c 3 -t  V4L2_CROPPING_QQVGA_DISPLAY_CROP_FACTOR_0_TEST
./v4l2_display_tests -n 200 -r 2 -w 160 -h 120 -c 3 -t  V4L2_CROPPING_QQVGA_DISPLAY_CROP_FACTOR_2_TEST
./v4l2_display_tests -n 200 -r 4 -w 160 -h 120 -c 3 -t  V4L2_CROPPING_QQVGA_DISPLAY_CROP_FACTOR_4_TEST
./v4l2_display_tests -n 200 -r 8 -w 160 -h 120 -c 3 -t  V4L2_CROPPING_QQVGA_DISPLAY_CROP_FACTOR_8_TEST

./v4l2_display_tests -n 200 -r 0 -w 720 -h 480 -c 3 -t  V4L2_CROPPING_NTSC_DISPLAY_CROP_FACTOR_0_TEST
./v4l2_display_tests -n 200 -r 2 -w 720 -h 480 -c 3 -t  V4L2_CROPPING_NTSC_DISPLAY_CROP_FACTOR_2_TEST
./v4l2_display_tests -n 200 -r 4 -w 720 -h 480 -c 3 -t  V4L2_CROPPING_NTSC_DISPLAY_CROP_FACTOR_4_TEST
./v4l2_display_tests -n 200 -r 8 -w 720 -h 480 -c 3 -t  V4L2_CROPPING_NTSC_DISPLAY_CROP_FACTOR_8_TEST

./v4l2_display_tests -n 200 -r 0 -w 720 -h 576 -c 3 -t  V4L2_CROPPING_PAL_DISPLAY_CROP_FACTOR_0_TEST
./v4l2_display_tests -n 200 -r 2 -w 720 -h 576 -c 3 -t  V4L2_CROPPING_PAL_DISPLAY_CROP_FACTOR_2_TEST
./v4l2_display_tests -n 200 -r 4 -w 720 -h 576 -c 3 -t  V4L2_CROPPING_PAL_DISPLAY_CROP_FACTOR_4_TEST
./v4l2_display_tests -n 200 -r 8 -w 720 -h 576 -c 3 -t  V4L2_CROPPING_PAL_DISPLAY_CROP_FACTOR_8_TEST

echo "Run the v4l2 tests for different crop factor with different pixel formats"
./v4l2_display_tests -n 200 -r 0 -p RGB565 -t V4L2_CROPPING_TEST_CROP_FACTOR_0_PIXEL_FORMAT_RGB565
./v4l2_display_tests -n 200 -r 2 -p RGB565 -t V4L2_CROPPING_TEST_CROP_FACTOR_2_PIXEL_FORMAT_RGB565
./v4l2_display_tests -n 200 -r 4 -p RGB565 -t V4L2_CROPPING_TEST_CROP_FACTOR_4_PIXEL_FORMAT_RGB565
./v4l2_display_tests -n 200 -r 8 -p RGB565 -t V4L2_CROPPING_TEST_CROP_FACTOR_8_PIXEL_FORMAT_RGB565

./v4l2_display_tests -n 200 -r 0 -p UYVY -t V4L2_CROPPING_TEST_CROP_FACTOR_0_PIXEL_FORMAT_UYVY
./v4l2_display_tests -n 200 -r 2 -p UYVY -t V4L2_CROPPING_TEST_CROP_FACTOR_2_PIXEL_FORMAT_UYVY
./v4l2_display_tests -n 200 -r 4 -p UYVY -t V4L2_CROPPING_TEST_CROP_FACTOR_4_PIXEL_FORMAT_UYVY
./v4l2_display_tests -n 200 -r 8 -p UYVY -t V4L2_CROPPING_TEST_CROP_FACTOR_8_PIXEL_FORMAT_UYVY

./v4l2_display_tests -n 200 -r 0 -p YUYV -t V4L2_CROPPING_TEST_CROP_FACTOR_0_PIXEL_FORMAT_YUYV
./v4l2_display_tests -n 200 -r 2 -p YUYV -t V4L2_CROPPING_TEST_CROP_FACTOR_2_PIXEL_FORMAT_YUYV
./v4l2_display_tests -n 200 -r 4 -p YUYV -t V4L2_CROPPING_TEST_CROP_FACTOR_4_PIXEL_FORMAT_YUYV
./v4l2_display_tests -n 200 -r 8 -p YUYV -t V4L2_CROPPING_TEST_CROP_FACTOR_8_PIXEL_FORMAT_YUYV

./v4l2_display_tests -n 200 -r 0 -p RGB888 -t V4L2_CROPPING_TEST_CROP_FACTOR_0_PIXEL_FORMAT_RGB888
./v4l2_display_tests -n 200 -r 2 -p RGB888 -t V4L2_CROPPING_TEST_CROP_FACTOR_2_PIXEL_FORMAT_RGB888
./v4l2_display_tests -n 200 -r 4 -p RGB888 -t V4L2_CROPPING_TEST_CROP_FACTOR_4_PIXEL_FORMAT_RGB888
./v4l2_display_tests -n 200 -r 8 -p RGB888 -t V4L2_CROPPING_TEST_CROP_FACTOR_8_PIXEL_FORMAT_RGB888

echo "Running Rotation tests with different resolutions"
#runs the default color bar test with mmap option and various other rotation options

./v4l2_display_tests -n 200 -R 0   -w 640 -h 480 -c 3 -t V4L2_ROTATION_0_DEGREE_VGA_DISPLAY_TEST
./v4l2_display_tests -n 200 -R 90  -w 640 -h 480 -c 3 -t V4L2_ROTATION_90_DEGREE_VGA_DISPLAY_TEST
./v4l2_display_tests -n 200 -R 180 -w 640 -h 480 -c 3 -t V4L2_ROTATION_180_DEGREE_VGA_DISPLAY_TEST
./v4l2_display_tests -n 200 -R 270 -w 640 -h 480 -c 3 -t V4L2_ROTATION_270_DEGREE_VGA_DISPLAY_TEST

./v4l2_display_tests -n 200 -R 0   -w 320 -h 240 -c 3 -t V4L2_ROTATION_0_DEGREE_QVGA_DISPLAY_TEST
./v4l2_display_tests -n 200 -R 90  -w 320 -h 240 -c 3 -t V4L2_ROTATION_90_DEGREE_QVGA_DISPLAY_TEST
./v4l2_display_tests -n 200 -R 180 -w 320 -h 240 -c 3 -t V4L2_ROTATION_180_DEGREE_QVGA_DISPLAY_TEST
./v4l2_display_tests -n 200 -R 270 -w 320 -h 240 -c 3 -t V4L2_ROTATION_270_DEGREE_QVGA_DISPLAY_TEST

./v4l2_display_tests -n 200 -R 0   -w 160 -h 120 -c 3 -t V4L2_ROTATION_0_DEGREE_QQVGA_DISPLAY_TEST
./v4l2_display_tests -n 200 -R 90  -w 160 -h 120 -c 3 -t V4L2_ROTATION_90_DEGREE_QQVGA_DISPLAY_TEST
./v4l2_display_tests -n 200 -R 180 -w 160 -h 120 -c 3 -t V4L2_ROTATION_180_DEGREE_QQVGA_DISPLAY_TEST
./v4l2_display_tests -n 200 -R 270 -w 160 -h 120 -c 3 -t V4L2_ROTATION_270_DEGREE_QQVGA_DISPLAY_TEST

./v4l2_display_tests -n 200 -R 0   -w 720 -h 480 -c 3 -t V4L2_ROTATION_0_DEGREE_NTSC_DISPLAY_TEST
./v4l2_display_tests -n 200 -R 90  -w 720 -h 480 -c 3 -t V4L2_ROTATION_90_DEGREE_NTSC_DISPLAY_TEST
./v4l2_display_tests -n 200 -R 180 -w 720 -h 480 -c 3 -t V4L2_ROTATION_180_DEGREE_NTSC_DISPLAY_TEST
./v4l2_display_tests -n 200 -R 270 -w 720 -h 480 -c 3 -t V4L2_ROTATION_270_DEGREE_NTSC_DISPLAY_TEST

./v4l2_display_tests -n 200 -R 0   -w 720 -h 576 -c 3 -t V4L2_ROTATION_0_DEGREE_PAL_DISPLAY_TEST
./v4l2_display_tests -n 200 -R 90  -w 720 -h 576 -c 3 -t V4L2_ROTATION_90_DEGREE_PAL_DISPLAY_TEST
./v4l2_display_tests -n 200 -R 180 -w 720 -h 576 -c 3 -t V4L2_ROTATION_180_DEGREE_PAL_DISPLAY_TEST
./v4l2_display_tests -n 200 -R 270 -w 720 -h 576 -c 3 -t V4L2_ROTATION_270_DEGREE_PAL_DISPLAY_TEST


echo "Running Rotation tests with different pixel formats"

./v4l2_display_tests -n 200 -R 0   -p RGB565 -t V4L2_ROTATION_0_DEGREE_TEST_PIXEL_FORMAT_RGB565
./v4l2_display_tests -n 200 -R 90  -p RGB565 -t V4L2_ROTATION_90_DEGREE_TEST_PIXEL_FORMAT_RGB565
./v4l2_display_tests -n 200 -R 180 -p RGB565 -t V4L2_ROTATION_180_DEGREE_TEST_PIXEL_FORMAT_RGB565
./v4l2_display_tests -n 200 -R 270 -p RGB565 -t V4L2_ROTATION_270_DEGREE_TEST_PIXEL_FORMAT_RGB565

./v4l2_display_tests -n 200 -R 0   -p UYVY -t V4L2_ROTATION_0_DEGREE_TEST_PIXEL_FORMAT_UYVY
./v4l2_display_tests -n 200 -R 90  -p UYVY -t V4L2_ROTATION_90_DEGREE_TEST_PIXEL_FORMAT_UYVY
./v4l2_display_tests -n 200 -R 180 -p UYVY -t V4L2_ROTATION_180_DEGREE_TEST_PIXEL_FORMAT_UYVY
./v4l2_display_tests -n 200 -R 270 -p UYVY -t V4L2_ROTATION_270_DEGREE_TEST_PIXEL_FORMAT_UYVY

./v4l2_display_tests -n 200 -R 0   -p YUYV -t V4L2_ROTATION_0_DEGREE_TEST_PIXEL_FORMAT_YUYV
./v4l2_display_tests -n 200 -R 90  -p YUYV -t V4L2_ROTATION_90_DEGREE_TEST_PIXEL_FORMAT_YUYV
./v4l2_display_tests -n 200 -R 180 -p YUYV -t V4L2_ROTATION_180_DEGREE_TEST_PIXEL_FORMAT_YUYV
./v4l2_display_tests -n 200 -R 270 -p YUYV -t V4L2_ROTATION_270_DEGREE_TEST_PIXEL_FORMAT_YUYV

#Run the API test- Runs all APIs supported. -T stands for special tests like api,stability. Currently only api,stability can be passed for -T. Wheraes the smsmall letter -t stands for test name(will be logged) and helpful for testers reference. User can pass any string to small -t option but string shouldn't have any spaces.
echo "Run the v4l2 api test cases "
./v4l2_display_tests -T api -t V4L2_API_TESTS

#Run the stability Test
echo "RUN_THE_V4L2_STABILITY_TEST"
./v4l2_display_tests -n 200 -T stability -C 2 -t V4L2_DISPLAY_STABILITY_TESTS

#runs the default color bar test with user pointer option and various other options
echo "RUN_THE_V4L2_TEST_WITH_USER_POINTER"
./v4l2_display_tests -n 200 -u 1 -t V4L2_DISPLAY_TEST_WITH_USER_POINTER

echo "Testing on TV with video1 complete"

echo "Switching video2 to TV"

#Runs the default color bar display-No options provided
./v4l2_display_tests -d /dev/video2 -n 200 -t V4L2_DEFAULT_COLOR_BAR_DISPLAY_TEST

#Run the performance tests
echo "RUN_THE_V4L2_TEST_WITH_THROUGHPUT_TV_DISPLAY_NTSC"   
./v4l2_display_tests -d /dev/video2 -w 720 -h 480 -F -t V4L2_DISPLAY_TEST_WITH_THROUGHTPUT_INFORMATION_NTSC

echo "RUN_THE_V4L2_TEST_WITH_CPULOAD_TV_DISPLAY_NTSC"   
./v4l2_display_tests -d /dev/video2 -w 720 -h 480 -l -t V4L2_DISPLAY_TEST_WITH_CPULOAD_INFORMATION_NTSC

echo "RUN_THE_V4L2_TEST_WITH_THROUGHPUT_AND_CPULOAD_TV_DISPLAY_NTSC"   
./v4l2_display_tests -d /dev/video2 -w 720 -h 480 -F -l -t V4L2_DISPLAY_TEST_WITH_THROUGHPUT_CPULOAD_INFORMATION_NTSC

echo "RUN_THE_V4L2_TEST_WITH_THROUGHPUT_TV_DISPLAY_PAL"   
./v4l2_display_tests -d /dev/video2 -w 720 -h 576 -F -t V4L2_DISPLAY_TEST_WITH_THROUGHTPUT_INFORMATION_PAL

echo "RUN_THE_V4L2_TEST_WITH_CPULOAD_TV_DISPLAY_PAL"   
./v4l2_display_tests -d /dev/video2 -w 720 -h 576 -l -t V4L2_DISPLAY_TEST_WITH_CPULOAD_INFORMATION_PAL

echo "RUN_THE_V4L2_TEST_WITH_THROUGHPUT_AND_CPULOAD_TV_DISPLAY_PAL"   
./v4l2_display_tests -d /dev/video2 -w 720 -h 576 -F -l -t V4L2_DISPLAY_TEST_WITH_THROUGHPUT_CPULOAD_INFORMATION_PAL

echo "Run the v4l2 tests for different standard resolutions"
#Run the display test- Displays default color bar with width (-w) 720, height (-h) 480, number of buffers queued is (-c) 3 and number of iterations (-n) 500 
./v4l2_display_tests -d /dev/video2 -n 200 -w 640 -h 480 -c 3 -t V4L2_VGA_DISPLAY_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -w 320 -h 240 -c 3 -t V4L2_QVGA_DISPLAY_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -w 160 -h 120 -c 3 -t V4L2_QQVGA_DISPLAY_TEST

echo "Run the v4l2 tests for different pixel format"

./v4l2_display_tests -d /dev/video2 -n 200 -p RGB565 -t V4L2_TEST_PIXEL_FORMAT_RGB565
./v4l2_display_tests -d /dev/video2 -n 200 -p UYVY   -t V4L2_TEST_PIXEL_FORMAT_UYVY
./v4l2_display_tests -d /dev/video2 -n 200 -p YUYV   -t V4L2_TEST_PIXEL_FORMAT_YUYV
./v4l2_display_tests -d /dev/video2 -n 200 -p RGB888 -t V4L2_TEST_PIXEL_FORMAT_RGB888

echo "Run the v4l2 tests for different crop factor with different resolution"
./v4l2_display_tests -d /dev/video2 -n 200 -r 0 -w 640 -h 480 -c 3 -t  V4L2_CROPPING_VGA_DISPLAY_CROP_FACTOR_0_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -r 2 -w 640 -h 480 -c 3 -t  V4L2_CROPPING_VGA_DISPLAY_CROP_FACTOR_2_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -r 4 -w 640 -h 480 -c 3 -t  V4L2_CROPPING_VGA_DISPLAY_CROP_FACTOR_4_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -r 8 -w 640 -h 480 -c 3 -t  V4L2_CROPPING_VGA_DISPLAY_CROP_FACTOR_8_TEST

./v4l2_display_tests -d /dev/video2 -n 200 -r 0 -w 320 -h 240 -c 3 -t  V4L2_CROPPING_QVGA_DISPLAY_CROP_FACTOR_0_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -r 2 -w 320 -h 240 -c 3 -t  V4L2_CROPPING_QVGA_DISPLAY_CROP_FACTOR_2_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -r 4 -w 320 -h 240 -c 3 -t  V4L2_CROPPING_QVGA_DISPLAY_CROP_FACTOR_4_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -r 8 -w 320 -h 240 -c 3 -t  V4L2_CROPPING_QVGA_DISPLAY_CROP_FACTOR_8_TEST

./v4l2_display_tests -d /dev/video2 -n 200 -r 0 -w 160 -h 120 -c 3 -t  V4L2_CROPPING_QQVGA_DISPLAY_CROP_FACTOR_0_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -r 2 -w 160 -h 120 -c 3 -t  V4L2_CROPPING_QQVGA_DISPLAY_CROP_FACTOR_2_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -r 4 -w 160 -h 120 -c 3 -t  V4L2_CROPPING_QQVGA_DISPLAY_CROP_FACTOR_4_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -r 8 -w 160 -h 120 -c 3 -t  V4L2_CROPPING_QQVGA_DISPLAY_CROP_FACTOR_8_TEST

./v4l2_display_tests -d /dev/video2 -n 200 -r 0 -w 720 -h 480 -c 3 -t  V4L2_CROPPING_NTSC_DISPLAY_CROP_FACTOR_0_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -r 2 -w 720 -h 480 -c 3 -t  V4L2_CROPPING_NTSC_DISPLAY_CROP_FACTOR_2_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -r 4 -w 720 -h 480 -c 3 -t  V4L2_CROPPING_NTSC_DISPLAY_CROP_FACTOR_4_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -r 8 -w 720 -h 480 -c 3 -t  V4L2_CROPPING_NTSC_DISPLAY_CROP_FACTOR_8_TEST

./v4l2_display_tests -d /dev/video2 -n 200 -r 0 -w 720 -h 576 -c 3 -t  V4L2_CROPPING_PAL_DISPLAY_CROP_FACTOR_0_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -r 2 -w 720 -h 576 -c 3 -t  V4L2_CROPPING_PAL_DISPLAY_CROP_FACTOR_2_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -r 4 -w 720 -h 576 -c 3 -t  V4L2_CROPPING_PAL_DISPLAY_CROP_FACTOR_4_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -r 8 -w 720 -h 576 -c 3 -t  V4L2_CROPPING_PAL_DISPLAY_CROP_FACTOR_8_TEST

echo "Run the v4l2 tests for different crop factor with different pixel formats"
./v4l2_display_tests -d /dev/video2 -n 200 -r 0 -p RGB565 -t V4L2_CROPPING_TEST_CROP_FACTOR_0_PIXEL_FORMAT_RGB565
./v4l2_display_tests -d /dev/video2 -n 200 -r 2 -p RGB565 -t V4L2_CROPPING_TEST_CROP_FACTOR_2_PIXEL_FORMAT_RGB565
./v4l2_display_tests -d /dev/video2 -n 200 -r 4 -p RGB565 -t V4L2_CROPPING_TEST_CROP_FACTOR_4_PIXEL_FORMAT_RGB565
./v4l2_display_tests -d /dev/video2 -n 200 -r 8 -p RGB565 -t V4L2_CROPPING_TEST_CROP_FACTOR_8_PIXEL_FORMAT_RGB565

./v4l2_display_tests -d /dev/video2 -n 200 -r 0 -p UYVY -t V4L2_CROPPING_TEST_CROP_FACTOR_0_PIXEL_FORMAT_UYVY
./v4l2_display_tests -d /dev/video2 -n 200 -r 2 -p UYVY -t V4L2_CROPPING_TEST_CROP_FACTOR_2_PIXEL_FORMAT_UYVY
./v4l2_display_tests -d /dev/video2 -n 200 -r 4 -p UYVY -t V4L2_CROPPING_TEST_CROP_FACTOR_4_PIXEL_FORMAT_UYVY
./v4l2_display_tests -d /dev/video2 -n 200 -r 8 -p UYVY -t V4L2_CROPPING_TEST_CROP_FACTOR_8_PIXEL_FORMAT_UYVY

./v4l2_display_tests -d /dev/video2 -n 200 -r 0 -p YUYV -t V4L2_CROPPING_TEST_CROP_FACTOR_0_PIXEL_FORMAT_YUYV
./v4l2_display_tests -d /dev/video2 -n 200 -r 2 -p YUYV -t V4L2_CROPPING_TEST_CROP_FACTOR_2_PIXEL_FORMAT_YUYV
./v4l2_display_tests -d /dev/video2 -n 200 -r 4 -p YUYV -t V4L2_CROPPING_TEST_CROP_FACTOR_4_PIXEL_FORMAT_YUYV
./v4l2_display_tests -d /dev/video2 -n 200 -r 8 -p YUYV -t V4L2_CROPPING_TEST_CROP_FACTOR_8_PIXEL_FORMAT_YUYV

./v4l2_display_tests -d /dev/video2 -n 200 -r 0 -p RGB888 -t V4L2_CROPPING_TEST_CROP_FACTOR_0_PIXEL_FORMAT_RGB888
./v4l2_display_tests -d /dev/video2 -n 200 -r 2 -p RGB888 -t V4L2_CROPPING_TEST_CROP_FACTOR_2_PIXEL_FORMAT_RGB888
./v4l2_display_tests -d /dev/video2 -n 200 -r 4 -p RGB888 -t V4L2_CROPPING_TEST_CROP_FACTOR_4_PIXEL_FORMAT_RGB888
./v4l2_display_tests -d /dev/video2 -n 200 -r 8 -p RGB888 -t V4L2_CROPPING_TEST_CROP_FACTOR_8_PIXEL_FORMAT_RGB888

echo "Running Rotation tests with different resolutions"
#runs the default color bar test with mmap option and various other rotation options

./v4l2_display_tests -d /dev/video2 -n 200 -R 0   -w 640 -h 480 -c 3 -t V4L2_ROTATION_0_DEGREE_VGA_DISPLAY_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -R 90  -w 640 -h 480 -c 3 -t V4L2_ROTATION_90_DEGREE_VGA_DISPLAY_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -R 180 -w 640 -h 480 -c 3 -t V4L2_ROTATION_180_DEGREE_VGA_DISPLAY_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -R 270 -w 640 -h 480 -c 3 -t V4L2_ROTATION_270_DEGREE_VGA_DISPLAY_TEST

./v4l2_display_tests -d /dev/video2 -n 200 -R 0   -w 320 -h 240 -c 3 -t V4L2_ROTATION_0_DEGREE_QVGA_DISPLAY_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -R 90  -w 320 -h 240 -c 3 -t V4L2_ROTATION_90_DEGREE_QVGA_DISPLAY_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -R 180 -w 320 -h 240 -c 3 -t V4L2_ROTATION_180_DEGREE_QVGA_DISPLAY_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -R 270 -w 320 -h 240 -c 3 -t V4L2_ROTATION_270_DEGREE_QVGA_DISPLAY_TEST

./v4l2_display_tests -d /dev/video2 -n 200 -R 0   -w 160 -h 120 -c 3 -t V4L2_ROTATION_0_DEGREE_QQVGA_DISPLAY_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -R 90  -w 160 -h 120 -c 3 -t V4L2_ROTATION_90_DEGREE_QQVGA_DISPLAY_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -R 180 -w 160 -h 120 -c 3 -t V4L2_ROTATION_180_DEGREE_QQVGA_DISPLAY_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -R 270 -w 160 -h 120 -c 3 -t V4L2_ROTATION_270_DEGREE_QQVGA_DISPLAY_TEST

./v4l2_display_tests -d /dev/video2 -n 200 -R 0   -w 720 -h 480 -c 3 -t V4L2_ROTATION_0_DEGREE_NTSC_DISPLAY_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -R 90  -w 720 -h 480 -c 3 -t V4L2_ROTATION_90_DEGREE_NTSC_DISPLAY_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -R 180 -w 720 -h 480 -c 3 -t V4L2_ROTATION_180_DEGREE_NTSC_DISPLAY_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -R 270 -w 720 -h 480 -c 3 -t V4L2_ROTATION_270_DEGREE_NTSC_DISPLAY_TEST

./v4l2_display_tests -d /dev/video2 -n 200 -R 0   -w 720 -h 576 -c 3 -t V4L2_ROTATION_0_DEGREE_PAL_DISPLAY_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -R 90  -w 720 -h 576 -c 3 -t V4L2_ROTATION_90_DEGREE_PAL_DISPLAY_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -R 180 -w 720 -h 576 -c 3 -t V4L2_ROTATION_180_DEGREE_PAL_DISPLAY_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -R 270 -w 720 -h 576 -c 3 -t V4L2_ROTATION_270_DEGREE_PAL_DISPLAY_TEST


echo "Running Rotation tests with different pixel formats"

./v4l2_display_tests -d /dev/video2 -n 200 -R 0   -p RGB565 -t V4L2_ROTATION_0_DEGREE_TEST_PIXEL_FORMAT_RGB565
./v4l2_display_tests -d /dev/video2 -n 200 -R 90  -p RGB565 -t V4L2_ROTATION_90_DEGREE_TEST_PIXEL_FORMAT_RGB565
./v4l2_display_tests -d /dev/video2 -n 200 -R 180 -p RGB565 -t V4L2_ROTATION_180_DEGREE_TEST_PIXEL_FORMAT_RGB565
./v4l2_display_tests -d /dev/video2 -n 200 -R 270 -p RGB565 -t V4L2_ROTATION_270_DEGREE_TEST_PIXEL_FORMAT_RGB565

./v4l2_display_tests -d /dev/video2 -n 200 -R 0   -p UYVY -t V4L2_ROTATION_0_DEGREE_TEST_PIXEL_FORMAT_UYVY
./v4l2_display_tests -d /dev/video2 -n 200 -R 90  -p UYVY -t V4L2_ROTATION_90_DEGREE_TEST_PIXEL_FORMAT_UYVY
./v4l2_display_tests -d /dev/video2 -n 200 -R 180 -p UYVY -t V4L2_ROTATION_180_DEGREE_TEST_PIXEL_FORMAT_UYVY
./v4l2_display_tests -d /dev/video2 -n 200 -R 270 -p UYVY -t V4L2_ROTATION_270_DEGREE_TEST_PIXEL_FORMAT_UYVY

./v4l2_display_tests -d /dev/video2 -n 200 -R 0   -p YUYV -t V4L2_ROTATION_0_DEGREE_TEST_PIXEL_FORMAT_YUYV
./v4l2_display_tests -d /dev/video2 -n 200 -R 90  -p YUYV -t V4L2_ROTATION_90_DEGREE_TEST_PIXEL_FORMAT_YUYV
./v4l2_display_tests -d /dev/video2 -n 200 -R 180 -p YUYV -t V4L2_ROTATION_180_DEGREE_TEST_PIXEL_FORMAT_YUYV
./v4l2_display_tests -d /dev/video2 -n 200 -R 270 -p YUYV -t V4L2_ROTATION_270_DEGREE_TEST_PIXEL_FORMAT_YUYV

#Run the API test- Runs all APIs supported. -T stands for special tests like api,stability. Currently only api,stability can be passed for -T. Wheraes the smsmall letter -t stands for test name(will be logged) and helpful for testers reference. User can pass any string to small -t option but string shouldn't have any spaces.
echo "Run the v4l2 api test cases "
./v4l2_display_tests -d /dev/video2 -T api -t V4L2_API_TESTS

#Run the stability Test
echo "RUN_THE_V4L2_STABILITY_TEST"
./v4l2_display_tests -d /dev/video2 -n 200 -T stability -C 2 -t V4L2_DISPLAY_STABILITY_TESTS

#runs the default color bar test with user pointer option and various other options
echo "RUN_THE_V4L2_TEST_WITH_USER_POINTER"
./v4l2_display_tests -d /dev/video2 -n 200 -u 1 -t V4L2_DISPLAY_TEST_WITH_USER_POINTER
