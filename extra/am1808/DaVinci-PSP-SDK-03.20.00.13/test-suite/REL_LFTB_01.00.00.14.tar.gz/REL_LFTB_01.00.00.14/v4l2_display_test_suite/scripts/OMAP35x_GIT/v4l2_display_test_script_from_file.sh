#  omap35x_GIT_v4l2_display_test_script_from_file.sh

#   ============================================================================
#-d       --displaynode     Device node on which display test is to be run
#-T       --testname        Name of the special test
#-w       --width           Width of the image to be displayed
#-h       --height          Height of the image to be displayed
#-c       --countofbuffers  Number of buffers to queue
#-C       --stabilitycount  Number of times to run stability test
#-t       --testcaseid      Test case id string for testers reference/logging purpose
#-n       --noofframes      Number of frames to be displayed
#-f       --filename        Name of the image file to display
#-s       --standard        Name of the standard
#-r       --ratiocrop       Cropping factor - An integer value like1, 2 etc
#-p       --pixelformat     Pixel formats
#-R       --Rotation        Rotation angle
#-m       --mirror          Mirroring
#-?       --help            Displays the help/usage
#-v       --version         Version of Display Test suite

#Default settings/values for display 
# DEFAULT_HEIGHT VGA_HEIGHT
# DEFAULT_WIDTH  VGA_WIDTH
# DEFAULT_NODE VID1_NODE
# DEFAULT_PIX_FMT ST_RGB_565
# DEFAULT_ROTATION_ANGLE 0
# DEFAULT_NO_BUFFERS 3
# DEFAULT_NO_FRAMES 1000
# DEFAULT_CROP_FACTOR 0
# DEFAULT_ZOOM_FACTOR 0

# Replace filename here(stefan) with your file and width, height, pixel format as your file

echo "Running tests from a YUV file"
./OMAP35x_GIT_v4l2_display_tests -f stefan_qvga_422.yuv -p UYVY -n 600 -w 320 -h 240

echo "Running frame rate tests "
./OMAP35x_GIT_v4l2_display_tests -F -l -f stefan_qvga_422.yuv -p UYVY -n 600 -w 320 -h 240

echo "Running Rotation tests"
#runs the default color bar test with mmap option and various other rotation options
./OMAP35x_GIT_v4l2_display_tests -f stefan_qvga_422.yuv -p UYVY -n 600 -w 320 -h 240 -R 90 -t V4L2_DISPLAY_TEST_WITH_ROTATION_OPTION_90
./OMAP35x_GIT_v4l2_display_tests -f stefan_qvga_422.yuv -p UYVY -n 600 -w 320 -h 240 -R 180 -t V4L2_DISPLAY_TEST_WITH_ROTATION_OPTION_180
./OMAP35x_GIT_v4l2_display_tests -f stefan_qvga_422.yuv -p UYVY -n 600 -w 320 -h 240 -R 270 -t V4L2_DISPLAY_TEST_WITH_ROTATION_OPTION_270

echo "Testing on LCD complete"

echo "Switching to TV"
echo "Switching video1 to TV"

echo "vid1 e:0" > /sys/devices/platform/omapfb/overlays
echo "vid1 t:tv e:0" > /sys/devices/platform/omapfb/overlays
echo "tv e:1" > /sys/devices/platform/omapfb/displays

# Replace filename here(stefan) with your file and width, height, pixel format as your file
./OMAP35x_GIT_v4l2_display_tests -f stefan_qvga_422.yuv -p UYVY -n 600 -w 320 -h 240

echo "Running Rotation tests"
#runs the default color bar test with mmap option and various other rotation options
./OMAP35x_GIT_v4l2_display_tests -f stefan_qvga_422.yuv -p UYVY -n 600 -w 320 -h 240 -R 90 -t V4L2_DISPLAY_TEST_WITH_ROTATION_OPTION_90
./OMAP35x_GIT_v4l2_display_tests -f stefan_qvga_422.yuv -p UYVY -n 600 -w 320 -h 240 -R 180 -t V4L2_DISPLAY_TEST_WITH_ROTATION_OPTION_180
./OMAP35x_GIT_v4l2_display_tests -f stefan_qvga_422.yuv -p UYVY -n 600 -w 320 -h 240 -R 270 -t V4L2_DISPLAY_TEST_WITH_ROTATION_OPTION_270


echo "Testing on TV complete"

#Stress Test- Run the display test overnight- Displays default color bar with number of buffers queued is 4 overnight
#Uncomment this to run overnight tests
#echo "RUN_THE_V4L2_OVERNIGHT_TEST"   
#./OMAP35x_GIT_v4l2_display_tests -f stefan_qvga_422.yuv -p UYVY -w 320 -h 240 -c 4 -n 864000 -t V4L2_DISPLAY_STRESS_TEST_ON_TV


echo "Switching back to LCD"
echo "vid1 e:0" > /sys/devices/platform/omapfb/overlays
echo "vid1 t:lcd e:0" > /sys/devices/platform/omapfb/overlays
echo "lcd e:1" > /sys/devices/platform/omapfb/displays

#Stress Test- Run the display test overnight- Displays default color bar with number of buffers queued is 4 overnight
#echo "RUN_THE_V4L2_OVERNIGHT_TEST"
#./OMAP35x_GIT_v4l2_display_tests -c 4 -n 864000 -t V4L2_DISPLAY_STRESS_TEST_ON_LCD

#Run the stability test for 10 times. By changing -C to high value, it can run over night and detect for any memory leak/crash.
# -d stands for device node. Can be passed as command line option as shown below.
#echo "RUN_THE_V4L2_STABILITY_TEST"
#./OMAP35x_GIT_v4l2_display_tests -d /dev/video1 -T stability -C 10 -t V4L2_DISPLAY_STABILITY_TEST_ON_LCD

