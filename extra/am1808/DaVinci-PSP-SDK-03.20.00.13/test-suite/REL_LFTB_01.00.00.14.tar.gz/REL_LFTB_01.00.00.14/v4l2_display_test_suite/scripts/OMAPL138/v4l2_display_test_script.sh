#v4l2_display_test script for OMAPL138

#Default test
./v4l2_display_tests -d /dev/video2 -w 720 -h 480
./v4l2_display_tests -d /dev/video2 -w 720 -h 576

#Run the performance tests
echo "RUN_THE_V4L2_TEST_WITH_THROUGHPUT_TV_DISPLAY_NTSC"   
./v4l2_display_tests -d /dev/video2 -w 720 -h 480 -F -t V4L2_DISPLAY_TEST_WITH_THROUGHTPUT_INFORMATION_NTSC

echo "RUN_THE_V4L2_TEST_WITH_CPULOAD_TV_DISPLAY_NTSC"   
./v4l2_display_tests -d /dev/video2 -w 720 -h 480 -l -t V4L2_DISPLAY_TEST_WITH_CPULOAD_INFORMATION_NTSC

echo "RUN_THE_V4L2_TEST_WITH_THROUGHPUT_AND_CPULOAD_TV_DISPLAY_NTSC"   
./v4l2_display_tests -d /dev/video2 -w 720 -h 480 -F -l -t V4L2_DISPLAY_TEST_WITH_THROUGHPUT_CPULOAD_INFORMATION_NTSC

echo "RUN_THE_V4L2_TEST_WITH_THROUGHPUT_TV_DISPLAY_PAL"   
./v4l2_display_tests -d /dev/video2 -w 720 -h 576 -F -t V4L2_DISPLAY_TEST_WITH_THROUGHTPUT_INFORMATION_PAL

echo "RUN_THE_V4L2_TEST_WITH_CPULOAD_TV_DISPLAY_PAL"   
./v4l2_display_tests -d /dev/video2 -w 720 -h 576 -l -t V4L2_DISPLAY_TEST_WITH_CPULOAD_INFORMATION_PAL

echo "RUN_THE_V4L2_TEST_WITH_THROUGHPUT_AND_CPULOAD_TV_DISPLAY_PAL"   
./v4l2_display_tests -d /dev/video2 -w 720 -h 576 -F -l -t V4L2_DISPLAY_TEST_WITH_THROUGHPUT_CPULOAD_INFORMATION_PAL

echo "Run the v4l2 tests for different crop factor with different resolution"
./v4l2_display_tests -d /dev/video2 -n 200 -r 0 -w 720 -h 480 -c 3 -t  V4L2_CROPPING_NTSC_DISPLAY_CROP_FACTOR_0_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -r 2 -w 720 -h 480 -c 3 -t  V4L2_CROPPING_NTSC_DISPLAY_CROP_FACTOR_2_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -r 4 -w 720 -h 480 -c 3 -t  V4L2_CROPPING_NTSC_DISPLAY_CROP_FACTOR_4_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -r 8 -w 720 -h 480 -c 3 -t  V4L2_CROPPING_NTSC_DISPLAY_CROP_FACTOR_8_TEST

./v4l2_display_tests -d /dev/video2 -n 200 -r 0 -w 720 -h 576 -c 3 -t  V4L2_CROPPING_PAL_DISPLAY_CROP_FACTOR_0_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -r 2 -w 720 -h 576 -c 3 -t  V4L2_CROPPING_PAL_DISPLAY_CROP_FACTOR_2_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -r 4 -w 720 -h 576 -c 3 -t  V4L2_CROPPING_PAL_DISPLAY_CROP_FACTOR_4_TEST
./v4l2_display_tests -d /dev/video2 -n 200 -r 8 -w 720 -h 576 -c 3 -t  V4L2_CROPPING_PAL_DISPLAY_CROP_FACTOR_8_TEST


#runs the default color bar test with user pointer option and various other options
echo "RUN_THE_V4L2_TEST_WITH_USER_POINTER"
./v4l2_display_tests -d /dev/video2 -n 200 -u 1 -t V4L2_DISPLAY_TEST_WITH_USER_POINTER
