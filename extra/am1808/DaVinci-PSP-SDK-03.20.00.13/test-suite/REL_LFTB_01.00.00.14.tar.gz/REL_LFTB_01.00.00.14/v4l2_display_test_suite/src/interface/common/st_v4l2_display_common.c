/*
 * st_v4l2_display_common.c
 *
 * This file contains the common functions definitions
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/ 
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/



#include <st_v4l2_display_common.h>



//Fill the color pattern

#ifdef USR_PTR_SUPPORT
static unsigned short ycbcr[8] = {
    (0x1F << 11) | (0x3F << 5) | (0x1F),
    (0x00 << 11) | (0x00 << 5) | (0x00),
    (0x1F << 11) | (0x00 << 5) | (0x00),
    (0x00 << 11) | (0x3F << 5) | (0x00),
    (0x00 << 11) | (0x00 << 5) | (0x1F),
    (0x1F << 11) | (0x3F << 5) | (0x00),
    (0x1F << 11) | (0x00 << 5) | (0x1F),
    (0x00 << 11) | (0x3F << 5) | (0x1F),
};
#else
static short ycbcr[8] = {
    (0x1F << 11) | (0x3F << 5) | (0x1F),
    (0x00 << 11) | (0x00 << 5) | (0x00),
    (0x1F << 11) | (0x00 << 5) | (0x00),
    (0x00 << 11) | (0x3F << 5) | (0x00),
    (0x00 << 11) | (0x00 << 5) | (0x1F),
    (0x1F << 11) | (0x3F << 5) | (0x00),
    (0x1F << 11) | (0x00 << 5) | (0x1F),
    (0x00 << 11) | (0x3F << 5) | (0x1F),
};
#endif
static short ycbcr_2[8] = {
    (0x1F << 11) | (0x3F << 5) | (0x1F),
    (0x1F << 11) | (0x3F << 5) | (0x1F),
    (0x1F << 11) | (0x3F << 5) | (0x1F),
    (0x1F << 11) | (0x3F << 5) | (0x1F),
    (0x1F << 11) | (0x3F << 5) | (0x1F),
    (0x1F << 11) | (0x3F << 5) | (0x1F),
    (0x1F << 11) | (0x3F << 5) | (0x1F),
    (0x1F << 11) | (0x3F << 5) | (0x1F),
};

/****************************************************************************
 * Function             - colorbar_generate
 * Functionality        - This function generates the color bars
 * Input Params         - device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
void colorbar_generate(unsigned char *addr, int width, int height, int order)
{
    unsigned short *ptr = ((unsigned short *)addr) + order*width;
    int i, j, k;

    for(i = 0 ; i < 8 ; i ++) {
        for(j = 0 ; j < height / 8 ; j ++) {
            for(k = 0 ; k < width / 2 ; k ++, ptr++)
                *ptr = ycbcr[i];
            if((unsigned int)ptr >= (unsigned int)addr +
                    width*height)
                ptr = (unsigned short *)addr;
        }
    }
}

/****************************************************************************
 * Function             - colorbar_generate_second
 * Functionality        - This function generates the color bars for alpha blending
 * Input Params         - device number
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/
void colorbar_generate_second(unsigned char *addr, int width, int height, int order)
{
    unsigned short *ptr = ((unsigned short *)addr) + order*width;
    int i, j, k;

    for(i = 0 ; i < 8 ; i ++) {
        for(j = 0 ; j < height / 8 ; j ++) {
            for(k = 0 ; k < width / 2 ; k ++, ptr++)
                *ptr = ycbcr_2[i];
            if((unsigned int)ptr >= (unsigned int)addr +
                    width*height)
                ptr = (unsigned short *)addr;
        }
    }
}

/****************************************************************************
 * Function             - fill_lines(),color_bar()
 * Functionality        - This function generates the color bars
 * Input Params         - addr,pitch,height,size for color_bar and width for
 *                        fill_lines()
 * Return Value         - 0: SUCCESS, -1: FAILURE
 * Note                 - None
 ****************************************************************************/

unsigned char lines[4][2][1920];
void fill_lines(int width)
{
    unsigned char CVal[4][2] = {{0x5A, 0xF0},{0x36, 0x22},
        {0xF0, 0x6E},{0x10, 0x92}};
    int i, j ,k;
    /* Copy Y data for all 4 colors in the array */
    memset(lines[0][0], 0x51, 240);
    memset(lines[1][0], 0x91, 240);
    memset(lines[2][0], 0x29, 240);
    memset(lines[3][0], 0xD2, 240);
    /* Copy C data for all 4 Colors in the array */
    for(i = 0 ; i < 4 ; i ++) {
        for(j = 0 ; j < 2 ; j ++){
            for(k = 0 + j ; k < 240 ; k+=2)
                lines[i][1][k] = CVal[i][j];
        }
    }
}

void color_bar(unsigned char *addr, int pitch, int h, int size, int order)
{
    unsigned char *ptrY = addr;
    unsigned char *ptrC = addr + pitch*(size/(pitch*2));
    unsigned char *tempY, *tempC;
    int i, j;

    /* Calculate the starting offset from where Y and C data should
     * should start. */
    tempY = ptrY + pitch * 160 + 240 + order*pitch;
    tempC = ptrC + pitch * 160 + 240 + order*pitch;
    /* Fill all the colors in the buffer */
    for(j = 0; j < 4 ; j ++) {
        for(i = 0; i < 40; i ++) {
            memcpy(tempY, lines[j][0], 240);
            memcpy(tempC, lines[j][1], 240);
            tempY += pitch;
            tempC += pitch;
            if(tempY > (ptrY + pitch * 320 + 240 + pitch)) {
                tempY = ptrY + pitch * 160 + 240;
                tempC = ptrC + pitch * 160 + 240;
            }
        }
    }

}

void color_bar_user_ptr(unsigned char *addr, int width, int height, int order)
{
    unsigned short *ptr = (unsigned short *)addr + order*width;
    int i, j, k;

    for(i = 0 ; i < 8 ; i ++) {
        for(j = 0 ; j < height / 8 ; j ++) {
            for(k = 0 ; k < width / 2 ; k ++, ptr++) {
                if((unsigned int)ptr >= (unsigned int)addr +
                                width*height)
                    ptr = (unsigned short *)addr;
                *ptr = ycbcr[i];
            }
        }
    }
}
/****************************************************************************
 * Function             - fill_line_centre(),color_bar_centre()
 * Functionality        - This function generates the color bars at the centre
 *                        of screen(optional function)
 * Input Params         - addr,pitch,height,size for color_bar and width for
 *                        fill_lines()
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/
unsigned char line[4][2][1920];

void fill_line_centre(int width)
{
    unsigned char CVal[4][2] = {{0x5A, 0xF0},{0x36, 0x22},
        {0xF0, 0x6E},{0x10, 0x92}};
    int i, j ,k;
    /* Copy Y data for all 4 colors in the array */
    memset(line[0][0], 0x51, width/3);
    memset(line[1][0], 0x91, width/3);
    memset(line[2][0], 0x29, width/3);
    memset(line[3][0], 0xD2, width/3);
    /* Copy C data for all 4 Colors in the array */
    for(i = 0 ; i < 4 ; i ++) {
        for(j = 0 ; j < 2 ; j ++){
            for(k = 0 + j ; k < (width/3) ; k+=2)
                lines[i][1][k] = CVal[i][j];
        }
    }
}

void color_bar_centre(unsigned char *addr, int pitch, int h, int size, int order)
{
    unsigned char *ptrY = addr;
    unsigned char *ptrC = addr + pitch*(size/(pitch*2));
    unsigned char *tempY, *tempC;
    int i, j; 

    /* Calculate the starting offset from where Y and C data should
     * should start. */
    tempY = ptrY + pitch * (h/3) + (pitch/3) + order*pitch;
    tempC = ptrC + pitch * (h/3) + (pitch/3) + order*pitch;
    /* Fill all the colors in the buffer */
    for(j = 0; j < 4 ; j ++) {
        for(i = 0; i < 40 ; i ++) {
            memcpy(tempY, lines[j][0],(pitch/3));
            memcpy(tempC, lines[j][1], (pitch/3));
            tempY += pitch;
            tempC += pitch;
            if(tempY > (ptrY + pitch * ((h/3)*2) + (pitch/3) + pitch)) {
                tempY = ptrY + pitch * h + (pitch/3);
                tempC = ptrC + pitch * h + (pitch/3);
            }
        }
    }

}


/* vim: set ts=4 sw=4 tw=80 et:*/
