/*
 * st_v4l2_display_common.h
 *
 * This file contains the common functions declaration
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/ 
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/


#ifndef _ST_COMMON_H_
#define _ST_COMMON_H_

/* Device parameters */
//#define V4L2_DEV1       "/dev/video1"
//#define V4L2_DEV2       "/dev/video2"

/* Standard Linux header files */
#include <st_v4l2_display_interface.h>
/*Testcode related Header files*/
#include <stDefines.h>
#include <stLog.h>
#include <stTimer.h>
#include <stBufferMgr.h>
#include <stCpuLoad.h>
#define MAXLOOPCOUNT    10000

/*Structure for holding the test options */
struct v4l2_display_testparams
{
    /* Device node name */
    char *devnode;
    /* Number of buffers to request/enqueue */
    int noofbuffers;
    /*Number of frames to display */
    int noofframes;
    /* Open mode- Blocking/non blocking */
    int openmode;
    /* Width of the input image to be displayed */
    int width;
    /* Height of the input image to be displayed */
    int height;
    /**/
    int fmtht;
    int fmtwt;
    /**/ 
    /* Pixel format of the input image to be displayed */
    int pixfmt;
    /* Rotation angle */
    int rotation;
    /* Background color */
    int bgcolor;
    /* Mirroring enabled/disabled */
    int mirror;
    /* Factor by which an image can be cropped */
    int cropfactor;
    /* Factor by which image can be zoomed */
    int zoomfactor;
	/*Global variable to control the use of user pointer or mmap*/
	Bool userpointer;
	/*variable to show the throughput info or not */
	Bool throughput;
	/*variable to show the cpu load info or  not */
	Bool cpuload;
        /*variable to fill Q and DQ BUF or not */
    Bool queue;
	/*For IOCTL test*/
	int loopcount;
	int ioctl_no;
};

/* Function declarations */
/* Function to generate color bar */
void colorbar_generate(unsigned char *addr, int width, int height, int order);
void colorbar_generate_second(unsigned char *addr, int width, int height, int order);
/* Function to print testcase options(print member values of
 * v4l2_display_testparams structure) */
void print_v4l2_display_test_params();

/* The Declarations of implementation defined in the interface.c */



#define USR_PTR_SUPPORT  /*define to use the user pointer*/
#define MAX_DEV		  5 // This value can be changed when more V4L2_DISPLAY devices are introduced
#define  MAX_BUFFER      3
#define  USR_PTR_MAX_BUFFER 1
#define USR_PTR_HEIGHT  640
#define USR_PTR_WIDTH  480

/* display buffers for fbdev dev 0 windows */
unsigned long buffer_addr[USR_PTR_MAX_BUFFER];
int fbdev_fd;
#define NTSC_HEIGHT         480

/* image types */
#define ST_YUYV         V4L2_PIX_FMT_YUYV
#define ST_UYVY         V4L2_PIX_FMT_UYVY
#define ST_RGB_565      V4L2_PIX_FMT_RGB565
#define ST_RGB_888      V4L2_PIX_FMT_RGB24
#define ST_RGB_32       V4L2_PIX_FMT_RGB32

/* output interfaces */
#define ST_COMPOSITE    1
#define ST_COMPONENT    2
#define ST_SVIDEO       3
#define ST_DVI          4

/* Standard macros */
/* SD standrads */
#define NTSC_MODE_NAME "NTSC"
#define PAL_MODE_NAME "PAL"

/* HD standards */
#define HD_720P_50_MODE_NAME "720P-50"
#define HD_720P_60_MODE_NAME "720P-60"
#define HD_1080I_30_MODE_NAME "1080I-30"
#define HD_1080I_25_MODE_NAME "1080I-25"

/*ED standards */
#define ED_480P_60_MODE_NAME "480P-60"
#define ED_576P_50_MODE_NAME "576P-50"

#define SVIDEO_OUTPUT_NAME "SVIDEO"
#define COMPOSITE_OUTPUT_NAME "COMPOSITE"
#define COMPONENT_OUTPUT_NAME "COMPONENT"
/* Buffer type */
#define BUFTYPE V4L2_BUF_TYPE_VIDEO_OUTPUT

/* Open() call modes */
#define BLOCKING_OPEN_MODE 0
#define NON_BLOCKING_OPEN_MODE 1

#define DEFAULT_OPEN_MODE BLOCKING_OPEN_MODE

/* max, min and default number of buffers */
#define MAX_BUFFERS     8 
#define MIN_BUFFERS		3
#define ST_VIDEO_NUM_BUFS   3

/* Enable color bar display */
#define COLOR_BAR_DISPLAY

/* max command length */
#define TEST_ID_LENGTH      100

/* ERROR CODES - Helpful to differentiate between failures from non supported features*/
#define DEV_NOT_AVAILABLE   			-10
#define ROTATION_NOT_SUPPORTED		-11
#define MODE_NOT_SUPPORTED 	-12
#define OPERATION_NOT_SUPPORTED -14
#define QUERYBUFFAIL    -2

/*Control options*/
#define HUE_AUTO                    1           
#define WHITE_BALANCE_TEMPERATURE   2
#define SHARPNESS                   3
#define BACKLIGHT_COMPENSATION      4
#define CHROMA_AGC                  5  
#define COLOR_KILLER                6  
#define ROTATION                    7 
#define BG_COLOR                    8
#define LASTP1                      9  
#define MPEG_BASE                   10
#define MPEG_CLASS                  11


int user_ptr_display_height;
int user_ptr_display_widht;
int image_size;

/* Wrapper structure for v4l2_fmt */
struct st_v4l2_format
{
    int width;
    int height;
    int  pixelformat;
    int type;
};


struct st_v4l2_queryctrl {
	Uint32		     id;
	enum v4l2_ctrl_type  type;
	Uint8	name[32];	/* Whatever */
	int		     minimum;	/* Note signedness */
	int		     maximum;
	int		     step;
	int 	     default_value;
	Uint32                flags;
	Uint32		     reserved[2];
};

/* Structure to hold bitfields */
typedef struct st_bitfield
{
    Uint32 offset;              /* beginning of bitfield        */
    Uint32 length;              /* length of bitfield           */
    Uint32 msb_right;           /* != 0 : Most significant bit is */
    /* right */
} st_fb_bitfield;

/* structure to hold fix screen info */
typedef struct st_fix_screeninfo
{
    char id[16];                /* identification string eg "TT Builtin" */
    unsigned long smem_start;   /* Start of frame buffer mem */
    /* (physical address) */
    Uint32 smem_len;            /* Length of frame buffer mem */
    Uint32 type;                /* see FB_TYPE_*                */
    Uint32 type_aux;            /* Interleave for interleaved Planes */
    Uint32 visual;              /* see FB_VISUAL_*              */
    Uint32 xpanstep;            /* zero if no hardware panning  */
    Uint32 ypanstep;            /* zero if no hardware panning  */
    Uint32 ywrapstep;           /* zero if no hardware ywrap    */
    Uint32 line_length;         /* length of a line in bytes    */
    unsigned long mmio_start;   /* Start of Memory Mapped I/O   */
    /* (physical address) */
    Uint32 mmio_len;            /* Length of Memory Mapped I/O  */
    Uint32 accel;               /* Indicate to driver which     */
    /*  specific chip/card we have      */
    Uint32 reserved[3];         /* Reserved for future compatibility */
} st_fb_fix_screeninfo;


/* structure to hold variable screen info */
typedef struct st_var_screeninfo
{
    Uint32 xres;                /* visible resolution           */
    Uint32 yres;
    Uint32 xres_virtual;        /* virtual resolution           */
    Uint32 yres_virtual;
    Uint32 xoffset;             /* offset from virtual to visible */
    Uint32 yoffset;             /* resolution                   */

    Uint32 bits_per_pixel;      /* guess what                   */
    Uint32 grayscale;           /* != 0 Graylevels instead of colors */

    st_fb_bitfield red;         /* bitfield in fb mem if true color, */
    st_fb_bitfield green;       /* else only length is significant */
    st_fb_bitfield blue;
    st_fb_bitfield transp;      /* transparency                 */

    Uint32 nonstd;              /* != 0 Non standard pixel format */

    Uint32 activate;            /* see FB_ACTIVATE_*            */

    Uint32 height;              /* height of picture in mm    */
    Uint32 width;               /* width of picture in mm     */

    Uint32 accel_flags;         /* (OBSOLETE) see fb_info.flags */

    /* Timing: All values in pixclocks, except pixclock (of course) */
    Uint32 pixclock;            /* pixel clock in ps (pico seconds) */
    Uint32 left_margin;         /* time from sync to picture    */
    Uint32 right_margin;        /* time from picture to sync    */
    Uint32 upper_margin;        /* time from sync to picture    */
    Uint32 lower_margin;
    Uint32 hsync_len;           /* length of horizontal sync    */
    Uint32 vsync_len;           /* length of vertical sync      */
    Uint32 sync;                /* see FB_SYNC_*                */
    Uint32 vmode;               /* see FB_VMODE_*               */
    Uint32 rotate;              /* angle we rotate counter clockwise */
    Uint32 reserved[5];         /* Reserved for future compatibility */
} st_fb_var_screeninfo;


/* function prototype */
/* Wrapper for open() sysyem call */
int st_v4l2_display_open_interface(int dev);
/* Wrapper for close() sysyem call */
int st_v4l2_display_close_interface(int dev);
/* Wrapper for display APIs */
int st_v4l2_display_display_interface(int dev, int width, int height, int st_img_type);
/* Wrapper for QBUF API */
int st_v4l2_display_enqueue_buffers(int dev);

/*Wrapper for the user pointer implementation - to que the buffer*/
int st_v4l2_display_enqueue_user_ptr_buff(int dev, int size, int count);

/* Functions to set sysfs paths for different standards/interfaces */
void set_sysfs_path_for_ntsc();
void set_sysfs_path_for_pal();
void set_sysfs_path_for_composite();
void set_sysfs_path_for_component();
void set_sysfs_path_for_svideo();

/* Functions to check on user passed command line values */
int check_pixel_format();
int check_output_path();
int check_interface();
int check_std();

/*Function declarations for testcase functions*/
void st_v4l2_display_api_test(struct v4l2_display_testparams *,char*);
void st_v4l2_display_stability_test(struct v4l2_display_testparams *testoptions,
char* test_id,int nooftimes);
void st_v4l2_display_test(struct v4l2_display_testparams *testoptions,  char*
test_id);
void st_v4l2_display_ioctl_test(struct v4l2_display_testparams *testoptions,  char*
test_id);
void st_v4l2_display_alphablending_test(struct v4l2_display_testparams *testoptions,  char*
test_id);
void st_v4l2_display_from_file_test(struct v4l2_display_testparams *testoptions,
char* test_id,char* filename);
int st_fbdev_getFscreenInfo_interface(st_fb_fix_screeninfo * fixInfo);
int st_fbdev_mapbuffer_interface(int size);
int st_fbdev_getVscreenInfo_interface(st_fb_var_screeninfo * varInfo);
void st_get_control_val(int st_dev, int ctrl);
void st_set_control_val(int st_dev, int ctrl);
void st_query_control_val(int st_dev, int ctrl);
int st_v4l2_get_rotation(int dev);
int st_v4l2_set_rotation(int dev,int degree);
int st_v4l2_query_rotation(int dev, struct st_v4l2_queryctrl *omap_vout_qctrl);
int fbdev_display_open_interface();
int st_v4l2_display_color_bar_user_ptr(int dev,int noframes);
void color_bar(unsigned char *addr, int pitch, int h, int size, int order);


void st_v4l2_set_device_number(char* devname, int* st_dev);
int st_v4l2_display_open_nonblock_interface(int dev);
int st_v4l2_display_getimg_interface(int dev, struct st_v4l2_format* st_fmt);
int st_v4l2_set_mirror(int dev, int state);
int st_v4l2_display_setimg_interface(int dev, struct st_v4l2_format* st_fmt);
int st_v4l2_display_set_crop_interface(int dev,int cropfactor);
int st_v4l2_display_set_zoom_interface(int dev,int zoomfactor, int fmtht, int fmtwt);
int st_v4l2_display_request_buffer_interface(int dev, int count);
int st_v4l2_display_query_buffer_mmap_interface(int dev);
void fill_lines(int width);
int st_v4l2_display_streamon_interface(int dev);
int st_v4l2_display_color_bar(int dev,int noframes);
int st_v4l2_display_streamoff_interface(int dev);
int st_v4l2_display_unmap_interface(int dev);


int st_v4l2_display_query_buffer_mmap_interface_file(int dev);
int st_v4l2_display_read_buffer_from_file_interface(int fd);
int st_v4l2_display_qbuf_interface(int dev);
int st_v4l2_display_from_file(int dev,int fd,int noframes);
int st_v4l2_display_querycap_interface(int dev);
int st_v4l2_display_enum_fmt_interface(int dev);
int st_v4l2_display_tryimg_interface(int dev, struct st_v4l2_format* st_fmt);
int st_v4l2_display_query_crop_interface(int dev);
int st_v4l2_display_get_crop_interface(int dev);


int st_v4l2_display_request_UserPtr_buffer_interface(int dev, int count);
int st_v4l2_display_color_bar_user_ptr(int dev,int noframes);
void init_v4l2_display_test_params();


void display_v4l2_display_test_suite_help(void);
void color_bar_user_ptr(unsigned char *addr, int width, int height, int order);


int st_v4l2_display_get_bg_color(int dev);
int st_v4l2_display_set_bg_color(int dev,int bgcolor);
int st_v4l2_get_set_framebuffer(int dev);
int st_v4l2_display_query_buffer_mmap_second_interface(int dev);
int st_v4l2_display_set_get_fmt_interface(int dev);
int st_v4l2_get_set_framebuffer_second(int dev);
int st_v4l2_display_color_second_bar(int dev,int noframes);
#endif /* _ST_COMMON_H_ */

/* vim: set ts=4 sw=4 tw=80 et:*/

