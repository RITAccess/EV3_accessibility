/*
 * st_v4l2_parser.c
 *
 * This file contains the parser code for v4l2 driver
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/ 
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/


/* Generic header files */

#define __USE_GNU

/* Test case common header file */
#include "st_v4l2_display_common.h"

#define DEFAULT_STABILITY_COUNT 1000

/* Default output interface - LCD */
char *displayout = "lcd";

/* Default values related to test */
char *testcaseid = "DisplayTests";
char *testname = "Functionality";

/* Test case options structure */
extern struct v4l2_display_testparams testoptions;

/* The below will hold the user passed strings from command line */
static void process_v4l2_display_test_options(int argc, char *argv[]);
char *pixelformat = "RGB565";
char *standard = "ntsc";
char *interface = "composite";
char *filename ="yuv";

/* This is to indicate if its a special test */
int othertests=0;

/*Function to display test suite version */
void display_v4l2_display_testsuite_version();

/* Place all extern functions here */

/* Function to check pixel format */
extern int check_pixel_format();

/* Function to check output path */
extern int check_output_path();

/* Function to check interface */
extern int check_interface();

/* Function to check standard */
extern int check_std();

/* Function to display help/usage instructions */
extern void display_help();

/****************************************************************************
 * Function             - process_v4l2_display_test_options 
 * Functionality        - This function parses the command line options and vallues passed for the options
 * Input Params         -  argc,argv
 * Return Value         -  None
 * Note                 -  None
 ****************************************************************************/
static void process_v4l2_display_test_options(int argc, char *argv[])
{
    int error=FALSE;
    int version=FALSE;
    int help = FALSE;
    int othertests = FALSE;
    int displayfromfile = FALSE;
    int stabilitycount = DEFAULT_STABILITY_COUNT;
    for (;;) {
        int option_index = 0;
        /** Options for getopt - New test case options added need to be
         * populated here*/
        static struct option long_options[] = {
            {"displaynode", optional_argument, NULL, 'd'},
            {"displayout", optional_argument, NULL, 'o'},
            {"openmode", optional_argument, NULL, 'b'},
            {"width", optional_argument, NULL, 'w'},
            {"height", optional_argument, NULL, 'h'},
            {"fmtwt", optional_argument, NULL, 'W'},
            {"fmtht", optional_argument, NULL, 'H'},
            {"countofbuffers", optional_argument, NULL, 'c'},
            {"noofframes", optional_argument, NULL, 'n'},
            {"stabilitycount", optional_argument, NULL, 'C'},
            {"ratiocrop", optional_argument, NULL, 'r'},
            {"zoomfactor", optional_argument, NULL, 'z'},
            {"testcaseid", optional_argument, NULL, 't'},
            {"testname", optional_argument, NULL, 'T'},
            {"filename", optional_argument, NULL, 'f'},
            {"pixelformat", optional_argument, NULL, 'p'},
            {"standard", optional_argument, NULL, 's'},
            {"Rotation", optional_argument, NULL, 'R'},
            {"loopcount", optional_argument, NULL, 'L'},
            {"ioctl_no", optional_argument, NULL, 'I'},
            {"Background Color", optional_argument, NULL, 'B'},
            {"mirror", optional_argument, NULL, 'm'},
            {"interface", optional_argument, NULL, 'i'},
            {"userptr", optional_argument, NULL, 'u'},
            {"framerate", no_argument, NULL, 'F'},
            {"cpuload", no_argument, NULL, 'l'},
            {"queue", no_argument, NULL, 'q'},
            {"version", no_argument, NULL, 'v'},
            {"help", no_argument, NULL, '?'},
            {NULL, 0, NULL, 0}
        };
        int c = getopt_long (argc,argv,"d:o:b:w:h:W:H:c:n:C:r:z:t:T:f:p:s:R:L:I:B:m:u:i::Flqv?",
                long_options, &option_index);
        if (c == -1)
        {
            break;
        }
        switch (c) {
            case 'd':  
                if(optarg != NULL)
                {
                    testoptions.devnode = optarg;
                }
                else if(optind<argc && argv[optind])
                {
                    testoptions.devnode = argv[optind];
                }
                break;
            case 'o' : 
                if(optarg!= NULL) 
                {
                    displayout = optarg;
                }
                else if(optind<argc && argv[optind])
                {
                    displayout = argv[optind];
                }
                break;
            case 'b':  
                if(optarg != NULL)
                {
                    testoptions.openmode = atoi(optarg);
                }
                else if(optind<argc && argv[optind])
                {
                    testoptions.openmode = atoi(argv[optind]);
                }
                break;
            case 'w' : 
                if(optarg!= NULL)
                {
                    testoptions.width= atoi(optarg);
                }
                else if(optind<argc && argv[optind])
                {
                    testoptions.width  = atoi(argv[optind]);
                }
                break;
            case 'h' : 
                if(optarg != NULL)
                { 
                    testoptions.height = atoi(optarg);
                }
                else if(optind<argc && argv[optind])
                {
                    testoptions.height  = atoi(argv[optind]);
                }
                break; 
            case 'W' :
                if(optarg!= NULL)
                {
                    testoptions.fmtwt= atoi(optarg);
                }
                else if(optind<argc && argv[optind])
                {
                    testoptions.fmtwt  = atoi(argv[optind]);
                }
                break;
            case 'H' :
                if(optarg != NULL)
                {
                    testoptions.fmtht = atoi(optarg);
                }
                else if(optind<argc && argv[optind])
                {
                    testoptions.fmtht  = atoi(argv[optind]);
                }
                break;
            case 'c' : 
                if(optarg != NULL)
                { 
                    testoptions.noofbuffers = atoi(optarg);
                }
                else if(optind<argc && argv[optind])
                {
                    testoptions.noofbuffers  = atoi(argv[optind]);
                }
                break;
            case 'n' : 
                if(optarg != NULL)
                {
                    testoptions.noofframes = atoi(optarg);
                }
                else if(optind<argc && argv[optind])
                {
                    testoptions.noofframes  = atoi(argv[optind]);
                }
                break;
            case 'C' : 
                if(optarg != NULL)
                {
                    stabilitycount = atoi(optarg);
                }
                else if(optind<argc && argv[optind])
                {
                    stabilitycount  = atoi(argv[optind]);
                }
                break;
            case 'r' : 
                if(optarg != NULL)
                {
                    testoptions.cropfactor = atoi(optarg);
                }
                else if(optind<argc && argv[optind])
                {
                    testoptions.cropfactor  = atoi(argv[optind]);
                }
                break;
            case 'z' : 
                if(optarg != NULL)
                {
                    testoptions.zoomfactor = atoi(optarg);
                }
                else if(optind<argc && argv[optind])
                {
                    testoptions.zoomfactor  = atoi(argv[optind]);
                }
                break;
            case 't' : 
                if(optarg != NULL)
                { 
                    testcaseid=optarg;
                }
                else if(optind<argc && argv[optind])
                {
                    testcaseid = argv[optind];
                }
                break;
            case 'T' : 
                if(optarg != NULL)
                { 
                    testname=optarg;
                }
                else if(optind<argc && argv[optind])
                {
                    testname = argv[optind];
                }
                othertests = TRUE;
                break;
            case 'f' : 
                if(optarg != NULL)
                { 
                    filename=optarg;
                }
                else if(optind<argc && argv[optind])
                {
                    filename = argv[optind];
                }
                displayfromfile = TRUE;
                break;
            case 'p' : 
                if(optarg != NULL)
                {
                    pixelformat=optarg;
                }
                else if(optind<argc && argv[optind])
                {
                    pixelformat = argv[optind];
                }
                break;
            case 's' :
                if(optarg != NULL)
                {
                    standard=optarg;
                }
                else if(optind<argc && argv[optind])
                {
                    standard = argv[optind];
                }
                break;
            case 'R' : 
                if(optarg != NULL)
                {
                    testoptions.rotation = atoi(optarg);
                }
                else if(optind<argc && argv[optind])
                {
                    testoptions.rotation  = atoi(argv[optind]);
                }
                break;
            case 'L' : 
                if(optarg != NULL)
                {
                    testoptions.loopcount = atoi(optarg);
                }
                else if(optind<argc && argv[optind])
                {
                    testoptions.loopcount  = atoi(argv[optind]);
                }
                break;
            case 'I' : 
                if(optarg != NULL)
                {
                    testoptions.ioctl_no = atoi(optarg);
                }
                else if(optind<argc && argv[optind])
                {
                    testoptions.ioctl_no = atoi(argv[optind]);
                }
                break;
            case 'B' :
                if(optarg != NULL)
                {
                    testoptions.bgcolor = atoi(optarg);
                }
                else if(optind<argc && argv[optind])
                {
                    testoptions.bgcolor  = atoi(argv[optind]);
                }
                break;
            case 'm' : 
                if(optarg != NULL)
                {
                    testoptions.mirror = atoi(optarg);
                }
                else if(optind<argc && argv[optind])
                {
                    testoptions.mirror  = atoi(argv[optind]);
                }
                break;
            case 'i' :
                if(optarg != NULL)
                {
                    interface=optarg;
                }
                else if(optind<argc && argv[optind])
                {
                    interface = argv[optind];
                }
                break;
			case 'u' :
				if(optarg != NULL)
				{
                    testoptions.userpointer = atoi(optarg);
				}
				else if(optind<argc && argv[optind])
				{
                    testoptions.userpointer  = atoi(argv[optind]);
				}
				break;
            case 'F' : 
                testoptions.throughput = TRUE;
                break;
            case 'l' : 
                testoptions.cpuload = TRUE;
                break;
            case 'q' :
                testoptions.queue = TRUE;
                break;
            case 'v' : 
                display_v4l2_display_testsuite_version();
                version= TRUE;
                break;
            case '?': 
                help = TRUE; break;
        }
    }
    /* If any error in usage, values provided for options, display help to user*/ 
    if(help !=TRUE && version !=TRUE)
    {
        if(FAILURE == check_pixel_format() || FAILURE == check_interface() || FAILURE == check_std() || FAILURE == check_output_path())
        {
            error = TRUE;
        }	
    } 
    if (error == TRUE || help ==TRUE)
    {
        display_v4l2_display_test_suite_help();
    }

    if((version != TRUE && help !=TRUE) && (error != TRUE))
    {       
        print_v4l2_display_test_params(&testoptions,testcaseid);
        if(othertests != TRUE)
        {
            if(displayfromfile != TRUE)
            {
                st_v4l2_display_test(&testoptions,testcaseid);
            }
            else
            {
                st_v4l2_display_from_file_test(&testoptions,testcaseid,filename);
            }
        }
        else if(strcmp(testname,"stability") == SUCCESS)
        {
            st_v4l2_display_stability_test(&testoptions,testcaseid,stabilitycount);
        }
        else if(strcmp(testname,"api") == SUCCESS)
        {
            st_v4l2_display_api_test(&testoptions,testcaseid);
        }
        else if(strcmp(testname,"ioctl") == SUCCESS)
        {
            st_v4l2_display_ioctl_test(&testoptions,testcaseid);
        }
        else if(strcmp(testname,"alpha") == SUCCESS)
        {
            st_v4l2_display_alphablending_test(&testoptions,testcaseid);
        }
        else
        {
            printf("Test not supported\n");
        } 
    }
}


/****************************************************************************
 * Function             - display_version
 * Functionality        - This function displays the test suite version
 * Input Params         - None 
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/
void display_v4l2_display_testsuite_version()
{
    printf("v4l2DisplayTestSuite V %s\n", VERSION_STRING);
}

/****************************************************************************
 * Function             - Main function
 * Functionality        - This is where the execution begins
 * Input Params         - argc,argv
 * Return Value         - None
 * Note                 - None
 ****************************************************************************/
int main(int argc, char **argv)
{
    /* Initialize options with default vales */	
    init_v4l2_display_test_params();
    /* Invoke the parser function to process the command line options */
    process_v4l2_display_test_options(argc, argv);
    return 0;
}
/* vi: set ts=4 sw=4 tw=80 et:*/

