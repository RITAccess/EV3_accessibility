/*
 * st_v4l2_display_test.c
 *
 * This file calls V4L2 Display driver functions to display color bar 
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/ 
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/

/* function prototypes for interface functions are defined here*/
/*#include <linux/fb.h>*/
#include "st_v4l2_display_common.h"
#define V4L2_DEV1       "/dev/video1"
#define V4L2_DEV2       "/dev/video2"

/* global variables */
char displaynode[25];
int cropfactor = 1;

#define NUM_FRAMES_1 1000
#define NUM_FRAMES_2 1000
#define MAX_BUFFER_1 2


/*Code added to support the User pointer implementation*/
#ifdef USR_PTR_SUPPORT
#define FBDEV_DEV0    0         //OSD0
#endif	
void *video1_threadfun(void *ptr)
{
	DBG_PRINT_TRC0(("In thread 2"));
    char *devnode = V4L2_DEV1;
	int retVal = SUCCESS;
    int status = SUCCESS;
    struct st_v4l2_format st_fmt; 
    int st_dev ;

    Bool openStatus = FALSE;
    Bool mmapStatus = FALSE;
	
	/* get device number for a device string to avoid further string operations */
    st_v4l2_set_device_number(devnode, &st_dev);

    DBG_PRINT_TRC0(("Device number - %d",st_dev));

		retVal = st_v4l2_display_open_interface(st_dev);
		if (SUCCESS != retVal)
		{
			DBG_PRINT_ERR(("Failed to open V4L2 device /dev/video%d", st_dev));
			status = FAILURE;  
		}

        openStatus = TRUE; // device is opened
        DBG_PRINT_TRC0(("V4L2 device node /dev/video%d opened", st_dev));

        retVal = st_v4l2_get_set_framebuffer(st_dev);
            if (SUCCESS != retVal)
            {
				DBG_PRINT_ERR(("G_FBUF and S_FBUF Failed"));
			}

		DBG_PRINT_TRC0(("G_FBUF and S_FBUF Passed"));
	
        /* get format */
        retVal = st_v4l2_display_getimg_interface(st_dev, &st_fmt);
            if (SUCCESS != retVal)
            {
                DBG_PRINT_ERR(("G_FMT Ioctl Failed"));
                status = FAILURE;
            }
            DBG_PRINT_TRC0(("G_FMT Ioctl Passed")); 
  
        /* set format */
		st_fmt.width = 640;
		st_fmt.height = 480;
		st_fmt.type = BUFTYPE;
		st_fmt.pixelformat = ST_RGB_32;
		retVal = st_v4l2_display_setimg_interface(st_dev, &st_fmt);
		if (SUCCESS != retVal)
		{
			DBG_PRINT_ERR(("S_FMT Ioctl Failed"));
			status = FAILURE;
		}
		DBG_PRINT_TRC0(("S_FMT Ioctl Passed"));

		retVal = st_v4l2_display_get_crop_interface(st_dev);
		if (SUCCESS != retVal)
		{
			DBG_PRINT_ERR(("G_CROP Failed"));
		}
		DBG_PRINT_TRC0(("G_CROP Ioctl Passed"));
		
		retVal = st_v4l2_display_set_crop_interface(st_dev, cropfactor);
		if (SUCCESS != retVal)
		{
			DBG_PRINT_ERR(("G_CROP Failed"));
		}
		DBG_PRINT_TRC0(("G_CROP Ioctl Passed"));

		retVal = st_v4l2_display_set_get_fmt_interface(st_dev);
		if (SUCCESS != retVal)
		{
			DBG_PRINT_ERR(("S_FMT and G_FMT Failed"));
		}
		DBG_PRINT_TRC0(("S_FMT and G_FMT Ioctl Passed"));
		
		
		/*User pointer usage variable not set*/
		 retVal = st_v4l2_display_request_buffer_interface(st_dev,MAX_BUFFER_1);
		 if (SUCCESS != retVal)
		{
			DBG_PRINT_ERR(("REQBUF Ioctl Failed"));
			status = FAILURE;
		}
		
		 DBG_PRINT_TRC0(("REQBUF Ioctl Passed"));
		
		 /* Query buffer */
		 retVal = st_v4l2_display_query_buffer_mmap_interface(st_dev);
		
		 if (QUERYBUFFAIL == retVal)
		 {
			 DBG_PRINT_ERR(("QUERYBUF Ioctl Failed"));
			 status = FAILURE;
		 }
		
		 DBG_PRINT_TRC0(("QUERYBUF Ioctl Passed"));
		  if (FAILURE == retVal)
		 {
			 DBG_PRINT_ERR(("Mmap Failed"));
			 status = FAILURE;
		}
		
		 DBG_PRINT_TRC0(("Mmap Passed"));
		
		 /* Setting mmmapstatus as TRUE as mmap has passed if control reaches here*/
		 mmapStatus = TRUE;
		
		 /* get format */
		 retVal = st_v4l2_display_getimg_interface(st_dev, &st_fmt);
		 if (SUCCESS != retVal)
		 {
			 DBG_PRINT_ERR(("G_FMT Ioctl Failed"));
			 status = FAILURE;
			  
		 }
		 DBG_PRINT_TRC0(("G_FMT Ioctl Passed")); 
		
		 fill_lines(640);
		 /* Enqueue buffers */
		 retVal = st_v4l2_display_enqueue_buffers(st_dev);
		 if (SUCCESS != retVal)
		 {
			 DBG_PRINT_ERR(("Enqueue Failed"));
			 status = FAILURE;
			  
		 }
		
		 DBG_PRINT_TRC0(("Enqueuing Buffers Passed"));

		         /* Stream on */
 
        DBG_PRINT_TRC0(("Streaming on for frames | %d",NUM_FRAMES_1));
        /* Stream on */
	retVal = st_v4l2_display_streamon_interface(st_dev);
        if (SUCCESS != retVal)
        {
            DBG_PRINT_ERR(("STREAM ON Failed"));
            status = FAILURE;
        }

        DBG_PRINT_TRC0(("Streaming on for frames | %d",NUM_FRAMES_1));

		/* Display frames */       
		retVal = st_v4l2_display_color_bar(st_dev,NUM_FRAMES_1);
		if (SUCCESS != retVal)
		{
			DBG_PRINT_ERR(("Display Failed"));
			status = FAILURE;
			 
		}
		        /* Stream off */       
        retVal = st_v4l2_display_streamoff_interface(st_dev);
        if (SUCCESS != retVal)
        {
            DBG_PRINT_ERR(("STREAM OFF Failed"));
            status = FAILURE;
        }

        DBG_PRINT_TRC0(("Streaming off.....Stopping display"));

           retVal = 
            st_v4l2_display_close_interface(st_dev);
           if (SUCCESS != retVal)
            {
                DBG_PRINT_ERR(("V4L2 Device could not be closed"));
                status = FAILURE;
            } 

          openStatus = FALSE; // device is closed

            DBG_PRINT_TRC0(("V4L2 device node /dev/video%d closed",st_dev));
        return NULL; 		

}

void *video2_threadfun(void *ptr)
{
    DBG_PRINT_TRC0(("In thread 1"));
    char *devnode = V4L2_DEV2;

	/* variables to track device state, mapping of buffers and state of V4L2 window */ 
    Bool openStatus = FALSE;
    Bool mmapStatus = FALSE;
    int retVal = SUCCESS;
    int status = SUCCESS;
    struct st_v4l2_format st_fmt; 
    int st_dev ;	

	DBG_PRINT_TRC0(("In thread 2"));

	/* get device number for a device string to avoid further string operations */
    st_v4l2_set_device_number(devnode, &st_dev);

    DBG_PRINT_TRC0(("Device number - %d",st_dev));

            /* open V4L2 display device in non blocking mode*/
            retVal = st_v4l2_display_open_interface(st_dev);
            if (SUCCESS != retVal)
            {
                    DBG_PRINT_ERR(("Failed to open V4L2 device /dev/video%d", st_dev));
                    status = FAILURE;  
                     
            }
 
     

        openStatus = TRUE; // device is opened
        DBG_PRINT_TRC0(("V4L2 device node /dev/video%d opened", st_dev));


        /* get format */
        retVal = st_v4l2_display_getimg_interface(st_dev, &st_fmt);
            if (SUCCESS != retVal)
            {
                DBG_PRINT_ERR(("G_FMT Ioctl Failed"));
                status = FAILURE;
                  
            }
            DBG_PRINT_TRC0(("G_FMT Ioctl Passed")); 
  
        /* set format */
		st_fmt.width = 640;
		st_fmt.height = 480;
		st_fmt.type = BUFTYPE;
		st_fmt.pixelformat = ST_RGB_32;
		retVal = st_v4l2_display_setimg_interface(st_dev, &st_fmt);
		if (SUCCESS != retVal)
		{
			DBG_PRINT_ERR(("S_FMT Ioctl Failed"));
			status = FAILURE;
			 
		}
		DBG_PRINT_TRC0(("S_FMT Ioctl Passed"));

		retVal = st_v4l2_display_get_crop_interface(st_dev);
		if (SUCCESS != retVal)
		{
			DBG_PRINT_ERR(("G_CROP Failed"));
		}
		DBG_PRINT_TRC0(("G_CROP Ioctl Passed"));
		
		retVal = st_v4l2_display_set_crop_interface(st_dev, cropfactor);
		if (SUCCESS != retVal)
		{
			DBG_PRINT_ERR(("G_CROP Failed"));
		}
		DBG_PRINT_TRC0(("G_CROP Ioctl Passed"));

		retVal = st_v4l2_display_set_get_fmt_interface(st_dev);
		if (SUCCESS != retVal)
		{
			DBG_PRINT_ERR(("S_FMT and G_FMT Failed"));
		}
		DBG_PRINT_TRC0(("S_FMT and G_FMT Ioctl Passed"));
		
		
		/*User pointer usage variable not set*/
		 retVal = st_v4l2_display_request_buffer_interface(st_dev,MAX_BUFFER_1);
		 if (SUCCESS != retVal)
		{
			DBG_PRINT_ERR(("REQBUF Ioctl Failed"));
			status = FAILURE;
			 
		}
		
		 DBG_PRINT_TRC0(("REQBUF Ioctl Passed"));
		
		 /* Query buffer */
		 retVal = st_v4l2_display_query_buffer_mmap_second_interface(st_dev);
		
		 if (QUERYBUFFAIL == retVal)
		 {
			 DBG_PRINT_ERR(("QUERYBUF Ioctl Failed"));
			 status = FAILURE;
			  
		 }
		
		 DBG_PRINT_TRC0(("QUERYBUF Ioctl Passed"));
		  if (FAILURE == retVal)
		 {
			 DBG_PRINT_ERR(("Mmap Failed"));
			 status = FAILURE;
			  
		}
		
		 DBG_PRINT_TRC0(("Mmap Passed"));
		
		 /* Setting mmmapstatus as TRUE as mmap has passed if control reaches here*/
		 mmapStatus = TRUE;
		
		 /* get format */
		 retVal = st_v4l2_display_getimg_interface(st_dev, &st_fmt);
		 if (SUCCESS != retVal)
		 {
			 DBG_PRINT_ERR(("G_FMT Ioctl Failed"));
			 status = FAILURE;
			  
		 }
		 DBG_PRINT_TRC0(("G_FMT Ioctl Passed")); 
		
		 fill_lines(640);
		 /* Enqueue buffers */
		 retVal = st_v4l2_display_enqueue_buffers(st_dev);
		 if (SUCCESS != retVal)
		 {
			 DBG_PRINT_ERR(("Enqueue Failed"));
			 status = FAILURE;
			  
		 }
		
		 DBG_PRINT_TRC0(("Enqueuing Buffers Passed"));

        DBG_PRINT_TRC0(("Streaming on for frames | %d",NUM_FRAMES_2));
        /* Stream on */
        retVal = st_v4l2_display_streamon_interface(st_dev);
        if (SUCCESS != retVal)
        {
            DBG_PRINT_ERR(("STREAM ON Failed"));
            status = FAILURE;
             
        }

        DBG_PRINT_TRC0(("Streaming on for frames | %d",NUM_FRAMES_2));

		/* Display frames */       
		retVal = st_v4l2_display_color_second_bar(st_dev,NUM_FRAMES_2);
		if (SUCCESS != retVal)
		{
			DBG_PRINT_ERR(("Display Failed"));
			status = FAILURE;
			 
		}
		        /* Stream off */       
        retVal = st_v4l2_display_streamoff_interface(st_dev);
        if (SUCCESS != retVal)
        {
            DBG_PRINT_ERR(("STREAM OFF Failed"));
            status = FAILURE;
             
        }

        DBG_PRINT_TRC0(("Streaming off.....Stopping display"));

        /* unmap buffers if mapped */
        if (TRUE == mmapStatus)
        {
            /* close v4l2 device */
            retVal = st_v4l2_display_unmap_interface(st_dev);
            if (SUCCESS != retVal)
            {
                DBG_PRINT_ERR(("unmap failed"));
                status = FAILURE;
                 
            } 

            mmapStatus = FALSE; // buffers not mapped

            DBG_PRINT_TRC0(("Buffers unmapped Successfully"));
        }
		
        if (TRUE == openStatus)
        {

           /* close fbdev device */
            retVal = 
            st_v4l2_display_close_interface(st_dev);
            if (SUCCESS != retVal)
            {
                DBG_PRINT_ERR(("V4L2 Device could not be closed"));
                status = FAILURE;
                 
             } 

           openStatus = FALSE; // device is closed

            DBG_PRINT_TRC0(("V4L2 device node /dev/video%d closed",st_dev));
      }
        return NULL; 		

}

/****************************************************************************
 * Function             - st_v4l2_display_test
 * Functionality        - Function to display image of given width*height on the
 *                              V4L2 supported windows
 * Input Params         - mode and interface. resolution of the image,  test case id.
 * Return Value         - None.
 * Note                 - None
 ****************************************************************************/
void st_v4l2_display_alphablending_test(struct v4l2_display_testparams *testoptions,  char* test_id)
{
	int ret1, ret2;
	pthread_t t1, t2;
	char str[250];
	int status = SUCCESS;
	DBG_PRINT_TRC0(("I am in"));
	
	strcpy(str, "echo ""gfx e:0"" > /sys/devices/platform/omapdss/overlay0/enabled");

	/*  Disable Graphics pipeline for this demo.
	 *  So that it does not create show the past buffer
	 */
	if(system(str)) {
		DBG_PRINT_ERR(("Failed to dislable graphics pipeline"));
	}

	/* Two threads are created. one thread displays RGB24 unpacked image
	 * into video1 pipeline and other thread displays ARGB image into
	 * video2 pipeline */
	/* Create threads for Video1 and Video2 streaming*/
	ret1 = pthread_create(&t1, NULL, video1_threadfun, (void *)testoptions);
	ret2 = pthread_create(&t2, NULL, video2_threadfun, (void *)testoptions);
	pthread_join(t1, NULL);
	pthread_join(t2, NULL);

	strcpy(str,"echo ""gfx e:1"" > /sys/devices/platform/omapdss/overlay0/enabled");

		/*  Disable Graphics pipeline for this demo.
		 *  So that it does not create show the past buffer
		 */
		if(system(str)) {
			DBG_PRINT_ERR(("Failed to dislable graphics pipeline"));
		}

		    /* print status/result of the test case */
    if (FAILURE == status)
    {
        DBG_PRINT_TST_RESULT_FAIL((test_id));
    }
    else
    {
        DBG_PRINT_TST_RESULT_PASS((test_id));
    }
    /* end test case */
    DBG_PRINT_TST_END((test_id));	

    return;

}

/* vim: set ts=4 sw=4 tw=80 et:*/


