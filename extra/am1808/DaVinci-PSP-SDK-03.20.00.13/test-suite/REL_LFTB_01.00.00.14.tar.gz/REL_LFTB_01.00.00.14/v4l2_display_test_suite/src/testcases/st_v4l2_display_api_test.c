/*
 * st_v4l2_display_ioctl_test.c
 *
 * This file contains code to test various ioclts supported by V4L2 driver
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/ 
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/

/* function prototypes for interface functions are defined here*/
#include "st_v4l2_display_common.h"
#include "st_v4l2_display_interface.h"

/* global variables */
char displaynode[25];

#define NUM_FRAMES 1000


/****************************************************************************
 * Function             - st_v4l2_display_test
 * Functionality        - Function to display image of given width*height on the
 *                              V4L2 supported windows
 * Input Params         - mode and interface. resolution of the image,  test case id.
 * Return Value         - None.
 * Note                 - None
 ****************************************************************************/
void st_v4l2_display_api_test(struct v4l2_display_testparams *testoptions,  char* test_id)
{
    int retVal = SUCCESS;
    int status = SUCCESS;
    struct st_v4l2_format st_fmt; 
    int st_dev ;

    int noofframes =0;
    /* Retrieving test case options values */
    int st_width = testoptions->width;
    int st_height = testoptions->height;
    int noofbuffers = testoptions->noofbuffers;
    int pixelfmt = testoptions->pixfmt;
    int cropfactor = testoptions->cropfactor;
    int zoomfactor = testoptions->zoomfactor;  
    int fmtht = testoptions->fmtht;
    int fmtwt = testoptions->fmtwt;
    /* variables to track device state, mapping of buffers and state of V4L2 window */ 
    Bool openStatus = FALSE;
    Bool mmapStatus = FALSE;
    

    /* get device number for a device string to avoid further string operations */
    st_v4l2_set_device_number(testoptions->devnode, &st_dev);

    do
    {  
        /* open V4L2 display device */
        retVal = st_v4l2_display_open_interface(st_dev);
        if (SUCCESS != retVal)
        {
            DBG_PRINT_ERR(("Failed to open V4L2 device /dev/video%d", st_dev));
            status = FAILURE;  
            break;
        }

        openStatus = TRUE; // device is opened

        DBG_PRINT_TRC0(("V4L2 device node /dev/video%d opened", st_dev));
        DBG_PRINT_TRC0(("open API passed" ));

        retVal = st_v4l2_display_querycap_interface(st_dev);
        if (SUCCESS != retVal)
        {
            DBG_PRINT_ERR(("QUERY_CAPABILITIES Ioctl Failed"));
            status = FAILURE;
        }
        else
        {
            DBG_PRINT_TRC0(("QUERY_CAPABILITIES Ioctl Passed"));
        }
        retVal = st_v4l2_display_enum_fmt_interface(st_dev);
        if (SUCCESS != retVal)
        {
            DBG_PRINT_ERR(("ENUM_FMT Ioctl Failed"));
            status = FAILURE;
        }
        else
        { 
            DBG_PRINT_TRC0(("ENUM_FMT Ioctl Passed"));
        }
        /* get format */
        retVal = st_v4l2_display_getimg_interface(st_dev, &st_fmt);
        if (SUCCESS != retVal)
        {
            DBG_PRINT_ERR(("G_FMT Ioctl Failed"));
            status = FAILURE;
        }
        else
        {
            DBG_PRINT_TRC0(("G_FMT Ioctl Passed"));
        }
        retVal = st_v4l2_display_tryimg_interface(st_dev, &st_fmt);
        if (SUCCESS != retVal)
        {
            DBG_PRINT_ERR(("TRY_FMT Ioctl Failed"));
            status = FAILURE;
        }
        else
        { 
            DBG_PRINT_TRC0(("TRY_FMT Ioctl Passed"));
        }
        /* set format */
        st_fmt.width = st_width;
        st_fmt.height = st_height;
        st_fmt.type = BUFTYPE;
        st_fmt.pixelformat = pixelfmt;
        retVal = st_v4l2_display_setimg_interface(st_dev, &st_fmt);
        if (SUCCESS != retVal)
        {
            DBG_PRINT_ERR(("S_FMT Ioctl Failed"));
            status = FAILURE;
        }
        else
        {  
            DBG_PRINT_TRC0(("S_FMT Ioctl Passed"));
        }
        retVal = st_v4l2_display_query_crop_interface(st_dev);
        if (SUCCESS != retVal)
        {
            DBG_PRINT_ERR(("CROP_CAP Ioctl Failed"));
            status = FAILURE;
        }
        else
        {
            DBG_PRINT_TRC0(("CROP_CAP Ioctl Passed"));
        }

        if(cropfactor != 0)
        {
            retVal = st_v4l2_display_set_crop_interface(st_dev,cropfactor);
            if (SUCCESS != retVal)
            {
                if(OPERATION_NOT_SUPPORTED == retVal)
                {
                    DBG_PRINT_ERR(("Set crop not supported on this platform"));
                    status = FAILURE;
                }
                else
                {
                    DBG_PRINT_ERR(("Set crop Ioctl Failed"));
                    status = FAILURE;
                }
            }
            else
            { 
                DBG_PRINT_TRC0(("S_CROP Ioctl Passed"));
            }
            retVal = st_v4l2_display_get_crop_interface(st_dev);
            if (SUCCESS != retVal)
            {
                if(OPERATION_NOT_SUPPORTED == retVal)
                {
                    DBG_PRINT_ERR(("Get crop not supported on this platform"));
                    status = FAILURE;
                }
                else
                {
                    DBG_PRINT_ERR(("G_CROP Ioctl Failed"));
                    status = FAILURE;
                }
            }
            else
            { 
                DBG_PRINT_TRC0(("G_CROP Ioctl Passed"));
            }
        }
        if(zoomfactor != 0)
        {
            retVal = st_v4l2_display_set_zoom_interface(st_dev,zoomfactor,fmtht,fmtwt); 
            if (SUCCESS != retVal)
            {
                if(OPERATION_NOT_SUPPORTED == retVal)
                {
                    DBG_PRINT_ERR(("Set crop with zoom not supported on this platform"));
                    status = FAILURE;
                }
                else
                {
                    DBG_PRINT_ERR(("Set Zoom Ioctl Failed"));
                    status = FAILURE;
                }
            }
            else
            { 
                DBG_PRINT_TRC0(("G_CROP Ioctl Passed"));
            }
        }


        /* Request buffer */
        retVal = st_v4l2_display_request_buffer_interface(st_dev,noofbuffers);
        if (SUCCESS != retVal)
        {
            DBG_PRINT_ERR(("REQBUF Ioctl Failed"));
            status = FAILURE;
        }
        else
        {
            DBG_PRINT_TRC0(("REQBUF Ioctl Passed"));
        }
        /* Query buffer */
        retVal = st_v4l2_display_query_buffer_mmap_interface(st_dev);

        if (QUERYBUFFAIL == retVal)
        {
            DBG_PRINT_ERR(("QUERYBUF Ioctl Failed"));
            status = FAILURE;
        }

        else if (FAILURE == retVal)
        {
            DBG_PRINT_ERR(("Mmap API Failed"));
            status = FAILURE;
        }
        else
        {
            DBG_PRINT_TRC0(("Query Buf Ioctl Passed"));
            DBG_PRINT_TRC0(("Mmap API Passed"));
        }
        /* Setting mmmapstatus as TRUE as mmap has passed if control reaches
         * here*/
        mmapStatus = TRUE;

        /* get format */
        retVal = st_v4l2_display_getimg_interface(st_dev, &st_fmt);
        if (SUCCESS != retVal)
        {
            DBG_PRINT_ERR(("G_FMT Ioctl Failed"));
            status = FAILURE;
        }
        else
        {   
            DBG_PRINT_TRC0(("G_FMT Ioctl Passed")); 
        }
        /* Enqueue buffers */
        retVal = st_v4l2_display_enqueue_buffers(st_dev);
        if (SUCCESS != retVal)
        {
            DBG_PRINT_ERR(("QBUF ioctl Failed"));
            status = FAILURE;
        }
        else
        {
            DBG_PRINT_TRC0(("QBUF ioctl Passed"));
        }

		/*added the new api functions here */
        /*These are query and get controls*/
		
        DBG_PRINT_TRC0(("Get the required control value"));
        st_get_control_val(st_dev, ROTATION);
        
        DBG_PRINT_TRC0(("Query the required control value"));
        st_query_control_val(st_dev,ROTATION);
 

        /* Stream on */
        retVal = st_v4l2_display_streamon_interface(st_dev);
        if (SUCCESS != retVal)
        {
            DBG_PRINT_ERR(("STREAM ON ioctl Failed"));
            status = FAILURE;
        }
        else
        {
            DBG_PRINT_TRC0(("STREAMON ioctl passed"));
        }
        /* Display frames */       
        retVal = st_v4l2_display_color_bar(st_dev,noofframes);
        if (SUCCESS != retVal)
        {
            DBG_PRINT_ERR(("DQBUF ioctl Failed"));
            status = FAILURE;
        }
        else
        {
            DBG_PRINT_TRC0(("DQBUF ioctl passed"));
        }
        /* Stream off */       
        retVal = st_v4l2_display_streamoff_interface(st_dev);
        if (SUCCESS != retVal)
        {
            DBG_PRINT_ERR(("STREAM OFF ioctl Failed"));
            status = FAILURE;
        }
        else
        {
            DBG_PRINT_TRC0(("STREAMOFF ioctl passed"));
        }
        /* unmap buffers if mapped */
        if (TRUE == mmapStatus)
        {
            /* close v4l2 device */
            retVal = st_v4l2_display_unmap_interface(st_dev);
            if (SUCCESS != retVal)
            {
                DBG_PRINT_ERR(("unmap API failed"));
                status = FAILURE;
            } 
            else
            {
                DBG_PRINT_TRC0(("unmap API passed"));
                mmapStatus = FALSE; // buffers not mapped
            }

        }

        /* close device if opened */
        if (TRUE == openStatus)
        {
            /* close v4l2 device */
            retVal = st_v4l2_display_close_interface(st_dev);
            if (SUCCESS != retVal)
            {
                DBG_PRINT_ERR(("V4L2 Device could not be closed"));
                status = FAILURE;
            } 
            else
            { 
                DBG_PRINT_TRC0(("V4L2 device node /dev/video%d closed",st_dev));
                DBG_PRINT_TRC0(("close API passed"));
                openStatus = FALSE; // device is closed
            }

        }
        break;

    }while(SUCCESS != retVal);

    /* print status/result of the test case */
    if (FAILURE == status)
    {
        DBG_PRINT_TST_RESULT_FAIL((test_id));
    }
    else
    {
        DBG_PRINT_TST_RESULT_PASS((test_id));
    }
    /* end test case */
    DBG_PRINT_TST_END((test_id));	

    return;

}

/****************************************************************************
 * Function             - st_get_control_val
 * Functionality        - This function gets the control of the device
 * Input Params         - None
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/
void st_get_control_val(int st_dev, int ctrl)
{

    int gdegree=0;
    int retVal = SUCCESS;

    switch(ctrl)
    {
        case ROTATION:
                DBG_PRINT_TRC0(("Get the rotation value"));
                retVal = st_v4l2_get_rotation(st_dev);
                if (SUCCESS != retVal)
                {
                    DBG_PRINT_ERR(("VIDIOC_G_CTRL Ioctl Failed"));
                    break;
                }
                DBG_PRINT_TRC0(("Rotation value obtained - %d",gdegree));
                DBG_PRINT_TRC0(("VIDIOC_G_CTRL Ioctl Passed"));
                break;
        default:
            DBG_PRINT_TRC0(("Wrong paramter passed for the get  control"));
            retVal = FAILURE;
    }

    return;
}

/****************************************************************************
 * Function             - st_query_control_val
 * Functionality        - This function query's the control of the device
 * Input Params         - None
 * Return Value         - 0 on SUCCESS -1 on FAILURE
 * Note                 - None
 ****************************************************************************/
void st_query_control_val(int st_dev, int ctrl)
{

    struct st_v4l2_queryctrl omap_vout_qctrl;
    int retVal = SUCCESS;

    switch(ctrl)
    {
        case ROTATION:
                DBG_PRINT_TRC0(("Query the rotation value"));
                retVal = st_v4l2_query_rotation(st_dev, &omap_vout_qctrl);
                if (SUCCESS != retVal)
                {
                    DBG_PRINT_ERR(("VIDIOC_G_CTRL Ioctl Failed"));
                    break;
                }
                DBG_PRINT_TRC0(("Q_CTRL Ioctl Passed for rotation passed"));
                DBG_PRINT_TRC0(("Returned values"));
		
                DBG_PRINT_TRC0(("The value of id= %lu\n",omap_vout_qctrl.id));
		        DBG_PRINT_TRC0(("The value of name = %u\n",(unsigned int)omap_vout_qctrl.name));
		        DBG_PRINT_TRC0(("The value of minimum = %d\n",omap_vout_qctrl.minimum));
		        DBG_PRINT_TRC0(("The value of maximum = %d\n",omap_vout_qctrl.maximum));
		        DBG_PRINT_TRC0(("The value of step = %d\n",omap_vout_qctrl.step));
		        DBG_PRINT_TRC0(("The value of default_value = %d\n",omap_vout_qctrl.default_value));
		        DBG_PRINT_TRC0(("The value of flags = %lu\n",omap_vout_qctrl.flags));
		        DBG_PRINT_TRC0(("The value of type = %d\n",omap_vout_qctrl.type));
                break;
        default:
            DBG_PRINT_TRC0(("Wrong paramter passed for the query control"));
            retVal = FAILURE;
    }

    return;
}
/* vim: set ts=4 sw=4 tw=80 et:*/


