/*
 * TI Booting and Flashing Utilities
 *
 * UART driver header file
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as 
 * published by the Free Software Foundation version 2.
 *
 * This program is distributed "as is" WITHOUT ANY WARRANTY of any
 * kind, whether express or implied; without even the implied warranty
 * of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

/* --------------------------------------------------------------------------
  AUTHOR      : Daniel Allred
 --------------------------------------------------------------------------- */

#ifndef _UART_H_
#define _UART_H_

#include "tistdtypes.h"

// Prevent C++ name mangling
#ifdef __cplusplus
extern far "c" {
#endif

/************************************************************
* Global Macro Declarations                                 *
************************************************************/

#define MAXSTRLEN 256


/***********************************************************
* Global Typedef declarations                              *
***********************************************************/


/************************************************************
* Global Function Declarations                              *
************************************************************/

// Simple send/recv functions
Uint32 UART_sendString(String seq, Bool includeNull);
Uint32 UART_sendHexInt(Uint32 value);
Uint32 UART_recvString(String seq);
Uint32 UART_recvStringN(String seq, Uint32* len, Bool stopAtNull);

Uint32 UART_checkSequence(String seq, Bool includeNull);
Uint32 UART_recvHexData(Uint32 numBytes, Uint32* data);



/***********************************************************
* End file                                                 *
***********************************************************/

#ifdef __cplusplus
extern far "c" }
#endif

#endif // End _UART_H_

