/* --------------------------------------------------------------------------
    FILE        : device_sdmmc.c 				                             	 	        
    PROJECT     : TI Booting and Flashing Utilities
    AUTHOR      : Gaurav Agarwal
    DESC        : This file descibes and implements various device-specific SD/MMC
                  functionality.
-------------------------------------------------------------------------- */ 

// General type include
#include "tistdtypes.h"

// Device specific CSL
#include "device.h"

// Device specific NAND details
#include "device_sdmmc.h"

// Generic NAND header file
#include "sdmmc.h"


/************************************************************
* Explicit External Declarations                            *
************************************************************/


/************************************************************
* Local Macro Declarations                                  *
************************************************************/


/************************************************************
* Local Function Declarations                               *
************************************************************/

/************************************************************
* Local Variable Definitions                                *
************************************************************/


/************************************************************
* Global Variable Definitions                               *
************************************************************/

