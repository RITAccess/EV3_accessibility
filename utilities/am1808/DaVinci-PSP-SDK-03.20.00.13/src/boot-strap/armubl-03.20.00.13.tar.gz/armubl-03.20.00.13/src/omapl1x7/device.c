/*
 * TI Booting and Flashing Utilities
 *
 * This file provides low-level init functions for use in the UBL for booting
 * an application.
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation version 2.
 *
 * This program is distributed "as is" WITHOUT ANY WARRANTY of any
 * kind, whether express or implied; without even the implied warranty
 * of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

/* --------------------------------------------------------------------------
  AUTHOR      : Daniel Allred
 --------------------------------------------------------------------------- */

// General type include
#include "tistdtypes.h"

// This module's header file
#include "device.h"

//I2C module's header file
#include "i2c.h"

// Debug module
#include "debug.h"

// Utility functions
#include "util.h"

// TPS 65023 functions
#include "tps65023.h"


/************************************************************
* Explicit External Declarations                            *
************************************************************/


/************************************************************
* Local Macro Declarations                                  *
************************************************************/


/************************************************************
* Local Typedef Declarations                                *
************************************************************/


/************************************************************
* Local Function Declarations                               *
************************************************************/

static inline Uint8 LOCAL_getOPP(void);

/************************************************************
* Local Variable Definitions                                *
\***********************************************************/


/************************************************************
* Global Variable Definitions                               *
************************************************************/
DEVICE_OperatingPoint gDeviceOpPoint;

/************************************************************
* Global Function Definitions                               *
************************************************************/
Uint32 DEVICE_init(DEVICE_BootMode bootMode)
{
  Uint32 status    = E_PASS;
  Uint8  deviceOPP = 0;

  // Unlock kick registers
  SYSTEM->KICKR[0] = 0x83e70b13;  /* Kick0 register + data (unlock) */
  SYSTEM->KICKR[1] = 0x95a4f1e0;  /* Kick1 register + data (unlock) */

#ifndef SKIP_LOW_LEVEL_INIT
  // System PSC Setup
  DEVICE_PSCInit();

  deviceOPP = LOCAL_getOPP();

  if(DEVICE_OPP_1P3V_456MHZ == deviceOPP) { /* HIGHER OPP */

    gDeviceOpPoint.megaHz = 456;
    gDeviceOpPoint.milliVolt = 1300;
    gDeviceOpPoint.opp = deviceOPP;

    // Set the higher voltage first OPP(456MHz, 1.3V)
    status  = TPS65023_set_DCDC1_voltage(0, TPS_VDCDC1_MILLIVOLT_1300);

    if(status != E_PASS)
    {
      return E_FAIL;
    }
    // System PLL0 Setup
    if (status == E_PASS) status |= DEVICE_PLL0Init(DEVICE_PLL0_MULTIPLIER_456MHz);

    // DDR2 Timing Setup
    if (status == E_PASS) status |= DEVICE_SDRAMInit(114);

  } else if(DEVICE_OPP_1P3V_408MHZ == deviceOPP) {

    gDeviceOpPoint.megaHz = 408;
    gDeviceOpPoint.milliVolt = 1300;
    gDeviceOpPoint.opp = deviceOPP;

    // Set the higher voltage first OPP(408MHz, 1.3V)
    status  = TPS65023_set_DCDC1_voltage(0, TPS_VDCDC1_MILLIVOLT_1300);

    if(status != E_PASS)
    {
      return E_FAIL;
    }
    // System PLL0 Setup
    if (status == E_PASS) status |= DEVICE_PLL0Init(DEVICE_PLL0_MULTIPLIER_408MHz);

    // DDR2 Timing Setup
    if (status == E_PASS) status |= DEVICE_SDRAMInit(102);

  } else if(DEVICE_OPP_1P2V_372MHZ == deviceOPP) {

    gDeviceOpPoint.megaHz = 372;
    gDeviceOpPoint.milliVolt = 1200;
    gDeviceOpPoint.opp = deviceOPP;

    // Set the higher voltage first OPP(375MHz, 1.2V)
    status  = TPS65023_set_DCDC1_voltage(0, TPS_VDCDC1_MILLIVOLT_1200);

    if(status != E_PASS)
    {
      return E_FAIL;
    }
    // System PLL0 Setup
    if (status == E_PASS) status |= DEVICE_PLL0Init(DEVICE_PLL0_MULTIPLIER_372MHz);

    // DDR2 Timing Setup
    if (status == E_PASS) status |= DEVICE_SDRAMInit(124);

  }  else if(DEVICE_OPP_1P2V_300MHZ == deviceOPP) {

    gDeviceOpPoint.megaHz = 300;
    gDeviceOpPoint.milliVolt = 1200;
    gDeviceOpPoint.opp = deviceOPP;

    // Set the higher voltage first OPP(300MHz, 1.2V)
    status  = TPS65023_set_DCDC1_voltage(0, TPS_VDCDC1_MILLIVOLT_1200);

    if(status != E_PASS)
    {
      return E_FAIL;
    }
    // System PLL0 Setup
    if (status == E_PASS) status |= DEVICE_PLL0Init(DEVICE_PLL0_MULTIPLIER);

    // DDR2 Timing Setup
    if (status == E_PASS) status |= DEVICE_SDRAMInit(133);

  } else {
    gDeviceOpPoint.megaHz = 0;
    gDeviceOpPoint.milliVolt = 0;
    gDeviceOpPoint.opp = 0;
    return E_FAIL;
  }

 #if defined(DEVICE_UART0_FOR_DEBUG)
  DEVICE_UARTInit(0);
 #elif defined(DEVICE_UART1_FOR_DEBUG)
  DEVICE_UARTInit(1);
 #elif defined(DEVICE_UART2_FOR_DEBUG)
  DEVICE_UARTInit(2);
 #endif
#endif

#ifdef UBL_SPI
    if(bootMode == DEVICE_BOOTMODE_SPI0_FLASH) {
        status |= DEVICE_SPI0Init();
    } else if(bootMode == DEVICE_BOOTMODE_SPI1_FLASH) {
        status |= DEVICE_SPI1Init();
    }
#endif

#ifdef UBL_NAND
  // AEMIF Setup
  if (status == E_PASS) status |= DEVICE_EMIFInit();
#endif

  return status;
}


void DEVICE_LPSCTransition(Uint8 pscnum, Uint8 module, Uint8 domain, Uint8 state)
{
  DEVICE_PSCRegs *PSC;

  if (pscnum == 0)
    PSC = PSC0;
  else if(pscnum == 1)
    PSC = PSC1;
  else
    return;

  // Wait for any outstanding transition to complete
  while ( (PSC->PTSTAT) & (0x00000001 << domain) );

  // If we are already in that state, just return
  if (((PSC->MDSTAT[module]) & 0x1F) == state) return;

  // Perform transition
  PSC->MDCTL[module] = ((PSC->MDCTL[module]) & (0xFFFFFFE0)) | (state);
  PSC->PTCMD |= (0x00000001 << domain);

  // Wait for transition to complete
  while ( (PSC->PTSTAT) & (0x00000001 << domain) );

  // Wait and verify the state
  while (((PSC->MDSTAT[module]) & 0x1F) != state);
}

void DEVICE_PSCInit()
{
  Uint32 i;

  // PSC0, domain 0 init
  while ((PSC0->PTSTAT) & 0x00000001);

  for( i = 3 ; i <= 4 ; i++ )
    if((PSC0->MDCTL[i] & 0x1F) != PSC_ENABLE)
      PSC0->MDCTL[i] = (PSC0->MDCTL[i] & 0xFFFFFFE0) | PSC_ENABLE;

  if((PSC0->MDCTL[7] & 0x1F) != PSC_ENABLE)
      PSC0->MDCTL[7] = (PSC0->MDCTL[7] & 0xFFFFFFE0) | PSC_ENABLE;

  for( i =  9; i <= 12 ; i++ )
    if((PSC0->MDCTL[i] & 0x1F) != PSC_ENABLE)
      PSC0->MDCTL[i] = (PSC0->MDCTL[i] & 0xFFFFFFE0) | PSC_ENABLE;

  // Do Always-On Power Domain Transitions
  PSC0->PTCMD |= 0x00000001;
  while ((PSC0->PTSTAT) & 0x00000001);

  // PSC1, domain 1 init
  while ((PSC1->PTSTAT) & 0x00000001);

  if((PSC1->MDCTL[3] & 0x1F) != PSC_ENABLE)
      PSC1->MDCTL[3] = (PSC1->MDCTL[3] & 0xFFFFFFE0) | PSC_ENABLE;

  if((PSC1->MDCTL[6] & 0x1F) != PSC_ENABLE)
      PSC1->MDCTL[6] = (PSC1->MDCTL[6] & 0xFFFFFFE0) | PSC_ENABLE;

  for( i = 12 ; i <= 13 ; i++ )
    if((PSC1->MDCTL[i] & 0x1F) != PSC_ENABLE)
      PSC1->MDCTL[i] = (PSC1->MDCTL[i] & 0xFFFFFFE0) | PSC_ENABLE;

  for( i = 22 ; i <= 23 ; i++ )
    if((PSC1->MDCTL[i] & 0x1F) != PSC_ENABLE)
      PSC1->MDCTL[i] = (PSC1->MDCTL[i] & 0xFFFFFFE0) | PSC_ENABLE;

  if((PSC1->MDCTL[26] & 0x1F) != PSC_ENABLE)
      PSC1->MDCTL[26] = (PSC1->MDCTL[26] & 0xFFFFFFE0) | PSC_ENABLE;

  if((PSC1->MDCTL[31] & 0x1F) != PSC_ENABLE)
      PSC1->MDCTL[31] = (PSC1->MDCTL[31] & 0xFFFFFFE0) | PSC_ENABLE;

  // Do Always-On Power Domain Transitions
  PSC1->PTCMD |= 0x00000001;
  while ((PSC1->PTSTAT) & 0x00000001);

  SYSTEM->SUSPSRC &= (~0x00010000);

}

void DEVICE_pinmuxControl(Uint32 regOffset, Uint32 mask, Uint32 value)
{
  SYSTEM->PINMUX[regOffset] &= ~mask;
  SYSTEM->PINMUX[regOffset] |= (mask & value);
}

static const DEVICE_BootMode bootModes[] = {
    DEVICE_BOOTMODE_I2C0_MASTER,
    DEVICE_BOOTMODE_I2C0_SLAVE,
    DEVICE_BOOTMODE_NOR_EMIFA, DEVICE_BOOTMODE_NOR_EMIFA,
    DEVICE_BOOTMODE_UHPI, DEVICE_BOOTMODE_UHPI,
    DEVICE_BOOTMODE_I2C1_MASTER,
    DEVICE_BOOTMODE_I2C1_SLAVE,
    DEVICE_BOOTMODE_SPI0_EEPROM,
    DEVICE_BOOTMODE_SPI1_EEPROM,
    DEVICE_BOOTMODE_SPI0_FLASH, DEVICE_BOOTMODE_SPI0_FLASH,
    DEVICE_BOOTMODE_SPI1_FLASH, DEVICE_BOOTMODE_SPI1_FLASH,
    DEVICE_BOOTMODE_NAND_EMIFA_8BIT, DEVICE_BOOTMODE_NAND_EMIFA_8BIT,
    DEVICE_BOOTMODE_NAND_EMIFA_16BIT,
    DEVICE_BOOTMODE_NONE,
    DEVICE_BOOTMODE_SPI0_SLAVE,
    DEVICE_BOOTMODE_SPI1_SLAVE,
    DEVICE_BOOTMODE_UART2,
    DEVICE_BOOTMODE_THB,
    DEVICE_BOOTMODE_UART0,
    DEVICE_BOOTMODE_UART1,
    DEVICE_BOOTMODE_ESF, DEVICE_BOOTMODE_ESF,
    DEVICE_BOOTMODE_USB11,
    DEVICE_BOOTMODE_USB20,
    DEVICE_BOOTMODE_MMC,
    DEVICE_BOOTMODE_RMII,
    DEVICE_BOOTMODE_EMU_DEBUG,
    DEVICE_BOOTMODE_NONE,
};


DEVICE_BootMode DEVICE_bootMode( void )
{
    Uint32 i;
    // Read BOOT pins and set bootMode
    // Using a look-up table
    i = SYSTEM->BOOTCFG & 0xFFFF;
    // Bit sequence used for LUT is 7,2,1,0,3
    // Translate: 76543210 to ___72103
    // (__210 << 1) + (7___3___ >> 3) = _210_ + 7___3 = 72103
    i = ((i & 0x0007) << 1) + ((i & 0x0088) >> 3);          // _210_ + 7___3

    return bootModes[i];
}

DEVICE_BusWidth DEVICE_emifBusWidth( void )
{
  if (DEVICE_bootMode() == DEVICE_BOOTMODE_NAND_EMIFA_8BIT)
  {
    return DEVICE_BUSWIDTH_8BIT;
  }
  else
  {
    return DEVICE_BUSWIDTH_16BIT;
  }
}

Uint32 DEVICE_EMIFInit()
{
  DEVICE_pinmuxControl(13,0xFFFFFFFF,0x11111111);
  DEVICE_pinmuxControl(14,0xFFFFFFFF,0x88111111);
  DEVICE_pinmuxControl(15,0xFFFFFFFF,0x11888888);
  DEVICE_pinmuxControl(16,0xFFFFFFFF,0x11111111);
  DEVICE_pinmuxControl(17,0xFFFFFFFF,0x08111111);
  DEVICE_pinmuxControl(18,0xFFFFFFFF,0x11111111);
  DEVICE_pinmuxControl(19,0xFFFFFFFF,0x00000001);

  return E_PASS;
}

void DEVICE_disable_DSP(void)
{
        /* assert DSP local reset */
    PSC0->MDCTL[15] &= ~0x100;

    /* Turn off DSP */
    DEVICE_LPSCTransition(0, 15, 1, PSC_SWRSTDISABLE);
}


Uint32 DEVICE_SPI0Init()
{
  DEVICE_pinmuxControl(7, 0xFFFFF000, 0x11111000);

  return E_PASS;
}

Uint32 DEVICE_SPI1Init()
{
    /* Enable SPI1 PSC and Pinmux */
    DEVICE_LPSCTransition(1, 10, 0, PSC_ENABLE);
#ifdef DEVICE_UART2_FOR_DEBUG
    DEVICE_pinmuxControl(8, 0xF0000FFF, 0x10000111);
    DEVICE_pinmuxControl(9, 0x0000000F, 0x00000001);
#else
    DEVICE_pinmuxControl(8, 0x00000FFF, 0x00000111);
#endif
    return E_PASS;
}

Uint32 DEVICE_I2CInit(Uint8 periphNum)
{
  // Assign the correct register base
  if (periphNum >= I2C_PERIPHERAL_CNT)
  {
    return E_FAIL;
  }

  switch (periphNum)
  {
    case 0:
      // No LPSC for I2C0
      DEVICE_pinmuxControl(8,0x000FF000,0x00022000); // I2C0_SCL, I2C0_SDA
      break;
    case 1:
      DEVICE_LPSCTransition(PSCNUM1, LPSC_I2C1, PD0, PSC_ENABLE);
      DEVICE_pinmuxControl(8,0x000000FF,0x00000022); // I2C1_SDA, I2C1_SCL
      break;
    default:
      return E_FAIL;
  }

  return E_PASS;
}


Uint32 DEVICE_UARTInit(Uint8 periphNum)
{
  Uint16 divisor = 0 ;
  // Assign the correct register base
  if (periphNum >= UART_PERIPHERAL_CNT)
  {
    return E_FAIL;
  }

  divisor = ((gDeviceOpPoint.megaHz * 1000000/2) / (DEVICE_UART0_DESIRED_BAUD*DEVICE_UART0_OVERSAMPLE_CNT));

  switch (periphNum)
  {
    case 0:
      DEVICE_LPSCTransition(PSCNUM0, LPSC_UART0, PD0, PSC_ENABLE);
      DEVICE_pinmuxControl(8,0x000FF000,0x00011000);
      UART0->PWREMU_MGNT |= 0x6000;
      UART0->LCR |= 0x3;
      UART0->DLL = (Uint8) divisor;
      UART0->DLH = (Uint8) (divisor >> 8);
      break;
    case 1:
      DEVICE_LPSCTransition(PSCNUM1, LPSC_UART1, PD0, PSC_ENABLE);
      DEVICE_pinmuxControl(11,0x0000FF00,0x00001100);
      UART1->PWREMU_MGNT |= 0x6000;
      UART1->LCR |= 0x3;
      UART1->DLL = (Uint8) divisor;
      UART1->DLH = (Uint8) (divisor >> 8);
      break;
    case 2:
      DEVICE_LPSCTransition(PSCNUM1, LPSC_UART2, PD0, PSC_ENABLE);
      DEVICE_pinmuxControl(8,0xF0000000,0x20000000);
      DEVICE_pinmuxControl(9,0x0000000F,0x00000002);
      UART2->PWREMU_MGNT |= 0x6000;
      UART2->LCR |= 0x3;
      UART2->DLL = (Uint8) divisor;
      UART2->DLH = (Uint8) (divisor >> 8);
      break;
    default:
      return E_FAIL;
  }

  return E_PASS;
}


Uint32 DEVICE_getPartNum(void)
{
        return ((JTAG_ID >> 12) & 0xffff);
}

Uint16 DEVICE_isDSPBoot(void)
{
        if ((DEVICE_getPartNum() == DA830_PART_NUM)
                && (CHIPREV_ID & (1 << 4)))
            return FALSE;

        return TRUE;
}

Uint32 DEVICE_TIMER0Init()
{
    return 1;
}

void DEVICE_TIMER0Start(void)
{
}

void DEVICE_TIMER0Stop(void)
{
}

Uint32 DEVICE_TIMER0Status(void)
{
    return 0;
}

Uint32 DEVICE_PLL0Init(Uint32 PLLMult)
{
    register unsigned int PLLM, POSTDIV, PLLDIV3, PLLDIV5, PLLDIV7, CLKMODE, PLL_LOCK_TIME_CNT;

    // Parse arguments
    PLLM = PLLMult;
    if (DEVICE_OPP_1P3V_456MHZ == gDeviceOpPoint.opp)
    {
        POSTDIV  =  0;
        PLLDIV3  =  4; // Divide by 5 for 91.2 MHz EMIFA
        PLLDIV5  =  3; // Divide by 4 for 114MHz SDRAM
        PLLDIV7  =  8; // Divide by 9 for 50MHz RMII
    } else if(DEVICE_OPP_1P3V_408MHZ == gDeviceOpPoint.opp) {
        POSTDIV  =  0;
        PLLDIV3  =  4; // Divide by 5 for 81.5 MHz EMIFA
        PLLDIV5  =  3; // Divide by 4 for 102MHz SDRAM
        PLLDIV7  =  7; // Divide by 8 for ~50MHz RMII
    } else if(DEVICE_OPP_1P2V_372MHZ == gDeviceOpPoint.opp) {
        POSTDIV  =  1;
        PLLDIV3  =  3; // Divide by 4 for 93.75 MHz EMIFA
        PLLDIV5  =  2; // Divide by 3 for 124MHz SDRAM
        PLLDIV7  =  7; // Divide by 8 for ~50MHz RMII
    } else if(DEVICE_OPP_1P2V_300MHZ == gDeviceOpPoint.opp) {
        POSTDIV = 1;
        PLLDIV3 = 2;
        PLLDIV5 = 5;
        PLLDIV7 = 5; // Divide by 6 for 50MHz RMII
    } else {
       /* This should never happen */
       return E_FAIL;
    }

    CLKMODE = 0;

    PLL_LOCK_TIME_CNT = 2400;

    // Execute

    // Reset PLL0 and put in bypass mode
    // Set PLLEN=0 and PLLRST=0
    PLL0->PLLCTL &= 0xFFFFFFFE;

    // wait for 4 cycles to allow PLLEN mux switches properly to bypass clock
    UTIL_waitLoop (4);

    // Select the Clock Mode bit 8 as External Clock or On Chip Oscilator
    PLL0->PLLCTL &= 0xFFFFFEFF;
    PLL0->PLLCTL |= (CLKMODE << 8);

    /* Set PLLENSRC '0',bit 5, PLL Enable(PLLEN) selection is controlled through MMR */
    PLL0->PLLCTL &= 0xFFFFFFDF;

    /* PLLCTL.EXTCLKSRC bit 9 should be left at 0 for Primus */
    PLL0->PLLCTL &= 0xFFFFFDFF;

    /* Clear PLLRST bit to 0 -Reset the PLL */
    PLL0->PLLCTL &= 0xFFFFFFF7;

    /* Disable the PLL output */
    PLL0->PLLCTL |= 0x10;

    /* PLL0 initialization sequence */

    /* Power up the PLL- PWRDN bit set to 0 to bring the PLL out of power down bit */
    PLL0->PLLCTL &= 0xFFFFFFFD;

    /* Enable the PLL from Disable Mode PLLDIS bit to 0 - This is step is not required for Primus */
    PLL0->PLLCTL &= 0xFFFFFFEF;

    /* Program the required multiplier value in PLLM */
    PLL0->PLLM = PLLM;

    /* If desired to scale all the SYSCLK frequencies of a given PLLC, program the POSTDIV ratio */
    PLL0->POSTDIV = 0x8000 | POSTDIV;

    /* Check for the GOSTAT bit in PLLSTAT to clear to 0 to indicate that no GO operation is currently in progress */
    while (PLL0->PLLSTAT & 0x1 == 1);

    /* Program the RATIO field in PLLDIVx with the desired divide factors. In addition, make sure in this step you leave the PLLDIVx.DxEN bits set so clocks are still enabled (default). */
    PLL0->PLLDIV3 = 0x8000 | PLLDIV3;
    PLL0->PLLDIV5 = 0x8000 | PLLDIV5;
    PLL0->PLLDIV7 = 0x8000 | PLLDIV7;

    /* Set the GOSET bit in PLLCMD to 1 to initiate a new divider transition. */
    PLL0->PLLCMD |= 0x1;

    /* Wait for the GOSTAT bit in PLLSTAT to clear to 0 (completion of phase alignment). */
    while (PLL0->PLLSTAT & 0x1 == 1);

    /* Set the PLLRST bit in PLLCTL to 1 to bring the PLL out of reset */
    PLL0->PLLCTL |= 0x8;

    /* Wait for PLL to lock. See PLL spec for PLL lock time */
    UTIL_waitLoop (PLL_LOCK_TIME_CNT);

    /* Set the PLLEN bit in PLLCTL to 1 to remove the PLL from bypass mode */
    PLL0->PLLCTL |= 0x1;
    if(DEVICE_OPP_1P2V_300MHZ != gDeviceOpPoint.opp) {
       SYSTEM->CFGCHIP[3] &= 0xFFFFFFF8; //clear EMIFA and EMIFB clock source settings, let them run off SYSCLK
    } else if(DEVICE_OPP_1P2V_300MHZ == gDeviceOpPoint.opp) {
       SYSTEM->CFGCHIP[3] |= 0x4;       // Enable 4.5 divider PLL0
       SYSTEM->CFGCHIP[3] |= 0x1;       // Select 4.5 divider for EMIFA / EMIFB clock source
    }

    return E_PASS;
}

Uint32 DEVICE_SDRAMInit(Uint32 freq)
{
    DEVICE_pinmuxControl(0, 0xFFFFFF00, 0x11111100);
    DEVICE_pinmuxControl(1, 0xFFFFFFFF, 0x11111111);
    DEVICE_pinmuxControl(2, 0xFFFFFFFF, 0x11111111);
    DEVICE_pinmuxControl(3, 0xFFFFFFFF, 0x11111111);
    DEVICE_pinmuxControl(4, 0xFFFFFFFF, 0x11111111);
    DEVICE_pinmuxControl(5, 0xFFFFFFFF, 0x11111111);
    DEVICE_pinmuxControl(6, 0xFFFFFFFF, 0x11111111);
    DEVICE_pinmuxControl(7, 0x00000FFF, 0x00000111);

   // ISSI IS42S16160B-6BL SDRAM, 2 x 16M x 16 (32-bit data path), <freq>MHz
    DDR->SDCR =  0         // SDRAM Bank Config Register
        |( 1 << 15)         // Unlock timing registers
        |( 2 << 9 )         // CAS latency is 2
        |( 2 << 4 )         // 4 bank SDRAM devices
        |( 1 << 0 );        // 512-word pages requiring 9 column address bits

    DDR->SDRCR = 0               // SDRAM Refresh Control Register
        |( 0 << 31)               // Low power mode disabled
        |( 0 << 30)               // MCLK stoping disabled
        |( 0 << 23)               // Selects self refresh instead of power down
        |( (unsigned int) ((7.8125 * freq)+1) <<0);  // Refresh rate = 7.8125us

    DDR->SDTIMR = 0        // SDRAM Timing Register 1
        |( (unsigned int) ((60.0 * freq / 1000)) << 25 )    // tRFC
        |( (unsigned int) ((18.0 * freq / 1000)) << 22 )    // tRP
        |( (unsigned int) ((18.0 * freq / 1000)) << 19 )    // tRCD
        |( (unsigned int) ((12.0 * freq / 1000)) << 16 )    // tWR / tDPL
        |( (unsigned int) ((42.0 * freq / 1000)) << 11 )    // tRAS
        |( (unsigned int) ((60.0 * freq / 1000)) <<  6 )    // tRC
        |( (unsigned int) ((12.0 * freq / 1000)) <<  3 );   // **Use special equation in documentation for 8 bank SDRAM

    DDR->SDTIMR2 = 0        // SDRAM Timing Register 2
        |( (unsigned int) ((120000 / 7812.5) - 1) << 27 )         // tRAS MAX / refresh rate
        |( (unsigned int) ((66.0 * freq / 1000)) << 16)     // tXSR
        |( (unsigned int) ((42.0 * freq / 1000)) << 0 );    // tCKE / tRAS

    DDR->SDCR = 0         // SDRAM Bank Config Register
        |( 1 << 16)
        |( 0 << 15)         // Unlock timing registers
        |( 2 << 9 )         // CAS latency is 2
        |( 2 << 4 )         // 4 bank SDRAM devices
        |( 1 << 0 );        // 512-word pages requiring 9 column address bits

    return E_PASS;
}



/************************************************************
* Local Function Definitions                                *
************************************************************/
static inline Uint8 LOCAL_getOPP(void)
{
#if (DEVICE_CONFIG_OPP == DEVICE_OPP_1P3V_456MHZ)
    /* If this is set then return the OPP define for (456MHz, 1.3V)*/
    return ((Uint8)DEVICE_OPP_1P3V_456MHZ);

#elif (DEVICE_CONFIG_OPP == DEVICE_OPP_1P2V_372MHZ)
    /* If this is set then return the OPP define for (375MHz, 1.2V)*/
    return ((Uint8)DEVICE_OPP_1P2V_372MHZ);

#elif (DEVICE_CONFIG_OPP == DEVICE_OPP_1P2V_300MHZ)
    /* If this is set then return the OPP define for (300MHz, 1.2V)*/
    return ((Uint8)DEVICE_OPP_1P2V_300MHZ);

#elif (DEVICE_CONFIG_OPP == DEVICE_OPP_1P3V_408MHZ)
    /* If this is set then return the OPP define for (400MHz, 1.2V)*/
    return ((Uint8)DEVICE_OPP_1P3V_408MHZ);
#else
 #error "Invalid Operating Point defined"
#endif
}

/***********************************************************
* End file                                                 *
***********************************************************/

/* --------------------------------------------------------------------------
    HISTORY
        v1.0 completion
            Daniel Allred  -  1-Nov-2007
 ----------------------------------------------------------------------------- */



