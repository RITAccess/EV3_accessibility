/*
 * TI Booting and Flashing Utilities
 *
 * This file provides low-level init functions for use in the UBL for booting
 * an application.
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation version 2.
 *
 * This program is distributed "as is" WITHOUT ANY WARRANTY of any
 * kind, whether express or implied; without even the implied warranty
 * of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

/* --------------------------------------------------------------------------
  AUTHOR      : Daniel Allred
 --------------------------------------------------------------------------- */

// General type include
#include "tistdtypes.h"

// This module's header file
#include "device.h"

// Debug module
#include "debug.h"

// Utility functions
#include "util.h"

// TPS65070 functions
#include "tps65070.h"

/************************************************************
* Explicit External Declarations                            *
************************************************************/


/************************************************************
* Local Macro Declarations                                  *
************************************************************/


/************************************************************
* Local Typedef Declarations                                *
************************************************************/


/************************************************************
* Local Function Declarations                               *
************************************************************/

static inline Uint8 LOCAL_getOPP(void);

/************************************************************
* Local Variable Definitions                                *
\***********************************************************/


/************************************************************
* Global Variable Definitions                               *
************************************************************/

DEVICE_OperatingPoint gDeviceOpPoint;

/************************************************************
* Global Function Definitions                               *
************************************************************/
Uint32 DEVICE_init(DEVICE_BootMode bootMode)
{
  Uint32 status = E_PASS;
  Uint8  deviceOPP = 0;

  // Unlock kick registers
  SYSTEM->KICKR[0] = 0x83e70b13;  /* Kick0 register + data (unlock) */
  SYSTEM->KICKR[1] = 0x95a4f1e0;  /* Kick1 register + data (unlock) */

  SYSTEM->SUSPSRC &= ( (1 << 27) | (1 << 22) | (1 << 20) | (1 << 5) | (1 << 16));


#ifndef SKIP_LOW_LEVEL_INIT
  // System PSC Setup
  DEVICE_PSCInit();

  deviceOPP = LOCAL_getOPP();

  if(DEVICE_OPP_1P3V_456MHZ == deviceOPP) { /* HIGHER OPP */

    gDeviceOpPoint.megaHz = 456;
    gDeviceOpPoint.milliVolt = 1300;
    gDeviceOpPoint.opp = deviceOPP;

    // Set the higher voltage first OPP(456MHz, 1.31V)
    status  = TPS65070_set_DCDC3_voltage(0, TPS_VDCDC3_MILLIVOLT_1300);

    if(status != E_PASS)
    {
      return E_FAIL;
    }
    // System PLL0 Setup
    if (status == E_PASS) status |= DEVICE_PLL0Init(DEVICE_PLL0_MULTIPLIER_456MHz);

  }else if(DEVICE_OPP_1P2V_372MHZ == deviceOPP) {
    gDeviceOpPoint.megaHz = 372;
    gDeviceOpPoint.milliVolt = 1200;
    gDeviceOpPoint.opp = deviceOPP;

    // Set the higher voltage first OPP(372MHz, 1.2V)
    status  = TPS65070_set_DCDC3_voltage(0, TPS_VDCDC3_MILLIVOLT_1200);

    if (status == E_PASS) status |= DEVICE_PLL0Init(DEVICE_PLL0_MULTIPLIER_372MHz);
        
  } else if(DEVICE_OPP_1P3V_408MHZ == deviceOPP) {

    gDeviceOpPoint.megaHz = 408;
    gDeviceOpPoint.milliVolt = 1300;
    gDeviceOpPoint.opp = deviceOPP;

    // Set the higher voltage first OPP(408MHz, 1.3V)
    status  = TPS65070_set_DCDC3_voltage(0, TPS_VDCDC3_MILLIVOLT_1300);

    if(status != E_PASS)
    {
      return E_FAIL;
    }
    // System PLL0 Setup
    if (status == E_PASS) status |= DEVICE_PLL0Init(DEVICE_PLL0_MULTIPLIER_408MHz);

  }else if(DEVICE_OPP_1P2V_300MHZ == deviceOPP){

    gDeviceOpPoint.megaHz = 300;
    gDeviceOpPoint.milliVolt = 1200;
    gDeviceOpPoint.opp = deviceOPP;

    // Set the higher voltage first OPP(300MHz, 1.2V)
    status  = TPS65070_set_DCDC3_voltage(0, TPS_VDCDC3_MILLIVOLT_1200);

    if (status == E_PASS) status |= DEVICE_PLL0Init(DEVICE_PLL0_MULTIPLIER);
  }

  // System PLL1 Setup
  if (status == E_PASS) status |= DEVICE_PLL1Init(DEVICE_PLL1_MULTIPLIER);

  // DDR2 Timing Setup
  if (status == E_PASS) status |= DEVICE_DDRInit();

 #if defined(DEVICE_UART0_FOR_DEBUG)
  DEVICE_UARTInit(0);
 #elif defined(DEVICE_UART1_FOR_DEBUG)
  DEVICE_UARTInit(1);
 #elif defined(DEVICE_UART2_FOR_DEBUG)
  DEVICE_UARTInit(2);
 #endif
#endif

#ifdef UBL_SPI
    if(bootMode == DEVICE_BOOTMODE_SPI0_FLASH) {
        status |= DEVICE_SPI0Init();
    } else if(bootMode == DEVICE_BOOTMODE_SPI1_FLASH) {
        status |= DEVICE_SPI1Init();
    }
#elif defined(UBL_NAND)
  if (status == E_PASS) status |= DEVICE_NANDInit();
#elif defined(UBL_NOR)
  if (status == E_PASS) status |= DEVICE_NORInit();
#elif defined(UBL_SD_MMC)
  if (status == E_PASS) status |= DEVICE_SDMMCInit();
#endif

#if defined(UBL_SD_MMC)
  status |= DEVICE_SDMMCInit();
#endif

  return status;
}


void DEVICE_LPSCTransition(Uint8 pscnum, Uint8 module, Uint8 domain, Uint8 state)
{
  DEVICE_PSCRegs *PSC;

  if (pscnum == 0)
    PSC = PSC0;
  else if(pscnum == 1)
    PSC = PSC1;
  else
    return;

  // Wait for any outstanding transition to complete
  while ( (PSC->PTSTAT) & (0x00000001 << domain) );

  // If we are already in that state, just return
  if (((PSC->MDSTAT[module]) & 0x1F) == state) return;

  // Perform transition
  PSC->MDCTL[module] = ((PSC->MDCTL[module]) & (0xFFFFFFE0)) | (state);
  PSC->PTCMD |= (0x00000001 << domain);

  // Wait for transition to complete
  while ( (PSC->PTSTAT) & (0x00000001 << domain) );

  // Wait and verify the state
  while (((PSC->MDSTAT[module]) & 0x1F) != state);
}

void DEVICE_PSCInit()
{
  Uint32 i;

  // PSC0, domain 0 init
  while ((PSC0->PTSTAT) & 0x00000001);

  for( i = 3 ; i <= 4 ; i++ )
    if((PSC0->MDCTL[i] & 0x1F) != PSC_ENABLE)
      PSC0->MDCTL[i] = (PSC0->MDCTL[i] & 0xFFFFFFE0) | PSC_ENABLE;

  if((PSC0->MDCTL[7] & 0x1F) != PSC_ENABLE)
      PSC0->MDCTL[7] = (PSC0->MDCTL[7] & 0xFFFFFFE0) | PSC_ENABLE;

  if((PSC0->MDCTL[8] & 0x1F) != PSC_ENABLE)
      PSC0->MDCTL[8] = (PSC0->MDCTL[8] & 0xFFFFFFE0) | PSC_ENABLE;

  for( i =  9; i <= 12 ; i++ )
    if((PSC0->MDCTL[i] & 0x1F) != PSC_ENABLE)
      PSC0->MDCTL[i] = (PSC0->MDCTL[i] & 0xFFFFFFE0) | PSC_ENABLE;

  // Do Always-On Power Domain Transitions
  PSC0->PTCMD |= 0x00000001;
  while ((PSC0->PTSTAT) & 0x00000001);

  // PSC1, domain 1 init
  while ((PSC1->PTSTAT) & 0x00000001);

  if((PSC1->MDCTL[3] & 0x1F) != PSC_ENABLE)
      PSC1->MDCTL[3] = (PSC1->MDCTL[3] & 0xFFFFFFE0) | PSC_ENABLE;

  if((PSC1->MDCTL[6] & 0x1F) != PSC_ENABLE)
      PSC1->MDCTL[6] = (PSC1->MDCTL[6] & 0xFFFFFFE0) | PSC_ENABLE;

  for( i = 12 ; i <= 13 ; i++ )
    if((PSC1->MDCTL[i] & 0x1F) != PSC_ENABLE)
      PSC1->MDCTL[i] = (PSC1->MDCTL[i] & 0xFFFFFFE0) | PSC_ENABLE;

  if((PSC1->MDCTL[26] & 0x1F) != PSC_ENABLE)
      PSC1->MDCTL[26] = (PSC1->MDCTL[26] & 0xFFFFFFE0) | PSC_ENABLE;

  if((PSC1->MDCTL[31] & 0x1F) != PSC_ENABLE)
      PSC1->MDCTL[31] = (PSC1->MDCTL[31] & 0xFFFFFFE0) | PSC_ENABLE;

  // Do Always-On Power Domain Transitions
  PSC1->PTCMD |= 0x00000001;
  while ((PSC1->PTSTAT) & 0x00000001);
}

void DEVICE_pinmuxControl(Uint32 regOffset, Uint32 mask, Uint32 value)
{
  SYSTEM->PINMUX[regOffset] &= ~mask;
  SYSTEM->PINMUX[regOffset] |= (mask & value);
}

static const DEVICE_BootMode bootModes[] = {
    DEVICE_BOOTMODE_I2C0_MASTER,
    DEVICE_BOOTMODE_I2C0_SLAVE,
    DEVICE_BOOTMODE_NOR_EMIFA, DEVICE_BOOTMODE_NOR_EMIFA,
    DEVICE_BOOTMODE_UHPI, DEVICE_BOOTMODE_UHPI,
    DEVICE_BOOTMODE_I2C1_MASTER,
    DEVICE_BOOTMODE_I2C1_SLAVE,
    DEVICE_BOOTMODE_SPI0_EEPROM,
    DEVICE_BOOTMODE_SPI1_EEPROM,
    DEVICE_BOOTMODE_SPI0_FLASH, DEVICE_BOOTMODE_SPI0_FLASH,
    DEVICE_BOOTMODE_SPI1_FLASH, DEVICE_BOOTMODE_SPI1_FLASH,
    DEVICE_BOOTMODE_NAND_EMIFA_8BIT, DEVICE_BOOTMODE_NAND_EMIFA_8BIT,
    DEVICE_BOOTMODE_NAND_EMIFA_16BIT,
    DEVICE_BOOTMODE_NONE,
    DEVICE_BOOTMODE_SPI0_SLAVE,
    DEVICE_BOOTMODE_SPI1_SLAVE,
    DEVICE_BOOTMODE_UART2,
    DEVICE_BOOTMODE_THB,
    DEVICE_BOOTMODE_UART0,
    DEVICE_BOOTMODE_UART1,
    DEVICE_BOOTMODE_ESF, DEVICE_BOOTMODE_ESF,
    DEVICE_BOOTMODE_USB11,
    DEVICE_BOOTMODE_USB20,
    DEVICE_BOOTMODE_MMC,
    DEVICE_BOOTMODE_SD_MMC,
    DEVICE_BOOTMODE_RMII,
    DEVICE_BOOTMODE_EMU_DEBUG,
    DEVICE_BOOTMODE_NONE,
};


DEVICE_BootMode DEVICE_bootMode( void )
{
    Uint32 i;

    // Read BOOT pins and set bootMode
    // Using a look-up table
    i = SYSTEM->BOOTCFG & 0x1F;

    return bootModes[i];
}

DEVICE_BusWidth DEVICE_emifBusWidth( void )
{
  if (DEVICE_bootMode() == DEVICE_BOOTMODE_NAND_EMIFA_8BIT)
  {
    return DEVICE_BUSWIDTH_8BIT;
  }
  else if (DEVICE_bootMode() == DEVICE_BOOTMODE_NOR_EMIFA)
  {
    return DEVICE_BUSWIDTH_16BIT;
  }
  else
  {
    return DEVICE_BUSWIDTH_16BIT;
  }
}

Uint32 DEVICE_NANDInit()
{
  DEVICE_pinmuxControl(7,0x00FF0FF0,0x00110110);
  DEVICE_pinmuxControl(9,0xFFFFFFFF,0x11111111);
  DEVICE_pinmuxControl(12,0x0FF00000,0x01100000);

  return E_PASS;

}

Uint32 DEVICE_NORInit()
{
  DEVICE_pinmuxControl(5,0xFF000000,0x11000000);
  DEVICE_pinmuxControl(6,0x0F00000F,0x01000001);
  DEVICE_pinmuxControl(7,0x00FF000F,0x00110001);
  DEVICE_pinmuxControl(8,0xFFFFFFFF,0x11111111);
  DEVICE_pinmuxControl(9,0xFFFFFFFF,0x11111111);
  DEVICE_pinmuxControl(10,0xFFFFFFFF,0x11111111);
  DEVICE_pinmuxControl(11,0xFFFFFFFF,0x11111111);
  DEVICE_pinmuxControl(12,0xFFFFFFFF,0x11111111);

  return E_PASS;
}

void DEVICE_disable_DSP(void)
{
        /* assert DSP local reset */
    PSC0->MDCTL[15] &= ~0x100;

    /* Turn off DSP */
    DEVICE_LPSCTransition(0, 15, 1, PSC_SWRSTDISABLE);
}


Uint32 DEVICE_SPI0Init()
{
#if defined(DEVICE_UART0_FOR_DEBUG)
  DEVICE_pinmuxControl(3, 0xFF00FFFF, 0x11001111);
  DEVICE_pinmuxControl(4, 0x000000FF, 0x00000011);
#else
  DEVICE_pinmuxControl(3, 0xFFFFFFFF, 0x11111111);
  DEVICE_pinmuxControl(4, 0x000000FF, 0x00000011);
#endif

  return E_PASS;
}

Uint32 DEVICE_SPI1Init()
{
    DEVICE_LPSCTransition(1, 10, 0, PSC_ENABLE);
#if defined(DEVICE_UART1_FOR_DEBUG)
    DEVICE_pinmuxControl(4, 0x00FFFF00, 0x00111100);
    DEVICE_pinmuxControl(5, 0x00FFFFFF, 0x00111111);
#elif defined(DEVICE_UART2_FOR_DEBUG)
    DEVICE_pinmuxControl(4, 0xFF00FF00, 0x11001100);
    DEVICE_pinmuxControl(5, 0x00FFFFFF, 0x00111111);
#else
    DEVICE_pinmuxControl(4, 0xFFFFFF00, 0x11111100);
    DEVICE_pinmuxControl(5, 0x00FFFFFF, 0x00111111);
#endif

    return E_PASS;
}

Uint32 DEVICE_I2CInit(Uint8 periphNum)
{
  // Assign the correct register base
  if (periphNum >= I2C_PERIPHERAL_CNT)
  {
    return E_FAIL;
  }

  switch (periphNum)
  {
    case 0:
      // No LPSC for I2C0
      DEVICE_pinmuxControl(4,0x0000FF00,0x00002200); // I2C0_SCL, I2C0_SDA
      break;
    case 1:
      DEVICE_LPSCTransition(PSCNUM1, LPSC_I2C1, PD0, PSC_ENABLE);
      DEVICE_pinmuxControl(4,0x00FF0000,0x00440000); // I2C1_SDA, I2C1_SCL
      break;
    default:
      return E_FAIL;
  }

  return E_PASS;
}

Uint32 DEVICE_SDMMCInit()
{
    DEVICE_LPSCTransition(0, 5, 0, PSC_ENABLE);
    DEVICE_pinmuxControl(10, 0xFFFFFFFF, 0x22222222);
	DEVICE_pinmuxControl(11, 0x000000FF, 0x00000022);
	return E_PASS;
}

Uint32 DEVICE_UARTInit(Uint8 periphNum)
{
  Uint16 divisor = 0 ;
  // Assign the correct register base
  if (periphNum >= UART_PERIPHERAL_CNT)
  {
    return E_FAIL;
  }

  divisor = ((gDeviceOpPoint.megaHz * 1000000/2) / (DEVICE_UART0_DESIRED_BAUD*DEVICE_UART0_OVERSAMPLE_CNT));

  switch (periphNum)
  {
    case 0:
      DEVICE_LPSCTransition(PSCNUM0, LPSC_UART0, PD0, PSC_ENABLE);
      DEVICE_pinmuxControl(3,0x00FF0000,0x00220000);
      UART0->PWREMU_MGNT |= 0x6000;
      UART0->LCR |= 0x3;
      UART0->DLL = (Uint8) divisor;
      UART0->DLH = (Uint8) (divisor >> 8);
      break;
    case 1:
      DEVICE_LPSCTransition(PSCNUM1, LPSC_UART1, PD0, PSC_ENABLE);
      DEVICE_pinmuxControl(4,0xFF000000,0x22000000);
      UART1->PWREMU_MGNT |= 0x6000;
      UART1->LCR |= 0x3;
      UART1->DLL = (Uint8) divisor;
      UART1->DLH = (Uint8) (divisor >> 8);
      break;
    case 2:
      DEVICE_LPSCTransition(PSCNUM1, LPSC_UART2, PD0, PSC_ENABLE);
      DEVICE_pinmuxControl(4,0x00FF0000,0x00220000);
      UART2->PWREMU_MGNT |= 0x6000;
      UART2->LCR |= 0x3;
      UART2->DLL = (Uint8) divisor;
      UART2->DLH = (Uint8) (divisor >> 8);
      break;
    default:
      return E_FAIL;
  }

  return E_PASS;
}


Uint32 DEVICE_getPartNum(void)
{
        return ((JTAG_ID >> 12) & 0xffff);
}

Uint16 DEVICE_isDSPBoot(void)
{
        if ((DEVICE_getPartNum() == DA850_PART_NUM)
                && (CHIPREV_ID & (1 << 4)))
            return FALSE;

        return TRUE;
}



Uint32 DEVICE_TIMER0Init()
{
    return 1;
}

void DEVICE_TIMER0Start(void)
{
}

void DEVICE_TIMER0Stop(void)
{
}

Uint32 DEVICE_TIMER0Status(void)
{
    return 0;
}

Uint32 DEVICE_PLL0Init(Uint32 PLLMult)
{
    register unsigned int PLLM, POSTDIV, PLLDIV1, PLLDIV2, PLLDIV3;
    register unsigned int PLLDIV7, CLKMODE, PLL_LOCK_TIME_CNT;

    // Parse arguments
    PLLM = PLLMult;
    if (DEVICE_OPP_1P3V_456MHZ == gDeviceOpPoint.opp){
        POSTDIV = 0;
        PLLDIV1 = 0;
        PLLDIV2 = 1;
        PLLDIV3 = 4; // Divide by 5 EMIFA Max is 100MHz
        PLLDIV7 = 5;
    }else if (DEVICE_OPP_1P2V_372MHZ == gDeviceOpPoint.opp) {
        POSTDIV = 1;
        PLLDIV1 = 0;
        PLLDIV2 = 1;
        PLLDIV3 = 3; // Divide by 4 EMIFA Max is 100MHz
        PLLDIV7 = 5;
    }else if (DEVICE_OPP_1P3V_408MHZ == gDeviceOpPoint.opp) {
        POSTDIV = 0;
        PLLDIV1 = 0;
        PLLDIV2 = 1;
        PLLDIV3 = 4; // Divide by 5. EMIFA Max is 100MHz
        PLLDIV7 = 5;
    }else if(DEVICE_OPP_1P2V_300MHZ == gDeviceOpPoint.opp) {
        POSTDIV = 1;
        PLLDIV1 = 0;
        PLLDIV2 = 1;
        PLLDIV3 = 2;
        PLLDIV7 = 5;
    } else {
       /* This should never happen */
       return E_FAIL;
    }

    CLKMODE = 0;
    PLL_LOCK_TIME_CNT = 2400;

    // Execute

    //Unlock PLL registers.
    SYSTEM->CFGCHIP[0] &= ~(0x00000010);
    /* Set PLLENSRC '0',bit 5, PLL Enable(PLLEN) selection is controlled through MMR */
    PLL0->PLLCTL &= ~(0x00000020);

    /* PLLCTL.EXTCLKSRC bit 9 should be left at 0 for Freon */
    PLL0->PLLCTL &= ~(0x00000200);

    /* Set PLLEN=0 to put in bypass mode*/
    PLL0->PLLCTL &= ~(0x00000001);

    // wait for 4 cycles to allow PLLEN mux switches properly to bypass clock
    UTIL_waitLoop (4);

    // Select the Clock Mode bit 8 as External Clock or On Chip Oscilator
    PLL0->PLLCTL &= 0xFFFFFEFF;
    PLL0->PLLCTL |= (CLKMODE << 8);

    /*Clear PLLRST bit to reset the PLL */
    PLL0->PLLCTL &= ~(0x00000008);

    /* Disable the PLL output*/
    PLL0->PLLCTL |= (0x00000010);

    /* PLL0 initialization sequence */

    /* Power up the PLL- PWRDN bit set to 0 to bring the PLL out of power down bit */
    PLL0->PLLCTL &= ~(0x00000002);

    /* Enable the PLL from Disable Mode PLLDIS bit to 0 - This is step is not required for Primus */
    PLL0->PLLCTL &= ~(0x00000010);

    /* Program the required multiplier value in PLLM */
    PLL0->PLLM = PLLM;

    /* If desired to scale all the SYSCLK frequencies of a given PLLC, program the POSTDIV ratio */
    PLL0->POSTDIV = 0x8000 | POSTDIV;

    /* Check for the GOSTAT bit in PLLSTAT to clear to 0 to indicate that no GO operation is currently in progress */
    while (PLL0->PLLSTAT & 0x1 == 1);

    /* Program the RATIO field in PLLDIVx with the desired divide factors. In addition, make sure in this step you leave the PLLDIVx.DxEN bits set so clocks are still enabled (default). */
    PLL0->PLLDIV1 = 0x8000 | PLLDIV1;
    PLL0->PLLDIV2 = 0x8000 | PLLDIV2;
    PLL0->PLLDIV4 = 0x8000 | (((PLLDIV1 + 1) * 4) - 1);
    PLL0->PLLDIV6 = 0x8000 | PLLDIV1;
    PLL0->PLLDIV3 = 0x8000 | PLLDIV3;
    PLL0->PLLDIV7 = 0x8000 | PLLDIV7;

    /* Set the GOSET bit in PLLCMD to 1 to initiate a new divider transition. */
    PLL0->PLLCMD |= 0x1;

    /* Wait for the GOSTAT bit in PLLSTAT to clear to 0 (completion of phase alignment). */
    while (PLL0->PLLSTAT & 0x1 == 1);

    /* Set the PLLRST bit in PLLCTL to 1 to bring the PLL out of reset */
    PLL0->PLLCTL |= 0x8;

    /* Wait for PLL to lock. See PLL spec for PLL lock time */
    UTIL_waitLoop (PLL_LOCK_TIME_CNT);

    /* Set the PLLEN bit in PLLCTL to 1 to remove the PLL from bypass mode */
    PLL0->PLLCTL |= 0x1;

    SYSTEM->CFGCHIP[3] &= 0xFFFFFFF8; //clear EMIFA and EMIFB clock source settings, let them run off SYSCLK

    return E_PASS;
}

Uint32 DEVICE_PLL1Init(Uint32 PLLMult)
{
    register unsigned int PLLM, POSTDIV, PLLDIV1, PLLDIV2, PLLDIV3;
    register unsigned int PLL_LOCK_TIME_CNT, PLL_RESET_TIME_CNT;

    // Parse arguments
    PLLM = PLLMult;
    POSTDIV = 1;
    PLLDIV1 = 0;
    PLLDIV2 = 1;
    PLLDIV3 = 2;

    PLL_LOCK_TIME_CNT = 2400;
    PLL_RESET_TIME_CNT = 200;

    // Execute

    /* Set PLLENSRC '0',bit 5, PLL Enable(PLLEN) selection is controlled through MMR */
    PLL1->PLLCTL &= ~(0x00000020);

    /* PLLCTL.EXTCLKSRC bit 9 should be left at 0 for Freon */
    PLL1->PLLCTL &= ~(0x00000200);

    /* Set PLLEN=0 to put in bypass mode*/
    PLL1->PLLCTL &= ~(0x00000001);

    // wait for 4 cycles to allow PLLEN mux switches properly to bypass clock
    UTIL_waitLoop (4);

    /*Clear PLLRST bit to reset the PLL */
    PLL1->PLLCTL &= ~(0x00000008);

    /* Disable the PLL output*/
    PLL1->PLLCTL |= (0x00000010);

    /* PLL1 initialization sequence */

    /* Power up the PLL- PWRDN bit set to 0 to bring the PLL out of power down bit */
    PLL1->PLLCTL &= ~(0x00000002);

    /* Enable the PLL from Disable Mode PLLDIS bit to 0 - This is step is not required for Primus */
    PLL1->PLLCTL &= ~(0x00000010);

    /* Program the required multiplier value in PLLM */
    PLL1->PLLM = PLLM;

    /* If desired to scale all the SYSCLK frequencies of a given PLLC, program the POSTDIV ratio */
    PLL1->POSTDIV = 0x8000 | POSTDIV;

    /* Check for the GOSTAT bit in PLLSTAT to clear to 0 to indicate that no GO operation is currently in progress */
    while (PLL1->PLLSTAT & 0x1 == 1);

    /* Program the RATIO field in PLLDIVx with the desired divide factors. In addition, make sure in this step you leave the PLLDIVx.DxEN bits set so clocks are still enabled (default). */
    PLL1->PLLDIV1 = 0x8000 | PLLDIV1;
    PLL1->PLLDIV2 = 0x8000 | PLLDIV2;
    PLL1->PLLDIV3 = 0x8000 | PLLDIV3;

    /* Set the GOSET bit in PLLCMD to 1 to initiate a new divider transition. */
    PLL1->PLLCMD |= 0x1;

    /* Wait for the GOSTAT bit in PLLSTAT to clear to 0 (completion of phase alignment). */
    while (PLL1->PLLSTAT & 0x1 == 1);

    /*Wait for PLL to reset properly. See PLL spec for PLL reset time - */
    UTIL_waitLoop (PLL_RESET_TIME_CNT);

    /* Set the PLLRST bit in PLLCTL to 1 to bring the PLL out of reset */
    PLL1->PLLCTL |= 0x8;

    /* Wait for PLL to lock. See PLL spec for PLL lock time */
    UTIL_waitLoop (PLL_LOCK_TIME_CNT);

    /* Set the PLLEN bit in PLLCTL to 1 to remove the PLL from bypass mode */
    PLL1->PLLCTL |= 0x1;

    return E_PASS;
}

#define DDR_SLEW        *(volatile unsigned int*) (0x01E2C004)
#define DDR_SLEW_CMOSEN_BIT 4

/**********************************************************************************
  mDDR Configuration routine:
    1. mDDR Enable
    2. VTP calibration
    3. Configure DDR
    4. Set to self-refresh, enable mclkstop and DDR Sync Reset
    5. Enable DDR and disable self-refresh

  int freq is MHz

***********************************************************************************/

static void DEVICE_mDDRConfig(unsigned int freq)
{
	unsigned int tmp_SDCR;

	DDR_SLEW |= (1 << DDR_SLEW_CMOSEN_BIT);

	/*Enable the Clock to EMIF3A SDRAM*/
	DEVICE_LPSCTransition(1, 6, 0, PSC_ENABLE);

	/*If VTP claiberation enabled , then skip the VTP calibration*/
	if((*VTPIO_CTL & 0x00000040))
	{
		// Begin VTP Calibration
		*VTPIO_CTL &= ~0x00000040;       // Clear POWERDN
		*VTPIO_CTL &= ~0x00000080;       // Clear LOCK
		*VTPIO_CTL |=  0x00002000;       // Set CLKRZ in case it was cleared before (VTP looks for CLKRZ edge transition)
		*VTPIO_CTL &= ~0x00002000;       // Clear CLKRZ (Use read-modify-write to ensure 1 VTP cycle wait for previous instruction)
		*VTPIO_CTL |=  0x00002000;       // Set CLKRZ (Use read-modify-write to ensure 1 VTP cycle wait for previous instruction)

		// Polling READY bit to see when VTP calibration is done
		while(!((*VTPIO_CTL & 0x00008000)>>15)) {}

		*VTPIO_CTL |= 0x00000080;       // Set LOCK bit for static calibration mode
		*VTPIO_CTL |= 0x00000040;       // Set POWERDN bit to power down VTP module
		// End VTP Calibration

		*VTPIO_CTL |= 0x00004000;       // Set IOPWRDN to allow powerdown of input receivers when PWRDNEN is set
	}

	// **********************************************************************************************
	// Setting based on 512Mb mDDR MT46H32M16LFBF-6 on EVM
	// Config DDR timings
	DDR->DDRPHYCR = (0x0               << 8)   |  // Reserved
			(0x1               << 7)   |  // EXT_STRBEN
			(0x1               << 6)   |  // PWRDNEN
			(0x0               << 3)   |  // Reserved
			(0x4               << 0);     // RL

	DDR->SDCR |= 0x00800000; // Set BOOTUNLOCK

	tmp_SDCR = (0x1               << 25)  |  // MSDRAMEN
		   (0x0               << 20);    // DDR2EN

	DDR->SDCR = tmp_SDCR		     |
		  (DDR->SDCR & 0xF0000000)   |  // Reserved
		  (0x0               << 27)  |  // DDR2TERM1
		  (0x0               << 26)  |  // IBANK_POS
		  (0x0               << 25)  |  // MSDRAMEN
		  (0x0               << 24)  |  // DDRDRIVE1
		  (0x0               << 23)  |  // BOOTUNLOCK
		  (0x0               << 22)  |  // DDR2DDQS
		  (0x0               << 21)  |  // DDR2TERM0
		  (0x0               << 20)  |  // DDR2EN
		  (0x0               << 19)  |  // DDRDLL_DIS
		  (0x0               << 18)  |  // DDRDRIVE0
		  (0x1               << 17)  |  // DDREN
		  (0x1               << 16)  |  // SDRAMEN
		  (0x1               << 15)  |  // TIMUNLOCK
		  (0x1               << 14)  |  // NM
		  (0x0               << 12)  |  // Reserved
		  (0x3               << 9)   |  // CL
		  (0x0               << 7)   |  // Reserved
		  (0x2               << 4)   |  // IBANK
		  (0x0               << 3)   |  // Reserved
		  (0x2               << 0);     // PAGESIZE

	DDR->SDCR2 = 0x00000000;

	// Subtracting 0.5 instead of 1 so that the int is rounded up after truncating a real value
	DDR->SDTIMR =   (((unsigned int) (110.0 * freq / 1000)) << 25) |  // tRFC
			(((unsigned int) (18.0 * freq / 1000)) << 22)  |  // tRP
			(((unsigned int) (18.0 * freq / 1000)) << 19)  |  // tRCD
			(((unsigned int) (15.0 * freq / 1000)) << 16)  |  // tWR
			(((unsigned int) (42.0 * freq / 1000)) << 11)  |  // tRAS
			(((unsigned int) (60.0 * freq / 1000)) << 6)   |  // tRC
			(((unsigned int) (12.0 * freq / 1000)) << 3)   |  // tRRD
			(DDR->SDTIMR & 0x4)                            |  // Reserved
			((2 - 1)                              << 0);      // tWTR

	// Subtracting 0.5 instead of 1 so that the int is rounded up after truncating a real value
	// tRASMAX is rounded down so subtracting 1
	// CAS/CL = 3
	DDR->SDTIMR2 = (DDR->SDTIMR2 & 0x80000000)                              |  // Reserved
			(((unsigned int) ((70000 / 7812.5) - 1))        << 27)  |  // tRASMAX [(70us/7.8125us)-1]
			(0x3                                            << 25)  |  // tXP
			(0x0                                            << 23)  |  // tODT (Not supported)
			(((unsigned int) ((138.0 * freq / 1000) - 0.5)) << 16)  |  // tXSNR
			(((unsigned int) ((138.0 * freq / 1000) - 0.5)) << 8)   |  // tXSRD
			((2 - 1)                                        << 5)   |  // tRTP (1 Cycle)
			((1 - 1)                                        << 0);     // tCKE

	DDR->SDCR    &= ~0x00008000; // Clear TIMUNLOCK

	DDR->SDRCR   =  (0x1                                  << 31)  |  // LPMODEN
			(0x1                                  << 30)  |  // MCLKSTOPEN
			(0x0                                  << 24)  |  // Reserved
			(0x0                                  << 23)  |  // SR_PD
			(0x0                                  << 16)  |  // Reserved
			(((unsigned int) (7.8125 * freq))     << 0);     // RR

	/*SyncReset the Clock to EMIF3A SDRAM*/
	DEVICE_LPSCTransition(1, 6, 0, PSC_SYNCRESET);

	/*Enable the Clock to EMIF3A SDRAM*/
	DEVICE_LPSCTransition(1, 6, 0, PSC_ENABLE);

	DDR->SDRCR &= ~0xC0000000;  // disable self-refresh

	DDR->PBBPR = 0x30;
}

Uint32 DEVICE_DDRInit()
{
    DEVICE_mDDRConfig(132);

    return E_PASS;
}


/************************************************************
* Local Function Definitions                                *
************************************************************/
static inline Uint8 LOCAL_getOPP(void)
{
#if (DEVICE_CONFIG_OPP == DEVICE_OPP_1P3V_456MHZ)
    /* If this is set then return the OPP define for (456MHz, 1.3V)*/
    return ((Uint8)DEVICE_OPP_1P3V_456MHZ);

#elif (DEVICE_CONFIG_OPP == DEVICE_OPP_1P2V_372MHZ)
    /* If this is set then return the OPP define for (375MHz, 1.2V)*/
    return ((Uint8)DEVICE_OPP_1P2V_372MHZ);

#elif (DEVICE_CONFIG_OPP == DEVICE_OPP_1P2V_300MHZ) 
    /* If this is set then return the OPP define for (300MHz, 1.2V)*/
    return ((Uint8)DEVICE_OPP_1P2V_300MHZ);

#elif (DEVICE_CONFIG_OPP == DEVICE_OPP_1P3V_408MHZ)
    /* If this is set then return the OPP define for (408MHz, 1.3V)*/
    return ((Uint8)DEVICE_OPP_1P3V_408MHZ);
#else
 #error "Invalid Operating Point defined"
#endif
}
/***********************************************************
* End file                                                 *
***********************************************************/

/* ----- */

